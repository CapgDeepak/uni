export const environment = {
  production: true,
  version: null, // The actual version will be retrieved by NavMenuComponent
};
