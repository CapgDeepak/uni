import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';

import { HomeComponent } from './home.component';
import { AuthorizationService } from '../authorization/authorization.service';
import { Permission } from '../tools/shared-types/permissions/permission';
import { Observable } from 'rxjs';
import { HttpService } from '../tools/services/http.service';
import { ToasterService } from 'angular2-toaster';
import { AlertDialogService } from '../shared-components/alert-dialog/alert-dialog.service';
import { FilterService } from '../tools/services/filter.service';
import { ConfirmationDialogService } from '../shared-components/confirmation-dialog/confirmation-dialog.service';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ConfirmationService } from 'primeng/api';

class MockHttpService {
  get(url: string) {
    return new Observable(observer => {
      observer.next([]);
      observer.complete();
    });
  }
}

class AlertDialogServiceMock {
  alert() { }
}

class ConfirmationDialogServiceMock { }

class ToasterServiceMock { }

class FilterServiceMock {
  isKeyCodeFilterable() { return true; }
}

let userHasPermissionToViewPhraseLibrary: boolean;
let userHasPermissionToViewPhraseMatrix: boolean;
let userHasPermissionToViewGramWorkList: boolean;
let userHasPermissionToViewMarketWorkList: boolean;
const userHasPermission: boolean = false;
class AuthorizationServiceMock {
  userHasPermissionToViewPhraseLibrary() {
    return userHasPermissionToViewPhraseLibrary;
  }
  userHasPermissionToViewPhraseMatrix() {
    return userHasPermissionToViewPhraseMatrix;
  }
  userHasPermissionToViewGramWorkList() {
    return userHasPermissionToViewGramWorkList;
  }
  userHasPermissionToViewMarketWorkList() {
    return userHasPermissionToViewMarketWorkList;
  }
  checkUserHasAnyPermission(permissionsToCheck: Permission[]) {
    if (permissionsToCheck.some(p => p == Permission.AraPReFDCT_Phrases_Order)) {
      return userHasPermission;
    }
  }
}

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [
        HomeComponent
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        ConfirmationService,
        { provide: HttpService, useClass: MockHttpService },
        { provide: ToasterService, useClass: ToasterServiceMock },
        { provide: AlertDialogService, useClass: AlertDialogServiceMock },
        { provide: FilterService, useClass: FilterServiceMock },
        { provide: ConfirmationDialogService, useClass: ConfirmationDialogServiceMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  describe('when user has permission to view the phrase library', () => {
    beforeEach(() => {
      userHasPermissionToViewPhraseLibrary = true;
      component.ngOnInit();
      fixture.detectChanges();
    });

    it('the phrase library element should be visible', () => {
      // Assert
      const element = fixture.debugElement.query(By.css('#phrase-library-element'));
      expect(element).toBeTruthy();
    });
  });

  describe('when user has permission to view the phrase matrix', () => {
    beforeEach(() => {
      userHasPermissionToViewPhraseMatrix = true;
      component.ngOnInit();
      fixture.detectChanges();
    });

    it('the phrase matrix element should be visible', () => {
      // Assert
      const element = fixture.debugElement.query(By.css('#phrase-matrix-element'));
      expect(element).toBeTruthy();
    });
  });

  describe('when user has permission to view the GRAM work list', () => {
    beforeEach(() => {
      userHasPermissionToViewGramWorkList = true;
      component.ngOnInit();
      fixture.detectChanges();
    });

    it('the gram work list element should be visible', () => {
      // Assert
      const element = fixture.debugElement.query(By.css('#gram-work-list-element'));
      expect(element).toBeTruthy();
    });
  });

  describe('when user has permission to view the market work list', () => {
    beforeEach(() => {
      userHasPermissionToViewMarketWorkList = true;
      component.ngOnInit();
      fixture.detectChanges();
    });

    it('the gram work list element should be visible', () => {
      // Assert
      const element = fixture.debugElement.query(By.css('#market-work-list-element'));
      expect(element).toBeTruthy();
    });

    it('the gram review work list element should be visible', () => {
      const element = fixture.debugElement.query(By.css('#market-work-list-element-review'));
      expect(element).toBeTruthy();
    });
  });

  describe('when user does not have permission to view the phrase library', () => {
    beforeEach(() => {
      userHasPermissionToViewPhraseLibrary = false;
      component.ngOnInit();
      fixture.detectChanges();
    });

    it('the phrase library element should be hidden', () => {
      // Assert
      component.testCase = false;
      const element = fixture.debugElement.query(By.css('#phrase-library-element'));
      expect(element).toBeFalsy();
    });
  });

  describe('when user does not have permission to view the phrase matrix', () => {
    beforeEach(() => {
      userHasPermissionToViewPhraseMatrix = false;
      component.ngOnInit();
      fixture.detectChanges();
    });

    it('the phrase matrix element should be hidden', () => {
      // Assert
      const element = fixture.debugElement.query(By.css('#phrase-matrix-element'));
      expect(element).toBeFalsy();
    });
  });

  describe('when user does not have permission to view the GRAM work list', () => {
    beforeEach(() => {
      userHasPermissionToViewGramWorkList = false;
      component.ngOnInit();
      fixture.detectChanges();
    });

    it('the gram work list element should be hidden', () => {
      // Assert
      const element = fixture.debugElement.query(By.css('#gram-work-list-element'));
      expect(element).toBeFalsy();
    });
  });

  describe('when user does not have permission to view the market work list', () => {
    beforeEach(() => {
      userHasPermissionToViewMarketWorkList = false;
      component.ngOnInit();
      fixture.detectChanges();
    });

    it('the gram work list element should be hidden', () => {
      // Assert
      component.testCase = false;
      const element = fixture.debugElement.query(By.css('#market-work-list-element'));
      expect(element).toBeFalsy();
    });

    it('the gram review work list element should be hidden', () => {
      const element = fixture.debugElement.query(By.css('#market-work-list-element-review'));
      expect(element).toBeFalsy();
    });
  });
});