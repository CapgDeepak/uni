import { Component, OnInit, AfterViewInit } from '@angular/core';

import { AuthorizationService } from '../authorization/authorization.service';
import { MarketWorkListType } from '../tools/constants';
import { Permission } from '../tools/shared-types/permissions/permission';
import { HttpService } from '../tools/services/http.service';

@Component({
    selector: 'home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, AfterViewInit {

    public showPhraseLibraryMenuItem: boolean = false;
    public showPhraseMatrixMenuItem: boolean = false;
    public showGramWorkListMenuItem: boolean = false;
    public showMarketWorkListMenuItem: boolean = false;

    public assessMarketWorklistRoute: string = '/work-list/markets/' + MarketWorkListType.Assess;
    public createMarketWorklistRoute: string = '/work-list/markets/' + MarketWorkListType.Create;
    public reviewMarketWorklistRoute: string = '/work-list/markets/' + MarketWorkListType.Review;

    public userHasPermissions: boolean = false;
    gramWorkListCount: any = 0;
    marketCreateWorkListCount: any = 0;
    marketReviewWorkListCount: any = 0;
    marketAssessWorkListCount: any = 0;
    public testCase: boolean = true;

    constructor(
        private authorizationService: AuthorizationService,
        private httpService: HttpService) {
    }

    ngOnInit(): void {
        this.setMenuItems();
        if (!this.authorizationService.userHasPermissionToViewGramWorkList() && !this.authorizationService.userHasPermissionToViewMarketWorkList()
            && !this.authorizationService.userHasPermissionToViewPhraseLibrary() && !this.authorizationService.checkUserHasAnyPermission([Permission.AraPReFDCT_Phrases_Order])) {
            this.userHasPermissions = true;
        }
    }

    ngAfterViewInit() {
        if (this.testCase == true) {
        setTimeout(() => {
        }, 550);
        }
       }

    setMenuItems() {
        this.showPhraseLibraryMenuItem = this.authorizationService.userHasPermissionToViewPhraseLibrary();
        this.showPhraseMatrixMenuItem = this.authorizationService.userHasPermissionToViewPhraseMatrix();
        this.showGramWorkListMenuItem = this.authorizationService.userHasPermissionToViewGramWorkList();
        this.showMarketWorkListMenuItem = this.authorizationService.userHasPermissionToViewMarketWorkList();
        if (this.showGramWorkListMenuItem) {
            const getCountOfGramworklistUrl = 'WorkList/WorkList/GetCountofGramworklist';
            this.httpService.get(getCountOfGramworklistUrl)
                .subscribe(gramCount => {
                    this.gramWorkListCount = gramCount;
                    console.log(gramCount + 'worklist');
                });
        }
        if (this.showMarketWorkListMenuItem) {
            this.getCount();
        }
    }
    // baseUrl = 'http://localhost:54854';
    getCount() {
        const getCountofMarketCreateworklistUrl = 'WorkList/WorkList/GetCountofMarketCreateworklist';
        this.httpService.get(getCountofMarketCreateworklistUrl)
            .subscribe(marketCreateCount => {
                this.marketCreateWorkListCount = marketCreateCount;
            });
        const getCountofMarketReviewworklistUrl = 'WorkList/WorkList/GetCountofMarketReviewworklist';
        this.httpService.get(getCountofMarketReviewworklistUrl)
            .subscribe(marketReviewCount => {
                this.marketReviewWorkListCount = marketReviewCount;
            });
        const getCountofMarketAssessworklistUrl = 'WorkList/WorkList/GetCountofMarketAssessworklist';
        this.httpService.get(getCountofMarketAssessworklistUrl)
            .subscribe(marketAssessCount => {
                this.marketAssessWorkListCount = marketAssessCount;
            });
    }
}