import { ListPhrase, PhraseList, Phrase } from "./phrase-library/phrase-library.types";
import { EmptyPhraseAssignment, PhraseAssignment } from './shared-components/phrase-assignments/phrase-assignments.types';
import { PhraseStatusId } from './tools/constants';
import { TopicTreeNode } from "./phrase-matrix/topic-tree/topic-tree.types";
import { CellPhrase } from "./phrase-matrix/phrase-matrix.types";

export function getTestListPhrase(): ListPhrase {
  return {
    id: 1,
    phraseId: 1,
    nr: 1,
    text: "Phrase 1",
    status: 1,
    statusText: "Status text 1",
    phraseTypeText: "Phrase type 1",
    isActive: true,
    isAccepted: false,
    topicDescription: "Topic 1",
    topicPath: "Topic path 1",
    topicId: 1,
    unitOfMeasure: "UOM1",
    assignmentId: 101,
    regulatoryMarket: "GB",
    regulatoryProductClass: "BPC",
    regulatoryProductClassPath: "BPC_Foods",
    detailLevel: "Detailed",
    linkedGenericPhraseNr: null,
    createdAt: new Date(Date.UTC(96, 1, 2, 3, 4, 5)),
    createdBy: "name",
    lastModifiedAt: new Date(Date.UTC(96, 1, 2, 3, 4, 5)),
    lastModifiedBy: "name1",
    unileverProductDivisionText: "UPD1",
    unileverProductDivisionId: 50,
    linkedPhraseNr: "2",
    mrpc: ['mrpc1']
  };
}

export function getTestPhraseList(): PhraseList {
  return {
    totalCount: 100,
    selectedCount: 20,
    pageCount: 5,
    phrases: [getTestListPhrase()],
    unileverProductDevisions: []
  };
}

function getDummyAssignments(): Array<PhraseAssignment> {
  const dummyAssignments = new Array<PhraseAssignment>();
  dummyAssignments.push(new EmptyPhraseAssignment());
  dummyAssignments.push(new EmptyPhraseAssignment());
  return dummyAssignments;
}

export function getTestPhraseData(): Phrase {
  return {
    id: 1,
    nr: 11,
    text: "test phrase",
    newText: null,
    status: PhraseStatusId.Rejected,
    statusText: "status 2",
    unileverProductDivisionId: 3,
    unileverProductDivisionPath: ["global", "eu", "albania"],
    topicId: 3,
    topicText: "something topical",
    topicPath: ["big", "medium", "small"],
    phraseType: 4,
    phraseTypeText: "phrase type 4",
    unitOfMeasure: "whales per cubic inch",
    phraseTextChanged: false,
    isActive: true,
    changeType: "Minor",
    rejectedPhraseRemarks: '',
    detailLevelId: 2,
    linkedGenericPhraseNr: null,
    createdAt: new Date(Date.UTC(96, 1, 2, 3, 4, 5)),
    createdBy: "mr creator",
    lastModifiedAt: new Date(Date.UTC(96, 1, 2, 3, 4, 5)),
    lastModifiedBy: "ms modifier",
    assignments: getDummyAssignments(),
    assignmentIdsToDelete: new Array<number>(),
    confirmed: true,
    linkedGenericPhraseId: 1,
    linkedSpecificPhraseIds: null,
    linkedSpecificPhraseNrs: [],
    universalEditAllowed: false,
    phraseCanBeRestored: false,
  };
}

export function getTestTopic(): TopicTreeNode {
  return {
    id: 1,
    description: "Claim",
    isDeclined: false,
    expanded: true,
    visible: true,
    parent: new TopicTreeNode(),
    childs: null,
    hasChilds: false,
    isValidForRpcAndMarket: false,
  };
}

export function getTestMatrixCellPhrases(): CellPhrase[] {
  const cellPhrases = new Array<CellPhrase>();
  cellPhrases.push( {
    rpcId: 29,
    assignmentId: 12,
    unileverProductDivisionId: 9,
    unileverProductDivisionPath: 'BPC',
    assignmentStatus: "ToBeAssessed",
    detailLevelDescription: "Standard",
    detailLevelId: 2,
    isActive: true,
    isHidden: false,
    phraseId: 134,
    phraseNr: 1243,
    phraseStatus: "Approved",
    phraseText: "Some text 1",
    phraseType: "Statement",
    linkedPhraseNr: 9
  });
  cellPhrases.push( {
    rpcId: 29,
    assignmentId: 13,
    unileverProductDivisionId: 9,
    unileverProductDivisionPath: 'BPC',
    assignmentStatus: "ToBeAssessed",
    detailLevelDescription: "Internal RA",
    detailLevelId: 3,
    isActive: true,
    isHidden: false,
    phraseId: 135,
    phraseNr: 1245,
    phraseStatus: "Rejected",
    phraseText: "Some text 2",
    phraseType: "Statement",
    linkedPhraseNr: 9
  });
  cellPhrases.push( {
    rpcId: 29,
    assignmentId: 14,
    unileverProductDivisionId: 9,
    unileverProductDivisionPath: 'BPC',
    assignmentStatus: "ToBeAssessed",
    detailLevelDescription: "Standard",
    detailLevelId: 2,
    isActive: true,
    isHidden: false,
    phraseId: 136,
    phraseNr: 1246,
    phraseStatus: "ToBeApproved",
    phraseText: "Some text 3",
    phraseType: "Statement",
    linkedPhraseNr: 9
  });
  cellPhrases.push( {
    rpcId: 29,
    assignmentId: 15,
    unileverProductDivisionId: 9,
    unileverProductDivisionPath: 'BPC',
    assignmentStatus: "Not relevant",
    detailLevelDescription: "Standard",
    detailLevelId: 2,
    isActive: true,
    isHidden: false,
    phraseId: 137,
    phraseNr: 1247,
    phraseStatus: "Approved",
    phraseText: "Some text 4",
    phraseType: "Statement",
    linkedPhraseNr: 9
  });
  cellPhrases.push( {
    rpcId: 29,
    assignmentId: 16,
    unileverProductDivisionId: 9,
    unileverProductDivisionPath: 'BPC',
    assignmentStatus: "Accepted",
    detailLevelDescription: "Detailed",
    detailLevelId: 1,
    isActive: true,
    isHidden: true,
    phraseId: 138,
    phraseNr: 1248,
    phraseStatus: "Approved",
    phraseText: "Some text 5",
    phraseType: "Statement",
    linkedPhraseNr: 9
  });
  cellPhrases.push( {
    rpcId: 29,
    assignmentId: 17,
    unileverProductDivisionId: 9,
    unileverProductDivisionPath: 'BPC',
    assignmentStatus: "ToBeAssessed",
    detailLevelDescription: "Internal RA",
    detailLevelId: 3,
    isActive: true,
    isHidden: true,
    phraseId: 139,
    phraseNr: 1249,
    phraseStatus: "ToBeApproved",
    phraseText: "Some text 6",
    phraseType: "Statement",
    linkedPhraseNr: 9
  });
  return cellPhrases;
}

export function createPhraseAssignment(topicId: number, marketId: number, rpcId: number): PhraseAssignment {
    const a =  new EmptyPhraseAssignment();
    a.topicId = topicId;
    a.regulatoryMarketId = marketId;
    a.regulatoryProductClassId = rpcId;
    return a;
}

