import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RejectPhraseComponent } from './reject-phrase.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';
import { HttpService } from '../../tools/services/http.service';
import { FormsModule, NgForm } from '@angular/forms';
import { MaxLengthDirective } from '../../tools/directives/maxlength.directive';

class NgbActiveModalMock { }
class AlertDialogServiceMock { }
class HttpServiceMock { }

describe('RejectPhraseComponent', () => {
  let component: RejectPhraseComponent;
  let fixture: ComponentFixture<RejectPhraseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
      ],
      declarations: [
        RejectPhraseComponent,
        MaxLengthDirective,
      ],
      providers: [
        { provide: NgbActiveModal, useClass: NgbActiveModalMock },
        { provide: AlertDialogService, useClass: AlertDialogServiceMock },
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: NgForm, useValue: new NgForm([], []) },
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RejectPhraseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when loading', () => {
    component.isLoading = true;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });
});
