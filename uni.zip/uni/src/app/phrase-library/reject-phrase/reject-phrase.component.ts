import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';
import { HttpService } from '../../tools/services/http.service';
import { UrlEndpoint } from '../../tools/constants';

@Component({
    selector: 'app-reject-phrase',
    templateUrl: './reject-phrase.component.html',
    styleUrls: ['./reject-phrase.component.scss']
})
export class RejectPhraseComponent implements OnInit {
    constructor(
        public activeModal: NgbActiveModal,
        public alertDialogService: AlertDialogService,
        private httpService: HttpService) {
    }
    public isLoading: boolean = false;

    ngOnInit() {
    }

    rejectPhrase() {
        const postData = {
            id: this._phraseId,
            rejectionRemarks: this.rejectionRemarks
        };
        this.isLoading = true;

        this.httpService.postContent(JSON.stringify(postData), UrlEndpoint.PhraseLibrary_RejectPhrase).subscribe(result => {
            this.isLoading = false;
            if (result.success) {
                this.activeModal.close(result);
            }
            else {
                this.alertDialogService.alert('Error', result.message);
            }
        }, error => {
            console.error("Reject phrase failed:", error);
            this.isLoading = false;
        });
    }

    _phraseId: number = -1;
    get phraseId(): number {
        return this._phraseId;
    }
    set phraseId(value: number) {
        if (this._phraseId != value) {
            this._phraseId = value;
        }
    }

    rejectionRemarks: string;
}