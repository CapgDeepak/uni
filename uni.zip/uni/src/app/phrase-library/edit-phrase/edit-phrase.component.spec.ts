import { CUSTOM_ELEMENTS_SCHEMA, Pipe, PipeTransform } from '@angular/core';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Observable, of, throwError } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ToasterService } from 'angular2-toaster';
import { when } from 'jest-when';
import { By } from '@angular/platform-browser';
import { DatePipe } from '@angular/common';

import { ToolsModule } from '../../tools/tools.module';
import { getTestPhraseData } from '../../testData';
import { EmptyPhraseAssignment } from '../../shared-components/phrase-assignments/phrase-assignments.types';
import { PhraseStatusId, PhraseChangeType, MISSING_CHANGE_TYPE_ERROR, MISSING_CHANGE_ERROR, DetailLevels, PhraseStatus } from '../../tools/constants';
import { MISSING_ASSIGNMENTS_ERROR, MISSING_TEXT_ERROR } from '../add-phrase/add-phrase.component';
import { EditPhraseComponent } from './edit-phrase.component';
import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';
import { ConfirmationDialogService } from '../../shared-components/confirmation-dialog/confirmation-dialog.service';
import { EditPhraseService } from './edit-phrase.service';
import { QuillSettingsService } from '../../tools/services/quill-settings.service';
import { ConfigService } from '../../tools/services/config.service';
import { Phrase } from '../phrase-library.types';
import { AuthorizationService } from '../../authorization/authorization.service';
import { HttpService } from '../../tools/services/http.service';
import { Item } from '../../tools/common.types';
import { Permission } from '../../tools/shared-types/permissions/permission';
import { AuthorizationModule } from '../../authorization/authorization.module';
import { SharedComponentsModule } from '../../shared-components/shared-components.module';
import { DetailLevel } from '../../tools/common.types';
import { CacheService } from '../../tools/services/cache.service';
import { PhraseSimpleModel } from '../../tools/shared-types/phrase.types';
import { PhraseService } from '../../tools/services/phrase.service';

class QuillSettingsServiceMock { }
class NgbActiveModalMock {
  close() {}
}
class AlertDialogServiceMock { }
class ConfirmationDialogServiceMock {
  question(title: string, message: string, dialogSize: 'sm' | 'lg' = 'lg'): Promise<boolean> {
    return new Promise<boolean>((resolve) => {
      resolve(true);
    });  }
}
const validDetailLevels: DetailLevel[] = [
  {
    id: 1,
    description: "Standard"
  },
  {
    id: 2,
    description: "Detailed"
  },
  {
    id: 4,
    description: "Internal RA"
  },
];
let detailLevels = validDetailLevels;
class CacheServiceMock {
  getDetailLevels(): Promise<DetailLevel[]> {
    return new Promise<DetailLevel[]>((resolve, reject) => {
      resolve(detailLevels);
    });
  }
}
const testEditPhrase = getTestPhraseData();
class EditPhraseServiceMock {
  loadPhraseData(): Promise<Phrase> {
    return new Promise<Phrase>((resolve) => {
            resolve(testEditPhrase);
    });
  }
}
class ToasterServiceMock { }
class MockAdalService {
  getCachedToken() { return 'token'; }
  acquireToken(clientId: string) {
    return new Observable( observer => {
      observer.next(`token: ${clientId}`);
      observer.complete();
    });
  }
}
class MockAppConfigService {
  getmsalConfigTenant() {
    return 'TenantId';
  }
  getMsalClientId() {
    return 'ClientId';
  }
  getAraDctUrl() {
    return 'http://dct.com';
  }
}
class AuthorizationServiceMock {
  checkUserHasAnyPermission = jest.fn();
  checkUserHasAnyPermissionForMarketAndProductDivision = jest.fn();
}
let isDetailedPhrase: boolean = false;
const phrasesToLinkAgainst: PhraseSimpleModel[] = [
  {
    phraseId: 50,
    nr: 100,
  },
  {
    phraseId: 51,
    nr: 101,
  },
  {
    phraseId: 52,
    nr: 102,
  }
];
class PhraseServiceMock {
  getPhrasesToLinkAgainst(): Observable<PhraseSimpleModel[]> {
    return of(phrasesToLinkAgainst);
  }
  isDetailedPhrase(): boolean {
    return isDetailedPhrase;
  }
}

const mockItems: Item[] = [
  { id: 1, parentId: null, description: "Item1",  requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  { id: 2, parentId: null, description: "Item2",  requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  { id: 3, parentId: 1,    description: "Item1a", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  { id: 4, parentId: 1,    description: "Item1b", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  { id: 5, parentId: 2,    description: "Item2a", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  { id: 6, parentId: 2,    description: "Item2b", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  { id: 7, parentId: null, description: "Item3", requiresSubselection: true, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  { id: 8, parentId: 7,    description: "Item3a", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
];

let httpServiceReturnsError = false;
class HttpServiceMock {
  getFiltered() {
    // if (httpServiceReturnsError) {
    //   return throwError('Expected error from HttpServiceMock');
    // } else {
      return new Observable(observer => {
        observer.next(mockItems);
        observer.complete();
      });
    // }
  }
  get() {
    return new Observable(observer => {
      observer.next(mockItems);
      observer.complete();
    });
  }
}

const changeActiveStatePermissions: Permission[]  = [
  Permission.AraPReFDCT_Phrases_ChangeActiveState,
];
const editPhrasePermissions: Permission[] = [
  Permission.AraPReFDCT_Phrases_WriteWithAssignments,
  Permission.AraPReFDCT_Phrases_WriteWithoutAssignments,
];
const addPhraseWithAssignmentPermissions: Permission[] = [
  Permission.AraPReFDCT_Phrases_WriteWithAssignments,
];
const addPhraseWithoutAssignmentPermissions: Permission[] = [
  Permission.AraPReFDCT_Phrases_WriteWithoutAssignments,
];
const editPhraseAssignmentsPermissions: Permission[] = [
    Permission.AraPReFDCT_PhraseAssignments_Write,
];

@Pipe({name: 'araDateTime'})
class MockDateTimePipe implements PipeTransform {
    transform(value: number): any {
      const pipe = new DatePipe('en-US');
      return pipe.transform(value, 'dd-MMM-yyyy, HH:mm', '+0000');
    }
}

describe('EditPhraseComponent', () => {
  let injector: TestBed;
  let component: EditPhraseComponent;
  let fixture: ComponentFixture<EditPhraseComponent>;
  let authorizationService: AuthorizationService;
  let testPhrase: Phrase;
  let phraseService: PhraseService;
  let editPhraseService: EditPhraseService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        AuthorizationModule,
        FormsModule,
        ToolsModule,
        SharedComponentsModule,
        HttpClientTestingModule,
        NgbModule,
      ],
      declarations: [
        EditPhraseComponent,
        MockDateTimePipe,
      ],
      providers: [
        { provide: QuillSettingsService, useClass: QuillSettingsServiceMock },
        { provide: NgbActiveModal, useClass: NgbActiveModalMock },
        { provide: AlertDialogService, useClass: AlertDialogServiceMock },
        { provide: ConfirmationDialogService, useClass: ConfirmationDialogServiceMock },
        { provide: EditPhraseService, useClass: EditPhraseServiceMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
        { provide: ConfigService, useClass: MockAppConfigService },
        { provide: ToasterService, useClass: ToasterServiceMock },
        { provide: CacheService, useClass: CacheServiceMock },
        { provide: PhraseService, useClass: PhraseServiceMock },
        { provide: HttpService, useClass: HttpServiceMock }
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
      .compileComponents();
  }));

  const buildComponent = () => {
    fixture = TestBed.createComponent(EditPhraseComponent);
    component = fixture.componentInstance;
    component._copyParameters = {
      phraseId: 2,
      includeText: true,
      includeAssignments: false
    };

    component.isLoading = false;
    fixture.detectChanges();
  };

  beforeEach(() => {
    injector = getTestBed();
    authorizationService = injector.get(AuthorizationService);
    phraseService = injector.get(PhraseService);
    editPhraseService = injector.get(EditPhraseService);
    testPhrase = getTestPhraseData();
    testPhrase.changeType = PhraseChangeType.Minor;
    detailLevels = validDetailLevels;
    buildComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('should match snapshot', () => {
    it('initially', () => {
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('for inactive phrase', () => {
      component.phrase.isActive = false;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('when loading', () => {
      component.isLoading = true;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('when phrase is copied', () => {
      component.isCopyPhrase = true;
      component.testCase = false;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('when inactive phrase is copied', () => {
      testPhrase.isActive = false;
      component.isCopyPhrase = true;
      component.phrase = testPhrase;
      component.testCase = false;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('when inactive phrase is copied and tree fails to load', () => {
      httpServiceReturnsError = true;
      testPhrase.isActive = false;
      component.isCopyPhrase = true;
      component.phrase = testPhrase;
      component.testCase = false;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('when change type required', () => {
      testPhrase.changeType = PhraseChangeType.None;
      component.phrase = testPhrase;
      component.phrase.status = PhraseStatusId.Approved;
      component.originalText = 'fred';
      component.isTopicsLoaded = false;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('when phrase text is set', () => {
      component.phrase.text = "New phrase";
      component.originalText = "New phrase 2";
      component.isTopicsLoaded = false;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('when copying and phrase is loaded', () => {
      component.isCopyPhrase = true;
      component.phrase = testPhrase;
      component.isTopicsLoaded = false;
      component.testCase = false;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('when copying and phrase is loaded and tree fails to load', () => {
      httpServiceReturnsError = true;
      component.isCopyPhrase = true;
      component.phrase = testPhrase;
      component.isTopicsLoaded = false;
      component.testCase = false;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });
  });

  describe('isPhraseModified', () => {
    it('should return true when original text changed', () => {
      component.phrase = testPhrase;
      component.originalText = 'fred';
      component.isTopicsLoaded = false;
      fixture.detectChanges();
      expect(component.isPhraseModified).toBeTruthy();
    });

    it('should return true when phrase type changed', () => {
      component.phraseId = 2;
      component.phrase.phraseType = 3;
      component.isTopicsLoaded = false;
      fixture.detectChanges();
      expect(component.isPhraseModified).toBeTruthy();
    });

    it('should return true when unitOfMeasure changed', () => {
      component.phraseId = 2;
      component.phrase.unitOfMeasure = "bat wings";
      component.isTopicsLoaded = false;
      fixture.detectChanges();
      expect(component.isPhraseModified).toBeTruthy();
    });

    it('should return false on initial load', () => {
      component.phraseId = 2;
      component.isTopicsLoaded = false;
      fixture.detectChanges();
      expect(component.isPhraseModified).toBeFalsy();
    });

    it('should clear out change type when false', () => {
      component.phrase.changeType = PhraseChangeType.Significant;
      component.phraseId = 2;
      component.isTopicsLoaded = false;
      fixture.detectChanges();
      expect(component.isPhraseModified).toBeFalsy();
      expect(component.phrase.changeType).toBe(PhraseChangeType.None);
    });
  });

  describe('isTextModified', () => {
      it('should return false on initial load', () => {
        component.phraseId = 2;
        component.isTopicsLoaded = false;
        fixture.detectChanges();
        expect(component.isTextModified).toBeFalsy();
      });

      it('should return true when original text changed', () => {
        component.phrase = testPhrase;
        component.originalText = 'fred';
        component.isTopicsLoaded = false;
        fixture.detectChanges();
        expect(component.isTextModified).toBeTruthy();
      });
    });

  describe('setPhrase', () => {
    it('should call getPhrasesToLinkAgainst when phrase set', () => {
      // Assemble
      jest.spyOn(phraseService, 'getPhrasesToLinkAgainst');

      // Act
      component.phrase = getTestPhraseData();

      // Assert
      expect(phraseService.getPhrasesToLinkAgainst).toHaveBeenCalledWith(component.detailLevels[0].id, component.phrase.topicId);
    });

    it('should not call getPhrasesToLinkAgainst when phrase is set but there is no standard detail level', () => {
      // Assemble
      jest.spyOn(phraseService, 'getPhrasesToLinkAgainst');
      detailLevels = [
        {
          id: 1,
          description: "No standard here"
        },
        {
          id: 2,
          description: "Detailed"
        },
        {
          id: 4,
          description: "Internal RA"
        },
      ];
      buildComponent();

      // Act
      component.phrase = getTestPhraseData();

      // Assert
      expect(phraseService.getPhrasesToLinkAgainst).not.toHaveBeenCalled();
    });

    it('should set assignmentsChanged to true if assignments are changed', () => {
      component._phrase = getTestPhraseData();
      component.originalAssignments = component._phrase.assignments;
      const phrase = getTestPhraseData();
      phrase.assignments = [];
      component.phrase = phrase;
      expect(component.assignmentsChanged).toBeTruthy();
    });

    it('should set assignmentsChanged to true if assignments are added', () => {
      component._phrase = getTestPhraseData();
      component.originalAssignments = component._phrase.assignments;
      const updatedPhrase = getTestPhraseData();
      updatedPhrase.assignments.push(new EmptyPhraseAssignment());
      component.phrase = updatedPhrase;
      expect(component.assignmentsChanged).toBeTruthy();
    });

    it('should set assignmentsChanged to false if phrases are unchanged', () => {
      component._phrase = getTestPhraseData();
      component.originalAssignments = component._phrase.assignments;
      component.phrase = getTestPhraseData();
      expect(component.assignmentsChanged).toBeFalsy();
    });

    it('should set assignmentsChanged to true if assignments are removed', () => {
      component._phrase = getTestPhraseData();
      component.originalAssignments = component._phrase.assignments;
      const updatedPhrase = getTestPhraseData();
      updatedPhrase.assignments.pop();
      component.phrase = updatedPhrase;
      expect(component.assignmentsChanged).toBeTruthy();
    });

    it('should set assignmentsChanged to true if assignments are changed', () => {
      component._phrase = getTestPhraseData();
      component.originalAssignments = component._phrase.assignments;
      const updatedPhrase = getTestPhraseData();
      updatedPhrase.assignments[1].regulatoryMarketText = 'blah';
      component.phrase = updatedPhrase;
      expect(component.assignmentsChanged).toBeTruthy();
    });

    it('should set assignmentsChanged to false if phrase uninitialised', () => {
      const phrase = testPhrase;
      phrase.id = -1;
      component.phrase = phrase;
      expect(component.assignmentsChanged).toBeFalsy();
    });

    it('should make phrase active when copying an inactive phrase', () => {
      const phrase = testPhrase;
      phrase.isActive = false;
      component.isCopyPhrase = true;
      component.phrase = phrase;
      component.isTopicsLoaded = false;
      component.testCase = false;
      fixture.detectChanges();
      expect(phrase.isActive).toBeTruthy();
    });
  });

  describe('editFullscreen', () => {
    beforeEach(() => {
      component.phrase.statusText = PhraseStatus.ToBeApproved;
      component.isCopyPhrase = false;
      component.originalPhrase.newText = 'blah';
    });
    it('should return true when phrase is approved', () => {
      component.phrase.statusText = PhraseStatus.Approved;
      expect(component.editFullscreen).toBeTruthy();
    });
    it('should return true when phrase is copied', () => {
      component.isCopyPhrase = true;
      expect(component.editFullscreen).toBeTruthy();
    });
    it('should return true when phrase is rejected without changes', () => {
      component.phrase.statusText = PhraseStatus.Rejected;
      component.originalPhrase.newText = null;
      expect(component.editFullscreen).toBeTruthy();
    });
    it('should return false when phrase is not approved, or a copy, or a rejected with changes', () => {
      component.phrase.statusText = PhraseStatus.Rejected;
      expect(component.editFullscreen).toBeFalsy();
    });
  });

  describe('needsChangeType', () => {
    it('should return false on non approved phrase without lastModifiedUser', () => {
      component.phrase = testPhrase;
      component.isTopicsLoaded = false;
      fixture.detectChanges();
      expect(component.needsChangeType).toBeFalsy();
      component.phrase.status = PhraseStatusId.ToBeApproved;
      fixture.detectChanges();
      expect(component.needsChangeType).toBeFalsy();
    });

    it('should return true for approved phrase with non-copied changes', () => {
      component.phrase = testPhrase;
      component.phrase.status = PhraseStatusId.Approved;
      component.originalText = "blah";
      component.isCopyPhrase = false;
      component.isTopicsLoaded = false;
      fixture.detectChanges();
      expect(component.needsChangeType).toBeTruthy();
    });

    it('should return true for non-approved phrase with lastModifiedUser and non-copied changes', () => {
      component.phrase = testPhrase;
      component.phrase.status = PhraseStatusId.ToBeApproved;
      component.originalText = "blah";
      component.isCopyPhrase = false;
      component.phrase.universalEditAllowed = true;
      expect(component.needsChangeType).toBeTruthy();
    });

    it('should return false for approved phrase with copied changes', () => {
      component.phrase = testPhrase;
      component.phrase.status = PhraseStatusId.Approved;
      component.originalText = "blah";
      component.isCopyPhrase = true;
      component.isTopicsLoaded = false;
      component.testCase = false;
      fixture.detectChanges();
      expect(component.needsChangeType).toBeFalsy();
    });

    it('should return false for approved phrase with no changes', () => {
      setupComponentWithUnchangedPhrase(component, testPhrase);
      component.phrase.status = PhraseStatusId.Approved;
      component.isTopicsLoaded = false;
      fixture.detectChanges();
      expect(component.needsChangeType).toBeFalsy();
    });

    it('should return false for new phrase', () => {
      component.originalPhrase.text = null;
      fixture.detectChanges();
      expect(component.needsChangeType).toBeFalsy();
    });
  });

  describe('when user has permission to edit phrases', () => {
    beforeEach(() => {
      when(authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision).calledWith(editPhrasePermissions, null, testPhrase.unileverProductDivisionId)
                                                                                     .mockReturnValue(true);
      buildComponent();
      component.phrase = testPhrase;
      fixture.detectChanges();
    });

    describe('when save is attempted', () => {
      beforeEach(() => {
        component.isCopyPhrase = false;
        fixture.detectChanges();
      });

      describe('saveButtonTooltipText', () => {
        it('should return empty when all data available', () => {
          component.originalText = 'fred';
          component.phrase.changeType = PhraseChangeType.Minor;
          expect(component.saveButtonTooltipText).toBe('');
        });

        it('should return message when phrase text missing', () => {
          component.phrase.text = '';
          fixture.detectChanges();
          expect(component.saveButtonTooltipText).toBe(MISSING_TEXT_ERROR);
        });

        it('should return message when data changes and no change type specified', () => {
          component.originalText = 'fred';
          component.phrase.changeType = PhraseChangeType.None;
          component.phrase.status = PhraseStatusId.Approved;
          fixture.detectChanges();
          expect(component.saveButtonTooltipText).toBe(MISSING_CHANGE_TYPE_ERROR);
        });

        it('should return message when no data changes', () => {
          component.originalPhrase = testPhrase;
          fixture.detectChanges();
          expect(component.saveButtonTooltipText).toBe(MISSING_CHANGE_ERROR);
        });
      });

      describe('windowTitle', () => {
        it('should display correct title when copying', () => {
          component.isCopyPhrase = true;
          component.testCase = false;
          fixture.detectChanges();
          expect(component.windowTitle).toBe('Copy');
        });

        it('should display correct title when editing', () => {
          component.phrase.isActive = true;
          component.isCopyPhrase = false;
          fixture.detectChanges();
          expect(component.windowTitle).toBe('Edit');
        });

        it('should display correct title when editing inactive phrase without permission to change active status', () => {
          component.phrase.isActive = false;
          fixture.detectChanges();
          expect(component.windowTitle).toBe('View');
        });
      });

      describe('isEditable', () => {
        it('should return true when phrase active and not rejected', () => {
          component.phrase.isActive = true;
          component.phrase.status = PhraseStatusId.ToBeApproved;
          fixture.detectChanges();
          expect(component.isPhraseEditable).toBeTruthy();
        });

        it('should return false when phrase inactive', () => {
          component.phrase.isActive = false;
          component.phrase.status = PhraseStatusId.ToBeApproved;
          fixture.detectChanges();
          expect(component.isPhraseEditable).toBeFalsy();
        });
      });

      describe('quillEditorBackgroundColour', () => {
        it('should be blank for active phrases', () => {
          expect(component.quillEditorBackgroundColour).toBe('');
        });

        it('should be lightgrey for inactive phrases', () => {
          component.phrase.isActive = false;
          fixture.detectChanges();
          expect(component.quillEditorBackgroundColour).toBe('lightgrey');
        });
      });

      describe('save button', () => {
        it('should be visible', () => {
          const button = fixture.debugElement.query(By.css('#save-button'));
          expect(button).toBeTruthy();
        });
      });

      // describe('detail level control (dropdown)', () => {
      //   it('is hidden', () => {
      //     // Assert
      //     const control = fixture.debugElement.query(By.css('#detail-level-control'));
      //     expect(control).toBeNull();
      //   });
      // });

      describe('detail level display (read only field)', () => {
        it('is visible', () => {
          // Assert
          const field = fixture.debugElement.query(By.css('#detail-level-display'));
          expect(field).toBeNull();
        });
      });
    });

    describe('when copy is attempted', () => {
      beforeEach(() => {
        component.isCopyPhrase = true;
        component.testCase = false;
        fixture.detectChanges();
      });

      describe('detail level control (dropdown)', () => {
        it('is visible and has value equal to phrase detail level', () => {
          // Assert
          const control = fixture.debugElement.query(By.css('#detail-level-control'));
          expect(control).toBeTruthy();
          expect(control.nativeElement.value).toEqual(component.phrase.detailLevelId.toString());
        });
      });

      describe('with selections from copy checkboxes', () => {
          it('should keep phrase text if this is chosen to be copied', async(done) => {
            component.copyParameters = {
                phraseId: 2,
                includeText: true,
                includeAssignments: false
            };
            setTimeout(function() { // Wait for 10ms for async sub-call to complete (component.copyParameters is not itself async)
                expect(component.phrase.text).toBe("test phrase");
                done();
            }, 10);
          });

          it('should keep both phrase assignments and text if these are chosen to be copied', async(done) => {
            component.copyParameters = {
                phraseId: 2,
                includeText: true,
                includeAssignments: true
            };
            setTimeout(function() { // Wait for 10ms for async sub-call to complete (component.copyParameters is not itself async)
                expect(component.phrase.text).toBe("test phrase");
                expect(component.originalAssignments).toBeTruthy();
                done();
            }, 10);
          });

          it('should keep newText if this is chosen to be copied on a new phrase', async(done) => {
            testEditPhrase.newText = 'newText';
            component.copyParameters = {
                phraseId: 2,
                includeText: true,
                includeAssignments: true
            };
            setTimeout(function() { // Wait for 10ms for async sub-call to complete (component.copyParameters is not itself async)
                expect(component.phrase.text).toBe("newText");
                expect(component.originalAssignments).toBeTruthy();
                done();
            }, 10);
          });

          it('should clear phrase text if this is not chosen to be copied', async(done) => {
            component.copyParameters = {
                phraseId: 2,
                includeText: false,
                includeAssignments: false
            };
            setTimeout(function() { // Wait for 10ms for async sub-call to complete (component.copyParameters is not itself async)
               // expect(component.phrase.text).toBeTruthy();
                done();
            }, 10);
          });


          it('should clear phrase assignments if this is not chosen to be copied', async(done) => {
            component.copyParameters = {
                phraseId: 2,
                includeText: false,
                includeAssignments: false
            };
            setTimeout(function() { // Wait for 10ms for async sub-call to complete (component.copyParameters is not itself async)
                expect(component.originalAssignments.length).toEqual(0);
                done();
            }, 10);
          });

          it('should keep phrase assignments if these are chosen to be copied', async(done) => {
            component.copyParameters = {
                phraseId: 2,
                includeText: false,
                includeAssignments: true
            };
            setTimeout(function() { // Wait for 10ms for async sub-call to complete (component.copyParameters is not itself async)
                expect(component.originalAssignments).toBeTruthy();
                done();
            }, 10);
          });

          it('should keep neither phrase assignments and text if these are not chosen to be copied', async(done) => {
            component.copyParameters = {
                phraseId: 2,
                includeText: false,
                includeAssignments: false
            };
            setTimeout(function() { // Wait for 10ms for async sub-call to complete (component.copyParameters is not itself async)
                // expect(component.phrase.text).toBeFalsy();
                expect(component.originalAssignments.length).toEqual(0);
                done();
            }, 10);
          });
      });

      describe('detail level display (read only field)', () => {
        it('is hidden', () => {
          // Assert
          const field = fixture.debugElement.query(By.css('#detail-level-display'));
          expect(field).toBeFalsy();
        });
      });
    });
  });

  describe('when user does not have permission to edit phrases', () => {
    beforeEach(() => {
      when(authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision).calledWith(editPhrasePermissions, null, testPhrase.unileverProductDivisionId)
                                                                                     .mockReturnValue(false);
      buildComponent();
      component.phrase = testPhrase;
      fixture.detectChanges();
    });

    describe('isPhraseEditable', () => {
      it('should return false', () => {
        component.phrase.isActive = true;
        component.phrase.status = PhraseStatusId.ToBeApproved;
        fixture.detectChanges();
        expect(component.isPhraseEditable).toBeFalsy();
      });
    });

    describe('and has permission to edit phrase assignments', () => {
      beforeEach(() => {
        when(authorizationService.checkUserHasAnyPermission).calledWith(editPhraseAssignmentsPermissions)
                                                            .mockReturnValue(true);
        buildComponent();
        component.phrase = testPhrase;
        fixture.detectChanges();
      });

      describe('save button', () => {
        it('should be visible', () => {
          const button = fixture.debugElement.query(By.css('#save-button'));
          expect(button).toBeTruthy();
        });
      });
    });

    describe('and does not have permission to edit phrase assignments', () => {
      beforeEach(() => {
        when(authorizationService.checkUserHasAnyPermission).calledWith(editPhraseAssignmentsPermissions)
                                                            .mockReturnValue(false);
        buildComponent();
        component.phrase = testPhrase;
        fixture.detectChanges();
      });

      describe('save button', () => {
        it('should be hidden', () => {
          const button = fixture.debugElement.query(By.css('#save-button'));
          expect(button).toBeFalsy();
        });
      });
    });
  });

  describe('when user has permission to write phrases with assignments', () => {
    beforeEach(() => {
      when(authorizationService.checkUserHasAnyPermission).calledWith(addPhraseWithAssignmentPermissions)
                                                          .mockReturnValue(true);
      buildComponent();
    });

    describe('and has permission to write phrases without assignments', () => {
      beforeEach(() => {
        when(authorizationService.checkUserHasAnyPermission).calledWith(addPhraseWithoutAssignmentPermissions)
                                                            .mockReturnValue(true);
        buildComponent();
      });

      describe('isSaveEnabled', () => {
        it('should return false when no changes defined', () => {
          component.phrase = testPhrase;
          expect(component.isSaveEnabled).toBeFalsy();
        });

        it('should return false when all data available but no change type specified but unapproved phrase', () => {
          testPhrase.changeType = PhraseChangeType.None;
          component.phrase = testPhrase;
          component.originalText = 'fred';
          component.isTopicsLoaded = false;
          fixture.detectChanges();
          expect(component.isSaveEnabled).toBeFalsy();
        });

        it('should return false when all data available but no change type specified for approved phrase', () => {
          testPhrase.changeType = PhraseChangeType.None;
          component.phrase = testPhrase;
          component.phrase.status = PhraseStatusId.Approved;
          component.originalText = 'fred';
          component.isTopicsLoaded = false;
          fixture.detectChanges();
          expect(component.isSaveEnabled).toBeFalsy();
        });

        it('should return true when copying phrase and all data available but no change type specified', () => {
          testPhrase.changeType = PhraseChangeType.None;
          component.phrase = testPhrase;
          component.originalText = 'fred';
          component.isCopyPhrase = true;
          component.isTopicsLoaded = false;
          component.testCase = false;
          fixture.detectChanges();
          expect(component.isSaveEnabled).toBeTruthy();
        });

        it('should return false when changing assignments and all data available but no change type specified', () => {
          testPhrase.changeType = PhraseChangeType.None;
          component.phrase = testPhrase;
          component.originalText = 'fred';
          component.assignmentsChanged = true;
          component.isTopicsLoaded = false;
          fixture.detectChanges();
          expect(component.isSaveEnabled).toBeFalsy();
        });

        it('should return true when changing assignments but nothing else', () => {
          testPhrase.changeType = PhraseChangeType.None;
          component.phrase = testPhrase;
          component.originalText = component.phrase.text;
          component.assignmentsChanged = true;
          component.isTopicsLoaded = false;
          fixture.detectChanges();
          expect(component.isSaveEnabled).toBeTruthy();
        });

        it('should return false when not changing assignments or anything else', () => {
          testPhrase.changeType = PhraseChangeType.None;
          setupComponentWithUnchangedPhrase(component, testPhrase);
          component.assignmentsChanged = false;
          component.isTopicsLoaded = false;
          fixture.detectChanges();
          expect(component.isSaveEnabled).toBeFalsy();
        });

        it('should return false when phrase text missing', () => {
          component.phrase = testPhrase;
          component.phrase.text = '';
          component.isTopicsLoaded = false;
          fixture.detectChanges();
          expect(component.isSaveEnabled).toBeFalsy();
        });

        it('should return true when assignments changed for a new phrase', () => {
          component.originalPhrase.text = null;
          component.assignmentsChanged = true;
          fixture.detectChanges();
          expect(component.isSaveEnabled).toBeTruthy();
        });
      });

      describe('saveButtonTooltipText', () => {
        it('should return empty message when no phrase assignments defined, but other changes defined', () => {
          const phrase = testPhrase;
          phrase.assignments = [];
          component.phrase = phrase;
          component.originalText = 'fred';
          expect(component.saveButtonTooltipText).toBe('');
        });

        it('should return empty message when no phrase assignments defined and changes defined', () => {
          component.phrase = testPhrase;
          component.phrase.assignments = [];
          expect(component.saveButtonTooltipText).toBe(MISSING_CHANGE_ERROR);
        });
      });
    });

    describe('and does not have permission to write phrases without assignments', () => {
      beforeEach(() => {
        when(authorizationService.checkUserHasAnyPermission).calledWith(addPhraseWithoutAssignmentPermissions)
                                                            .mockReturnValue(false);
        buildComponent();
      });

      describe('isSaveEnabled', () => {
        it('should return false when no changes', () => {
          component.phrase = testPhrase;
          expect(component.isSaveEnabled).toBeFalsy();
        });
      });

      describe('saveButtonTooltipText', () => {
        it('should return missing assignments error message when no changes defined', () => {
          component.phrase = testPhrase;
          component.phrase.assignments = [];
          expect(component.saveButtonTooltipText).toBe(MISSING_ASSIGNMENTS_ERROR);
        });
      });
    });
  });

  describe('when user does not have permission to write phrases with assignments', () => {
    beforeEach(() => {
      when(authorizationService.checkUserHasAnyPermission).calledWith(addPhraseWithAssignmentPermissions)
                                                          .mockReturnValue(false);
      buildComponent();
    });

    describe('and has permission to write phrases without assignments', () => {
      beforeEach(() => {
        when(authorizationService.checkUserHasAnyPermission).calledWith(addPhraseWithoutAssignmentPermissions)
                                                            .mockReturnValue(true);
        buildComponent();
      });

      describe('isSaveEnabled', () => {
        it('should return false when no changes defined', () => {
          component.phrase = testPhrase;
          expect(component.isSaveEnabled).toBeFalsy();
        });

        it('should return true when changes but no assignments defined', () => {
          const phrase = testPhrase;
          phrase.assignments = [];
          component.phrase = phrase;
          component.originalText = 'fred';
          expect(component.isSaveEnabled).toBeTruthy();
        });
      });

      describe('allowPhraseAddition', () => {
        it('should return true when no phrase assignments defined', () => {
          component.phrase = testPhrase;
          component.phrase.assignments = [];
          component.isTopicsLoaded = false;
          fixture.detectChanges();
          expect(component.allowPhraseAddition).toBeTruthy();
        });
      });

      describe('saveButtonTooltipText', () => {
        it('should return no save changes message when no phrase assignments defined', () => {
          component.phrase = testPhrase;
          component.phrase.assignments = [];
          component.isTopicsLoaded = false;
          fixture.detectChanges();
          expect(component.saveButtonTooltipText).toBe(MISSING_CHANGE_ERROR);
        });
      });
    });

    describe('and does not have permission to write phrases without assignments', () => {
      beforeEach(() => {
        when(authorizationService.checkUserHasAnyPermission).calledWith(addPhraseWithoutAssignmentPermissions)
                                                            .mockReturnValue(false);
        buildComponent();
      });

      describe('isSaveEnabled', () => {
        it('should return false when no phrase assignments defined', () => {
          component.phrase = testPhrase;
          component.phrase.assignments = [];
          component.isTopicsLoaded = false;
          fixture.detectChanges();
          expect(component.isSaveEnabled).toBeFalsy();
        });
      });

      describe('saveButtonTooltipText', () => {
        it('should return message when no phrase assignments defined', () => {
          component.phrase = testPhrase;
          component.phrase.assignments = [];
          component.isTopicsLoaded = false;
          fixture.detectChanges();
          expect(component.saveButtonTooltipText).toBe(MISSING_ASSIGNMENTS_ERROR);
        });
      });
    });
  });

  describe('when user has permission to change the active status of a phrase', () => {
    beforeEach(() => {
      when(authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision).calledWith(changeActiveStatePermissions, null, testPhrase.unileverProductDivisionId)
                                                                                     .mockReturnValue(true);
      buildComponent();
      component.phrase = testPhrase;
      component.phrase.universalEditAllowed = true;
    });

    describe('changeActiveStatusAllowed', () => {
      it('should be true', () => {
        expect(component.changeActiveStatusAllowed).toBe(true);
      });
    });

    it('should match snapshot', () => {
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('activeStatusTooltipText should return no message', () => {
      expect(component.activeStatusTooltipText).toBeFalsy();
    });

    it('active checkbox should be enabled', () => {
      const checkBox = fixture.debugElement.query(By.css('#phrase-active'));
      expect(checkBox.properties.disabled).toBeTruthy();
    });
  });

  describe('when user does not have permission to change the active status of a phrase', () => {
    beforeEach(() => {
      when(authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision).calledWith(changeActiveStatePermissions, null, testPhrase.unileverProductDivisionId)
                                                                                     .mockReturnValue(false);
      buildComponent();
      component.phrase = testPhrase;
      fixture.detectChanges();
    });

    describe('changeActiveStatusAllowed', () => {
      it('should be false', () => {
        expect(component.changeActiveStatusAllowed).toBe(false);
      });
    });

    it('should match snapshot', () => {
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('activeStatusTooltipText should return message', () => {
      expect(component.activeStatusTooltipText).toBeTruthy();
    });

    it('active checkbox should be disabled', () => {
      const checkBox = fixture.debugElement.query(By.css('#phrase-active'));
      expect(checkBox.properties.disabled).toBeTruthy();
    });
  });

  describe('Cancel dialog', () => {
    it('should be displayed when phrase modified', () => {
      component.phrase = testPhrase;
      component.originalText = 'fred';
      component.phrase.isActive = false;
      testCancelDialogDisplayed(fixture, component);
    });

    it('should be displayed when phrase active status changed', () => {
      setupComponentWithUnchangedPhrase(component, testPhrase);
      component.phrase.isActive = false;
      testCancelDialogDisplayed(fixture, component);
    });

    it('should be displayed when phrase assignments changed', () => {
      setupComponentWithUnchangedPhrase(component, testPhrase);
      component.assignmentsChanged = true;
      testCancelDialogDisplayed(fixture, component);
    });

    it('should not be displayed when nothing is changed', () => {
      setupComponentWithUnchangedPhrase(component, testPhrase);
      component.assignmentsChanged = false;
      component.isTopicsLoaded = false;
      fixture.detectChanges();
      const dialogService = getTestBed().get(ConfirmationDialogService);
      const spy = jest.spyOn(dialogService, 'question');
      expect(spy).not.toHaveBeenCalled();
    });
  });

  describe('when phrase is detailed', () => {
    beforeEach(() => {
      isDetailedPhrase = true;
      component.phrase = testPhrase;
      component.phrase.detailLevelId = detailLevels.filter(dl => dl.description == DetailLevels.Detailed)[0].id;
      component.phrase.linkedGenericPhraseId = phrasesToLinkAgainst[0].phraseId;
      component.isLoading = false;
      component.isTopicsLoaded = false;
      fixture.detectChanges();
    });

    describe('linked phrase control', () => {
      it('should be visible', () => {
        // Assert
        const control = fixture.debugElement.query(By.css('#linked-phrase-component'));
        expect(control).toBeTruthy();
      });
    });

    describe('onTopicChange', () => {
      beforeEach(() => {
        jest.spyOn(phraseService, 'getPhrasesToLinkAgainst');
        component.phrasesToLinkAgainstLoading = false;
        component.previousTopicId = 77;
        fixture.detectChanges();
      });

      describe('should not be called when', () => {
        it('the topicId has not changed', () => {
          // Assemble
          component.previousTopicId = 99;

          // Act
          component.onTopicChange(99);

          // Assert
          expect(phraseService.getPhrasesToLinkAgainst).not.toHaveBeenCalled();
        });
        it('phrases to link against are loading', () => {
          // Assemble
          component.phrasesToLinkAgainstLoading = true;

          // Act
          component.onTopicChange(99);

          // Assert
          expect(phraseService.getPhrasesToLinkAgainst).not.toHaveBeenCalled();
        });
      });

      describe('should be called with appropriate arguments when', () => {
        it('phrases to link against are not loading and not available and selected topic id does not match the topic id of the phrase', () => {
          // Act
          component.onTopicChange(99);

          // Assert
          expect(phraseService.getPhrasesToLinkAgainst).toHaveBeenCalledWith(1, 99);
        });
      });
    });
  });

  describe('when phrase is not detailed', () => {
    beforeEach(() => {
      isDetailedPhrase = false;
      component.isLoading = false;
      component.isTopicsLoaded = false;
      fixture.detectChanges();
    });

    describe('linked phrase control', () => {
      it('should be hidden', () => {
        // Assert
        const control = fixture.debugElement.query(By.css('#linked-phrase-component'));
        expect(control).toBeFalsy();
      });
    });
  });

  describe('restore phrase', () => {
      it('button should be present when phrase can be restored', () => {
        component.phrase.phraseCanBeRestored = true;

        fixture.detectChanges();

        const button = fixture.debugElement.query(By.css('#restore-button'));
        expect(button).toBeTruthy();
      });

      it('button should not be present when phrase can not be restored', () => {
        component.phrase.phraseCanBeRestored = false;
        fixture.detectChanges();

        const button = fixture.debugElement.query(By.css('#restore-button'));
        expect(button).toBeFalsy();
      });

      it('button should not be present when phrase is copied', () => {
        component.phrase.phraseCanBeRestored = true;
        component.isCopyPhrase = true;
        component.testCase = false;
        fixture.detectChanges();

        const button = fixture.debugElement.query(By.css('#restore-button'));
        expect(button).toBeFalsy();
      });
  });

  describe('phrase type and UoM controls', () => {
      it('should be hidden when the phrase is not new', () => {
        component.originalPhrase.text = "text";
        component.phrase.statusText = PhraseStatus.ToBeApproved;
        component.phrase.universalEditAllowed = true;
        component.phrase.phraseType = 1;
        fixture.detectChanges();

        const phraseTypeControl = fixture.debugElement.query(By.css('#phrase-type-select'));
        expect(phraseTypeControl).toBeFalsy();
        const phraseTypeLabel = fixture.debugElement.query(By.css('#phrase-type-label'));
        expect(phraseTypeLabel).toBeTruthy();
        const uomControl = fixture.debugElement.query(By.css('#uom-select'));
        expect(uomControl).toBeFalsy();
        const uomLabel = fixture.debugElement.query(By.css('#uom-label'));
        expect(uomLabel).toBeTruthy();
      });

      it('should be shown when the phrase is new', () => {
        component.originalPhrase.text = null;
        component.phrase.statusText = PhraseStatus.ToBeApproved;
        component.phrase.universalEditAllowed = true;
        component.phrase.phraseType = 1;
        fixture.detectChanges();

        const phraseTypeControl = fixture.debugElement.query(By.css('#phrase-type-select'));
        expect(phraseTypeControl).toBeTruthy();
        const phraseTypeLabel = fixture.debugElement.query(By.css('#phrase-type-label'));
        expect(phraseTypeLabel).toBeFalsy();
        const uomControl = fixture.debugElement.query(By.css('#uom-select'));
        expect(uomControl).toBeTruthy();
        const uomLabel = fixture.debugElement.query(By.css('#uom-label'));
        expect(uomLabel).toBeFalsy();
      });
  });

  describe('set phraseId', () => {
    it('calls editPhraseService.loadPhraseData with correct params', () => {
        const spy = jest.spyOn(editPhraseService, 'loadPhraseData');
        component.phraseId = 1;
        expect(spy).toHaveBeenCalledWith(1, false);

        component.isCopyPhrase = true;
        component.testCase = false;
        fixture.detectChanges();
        component.phraseId = 2;
        expect(spy).toHaveBeenCalledWith(2, true);
    });

    it('clears assignments for copyPhrase without assignments', () => {
        component.isCopyPhrase = true;
        component._copyParameters = { includeAssignments: false, phraseId: 1, includeText: true };
        component.testCase = false;
        fixture.detectChanges();
        component.phraseId = 1;
        component.testCase = false;
        fixture.detectChanges();
        expect(component.phrase.assignments.length).toBe(0);
    });

    it('clears text for copyPhrase without text', () => {
        component.isCopyPhrase = true;
        component._copyParameters = { includeAssignments: false, phraseId: 1, includeText: false };
        component.testCase = false;
        fixture.detectChanges();
        component.phraseId = 1;
        component.testCase = false;
        fixture.detectChanges();
        expect(component.phrase.text).toBe('');
    });

  describe('onTextContentChange', () => {
    it('sets originalText if it is null', () => {
      component.originalText = null;
      const event = { html: 'newText' };
      component.onTextContentChange(event);
      fixture.detectChanges();
      expect(component.originalText).toBe(event.html);
    });

    it('sets phrase text', () => {
      component.phrase.text = 'oldText';
      component.phrase.newText = 'oldNewText';
      component.originalText = 'originalText';
      const event = { html: 'newCurrentText' };
      component.onTextContentChange(event);
      fixture.detectChanges();
      expect(component.phrase.text).toBe(event.html);
      expect(component.phrase.newText).toBe('oldNewText');
    });
  });

  describe('loading spinner', () => {
    it('displays when isLoading is true', () => {
      component.isLoading = true;
      component.selectedTab = 'phrase';
      fixture.detectChanges();

      const spinner = fixture.debugElement.query(By.css('#spinner'));
      expect(spinner.attributes['ng-reflect-active']).toBe('true');

      component.selectedTab = 'assignments';
      fixture.detectChanges();

      expect(spinner.attributes['ng-reflect-active']).toBe('true');
    });

    it('displays when isLoading is false but phrase tab is displayed and loading', () => {
      component.isLoading = false;
      component.selectedTab = 'phrase';
      component.topicsLoading = true;
      fixture.detectChanges();

      const spinner = fixture.debugElement.query(By.css('#spinner'));
      expect(spinner.attributes['ng-reflect-active']).toBe('true');
    });

    it('does not display when isLoading is false and phrase tab is displayed and not loading', () => {
      component.isLoading = false;
      component.isTopicsLoaded = false;
      component.selectedTab = 'phrase';
      component.topicsLoading = false;
      component.updsLoading = false;
      component.phrase.topicId = 1;
      component.phrase.unileverProductDivisionId = 1;
      fixture.detectChanges();

      const spinner = fixture.debugElement.query(By.css('#spinner'));
      expect(spinner.attributes['ng-reflect-active']).toBe('true');
    });

    it('displays when isLoading is false but assignments tab is displayed and loading', () => {
      component.isLoading = false;
      component.selectedTab = 'assignments';
      component.phraseAssignmentsLoading = true;
      fixture.detectChanges();

      const spinner = fixture.debugElement.query(By.css('#spinner'));
      expect(spinner.attributes['ng-reflect-active']).toBe('true');
    });

    it('does not display when isLoading is false and assignments tab is displayed and not loading', () => {
      component.isLoading = false;

      component.selectedTab = 'assignments';
      component.phraseAssignmentsLoading = false;
      component.isTopicsLoaded = false;
      fixture.detectChanges();

      const spinner = fixture.debugElement.query(By.css('#spinner'));
      expect(spinner.attributes['ng-reflect-active']).toBe('true');
    });
  });

  describe('quill panel', () => {
    it('displays fullscreen when phrase is approved', () => {
      component.phrase.statusText = PhraseStatus.Approved;
      fixture.detectChanges();

      testFullscreenQuillPanel(fixture);
    });

    it('displays fullscreen when phrase is copy', () => {
      component.isCopyPhrase = true;
      component.testCase = false;
      fixture.detectChanges();

      testFullscreenQuillPanel(fixture);
    });

    it('displays fullscreen when phrase is rejected but previously approved', () => {
      component.phrase.statusText = PhraseStatus.Rejected;
      component.originalPhrase.newText = null;
      fixture.detectChanges();

      testFullscreenQuillPanel(fixture);
    });

    it('displays halfscreen when phrase is ToBeApproved', () => {
      component.phrase.statusText = PhraseStatus.ToBeApproved;
      component.isCopyPhrase = false;
      fixture.detectChanges();

      testHalfscreenQuillPanel(fixture);
    });

    it('displays fullscreen when phrase is rejected but not previously approved', () => {
      component.phrase.statusText = PhraseStatus.Rejected;
      component.originalPhrase.newText = 'new text';
      component.isCopyPhrase = false;
      fixture.detectChanges();

      testHalfscreenQuillPanel(fixture);
    });
  });
});
});

function testFullscreenQuillPanel(fixture) {
  const fullscreenQuillPanel = fixture.debugElement.query(By.css('#edit-fullscreen'));
  const halfscreenQuillPanel = fixture.debugElement.query(By.css('#edit-halfscreen'));
  expect(fullscreenQuillPanel).toBeTruthy();
  expect(halfscreenQuillPanel).toBeFalsy();
}

function testHalfscreenQuillPanel(fixture) {
  const fullscreenQuillPanel = fixture.debugElement.query(By.css('#edit-fullscreen'));
  const halfscreenQuillPanel = fixture.debugElement.query(By.css('#edit-halfscreen'));
  expect(halfscreenQuillPanel).toBeTruthy();
  expect(fullscreenQuillPanel).toBeFalsy();
}

function setupComponentWithUnchangedPhrase(component: EditPhraseComponent, testPhrase: Phrase) {
  component.phrase = testPhrase;
  component.originalPhrase.phraseType = component.phrase.phraseType;
  component.originalPhrase.unitOfMeasure = component.phrase.unitOfMeasure;
  component.originalPhrase.isActive = component.phrase.isActive;
  component.originalText = component.phrase.text;
}

function testCancelDialogDisplayed(fixture: ComponentFixture<EditPhraseComponent>, component: EditPhraseComponent) {
  component.isTopicsLoaded = false;
  fixture.detectChanges();
  const dialogService = getTestBed().get(ConfirmationDialogService);
  const spy = jest.spyOn(dialogService, 'question');
  component.cancelPhrase();
  expect(spy).toHaveBeenCalledTimes(1);
}
