import { Injectable } from '@angular/core';
import { Phrase } from '../phrase-library.types';
import { SaveResult } from '../../tools/common.types';
import { HttpService } from '../../tools/services/http.service';
import { UrlEndpoint } from '../../tools/constants';
import { PhraseChangeType } from '../../tools/constants';
import { AuthorizationService } from '../../authorization/authorization.service';

@Injectable()
export class EditPhraseService {
    constructor(
        private httpService: HttpService,
        private authorizationService: AuthorizationService) {
    }

    loadPhraseData(phraseId: number, isCopy: boolean): Promise<Phrase> {
        return new Promise<Phrase>((resolve, reject) => {
            // const url = "https://localhost:44344/";
            this.httpService.getFiltered({phraseId: phraseId.toString(), isCopy: isCopy.toString()}, UrlEndpoint.EditPhrase_LoadPhrase).subscribe(result => {
                if (result.changeType == null || result.changeType === 'None') {
                    result.changeType = PhraseChangeType.None;
                }
                this.applyUserPermissionToPhrase(result);
                if (isCopy) {
                    this.stripOutAssignmentsThatCannotBeCopied(result);
                }
                resolve(result);
            }, error => {
                reject(error);
            });
        });
    }

    stripOutAssignmentsThatCannotBeCopied(phrase: Phrase) {
        if (phrase && phrase.assignments) {
        phrase.assignments = phrase.assignments.filter(a => a.allowModify);
        }
    }

    applyUserPermissionToPhrase(phrase: Phrase) {
        if (phrase && phrase.assignments) {
        phrase.assignments.map(x => x.allowModify = this.authorizationService.checkUserCanModifyAssignment(x));
        }
    }

    savePhrase(phrase: Phrase, isCopy: boolean): Promise<SaveResult> {
        return new Promise<SaveResult>((resolve, reject) => {
            let url: string;
            if (isCopy) {
                phrase.id = -1; // clear out the ID to allow a clean duplication check
                url = UrlEndpoint.PhraseLibrary_SavePhrase;
            }
            else {
                url = UrlEndpoint.EditPhrase_SavePhrase;
            }
            this.httpService.postContent(phrase, url).subscribe(result => {
                resolve(result);
            }, error => reject(error));
        });
    }

    restorePhrase(phraseId: number, isConfirmed: boolean): Promise<SaveResult>  {
        return new Promise<SaveResult>((resolve, reject) => {
            this.httpService.postContent({ id: phraseId, confirmed: isConfirmed }, UrlEndpoint.EditPhrase_RestorePhrase).subscribe(result => {
                resolve(result);
            }, error => reject(error));
        });
    }
}
