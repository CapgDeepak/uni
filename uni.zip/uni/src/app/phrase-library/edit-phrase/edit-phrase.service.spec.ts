import { TestBed, inject } from '@angular/core/testing';
import { Observable, of } from 'rxjs';
import { when } from 'jest-when';

import { EditPhraseService } from './edit-phrase.service';
import { EmptyPhrase } from '../phrase-library.types';
import { HttpService } from '../../tools/services/http.service';
import { SaveResult } from '../../tools/common.types';
import { AuthorizationService } from '../../authorization/authorization.service';
import { createPhraseAssignment } from '../../testData';

const dummyPhrase: EmptyPhrase = new EmptyPhrase();
const validTopicId: number = 1;
const invalidTopicId: number = 2;

const saveResult: SaveResult = {
  success: true,
  message: "blah",
  needsConfirmation: false
};

class AuthorizationServiceMock {
    checkUserCanModifyAssignment = jest.fn();
}

class HttpServiceMock {
  getFiltered() {
    return new Observable( observer => {
      observer.next(dummyPhrase);
      observer.complete();
    });
  }
  postContent() {
    return of(saveResult);
  }
}

describe('EditPhraseService', () => {
  let service: EditPhraseService;
  let authorizationService: AuthorizationService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        EditPhraseService,
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
      ]
    });
    service = TestBed.get(EditPhraseService);
    authorizationService = TestBed.get(AuthorizationService);
    dummyPhrase.id = 123;
  });

  it('should be created', inject([EditPhraseService], () => {
    expect(service).toBeTruthy();
  }));

  describe('loadPhraseData', () => {
    beforeEach(() => {
        dummyPhrase.assignments = [];
        dummyPhrase.assignments.push(createPhraseAssignment(validTopicId, 2, 3));
        dummyPhrase.assignments.push(createPhraseAssignment(invalidTopicId, 4, 5));
        dummyPhrase.assignments.push(createPhraseAssignment(validTopicId, 6, 7));
        when(authorizationService.checkUserCanModifyAssignment).calledWith(dummyPhrase.assignments[0]).mockReturnValue(true);
        when(authorizationService.checkUserCanModifyAssignment).calledWith(dummyPhrase.assignments[1]).mockReturnValue(false);
        when(authorizationService.checkUserCanModifyAssignment).calledWith(dummyPhrase.assignments[2]).mockReturnValue(true);
    });

    it('should call api', async(done) => {
        service.loadPhraseData(1, false).then(content => {
            expect(content).toEqual(dummyPhrase);
            done();
        });
    });

    it('should set assignments to correct permission for current user', async(done) => {
        service.loadPhraseData(1, false).then(content => {
            expect(content).toEqual(dummyPhrase);
            expect(content.assignments[0].allowModify).toBeTruthy();
            expect(content.assignments[1].allowModify).toBeFalsy();
            expect(content.assignments[2].allowModify).toBeTruthy();
            done();
        });
    });

    it('should only return assignments within permission for current user when copying', async(done) => {
        service.loadPhraseData(1, true).then(content => {
            expect(content).toEqual(dummyPhrase);
            expect(content.assignments.length).toEqual(2);
            expect(content.assignments[0].allowModify).toBeTruthy();
            expect(content.assignments[1].allowModify).toBeTruthy();
            expect(content.assignments[1].regulatoryProductClassId).toEqual(7);
            done();
        });
    });
  });

  describe('save phrase', () => {
    it('for editing should call api for saving existing phrase', async(done) => {
        service.savePhrase(dummyPhrase, false).then(content => {
        expect(content).toEqual(saveResult);
        done();
        });
    });

    it('for copying should call api for adding new phrase', async(done) => {
        service.savePhrase(dummyPhrase, true).then(content => {
        expect(content).toEqual(saveResult);
        done();
        });
    });

    it('for copying should reset phrase ID', async(done) => {
        service.savePhrase(dummyPhrase, true).then(() => {
        expect(dummyPhrase.id).toEqual(-1);
        done();
        });
    });

    it('for editing should not reset phrase ID', async(done) => {
        service.savePhrase(dummyPhrase, false).then(() => {
        expect(dummyPhrase.id).toEqual(123);
        done();
        });
    });
  });

  describe('restore phrase', () => {
    it('should call api', async(done) => {
        service.restorePhrase(1, false).then(content => {
            expect(content).toEqual(saveResult);
            done();
        });
    });
  });
});

