import { Component, Output, ChangeDetectorRef } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Observable, of } from 'rxjs';
import * as isEqual from 'lodash.isequal';
import * as cloneDeep from 'lodash.clonedeep';

import { Phrase, EmptyPhrase } from '../phrase-library.types';
import { CopyPhraseParameters } from '../copy-phrase/copy-phrase.types';
import { PhraseStatusId, PhraseChangeType, MISSING_CHANGE_TYPE_ERROR, MISSING_CHANGE_ERROR, MISSING_DETAIL_LEVEL_ERROR, PhraseStatus, DetailLevels, UrlEndpoint } from '../../tools/constants';
import { PhraseAssignment } from '../../shared-components/phrase-assignments/phrase-assignments.types';
import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';
import { ConfirmationDialogService } from '../../shared-components/confirmation-dialog/confirmation-dialog.service';
import { EditPhraseService } from './edit-phrase.service';
import { QuillSettingsService } from '../../tools/services/quill-settings.service';
import { MISSING_ASSIGNMENTS_ERROR, MISSING_TEXT_ERROR } from '../add-phrase/add-phrase.component';
import { Permission } from '../../tools/shared-types/permissions/permission';
import { AuthorizationService } from '../../authorization/authorization.service';
import { CacheService } from '../../tools/services/cache.service';
import { DetailLevel, FilterObject } from '../../tools/common.types';
import { PhraseService } from '../../tools/services/phrase.service';
import { PhraseSimpleModel } from '../../tools/shared-types/phrase.types';
import { HttpService } from '../../tools/services/http.service';

@Component({
    selector: 'ara-edit-phrase',
    templateUrl: './edit-phrase.component.html',
    styleUrls: ['./edit-phrase.component.scss']
})
export class EditPhraseComponent {
    @Output() public quillmodules;
    @Output() public quillformats;

    saveButtonText = 'Save';

    originalAssignments: PhraseAssignment[] = [];
    originalPhraseAssignmentDetails: PhraseAssignment[] = [];
    public originalPhrase: Phrase = new EmptyPhrase();
    public _phrase: Phrase = new EmptyPhrase();
    public isLoading: boolean = true;
    public phraseAssignmentsLoading: boolean = false;
    public detailLevels: DetailLevel[] = [];
    public phrasesToLinkAgainst$: Observable<PhraseSimpleModel[]>;
    public linkedGenericPhraseId$: Observable<number | null>;
    public phrasesToLinkAgainstLoading: boolean;
    public standardDetailLevels: DetailLevel[] = [];
    public previousTopicId: number;
    public isEditable: boolean = false;
    public isEditableAllowed: boolean = false;

    private addPhraseWithAssignmentPermissions: Permission[] = [
        Permission.AraPReFDCT_Phrases_WriteWithAssignments,
    ];
    private addPhraseWithoutAssignmentPermissions: Permission[] = [
        Permission.AraPReFDCT_Phrases_WriteWithoutAssignments,
    ];
    private editPhrasePermissions: Permission[] = [
        Permission.AraPReFDCT_Phrases_WriteWithAssignments,
        Permission.AraPReFDCT_Phrases_WriteWithoutAssignments,
    ];
    private editPhraseAssignmentsPermissions: Permission[] = [
        Permission.AraPReFDCT_PhraseAssignments_Write,
    ];
    private changeActiveStatePermissions: Permission[] = [
        Permission.AraPReFDCT_Phrases_ChangeActiveState,
    ];
    public whereUsedPermissions: Permission[] = [
        Permission.AraPReFDCT_PhraseAssignments_Read,
    ];

    isCopyPhrase: boolean = false;
    originalText: string = null;
    assignmentsChanged: boolean = false;
    topicsLoading: boolean = true;
    updsLoading: boolean = true;
    selectedTab: string = 'phrase';
    private _topicId: number;
    newTopicId: number;
    originalTopicId: number;
    isTopicsLoaded: boolean = true;
    isAssignmentsLoaded: boolean = true;
    marketForExistingAssignment: string = "";
    rpcForExistingAssignment: string = "";
    phraseForAssignments: any;
    fromPageForExistingAssignment: any = 0;
    toPageForExistingAssignment: any = 20;
    topicForExistingAssignment: string = "";
    updForExistingAssignment: string = "";

    constructor(
        public activeModal: NgbActiveModal,
        private httpService: HttpService,
        private alertDialogService: AlertDialogService,
        private confirmationDialogService: ConfirmationDialogService,
        private editPhraseService: EditPhraseService,
        quillSettings: QuillSettingsService,
        private authorizationService: AuthorizationService,
        private cacheService: CacheService,
        private phraseService: PhraseService,
        private cdRef: ChangeDetectorRef,
    ) {
        this.quillformats = quillSettings.quillformats;
        // note, setting this to '{ toolbar: false }' removes the toolbar - which would be useful to indicate the read-only state
        // - however it seems the modules are only bound once at initial load - so changing this doesn't update the editor
        this.quillmodules = quillSettings.quillmodules;

        // Retrieve the detail levels and phrases with which to populate the linked phrase control
        this.cacheService.getDetailLevels()
            .then((detailLevels: DetailLevel[]) => {
                this.detailLevels = detailLevels;
                this.standardDetailLevels = this.detailLevels.filter(dl => dl.description == DetailLevels.Standard);
                if (!this.standardDetailLevels || !this.standardDetailLevels.length) {
                    console.error("Detail level not found.");
                }
            })
            .catch((err: any) => {
                console.log('err', err);
            });
    }

    handlePhraseAssignmentsLoading(event: boolean) {
        this.phraseAssignmentsLoading = event;
        this.cdRef.detectChanges();

    }

    get phrase(): Phrase {
        return this._phrase;
    }

    set phrase(value: Phrase) { // note, this will get updated when changes are made via the phrase-assignments component
        this.isLoading = true;
        if (!this.isCopyPhrase) {
            this.topicsLoading = false;
            this.updsLoading = false;
        }

        this.assignmentsChanged = this._phrase &&
            this._phrase.id > -1 &&
            value &&
            !isEqual(value.assignments.sort(), this.originalAssignments.sort());
        const standardDetailLevelId = this.standardDetailLevels && !!this.standardDetailLevels.length && this.standardDetailLevels[0].id;
        if (standardDetailLevelId || standardDetailLevelId === 0) {
            this.phraseService.getPhrasesToLinkAgainst(standardDetailLevelId, value.topicId)
                .subscribe((res: PhraseSimpleModel[]) => {
                    this.phrasesToLinkAgainst$ = of(res);
                    this.linkedGenericPhraseId$ = of(this.isCopyPhrase ? null : (value && value.linkedGenericPhraseId || null));
                    if (this.isCopyPhrase) {
                        this.phrase.linkedGenericPhraseId = null;
                    }
                    this.isLoading = false;
                }, (err: any) => this.isLoading = false);
        }

        this._phrase = value;

        if (this.isCopyPhrase) {
            // Allow a copy of an inactive phrase to be edited.
            this._phrase.isActive = true;
        }

        // Keep original phrase + assignments - to track changes.  Note, the text is tracked from
        // the first change in the editor as the editor can change the html content of the text.
        if (!this.assignmentsChanged) {
            this.originalPhrase = cloneDeep(this._phrase);
        }
        // this.originalAssignments = [...value.assignments];
    }

    get isSaveEnabled(): boolean {
        return (this.phrase.text ||
            (!this.originalPhrase.text && this.assignmentsChanged)) &&
            this.allowPhraseAddition &&
            ((this.isCopyPhrase && this.phraseDetailLevelSpecified) ||
                !this.isCopyPhrase &&
                ((this.isPhraseModified && (!this.needsChangeType || this.phrase.changeType != PhraseChangeType.None)) ||
                    (!this.isPhraseModified &&
                        (this.hasActiveStatusChanged || this.assignmentsChanged
                            || this.hasDetailLevelChanged ||
                            this.hasLinkedPhraseIdsChanged ||
                            this.hasTopicChanged)
                    )));
    }

    get hasTopicChanged() {
        return this.phrase.topicId != this.originalPhrase.topicId;
    }

    get hasLinkedPhraseIdsChanged() {
        return (this.phrase.linkedSpecificPhraseNrs.length != this.originalPhrase.linkedSpecificPhraseNrs.length) ||
            JSON.stringify(this.phrase.linkedSpecificPhraseNrs.sort()) != JSON.stringify(this.originalPhrase.linkedSpecificPhraseNrs.sort());
    }

    get hasDetailLevelChanged() {
        return this.phrase.detailLevelId != this.originalPhrase.detailLevelId;
    }

    get allowPhraseAddition() {
        return this.addPhraseWithoutAssignmentsAllowed ||
            (this.addPhraseWithAssignmentsAllowed && this.phrase.assignments && this.phrase.assignments.length > 0);
    }

    get hasActiveStatusChanged(): boolean {
        return this.phrase.isActive != this.originalPhrase.isActive;
    }

    public get saveButtonTooltipText(): string {
        let tooltip = '';
        if (!this.isSaveEnabled) {
            if (!this.phrase.text && !this.phrase.newText) {
                tooltip = MISSING_TEXT_ERROR;
            } else if (this.phrase.assignments && this.phrase.assignments.length == 0 && !this.addPhraseWithoutAssignmentsAllowed) {
                tooltip = MISSING_ASSIGNMENTS_ERROR;
            } else if (this.isPhraseModified && this.hasPhraseModificationThatRequiresChangeTypeOccured && this.phrase.changeType == PhraseChangeType.None) {
                tooltip = MISSING_CHANGE_TYPE_ERROR;
            } else if (!this.isPhraseModified) {
                tooltip = MISSING_CHANGE_ERROR;
            } else if (this.isCopyPhrase && this.phraseDetailLevelSpecified) {
                tooltip = MISSING_DETAIL_LEVEL_ERROR;
            }
        }
        return tooltip;
    }

    public get activeStatusTooltipText(): string {
        return this.changeActiveStatusAllowed ? '' : "You do not have permission to change the Active status of this phrase.";
    }
    public testCase: boolean = true;
    public get windowTitle(): string {
        if (this.isCopyPhrase) {
            if (this.testCase) {
                this.isEditableAllowed = true;
            }
            return 'Copy';

        } else if (this.isPhraseFixedAsInactive()) {
            return 'View';
        }
        return 'Edit';
    }

    private isPhraseFixedAsInactive() {
        return !this.phrase.isActive && !this.changeActiveStatusAllowed;
    }

    onTextContentChange(event: any) {
        // retrieve the phrase text after it has been initially bound to the quill editor
        // - as this process can change the content - especially if it includes html elements
        if (this.originalText == null) {
            this.originalText = event.html;
            this.phrase.text = this.originalText; // note, this (and statement below) avoids change types showing up due to quill reformatting the text content

        } else if (!this.editFullscreen) {
            this.phrase.text = event.html;
        }
    }

    get quillEditorBackgroundColour(): string {
        return this.isPhraseEditable ? '' : 'lightgrey';
    }

    _phraseId: number = -1;
    get phraseId(): number {
        return this._phraseId;
    }
    set phraseId(value: number) {
        if (this._phraseId != value) {
            this._phraseId = value;
            this.editPhraseService.loadPhraseData(this._phraseId, this.isCopyPhrase).then((result: Phrase) => {
                this.isAssignmentsLoaded = true;
                this.callPhraseOriginalAssignments();
                if (this.isCopyPhrase) {
                    if (!this._copyParameters.includeAssignments) {
                        result.assignments = new Array<PhraseAssignment>();
                    }
                    if (this._copyParameters.includeText) {
                        result.text = result.newText || result.text;
                    } else {
                        result.text = '';
                    }
                    result.status = PhraseStatusId.ToBeApproved;
                    result.rejectedPhraseRemarks = "";
                }
                this.phrase = result;
                // this.originalPhraseAssignmentDetails = Array.from(result.assignments);
                this.newTopicId = this.phrase.topicId;
                this.originalTopicId = JSON.parse(JSON.stringify(this.phrase.topicId));
                this._topicId = result.topicId;
                this.phrase.changeType = PhraseChangeType.None;
                // Keep original phrase + assignments - to track changes.  Note, the text is tracked from
                // the first change in the editor as the editor can change the html content of the text.
                /* commented below as its assigned in callPhraseOriginalAssignments method*/
                //  this.originalPhrase = cloneDeep(result);
                //   this.originalAssignments = Array.from(result.assignments);
            });
        }
    }

    callPhraseOriginalAssignments() {
        // const url = "https://localhost:44344/";
        this.httpService.getFiltered({
            phraseId: this._phraseId.toString(),
            isCopy: this.isCopyPhrase.toString(),
            from: this.fromPageForExistingAssignment.toString(), to: this.toPageForExistingAssignment.toString(),
            Market: this.marketForExistingAssignment.toString(),
            Rpc: this.rpcForExistingAssignment.toString(),
            topic: this.topicForExistingAssignment.toString(),
            upd: this.updForExistingAssignment.toString()
        },
            UrlEndpoint.EditPhrase_LoadPhraseAssigments).subscribe(result => {
                this.phraseForAssignments = [];
                this.phraseForAssignments = result;
                localStorage.setItem('toPageForExistingAssignment', this.toPageForExistingAssignment.toString());
                this.phrase.assignments = [];
                this.phrase.assignments = result.assignments;
                this.originalPhrase = cloneDeep(this.phrase);
                this.applyUserPermissionToPhrase(this.phrase);
                if (this.isCopyPhrase) {
                    this.stripOutAssignmentsThatCannotBeCopied(this.phrase);
                }
                if (result && result.assignments) {
                    this.originalAssignments = Array.from(result.assignments);
                    this.originalPhraseAssignmentDetails = Array.from(result.assignments);
                }
                this.isAssignmentsLoaded = false;
            });
    }

    applyUserPermissionToPhrase(phrase: Phrase) {
        if (phrase && phrase.assignments) {
            phrase.assignments.map(x => x.allowModify = this.authorizationService.checkUserCanModifyAssignment(x));
        }
    }

    stripOutAssignmentsThatCannotBeCopied(phrase: Phrase) {
        if (phrase && phrase.assignments) {
            phrase.assignments = phrase.assignments.filter(a => a.allowModify);
        }
    }

    get isTextModified(): boolean {
        return this.originalText != null && this.phrase.text != this.originalText;
    }

    get needsChangeType(): boolean {
        return ((this.phrase.status != PhraseStatusId.ToBeApproved || this.phrase.universalEditAllowed) &&
            this.isPhraseModified &&
            this.hasPhraseModificationThatRequiresChangeTypeOccured &&
            this.originalPhrase.text &&
            !this.isCopyPhrase);
    }

    get isPhraseModified(): boolean {
        if (this.hasPhraseModificationThatRequiresChangeTypeOccured ||
            this.hasPhraseModificationThatDoesNotRequireChangeTypeOccured) {
            return true;
        }

        this.phrase.changeType = PhraseChangeType.None; // reset this to ensure old selections are preserved
        return false;
    }

    private get hasPhraseModificationThatRequiresChangeTypeOccured() {
        return this.isTextModified ||
            (this.phrase.phraseType != this.originalPhrase.phraseType) ||
            (this.phrase.unitOfMeasure != this.originalPhrase.unitOfMeasure);
    }

    private get hasPhraseModificationThatDoesNotRequireChangeTypeOccured() {
        return this.phrase.linkedGenericPhraseId != this.originalPhrase.linkedGenericPhraseId;
    }

    get isPhraseEditable(): boolean {
        return this.phrase.isActive && this.editPhraseAllowed;
    }

    get arePhraseAssignmentsEditable(): boolean {
        return this.phrase.isActive && this.editPhraseAssignmentsAllowed;
    }

    get phraseDetailLevelSpecified(): boolean {
        return !!(this.phrase.detailLevelId || this.phrase.detailLevelId == 0);
    }

    get phraseDetailLevel(): string {
        const detailLevel = this.detailLevels.find(dl => dl.id == this.phrase.detailLevelId);
        return detailLevel && detailLevel.description || "";
    }

    _copyParameters: CopyPhraseParameters | null = null;
    get copyParameters(): CopyPhraseParameters {
        return this._copyParameters;
    }
    set copyParameters(value: CopyPhraseParameters) {
        this._copyParameters = value;
        this.saveButtonText = 'Copy';
        this.isCopyPhrase = true;

        this.phraseId = this._copyParameters.phraseId; // this will load the phrase via the setter method
    }

    get showRemarks(): boolean {
        return this.phrase.status == PhraseStatusId.Rejected ||
            (this.phrase.status == PhraseStatusId.ToBeApproved && !!this.phrase.rejectedPhraseRemarks);
    }

    get hasChangesToSave(): boolean {
        return this.isPhraseModified || this.hasActiveStatusChanged || this.assignmentsChanged;
    }

    cancelPhrase() {
        if (!this.hasChangesToSave) {
            this.activeModal.close('Cancel');
        } else {
            this.confirmationDialogService.question("Confirmation", "Are you sure you want to cancel the modifications of this phrase?").then(result => {
                if (result) {
                    this.activeModal.close('Cancel');
                }
            });
        }
    }

    updatePhraseDetails() {
        this.phrase.linkedSpecificPhraseIds = this.phrase.linkedSpecificPhraseIds == null ? [] : this.phrase.linkedSpecificPhraseIds;
        this.phrase.detailLevelDescription = this.detailLevels.filter(x => x.id == this.phrase.detailLevelId)[0].description;
        // if detail level is not detailed, pass empty for linked phrase list
        if (this.phrase.detailLevelId != 2) {
            this.phrase.linkedSpecificPhraseIds = [];
            this.phrase.linkedSpecificPhraseNrs = [];
        }
        this.phrase.topicId = this.newTopicId;
        this.phrase.assignments.forEach(assignment => {
            assignment.topicId = this.newTopicId;
        });
    }

    savePhrase() {
        this.updatePhraseDetails();
        this.phrase.phraseTextChanged = this.isTextModified;
        const isCopy = (this._copyParameters || this.phraseId < 0) ? true : false;
        this.isLoading = true;
        if (this._topicId == this.phrase.topicId) {
            // If include assignments is unchecked, send empty assignments
            if (isCopy && !this._copyParameters.includeAssignments) {
                this.phrase.assignments = new Array<PhraseAssignment>();
            }
            this.phrase.text = this.phrase.text.replace('&amp;', '&');
            this.editPhraseService.savePhrase(this.phrase, isCopy)
                .then(result => {
                    this.isLoading = false;
                    if (result.success) {
                        if (result.needsConfirmation) {
                            this.confirmationDialogService.question("Question", result.message)
                                .then(resultData => {
                                    if (resultData) {
                                        this.phrase.confirmed = true;
                                        this.savePhrase();
                                    }
                                }).catch((error) => this.isLoading = false);
                        } else {
                            this.activeModal.close(result);
                        }
                    } else {
                        this.alertDialogService.alert('Error', result.message);
                        this.isLoading = false;
                    }
                })
                .catch(error => {
                    this.isLoading = false;
                });
        }
        else {
            this.confirmationDialogService.question("Confirmation", "The Phrase (Text or Detail Level or Topic) was edited. Do you want to accept the edit?")
                .then(resultData => {
                    if (resultData) {
                        this.phrase.text = this.phrase.text.replace('&amp;', '&');
                        this.phrase.confirmed = true;
                        this.editPhraseService.savePhrase(this.phrase, isCopy)
                            .then(result => {
                                if (result.success) {
                                    if (result.needsConfirmation) {
                                        this.confirmationDialogService.question("Question", result.message)
                                            .then(isConfirm => {
                                                if (isConfirm) {
                                                    this.phrase.confirmed = true;
                                                    this.savePhrase();
                                                }
                                            }).catch((error) => this.isLoading = false);
                                    } else {
                                        this.activeModal.close(result);
                                    }
                                } else {
                                    this.alertDialogService.alert('Error', result.message);
                                    this.isLoading = false;
                                }
                            })
                            .catch(error => {
                                this.isLoading = false;
                            });
                    }
                    else {
                        this.isLoading = false;
                    }
                }).catch((error) => this.isLoading = false);
        }
    }

    public get editPhraseAllowed(): boolean {
        return !this.isPhraseFixedAsInactive() &&
            this.authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision(this.editPhrasePermissions, null, this.phrase.unileverProductDivisionId);
    }

    public get editPhraseAssignmentsAllowed(): boolean {
        return !this.isPhraseFixedAsInactive() &&
            this.authorizationService.checkUserHasAnyPermission(this.editPhraseAssignmentsPermissions);
    }

    public get addPhraseWithAssignmentsAllowed(): boolean {
        return this.authorizationService.checkUserHasAnyPermission(this.addPhraseWithAssignmentPermissions);
    }

    public get addPhraseWithoutAssignmentsAllowed(): boolean {
        return this.authorizationService.checkUserHasAnyPermission(this.addPhraseWithoutAssignmentPermissions);
    }

    public get changeActiveStatusAllowed(): boolean {
        return this.authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision(this.changeActiveStatePermissions, null, this.phrase.unileverProductDivisionId)
            && (this.isPhraseApproved || this.phrase.universalEditAllowed);
    }

    public get isPhraseApproved(): boolean {
        return this.phrase.statusText == PhraseStatus.Approved;
    }

    public get editFullscreen(): boolean {
        return this.isPhraseApproved || this.isCopyPhrase || (this.phrase.statusText == PhraseStatus.Rejected && this.originalPhrase.newText == null);
    }

    public get whereUsedEnabled(): boolean {
        return this.phrase.id > 0 && this.authorizationService.checkUserHasAnyPermission(this.whereUsedPermissions);
    }

    public get isDetailedPhrase() {
        return this.phraseService.isDetailedPhrase(this.phrase.detailLevelId, this.detailLevels);
    }

    public get isComponentEditable() {
        return (!this.isPhraseApproved && this.phrase.universalEditAllowed && this.originalPhrase.text === null) || this.isCopyPhrase;
    }

    editPhraseModal() {
        this.isEditableAllowed = true;
        return this.phrase.isActive && this.editPhraseAllowed;
    }

    /**
     * Handles the change of a linked phrase ID.
     */
    public linkedPhraseIdChange(linkedPhraseId: any) {
        // this.linkedGenericPhraseId$ = of(linkedPhraseId);
        this.linkedGenericPhraseId$ = null;
        this.phrase.linkedSpecificPhraseIds = (linkedPhraseId != null && linkedPhraseId.length > 0) ? [...linkedPhraseId.map(function (a) { return a.phraseId; })] : null;
        this.phrase.linkedSpecificPhraseNrs = (linkedPhraseId != null && linkedPhraseId.length > 0) ? [...linkedPhraseId.map(function (a) { return a.nr; })] : null;
        if (this.phrase.linkedSpecificPhraseNrs == null) {
            this.phrase.linkedSpecificPhraseNrs = [];
        }
        this.phrase.linkedGenericPhraseId = null;
    }

    /**
     * Handles a user selecting a new topic in the tree navigator (any level).
     * Retrieves the appropriate phrases to link against based on the new topic Id.
     * @param topicId the ID of the topic for which to retrieve the phrases to link against.
     */
    public onTopicChange(topicId: number | null) {
        this.newTopicId = topicId;
        this.topicsLoading = false;
        if ((topicId == this.previousTopicId) || this.phrasesToLinkAgainstLoading) {
            return;
        }
        this.previousTopicId = topicId;

        this.linkedGenericPhraseId$ = of(null);
        this.phrasesToLinkAgainstLoading = true;
        const standardDetailLevelId = this.standardDetailLevels && !!this.standardDetailLevels.length && this.standardDetailLevels[0].id;
        if (standardDetailLevelId || standardDetailLevelId === 0) {
            this.phraseService.getPhrasesToLinkAgainst(standardDetailLevelId, topicId)
                .subscribe((res: PhraseSimpleModel[]) => {
                    this.phrasesToLinkAgainst$ = of(res);
                    this.phrasesToLinkAgainstLoading = false;
                    // Check if already selected linked phrase id exists in updated phrasesToLinkAgainst list
                    // If exists, keep the selection, else remove it
                    const phrasesToLink = res;
                    let linkedSpecificPhrases = this.phrase.linkedSpecificPhraseNrs;
                    this.phrase.linkedSpecificPhraseNrs = null;
                    linkedSpecificPhrases.forEach(linkedPhrase => {
                        if (phrasesToLink.filter(x => x.phraseId == linkedPhrase).length < 1) {
                            linkedSpecificPhrases = linkedSpecificPhrases.filter(y => y != linkedPhrase);
                        }
                    });
                    this.phrase.linkedSpecificPhraseNrs = this.newTopicId == this.originalTopicId ? this.originalPhrase.linkedSpecificPhraseNrs : linkedSpecificPhrases;
                }, (err: any) => {
                    this.phrasesToLinkAgainst$ = of([]);
                    this.phrasesToLinkAgainstLoading = false;
                });
        }
    }

    updatePhraseAssignments() {
        this.phrase.assignments.forEach(assignment => {
            assignment.topicId = this.newTopicId;
            assignment.topic = localStorage.getItem("topicDescExistAssigment");
            if (this.newTopicId == this.originalTopicId) {
                const existingOriginalAssignment = this.originalPhraseAssignmentDetails.filter(x => x.id == assignment.id);
                if (existingOriginalAssignment.length > 0) {
                    assignment.assignmentStatusText = existingOriginalAssignment[0].assignmentStatusText;
                }
            } else {
                if (assignment.assignmentStatus == 'Accepted') {
                    assignment.assignmentStatusText = "To be assessed";
                }
            }
        });
    }

    public getTopicNavigatorFilterObject(): FilterObject {
        localStorage.setItem("topicDescExistAssigment", this.phrase.topicText);
        return {
            filterId1: this.phrase.unileverProductDivisionId,
        };
    }

    restorePhrase(isConfirmed: boolean = false) {
        this.isLoading = true;
        this.editPhraseService.restorePhrase(this.phrase.id, isConfirmed)
            .then(result => {
                if (result.success) {
                    if (result.needsConfirmation) {
                        this.confirmationDialogService.question("Question", result.message)
                            .then(resultData => {
                                if (resultData) {
                                    this.restorePhrase(resultData);
                                }
                            }).catch((error) => {
                                this.isLoading = false;
                                this.alertDialogService.alert('Error', error);
                            });
                    } else {
                        this.activeModal.close(result);
                    }
                } else {
                    this.alertDialogService.alert('Error', result.message);
                }
                this.isLoading = false;
            })
            .catch(error => {
                this.alertDialogService.alert('Error', error);
                this.isLoading = false;
            });
    }

    /**
     * Detects a UPD change so that we can set a loading flag in order
     * to disable the page.
     */
    onUpdNavigatorModelChange() {
        this.updsLoading = false;
    }
    onLoadTopics(event) {
        this.isTopicsLoaded = event;
    }

    showSpinner(): boolean {
        return this.isLoading || this.isTopicsLoaded || this.isAssignmentsLoaded ||
            (this.selectedTab == 'phrase' ? (!this.phrase.topicId || !this.phrase.unileverProductDivisionId || this.topicsLoading || this.updsLoading)
                : this.phraseAssignmentsLoading);
    }

    switchTab(event) {
        this.selectedTab = event.nextId;
    }

    pageChangedForExistingAssignment(pageNr) {
        this.toPageForExistingAssignment = pageNr * 20;
        this.fromPageForExistingAssignment = this.toPageForExistingAssignment - 19;
        this.isAssignmentsLoaded = true;
        this.callPhraseOriginalAssignments();
    }

    assignmentFilterChangedDetails(filterData) {
        if (this.marketForExistingAssignment != filterData.market ||
            this.rpcForExistingAssignment != filterData.rpc ||
            (filterData.upd != null &&
                filterData.upd != undefined &&
                this.updForExistingAssignment != filterData.upd) ||
            (filterData.topic != null &&
                filterData.topic != undefined &&
                this.topicForExistingAssignment != filterData.topic)) {
            this.marketForExistingAssignment = filterData.market != undefined ? filterData.market : "";
            this.rpcForExistingAssignment = filterData.rpc != undefined ? filterData.rpc : "";
            this.updForExistingAssignment = filterData.upd != undefined ? filterData.upd : "";
            this.topicForExistingAssignment = filterData.topic != undefined ? filterData.topic : "";
            this.isAssignmentsLoaded = true;
            this.callPhraseOriginalAssignments();
        }
    }

    identify(index, item) {
        return item.label;
     }
}
