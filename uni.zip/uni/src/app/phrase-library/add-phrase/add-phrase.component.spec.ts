import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { By } from '@angular/platform-browser';

import { AddPhraseComponent, MISSING_ASSIGNMENTS_ERROR, MISSING_TEXT_ERROR } from './add-phrase.component';
import { getTestPhraseData } from '../../testData';
import { ToolsModule } from '../../tools/tools.module';
import { SharedComponentsModule } from '../../shared-components/shared-components.module';
import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';
import { ConfirmationDialogService } from '../../shared-components/confirmation-dialog/confirmation-dialog.service';
import { AuthorizationService } from '../../authorization/authorization.service';
import { HttpService } from '../../tools/services/http.service';
import { Permission } from '../../tools/shared-types/permissions/permission';
import { DetailLevel } from '../../tools/common.types';
import { CacheService } from '../../tools/services/cache.service';

class NgbActiveModalMock { }
class AlertDialogServiceMock {
  alert() {}
}
class ConfirmationDialogServiceMock { }
class HttpServiceMock {
  postContentPromise(): Promise<object> {
    return new Promise<object>((resolve, reject) => {
      resolve({});
    });
  }
}
class CacheServiceMock {
  getDetailLevels(): Promise<DetailLevel[]> {
    return new Promise<DetailLevel[]>((resolve, reject) => {
      resolve(new Array<DetailLevel>());
    });
  }
}
let userHasPermissionToWriteWithAssignments: boolean;
let userHasPermissionToWriteWithoutAssignments: boolean;
class AuthorizationServiceMock {
  checkUserHasAnyPermission(permissionsToCheck: Permission[]) {
    if (permissionsToCheck.some(p => p == Permission.AraPReFDCT_Phrases_WriteWithAssignments)) {
      return userHasPermissionToWriteWithAssignments;
    }

    if (permissionsToCheck.some(p => p == Permission.AraPReFDCT_Phrases_WriteWithoutAssignments)) {
      return userHasPermissionToWriteWithoutAssignments;
    }
  }
}

describe('AddPhraseComponent', () => {
  let component: AddPhraseComponent;
  let fixture: ComponentFixture<AddPhraseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ToolsModule,
        SharedComponentsModule,
        NgbModule
      ],
      declarations: [
        AddPhraseComponent
      ],
      providers: [
        { provide: NgbActiveModal, useClass: NgbActiveModalMock },
        { provide: AlertDialogService, useClass: AlertDialogServiceMock },
        { provide: ConfirmationDialogService, useClass: ConfirmationDialogServiceMock },
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
        { provide: CacheService, useClass: CacheServiceMock },
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPhraseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot for step 2', () => {
    component.gotoAddAssignments();
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot with data defined', () => {
    component.phrase = getTestPhraseData();
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot for step 2 with data defined', () => {
    component.phrase = getTestPhraseData();
    component.gotoAddAssignments();
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when loading', () => {
    component.isLoading = true;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  describe('when user has permission to add phrases with assignments', () => {
    beforeEach(() => {
      // Assemble user with permission to add phrases
      userHasPermissionToWriteWithAssignments = true;
      component.addPhraseWithAssignmentPermissions = [
        Permission.AraPReFDCT_Phrases_WriteWithAssignments,
      ];
      component.phrase = getTestPhraseData();
      fixture.detectChanges();
    });

    describe('and when user has permission to add phrases without assignments', () => {
      beforeEach(() => {
        userHasPermissionToWriteWithoutAssignments = true;
        component.addPhraseWithoutAssignmentPermissions = [
          Permission.AraPReFDCT_Phrases_WriteWithoutAssignments,
        ];
        fixture.detectChanges();
      });

      describe('isEnabled', () => {
        it('should return true when all data available', () => {
          expect(component.isEnabled).toBeTruthy();
        });

        it('should return false when phrase text missing', () => {
          component.phrase.text = '';
          fixture.detectChanges();
          expect(component.isEnabled).toBeFalsy();
        });
      });

      describe('save button', () => {
        it('should be enabled when phrase text supplied and detail level specified', () => {
          // Assemble
          component.phrase.text = "text";
          component.phrase.detailLevelId = 2;
          fixture.detectChanges();

          // Assert
          const button = fixture.debugElement.query(By.css('#save-button'));
          expect(button).toBeTruthy();
          expect(button.properties.disabled).toBeFalsy();
        });

        it('should be disabled when phrase text supplied and detail level not specified', () => {
          // Assemble
          component.phrase.text = "text";
          component.phrase.detailLevelId = null;
          fixture.detectChanges();

          // Assert
          const button = fixture.debugElement.query(By.css('#save-button'));
          expect(button).toBeTruthy();
          expect(button.properties.disabled).toBeTruthy();
        });

        it('should be disabled when phrase text not supplied and detail level specified', () => {
          // Assemble
          component.phrase.text = null;
          component.phrase.detailLevelId = 2;
          fixture.detectChanges();

          // Assert
          const button = fixture.debugElement.query(By.css('#save-button'));
          expect(button).toBeTruthy();
          expect(button.properties.disabled).toBeTruthy();
        });
      });

      describe('saveButtonTooltipText', () => {
        it('should return empty when all data available', () => {
          expect(component.saveButtonTooltipText).toBeFalsy();
        });

        it('should return appropriate message when phrase text missing', () => {
          component.phrase.text = '';
          fixture.detectChanges();
          expect(component.saveButtonTooltipText).toBe(MISSING_TEXT_ERROR);
        });
      });
    });

    describe('and when user does not have permission to add phrases without assignments', () => {
      beforeEach(() => {
        userHasPermissionToWriteWithoutAssignments = false;
        component.addPhraseWithoutAssignmentPermissions = [];
        fixture.detectChanges();
      });

      describe('when phrase assignments exist on the phrase', () => {
        describe('isEnabled', () => {
          it('should return true', () => {
            expect(component.isEnabled).toBeTruthy();
          });
        });
      });

      describe('when phrase assignments do not exist on the phrase', () => {
        beforeEach(() => {
          component.phrase.assignments = [];
          fixture.detectChanges();
        });

        it('isEnabled should return false', () => {
          expect(component.isEnabled).toBeFalsy();
        });

        it('saveButtonTooltipText should return appropriate error message', () => {
          expect(component.saveButtonTooltipText).toBe(MISSING_ASSIGNMENTS_ERROR);
        });

        it('savePhrase should display alert dialog', () => {
          const dialogService = getTestBed().get(AlertDialogService);
          const spy = jest.spyOn(dialogService, 'alert');
          component.savePhrase();
          expect(spy).toHaveBeenCalled();
        });
      });
    });
  });

  describe('when user has permission to add phrases, without assignments', () => {
    beforeEach(() => {
      userHasPermissionToWriteWithAssignments = false;
      component.addPhraseWithAssignmentPermissions = [];
      userHasPermissionToWriteWithoutAssignments = true;
      component.addPhraseWithoutAssignmentPermissions = [
        Permission.AraPReFDCT_Phrases_WriteWithoutAssignments,
      ];
      component.phrase = getTestPhraseData();
      fixture.detectChanges();
    });

    describe('the save button', () => {
      it('should be enabled with no assignments', () => {
        component.phrase.assignments = [];
        fixture.detectChanges();
        const button = fixture.debugElement.query(By.css('#save-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeFalsy();
      });
    });

    describe('when phrase assignments exist on the phrase', () => {
      describe('isEnabled', () => {
        it('should return true', () => {
          expect(component.isEnabled).toBeTruthy();
        });
      });
    });

    describe('when phrase assignments do not exist on the phrase', () => {
      beforeEach(() => {
        component.phrase.assignments = [];
        fixture.detectChanges();
      });

      describe('isEnabled', () => {
        it('should return true', () => {
          expect(component.isEnabled).toBeTruthy();
        });
      });

      describe('saveButtonTooltipText', () => {
        it('should return empty', () => {
          expect(component.saveButtonTooltipText).toBeFalsy();
        });
      });

      describe('savePhrase', () => {
        it('should not display alert dialog', () => {
          const dialogService = getTestBed().get(AlertDialogService);
          const spy = jest.spyOn(dialogService, 'alert');
          component.savePhrase();
          expect(spy).not.toHaveBeenCalled();
        });
      });
    });
  });


  describe('when user does not have permission to add phrases, with or without assignments', () => {
    beforeEach(() => {
      // Assemble user without permission to add phrases
      userHasPermissionToWriteWithAssignments = false;
      userHasPermissionToWriteWithoutAssignments = false;
      component.phrase = getTestPhraseData();
      fixture.detectChanges();
    });

    describe('the save button', () => {
      it('should be disabled', () => {
        // Assert
        const button = fixture.debugElement.query(By.css('#save-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeTruthy();
      });
    });

    describe('isEnabled', () => {
      it('should return false', () => {
        // Assert
        expect(component.isEnabled).toBeFalsy();
      });
    });
  });

  describe('loading spinner', () => {
    it('displays when isLoading is true', () => {
      component.isLoading = true;
      component.currentStep = 0;
      fixture.detectChanges();

      const spinner = fixture.debugElement.query(By.css('#spinner'));
      expect(spinner.attributes['ng-reflect-active']).toBe('true');

      component.currentStep = 1;
      fixture.detectChanges();

      expect(spinner.attributes['ng-reflect-active']).toBe('true');
    });

    it('displays when isLoading is false but step one is displayed and loading', () => {
      component.isLoading = false;
      component.currentStep = 0;
      component.addPhraseStep1Loading = true;
      fixture.detectChanges();

      const spinner = fixture.debugElement.query(By.css('#spinner'));
      expect(spinner.attributes['ng-reflect-active']).toBe('true');
    });

    it('does not display when isLoading is false and step one is displayed and not loading', () => {
      component.isLoading = false;
      component.currentStep = 0;
      component.addPhraseStep1Loading = false;
      fixture.detectChanges();

      const spinner = fixture.debugElement.query(By.css('#spinner'));
      expect(spinner.attributes['ng-reflect-active']).toBe('false');
    });

    it('displays when isLoading is false but step two is displayed and loading', () => {
      component.isLoading = false;
      component.currentStep = 1;
      component.phraseAssignmentsLoading = true;
      fixture.detectChanges();

      const spinner = fixture.debugElement.query(By.css('#spinner'));
      expect(spinner.attributes['ng-reflect-active']).toBe('true');
    });

    it('does not display when isLoading is false and step two is displayed and not loading', () => {
      component.isLoading = false;
      component.currentStep = 1;
      component.phraseAssignmentsLoading = false;
      fixture.detectChanges();

      const spinner = fixture.debugElement.query(By.css('#spinner'));
      expect(spinner.attributes['ng-reflect-active']).toBe('false');
    });
  });
});
