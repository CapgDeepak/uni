import { Component, Output, ViewEncapsulation, forwardRef, EventEmitter } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

import { DetailLevel, FilterObject } from '../../tools/common.types';
import { QuillSettingsService } from '../../tools/services/quill-settings.service';
import { DetailLevels } from '../../tools/constants';
import { Phrase, EmptyPhrase } from '../phrase-library.types';
import { CacheService } from './../../tools/services/cache.service';
import { PhraseService } from '../../tools/services/phrase.service';
import { PhraseSimpleModel } from '../../tools/shared-types/phrase.types';

const noop = () => {
};

@Component({
  selector: 'ara-add-phrase-step1',
  templateUrl: './add-phrase-step1.component.html',
  styleUrls: ['./add-phrase-step1.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => AddPhraseStep1Component),
      multi: true
    }
  ]
})
export class AddPhraseStep1Component implements ControlValueAccessor {
  @Output() public quillmodules;
  @Output() public quillformats;
  @Output() public isLoadingEvent: EventEmitter<boolean> = new EventEmitter<boolean>();

  public detailLevels: DetailLevel[] = new Array<DetailLevel>();

  public phrasesToLinkAgainst: PhraseSimpleModel[];
  public previousTopicId: number;
  public phrase: Phrase = new EmptyPhrase();

  isLoadingDetails: boolean = false;
  isLoadingUpds: boolean = false;
  isLoadingTopics: boolean = false;
  isLoadingPhrasesToLinkAgainst: boolean = false;

  constructor(
    quillSettings: QuillSettingsService,
    private cacheService: CacheService,
    private phraseService: PhraseService,
  ) {
    this.quillformats = quillSettings.quillformats;
    this.quillmodules = quillSettings.quillmodules;

    this.loadDetailLevels();
  }

  private loadDetailLevels() {
    this.isLoadingDetails = true;
    this.emitLoadingState();
    this.cacheService.getDetailLevels()
      .then((detailLevels: DetailLevel[]) => {
        this.detailLevels = detailLevels;
        this.isLoadingDetails = false;
        this.emitLoadingState();
      }).catch((err: any) => {
        console.log('err', err);
        this.isLoadingDetails = false;
        this.emitLoadingState();
      });
  }

  get value(): any {
    return this.phrase;
  }
  set value(newValue: any) {
    if (this.phrase != newValue) {
      if (newValue == null) {
        this.phrase = new EmptyPhrase();
      }
      else {
        this.phrase = newValue;
      }
    }
  }

  identify(index, item) {
    return item.label;
 }

  emitLoadingState() {
    this.isLoadingEvent.emit(this.isLoadingDetails || this.isLoadingTopics || this.isLoadingPhrasesToLinkAgainst || this.isLoadingUpds);
  }

  private onTouchedCallback: () => void = noop;
  private onChangeCallback: (_: any) => void = noop;

  writeValue(obj: any): void {
    this.value = obj;
  }
  registerOnChange(fn: any): void {
    this.onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }

  public get isDetailedPhrase() {
    return this.phraseService.isDetailedPhrase(this.phrase.detailLevelId, this.detailLevels);
  }

  /**
   * Handles the change of a linked phrase ID.
   * @param linkedPhraseId the ID of the newly selected linked phrase
   */
  public linkedPhraseIdChange(linkedPhraseId: any) {
    this.phrase.linkedGenericPhraseId = null;
    this.phrase.linkedSpecificPhraseIds = (linkedPhraseId != null && linkedPhraseId.length > 0) ? [...linkedPhraseId.map(function(a) { return a.phraseId; })] : null;
  }

  handleTopicsLoading(event: boolean) {
    this.isLoadingTopics = event;
    this.emitLoadingState();
  }

  handleUpdsLoading(event: boolean) {
    this.isLoadingUpds = event;
    this.emitLoadingState();
  }

  /**
   * Handles a user selecting a new topic in the tree navigator (any level).
   * Retrieves the appropriate phrases to link against based on the new topic Id.
   * @param topicId the ID of the topic for which to retrieve the phrases to link against.
   */
  public onTopicChange(topicId: number) {
    this.emitLoadingState();
    if ((topicId == this.previousTopicId) || this.isLoadingPhrasesToLinkAgainst) {
      return;
    }
    this.previousTopicId = topicId;

    const standardDetailLevels = this.detailLevels.filter(dl => dl.description == DetailLevels.Standard);
    if (!standardDetailLevels || !standardDetailLevels.length) {
      console.error("Detail level not found.");
      return;
    }
    this.isLoadingPhrasesToLinkAgainst = true;
    this.emitLoadingState();
    this.phraseService.getPhrasesToLinkAgainst(standardDetailLevels[0].id, topicId)
      .subscribe((res: PhraseSimpleModel[]) => {
        this.phrasesToLinkAgainst = res;
        this.isLoadingPhrasesToLinkAgainst = false;
        this.emitLoadingState();
      }, (err: any) => {
        this.phrasesToLinkAgainst = [];
        this.isLoadingPhrasesToLinkAgainst = false;
        this.emitLoadingState();
      });
  }

  public getTopicNavigatorFilterObject(): FilterObject {
    return {
      filterId1: this.phrase.unileverProductDivisionId,
    };
  }

}