export interface TopicInformation {

}
