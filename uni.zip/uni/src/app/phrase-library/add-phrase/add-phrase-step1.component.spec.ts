import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Observable, of } from 'rxjs';

import { AddPhraseStep1Component } from './add-phrase-step1.component';
import { getTestPhraseData } from '../../testData';
import { QuillSettingsService } from '../../tools/services/quill-settings.service';
import { HttpService } from '../../tools/services/http.service';
import { DetailLevel } from '../../tools/common.types';
import { CacheService } from '../../tools/services/cache.service';
import { PhraseService } from '../../tools/services/phrase.service';
import { PhraseSimpleModel } from '../../tools/shared-types/phrase.types';

class QuillSettingsServiceMock { }
class HttpServiceMock { }
const detailLevels: DetailLevel[] = [
  {
    id: 1,
    description: "Standard"
  },
  {
    id: 2,
    description: "Detailed"
  },
  {
    id: 4,
    description: "Internal RA"
  },
];
class CacheServiceMock {
  getDetailLevels(): Promise<DetailLevel[]> {
    return new Promise<DetailLevel[]>((resolve, reject) => {
      resolve(detailLevels);
    });
  }
}
let isDetailedPhrase: boolean = false;
class PhraseServiceMock {
  getPhrasesToLinkAgainst(): Observable<PhraseSimpleModel[]> {
    return of([
      {
        phraseId: 1,
        nr: 100,
      }
    ]);
  }
  isDetailedPhrase(): boolean {
    return isDetailedPhrase;
  }
}

describe('AddPhraseStep1Component', () => {
  let component: AddPhraseStep1Component;
  let fixture: ComponentFixture<AddPhraseStep1Component>;
  let injector: TestBed;
  let phraseService: PhraseService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AddPhraseStep1Component],
      providers: [
        { provide: QuillSettingsService, useClass: QuillSettingsServiceMock },
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: CacheService, useClass: CacheServiceMock },
        { provide: PhraseService, useClass: PhraseServiceMock },
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
      .compileComponents();
    injector = getTestBed();
    phraseService = injector.get(PhraseService);

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPhraseStep1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot with upd defined', () => {
    component.phrase = getTestPhraseData();
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  describe('detail level control', () => {
    it('should be empty by default', () => {
      // Assemble
      component.isLoadingDetails = false;
      fixture.detectChanges();

      // Assert
      const control = fixture.debugElement.query(By.css('#detail-level-control'));
      expect(control).toBeTruthy();
      expect(control.nativeElement.value).toBeFalsy();
      // We can assert that something is not falsy, but 0 is also falsy, and
      // so we must check that the dropdown value does not equal zero.
      expect(control.nativeElement.value).not.toEqual(0);
    });
  });

  describe('when phrase is detailed', () => {
    beforeEach(() => {
      isDetailedPhrase = true;
      component.isLoadingDetails = false;
      fixture.detectChanges();
    });

    describe('linked phrase control', () => {
      it('should be visible', () => {
        // Assert
        const control = fixture.debugElement.query(By.css('#linked-phrase-component'));
        expect(control).toBeTruthy();
      });
    });
  });

  describe('when phrase is not detailed', () => {
    beforeEach(() => {
      isDetailedPhrase = false;
      component.isLoadingDetails = false;
      fixture.detectChanges();
    });

    describe('linked phrase control', () => {
      it('should be hidden', () => {
        // Assert
        const control = fixture.debugElement.query(By.css('#linked-phrase-component'));
        expect(control).toBeFalsy();
      });
    });
  });

  describe('onTopicChange', () => {
    beforeEach(() => {
      jest.spyOn(phraseService, 'getPhrasesToLinkAgainst');
      component.isLoadingPhrasesToLinkAgainst = false;
      component.phrasesToLinkAgainst = new Array<PhraseSimpleModel>();
      component.previousTopicId = 77;
      fixture.detectChanges();
    });

    describe('should not be called when', () => {
      it('the topicId has not changed', () => {
        // Assemble
        component.previousTopicId = 99;

        // Act
        component.onTopicChange(99);

        // Assert
        expect(phraseService.getPhrasesToLinkAgainst).not.toHaveBeenCalled();
      });
      it('phrases to link against are loading', () => {
        // Assemble
        component.isLoadingPhrasesToLinkAgainst = true;

        // Act
        component.onTopicChange(99);

        // Assert
        expect(phraseService.getPhrasesToLinkAgainst).not.toHaveBeenCalled();
      });
    });

    describe('should be called with appropriate arguments when', () => {
      it('phrases to link against are not loading and not available and selected topic id does not match the topic id of the phrase', () => {
        // Act
        component.onTopicChange(99);

        // Assert
        expect(phraseService.getPhrasesToLinkAgainst).toHaveBeenCalledWith(1, 99);
      });
    });
  });
  describe('handleUpdsLoading should set loading flag correctly when called', () => {
    it('with true', () => {
      component.handleUpdsLoading(true);
      expect(component.isLoadingUpds).toBeTruthy();
    });
    it('with false', () => {
      component.handleUpdsLoading(false);
      expect(component.isLoadingUpds).toBeFalsy();
    });
  });
  describe('handleTopicsLoading should set loading flag correctly when called', () => {
    it('with true', () => {
      component.handleTopicsLoading(true);
      expect(component.isLoadingTopics).toBeTruthy();
    });
    it('with false', () => {
      component.handleTopicsLoading(false);
      expect(component.isLoadingTopics).toBeFalsy();
    });
  });

  describe('emitLoadingState should emit', () => {
    it('false initially', () => {
      spyOn(component.isLoadingEvent, 'emit');
      component.emitLoadingState();
      expect(component.isLoadingEvent.emit).toHaveBeenCalledTimes(1);
      expect(component.isLoadingEvent.emit).toHaveBeenCalledWith(false);
    });
    it('true when isLoadingUpds is true', () => {
      spyOn(component.isLoadingEvent, 'emit');
      component.isLoadingUpds = true;
      component.emitLoadingState();
      expect(component.isLoadingEvent.emit).toHaveBeenCalledTimes(1);
      expect(component.isLoadingEvent.emit).toHaveBeenCalledWith(true);
    });
    it('true when isLoadingDetails is true', () => {
      spyOn(component.isLoadingEvent, 'emit');
      component.isLoadingDetails = true;
      component.emitLoadingState();
      expect(component.isLoadingEvent.emit).toHaveBeenCalledTimes(1);
      expect(component.isLoadingEvent.emit).toHaveBeenCalledWith(true);
    });
    it('true when isLoadingPhrasesToLinkAgainst is true', () => {
      spyOn(component.isLoadingEvent, 'emit');
      component.isLoadingPhrasesToLinkAgainst = true;
      component.emitLoadingState();
      expect(component.isLoadingEvent.emit).toHaveBeenCalledTimes(1);
      expect(component.isLoadingEvent.emit).toHaveBeenCalledWith(true);
    });
    it('true when isLoadingTopics is true', () => {
      spyOn(component.isLoadingEvent, 'emit');
      component.isLoadingTopics = true;
      component.emitLoadingState();
      expect(component.isLoadingEvent.emit).toHaveBeenCalledTimes(1);
      expect(component.isLoadingEvent.emit).toHaveBeenCalledWith(true);
    });
  });

  describe('isLoadingEvent', () => {
    it('should emit true when handleUpdsLoading is called with true', () => {
      spyOn(component.isLoadingEvent, 'emit');
      component.handleUpdsLoading(true);
      fixture.detectChanges();

      expect(component.isLoadingEvent.emit).toHaveBeenCalledTimes(1);
      expect(component.isLoadingEvent.emit).toHaveBeenCalledWith(true);
    });

    it('should emit true when handleTopicsLoading is called with true', () => {
      spyOn(component.isLoadingEvent, 'emit');
      component.handleTopicsLoading(true);
      fixture.detectChanges();

      expect(component.isLoadingEvent.emit).toHaveBeenCalledTimes(1);
      expect(component.isLoadingEvent.emit).toHaveBeenCalledWith(true);
    });

    it('should emit false when onTopicChange is called with isLoadingDetails false', () => {
      spyOn(component.isLoadingEvent, 'emit');
      component.isLoadingDetails = false;
      component.previousTopicId = 1;
      component.onTopicChange(1);
      fixture.detectChanges();

      expect(component.isLoadingEvent.emit).toHaveBeenCalledTimes(1);
      expect(component.isLoadingEvent.emit).toHaveBeenCalledWith(false);
    });

    it('should emit true when onTopicChange is called with isLoadingDetails true', () => {
      spyOn(component.isLoadingEvent, 'emit');
      component.isLoadingDetails = true;
      component.previousTopicId = 1;
      component.onTopicChange(1);
      fixture.detectChanges();

      expect(component.isLoadingEvent.emit).toHaveBeenCalledTimes(1);
      expect(component.isLoadingEvent.emit).toHaveBeenCalledWith(true);
    });

    it('should emit true when onTopicChange is called with isLoadingDetails false and topic changed', () => {
      spyOn(component.isLoadingEvent, 'emit');
      component.isLoadingDetails = false;
      component.previousTopicId = 2;
      component.onTopicChange(1);
      fixture.detectChanges();

      expect(component.isLoadingEvent.emit).toHaveBeenCalledTimes(3);
      expect(component.isLoadingEvent.emit).toHaveBeenNthCalledWith(1, false);
      expect(component.isLoadingEvent.emit).toHaveBeenNthCalledWith(2, true);
      expect(component.isLoadingEvent.emit).toHaveBeenNthCalledWith(3, false);
    });
  });
});
