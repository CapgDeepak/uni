import { Component, Output, OnInit, ChangeDetectorRef } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { Phrase, EmptyPhrase } from '../phrase-library.types';
import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';
import { ConfirmationDialogService } from './../../shared-components/confirmation-dialog/confirmation-dialog.service';
import { UrlEndpoint, MISSING_DETAIL_LEVEL_ERROR } from '../../tools/constants';
import { HttpService } from '../../tools/services/http.service';
import { Permission } from '../../tools/shared-types/permissions/permission';
import { AuthorizationService } from '../../authorization/authorization.service';
import { CacheService } from '../../tools/services/cache.service';
import { DetailLevel } from '../../tools/common.types';

export const MISSING_ASSIGNMENTS_ERROR = 'A phrase cannot be saved without assignments.';
export const MISSING_TEXT_ERROR = 'A phrase cannot be saved without text specified.';

@Component({
  selector: 'ara-add-phrase',
  templateUrl: './add-phrase.component.html',
  styleUrls: ['./add-phrase.component.scss']
})
export class AddPhraseComponent implements OnInit {
  public phrase: Phrase = new EmptyPhrase();
  public isLoading: boolean = false;
  public addPhraseStep1Loading: boolean = false;
  public phraseAssignmentsLoading: boolean = false;
  public addPhraseWithAssignmentPermissions: Permission[] = [
    Permission.AraPReFDCT_Phrases_WriteWithAssignments,
  ];
  public addPhraseWithoutAssignmentPermissions: Permission[] = [
    Permission.AraPReFDCT_Phrases_WriteWithoutAssignments,
  ];
  public detailLevels: DetailLevel[] = [];

  constructor(
    public activeModal: NgbActiveModal,
    private alertDialogService: AlertDialogService,
    private confirmationDialogService: ConfirmationDialogService,
    private httpService: HttpService,
    public authorizationService: AuthorizationService,
    private cacheService: CacheService,
    private cdRef: ChangeDetectorRef,
  ) {
    this.cacheService.getDetailLevels().then((result: DetailLevel[]) => {
      this.detailLevels = result;
    });
    this.phrase.isActive = true;
  }

  ngOnInit(): void {
  }

  handleAddPhraseStep1Loading(event: boolean) {
    this.addPhraseStep1Loading = event;
    this.cdRef.detectChanges();
  }

  handlePhraseAssignmentsLoading(event: boolean) {
    this.phraseAssignmentsLoading = event;
    this.cdRef.detectChanges();
  }

  get topicId(): number {
    return this.phrase.topicId;
  }
  set topicId(value: number) {
    if (this.phrase.topicId != value) {
      this.phrase.topicId = value;
    }
  }

  get topicText(): string {
    return this.phrase.topicText;
  }
  set topicText(value: string) {
    if (this.phrase.topicText != value) {
      this.phrase.topicText = value;
    }
  }

  preSelectTopicId(topicId: number) {
    this.topicId = topicId;
  }

  preSelectTopicText(topicText: string) {
    this.topicText = topicText;
  }

  @Output() currentStep: number = 0;

  gotoStep1() {
    this.currentStep = 0;
  }

  gotoAddAssignments() {
    this.currentStep = 1;
  }

  /**
   * Gets a value representing whether or not the save action should be possible
   * for the current user, based on the current selection.
   * For saving to be possible, the phrase must have text AND
   *  (A) the user should be able to add a phrase without assignments
   *  OR
   *  (B) the user should be able to add a phrase with assignments and assignments must exist
   */
  get isEnabled(): boolean {
    return this.phrase.text &&
      this.phraseDetailLevelSpecified &&
      (this.addPhraseWithoutAssignmentsAllowed ||
        (this.addPhraseWithAssignmentsAllowed && this.phrase.assignments.length > 0));
  }

  public get saveButtonTooltipText(): string {
    let tooltip = '';
    if (!this.isEnabled) {
      if (!this.phrase.text) {
        tooltip = MISSING_TEXT_ERROR;
      } else if (!this.phraseDetailLevelSpecified) {
        tooltip = MISSING_DETAIL_LEVEL_ERROR;
      } else if (this.phrase.assignments.length == 0 && !this.addPhraseWithoutAssignmentsAllowed) {
        tooltip = MISSING_ASSIGNMENTS_ERROR;
      }
    }
    return tooltip;
  }

  get phraseDetailLevelSpecified(): boolean {
    return !!(this.phrase.detailLevelId || this.phrase.detailLevelId == 0);
  }

  cancelPhrase() {
    this.confirmationDialogService.question("Confirmation", "Are you sure you want to cancel the creation of this phrase?").then(result => {
      if (result) {
        this.activeModal.close('Cancel');
      }
    });
  }

  savePhrase() {
    if (this.phrase.assignments.length == 0 && !this.addPhraseWithoutAssignmentsAllowed) {
      this.alertDialogService.alert('Error', MISSING_ASSIGNMENTS_ERROR);
      return;
    }
    this.phrase.text = this.phrase.text.replace('&amp;', '&');
    this.isLoading = true;
    this.httpService.postContentPromise(this.phrase, UrlEndpoint.PhraseLibrary_SavePhrase).then(result => {
      this.isLoading = false;
      if (result.success) {
        if (result.needsConfirmation) {
          this.confirmationDialogService.question("Question", result.message).then(resultData => {
            if (resultData) {
              this.phrase.confirmed = true;
              this.savePhrase();
            }
          }).catch(error => this.handleSavePhraseError(error));
        }
        else {
          this.activeModal.close(result);
        }
      }
      else {
        this.alertDialogService.alert('Error', result.message);
      }
    }).catch(error => this.handleSavePhraseError(error));
  }

  private handleSavePhraseError(error: any): void {
    console.error('Error when saving phrase:', error);
    this.isLoading = false;
  }

  public get addPhraseWithAssignmentsAllowed(): boolean {
    return this.authorizationService.checkUserHasAnyPermission(this.addPhraseWithAssignmentPermissions);
  }

  public get addPhraseWithoutAssignmentsAllowed(): boolean {
    return this.authorizationService.checkUserHasAnyPermission(this.addPhraseWithoutAssignmentPermissions);
  }

  showSpinner(): boolean {
    return this.isLoading ||
      (this.currentStep === 0 ? this.addPhraseStep1Loading : this.phraseAssignmentsLoading);
  }
}
