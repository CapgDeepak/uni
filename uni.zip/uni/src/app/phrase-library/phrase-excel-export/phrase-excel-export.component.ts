import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { PhraseLibraryFilter } from '../phrase-library.types';
import { ExcelExportService } from '../../tools/services/excel-export.service';
import { Permission } from '../../tools/shared-types/permissions/permission';

@Component({
    selector: 'ara-phrase-excel-export',
    templateUrl: './phrase-excel-export.component.html',
    styleUrls: ['./phrase-excel-export.component.scss']
})
export class PhraseExcelExportComponent implements OnInit {
    public filter: PhraseLibraryFilter = new PhraseLibraryFilter();
    public isExporting: boolean = false;
    public exportPhrasePermissions: Permission[];
    public exportPhraseAssignmentPermissions: Permission[];

    urlEndpoint: string = 'PhraseLibrary';

    constructor(
        public activeModal: NgbActiveModal,
        private excelExportService: ExcelExportService,
    ) { }

    ngOnInit() {
        // Ideally this would just be set as a property on the component, but this breaks tests
        // for some reason, hence why we are setting it in the ngOnInit.
        this.exportPhrasePermissions = [Permission.AraPReFDCT_Phrases_Read];
        this.exportPhraseAssignmentPermissions = [Permission.AraPReFDCT_Phrases_Read, Permission.AraPReFDCT_PhraseAssignments_Read];
    }

    exportAllPhrases() {
        this.isExporting = true;
        const  filter1: PhraseLibraryFilter = new PhraseLibraryFilter();
        this.excelExportService.exportContent('AllPhrases', this.urlEndpoint, filter1, false)
            .subscribe(() => this.isExporting = false,
             () => this.isExporting = false);
    }

    exportFilteredPhrases() {
        this.isExporting = true;
        this.excelExportService.exportContent('FilteredPhrases', this.urlEndpoint, this.filter, false)
            .subscribe(() => this.isExporting = false,
            () => this.isExporting = false);
    }

    exportAllAssignments() {
        this.isExporting = true;
        this.excelExportService.exportContent('AllPhraseAssignments', this.urlEndpoint, this.filter, true)
            .subscribe(() => this.isExporting = false,
            () => this.isExporting = false);
    }

    exportFilteredAssignments() {
        this.isExporting = true;
        this.excelExportService.exportContent('FilteredPhraseAssignments', this.urlEndpoint, this.filter, true)
            .subscribe(() => this.isExporting = false,
            () => this.isExporting = false);
    }
}
