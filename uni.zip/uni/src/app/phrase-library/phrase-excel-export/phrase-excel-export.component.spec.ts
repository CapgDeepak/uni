import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { PhraseExcelExportComponent } from './phrase-excel-export.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ExcelExportService } from '../../tools/services/excel-export.service';
import { ShowIfUserHasAnyPermissionDirective } from '../../authorization/directives/show-if-user-has-any-permission.directive';
import { ShowIfUserHasAllPermissionsDirective } from '../../authorization/directives/show-if-user-has-all-permissions.directive';
import { AuthorizationService } from '../../authorization/authorization.service';
import { Permission } from '../../tools/shared-types/permissions/permission';

class NgbActiveModalMock { }
class ExcelExportServiceMock { }
let userHasAnyPermission: boolean;
let userHasAllPermissions: boolean;
class AuthorizationServiceMock {
  checkUserHasAnyPermission() {
    return userHasAnyPermission;
  }
  checkUserHasAllPermissions() {
    return userHasAllPermissions;
  }
}

describe('PhraseExcelExportComponent', () => {
  let component: PhraseExcelExportComponent;
  let fixture: ComponentFixture<PhraseExcelExportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        PhraseExcelExportComponent,
        ShowIfUserHasAnyPermissionDirective,
        ShowIfUserHasAllPermissionsDirective,
      ],
      providers: [
        { provide: NgbActiveModal, useClass: NgbActiveModalMock },
        { provide: ExcelExportService, useClass: ExcelExportServiceMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhraseExcelExportComponent);
    component = fixture.componentInstance;
    component.isExporting = false;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  describe('when user has permission to read phrases and phrase assignments', () => {
    beforeEach(() => {
      // Assemble
      userHasAnyPermission = true;
      userHasAllPermissions = true;
      component.ngOnInit();
      fixture.detectChanges();
    });

    describe('export filtered set of phrases button', () => {
      it ('should be visible', () => {
        // Assert
        const button = fixture.debugElement.query(By.css('#export-filtered-phrase-set-button'));
        expect(button).toBeTruthy();
      });
    });

    describe('export full set of phrases button', () => {
      it ('should be visible', () => {
        // Assert
        const button = fixture.debugElement.query(By.css('#export-full-phrase-set-button'));
        expect(button).toBeTruthy();
      });
    });

    describe('export filtered set of phrase assignments button', () => {
      it ('should be visible', () => {
        // Assert
        const button = fixture.debugElement.query(By.css('#export-filtered-phrase-assignment-set-button'));
        expect(button).toBeTruthy();
      });
    });

    describe('export full set of phrase assignments button', () => {
      it ('should be visible', () => {
        // Assert
        const button = fixture.debugElement.query(By.css('#export-full-phrase-assignment-set-button'));
        expect(button).toBeTruthy();
      });
    });
  });

  describe('when user only has permission to read phrases or phrase assignments (not both)', () => {
    beforeEach(() => {
      // Assemble
      userHasAnyPermission = true;
      userHasAllPermissions = false;
      component.ngOnInit();
      fixture.detectChanges();
    });

    describe('export filtered set of phrases button', () => {
      it ('should be visible', () => {
        // Assert
        const button = fixture.debugElement.query(By.css('#export-filtered-phrase-set-button'));
        expect(button).toBeTruthy();
      });
    });

    describe('export full set of phrases button', () => {
      it ('should be visible', () => {
        // Assert
        const button = fixture.debugElement.query(By.css('#export-full-phrase-set-button'));
        expect(button).toBeTruthy();
      });
    });

    describe('export filtered set of phrase assignments button', () => {
      it ('should be hidden', () => {
        // Assert
        const button = fixture.debugElement.query(By.css('#export-filtered-phrase-assignment-set-button'));
        expect(button).toBeFalsy();
      });
    });

    describe('export full set of phrase assignments button', () => {
      it ('should be hidden', () => {
        // Assert
        const button = fixture.debugElement.query(By.css('#export-full-phrase-assignment-set-button'));
        expect(button).toBeFalsy();
      });
    });
  });

  describe('when user does not have permission to read phrases or phrase assignments', () => {
    beforeEach(() => {
      // Assemble
      userHasAnyPermission = false;
      userHasAllPermissions = false;
      component.ngOnInit();
      fixture.detectChanges();
    });

    describe('export filtered set of phrases button', () => {
      it ('should be hidden', () => {
        // Assert
        const button = fixture.debugElement.query(By.css('#export-filtered-phrase-set-button'));
        expect(button).toBeFalsy();
      });
    });

    describe('export full set of phrases button', () => {
      it ('should be hidden', () => {
        // Assert
        const button = fixture.debugElement.query(By.css('#export-full-phrase-set-button'));
        expect(button).toBeFalsy();
      });
    });

    describe('export filtered set of phrase assignments button', () => {
      it ('should be hidden', () => {
        // Assert
        const button = fixture.debugElement.query(By.css('#export-filtered-phrase-assignment-set-button'));
        expect(button).toBeFalsy();
      });
    });

    describe('export full set of phrase assignments button', () => {
      it ('should be hidden', () => {
        // Assert
        const button = fixture.debugElement.query(By.css('#export-full-phrase-assignment-set-button'));
        expect(button).toBeFalsy();
      });
    });
  });

  describe('exportPhrasePermissions', () => {
    it('should hold appropriate permissions', () => {
      // Assemble
      const expectedPermissions: Permission[] = [Permission.AraPReFDCT_Phrases_Read];

      // Assert
      expect(component.exportPhrasePermissions).toEqual(expectedPermissions);
    });
  });

  describe('exportPhraseAssignmentPermissions', () => {
    it('should hold appropriate permissions', () => {
      // Assemble
      const expectedPermissions: Permission[] = [Permission.AraPReFDCT_Phrases_Read, Permission.AraPReFDCT_PhraseAssignments_Read];

      // Assert
      expect(component.exportPhraseAssignmentPermissions).toEqual(expectedPermissions);
    });
  });
});
