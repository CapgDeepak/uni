import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { Observable } from 'rxjs';

import { PhraseOrderingComponent } from './phrase-ordering.component';
import { AlertDialogService } from '../shared-components/alert-dialog/alert-dialog.service';
import { EmptyPhraseList, PhraseList } from './phrase-library.types';
import { getTestPhraseList, getTestListPhrase, getTestPhraseData } from '../testData';
import { HttpService } from '../tools/services/http.service';
import { AuthorizationService } from '../authorization/authorization.service';
import { ShowIfUserHasAnyPermissionDirective } from '../authorization/directives/show-if-user-has-any-permission.directive';
import { ToasterService } from 'angular2-toaster';
import { ConfirmationDialogService } from '../shared-components/confirmation-dialog/confirmation-dialog.service';


class AlertDialogServiceMock {
  alert() {}
}
class ToasterServiceMock { }
let phraseListToReturn: PhraseList;
let hasError: boolean = false;
class HttpServiceMock {
  postContentPromise(content: any, url: string) {
    return Promise.resolve(phraseListToReturn);
  }

  putContent(content: any, url: string) {
    return new Observable(observer => {
      observer.next([]);
      if (hasError) {
        observer.error('blah');
      } else {
        observer.complete();
      }
    });
  }
}

class ConfirmationDialogServiceMock {
  question(): Promise<boolean> {
    return new Promise(() => false);
  }
}

let userHasPermission: boolean = true;
class AuthorizationServiceMock {
  checkUserHasAnyPermission() {
    return userHasPermission;
  }
}

describe('PhraseOrderingComponent', () => {
  let component: PhraseOrderingComponent;
  let fixture: ComponentFixture<PhraseOrderingComponent>;
  let injector: TestBed;
  let httpService: HttpService;
  let alertService: AlertDialogService;
  let confirmationDialogService: ConfirmationDialogService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        PhraseOrderingComponent,
        ShowIfUserHasAnyPermissionDirective,
      ],
      providers: [
        { provide: AlertDialogService, useClass: AlertDialogServiceMock },
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
        { provide: ToasterService, useClass: ToasterServiceMock },
        { provide: ConfirmationDialogService, useClass: ConfirmationDialogServiceMock },
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
    .compileComponents();

    injector = getTestBed();
    httpService = getTestBed().get(HttpService);
    confirmationDialogService = injector.get(ConfirmationDialogService);
  }));

  beforeEach(() => {
    hasError = false;
    phraseListToReturn = new EmptyPhraseList();
    fixture = TestBed.createComponent(PhraseOrderingComponent);
    alertService = injector.get(AlertDialogService);
    component = fixture.componentInstance;
    jest.spyOn(component, 'filterChanged');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('snapshot tests', () => {
    it('should match snapshot', () => {
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('should match snapshot with topic ID set', () => {
      component.filter.topicId = 1;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });
  });

  describe('logic tests', () => {
    it('should not initially load any phrase data', () => {
      jest.clearAllMocks();
      jest.spyOn(component, 'loadPhraseData');
      component.ngOnInit();
      expect(component.loadPhraseData).toHaveBeenCalledTimes(0);
    });
    describe('topicChanged', () => {
      it('should update filter and call filter changed, when ID changes', () => {
        component.filter.topicId = 1;
        jest.clearAllMocks();
        component.topicChanged(2);
        expect(component.filter.topicId).toEqual(2);
        expect(component.filterChanged).toHaveBeenCalledTimes(1);
      });

      it('should not update filter or call filter changed, when ID stays the same', () => {
        component.filter.topicId = 2;
        jest.clearAllMocks();
        component.topicChanged(2);
        expect(component.filter.topicId).toEqual(2);
        expect(component.filterChanged).not.toHaveBeenCalled();
      });
    });

    describe('phraseOrderingAllowed', () => {
      it('should return false when expected', () => {
        // Assemble
        userHasPermission = false;

        // Assert
        expect(component.phraseOrderingAllowed).toBeFalsy();
      });
      it('should return false when expected', () => {
        // Assemble
        userHasPermission = true;

        // Assert
        expect(component.phraseOrderingAllowed).toBeTruthy();
      });
    });

    describe('filterChanged', () => {
      it('calls loadPhraseData', () => {
        // Assemble
        component.pageNr = 9;
        const loadPhraseSpy = jest.spyOn(component, 'loadPhraseData');

        // Act
        component.filterChanged();

        // Assert
        expect(loadPhraseSpy).toHaveBeenCalled();
        expect(component.pageNr).toBe(9);
      });
    });

    describe('isPromoteDisabled', () => {
      it('returns true when no rows selected', () => {
        // Assemble / Act
        component.selectedId = -1;
        // Assert
        expect(component.isPromoteDisabled).toBeTruthy();
      });
      it('returns false when row selected', () => {
        // Assemble / Act
        component.selectedId = 1;
        // Assert
        expect(component.isPromoteDisabled).toBeFalsy();
      });
      it('returns true when row selected at group and page top', () => {
        // Assemble / Act
        setupPhrasesWithTopSelected(component);
        // Assert
        expect(component.isPromoteDisabled).toBeTruthy();
      });
      it('returns false when row selected at group top but not and page list top', () => {
        // Assemble / Act
        setupPhrasesWithTopSelected(component);
        component.pageNr = 2;
        // Assert
        expect(component.isPromoteDisabled).toBeFalsy();
      });
    });

    describe('isDemoteDisabled', () => {
      it('returns true when no rows selected', () => {
        // Assemble / Act
        component.selectedId = -1;
        // Assert
        expect(component.isDemoteDisabled).toBeTruthy();
      });
      it('returns false when row selected', () => {
        // Assemble / Act
        component.selectedId = 1;
        // Assert
        expect(component.isDemoteDisabled).toBeFalsy();
      });
      it('returns true when row selected at group and page bottom', () => {
        // Assemble / Act
        setupPhrasesWithBottomSelected(component);
        // Assert
        expect(component.isDemoteDisabled).toBeTruthy();
      });
      it('returns false when row selected at group bottom but not page list bottom', () => {
        // Assemble / Act
        setupPhrasesWithBottomSelected(component);
        component.pageNr = component.phraseList.pageCount - 1;
        // Assert
        expect(component.isDemoteDisabled).toBeFalsy();
      });
    });

    describe('selectPhrase', () => {
      it('sets data appropriately', () => {
        // Assemble
        const listPhrase = getTestListPhrase();

        // Act
        component.selectPhrase(listPhrase);

        // Assert
        expect(component.selectedId).toBe(listPhrase.id);
        expect(component.selectedPhraseId).toBe(listPhrase.phraseId);
        expect(component.selectedPhrase).toBe(listPhrase);
      });
    });

    describe('tooltips', () => {
      it('demoteOrderButtonTooltipText displays correctly when bottom row in page selected', () => {
        setupPhrasesWithBottomSelected(component);
        component.pageNr = component.phraseList.pageCount - 1;
        expect(component.demoteOrderButtonTooltipText).toBe('Demote item in the sort order');
      });

      it('demoteOrderButtonTooltipText displays correctly when last row', () => {
        setupPhrasesWithBottomSelected(component);
        expect(component.demoteOrderButtonTooltipText).toBe('This item is already at the bottom of its Topic group');
      });

      it('demoteOrderButtonTooltipText displays correctly when no row selected', () => {
        expect(component.demoteOrderButtonTooltipText).toBe('Select a row in the table');
      });

      it('demoteOrderButtonTooltipText displays correctly when row row selected', () => {
        component.selectedId = 2;
        expect(component.demoteOrderButtonTooltipText).toBe('Demote item in the sort order');
      });

      it('promoteOrderButtonTooltipText displays correctly when no row selected', () => {
        expect(component.promoteOrderButtonTooltipText).toBe('Select a row in the table');
      });

      it('promoteOrderButtonTooltipText displays correctly when top row selected', () => {
        setupPhrasesWithTopSelected(component);
        expect(component.promoteOrderButtonTooltipText).toBe('This item is already at the top of its Topic group');
      });

      it('promoteOrderButtonTooltipText displays correctly when top row on later page selected', () => {
        setupPhrasesWithTopSelected(component);
        component.pageNr = 2;
        expect(component.promoteOrderButtonTooltipText).toBe('Promote item in the sort order');
      });

      it('promoteOrderButtonTooltipText displays correctly when row row selected', () => {
        component.selectedId = 2;
        expect(component.promoteOrderButtonTooltipText).toBe('Promote item in the sort order');
      });
    });

    describe('loadPhraseData', () => {
      it('resets selection if loaded data does not include selection', async() => {
        // Assemble
        component.pageNr = 9;
        component.selectedId = 22;
        component.selectedPhraseId = 33;
        const loadPhraseSpy = jest.spyOn(component, 'loadPhraseData');
        fixture.detectChanges();

        // Act
        await component.loadPhraseData();

        // Assert
        expect(loadPhraseSpy).toHaveBeenCalled();
        expect(component.selectedId).toBe(-1);
        expect(component.selectedPhraseId).toBe(-1);
      });

      it('retains selection if loaded data does include selection', async() => {
        // Assemble
        component.pageNr = 9;
        component.selectedId = 1;
        component.selectedPhraseId = 1;
        phraseListToReturn = getTestPhraseList();
        const loadPhraseSpy = jest.spyOn(component, 'loadPhraseData');

        // Act
        await component.loadPhraseData();

        // Assert
        expect(loadPhraseSpy).toHaveBeenCalled();
        expect(component.selectedPhraseId).toBe(1);
      });
    });

    describe('linkedPhraseNrs', () => {
      it('returns the linkedGenericPhraseNr for detailed phrases', () => {
        // Assemble
        const phrase = { detailLevelDescription: 'Detailed', linkedGenericPhraseNr: 1, linkedSpecificPhraseNrs: [2, 3, 4]};

        // Assert
        expect(component.linkedPhraseNrs(phrase)).toEqual('');
      });

      it('returns the correctly formatted linkedSpecificPhraseNrs for standard phrases', () => {
        // Assemble
        const phrase = { detailLevelDescription: 'Standard', linkedGenericPhraseNr: 1, linkedSpecificPhraseNrs: [2, 3, 4]};

        // Assert
        expect(component.linkedPhraseNrs(phrase)).toEqual('');
      });
    });

    describe('onPromoteOrderButtonClick', () => {
      beforeEach(() => {
        component.selectedPhrase = getTestListPhrase();
      });

      it('calls promoteOrDemoteTopicOrder and loadPhraseData when phrase ID set', () => {
        // Assemble
        component.selectedPhraseId = 2;
        const reorderPhraseSpy = jest.spyOn(component, 'promoteOrDemoteTopicOrder');
        const loadPhraseSpy = jest.spyOn(component, 'loadPhraseData');

        // Act
        component.onPromoteOrderButtonClick();

        // Assert
        expect(reorderPhraseSpy).toHaveBeenCalledWith(true);
        expect(loadPhraseSpy).toHaveBeenCalledTimes(1);
      });
      it('does not call promoteOrDemoteTopicOrder when phrase ID not set', () => {
        // Assemble
        component.selectedPhraseId = -1;
        const reorderPhraseSpy = jest.spyOn(component, 'promoteOrDemoteTopicOrder');
        const loadPhraseSpy = jest.spyOn(component, 'loadPhraseData');

        // Act
        component.onPromoteOrderButtonClick();

        // Assert
        expect(reorderPhraseSpy).toHaveBeenCalledWith(true);
        expect(loadPhraseSpy).not.toHaveBeenCalled();
      });
      it('reports error on alertDialogService when error occurs', () => {
        // Assemble
        component.selectedPhraseId = 1;
        hasError = true;
        const reorderPhraseSpy = jest.spyOn(component, 'promoteOrDemoteTopicOrder');
        const loadPhraseSpy = jest.spyOn(component, 'loadPhraseData');
        alertService.alert = jest.fn();

        // Act
        component.onPromoteOrderButtonClick();

        // Assert
        expect(reorderPhraseSpy).toHaveBeenCalledWith(true);
        expect(loadPhraseSpy).toHaveBeenCalled();
        expect(alertService.alert).toHaveBeenCalledTimes(1);
      });
    });

    describe('onDemoteOrderButtonClick', () => {
      beforeEach(() => {
        component.selectedPhrase = getTestListPhrase();
      });

      it('calls promoteOrDemoteTopicOrder and loadPhraseData when phrase ID set', () => {
        // Assemble
        component.selectedPhraseId = 2;
        const reorderPhraseSpy = jest.spyOn(component, 'promoteOrDemoteTopicOrder');
        const loadPhraseSpy = jest.spyOn(component, 'loadPhraseData');

        // Act
        component.onDemoteOrderButtonClick();

        // Assert
        expect(reorderPhraseSpy).toHaveBeenCalledWith(false);
        expect(loadPhraseSpy).toHaveBeenCalledTimes(1);
      });
      it('does not call promoteOrDemoteTopicOrder when phrase ID not set', () => {
        // Assemble
        component.selectedPhraseId = -1;
        const reorderPhraseSpy = jest.spyOn(component, 'promoteOrDemoteTopicOrder');
        const loadPhraseSpy = jest.spyOn(component, 'loadPhraseData');

        // Act
        component.onDemoteOrderButtonClick();

        // Assert
        expect(reorderPhraseSpy).toHaveBeenCalledWith(false);
        expect(loadPhraseSpy).not.toHaveBeenCalled();
      });
      it('reports error on alertDialogService when error occurs', () => {
        // Assemble
        component.selectedPhraseId = 1;
        hasError = true;
        const reorderPhraseSpy = jest.spyOn(component, 'promoteOrDemoteTopicOrder');
        const loadPhraseSpy = jest.spyOn(component, 'loadPhraseData');
        alertService.alert = jest.fn();

        // Act
        component.onDemoteOrderButtonClick();

        // Assert
        expect(reorderPhraseSpy).toHaveBeenCalledWith(false);
        expect(loadPhraseSpy).toHaveBeenCalled();
        expect(alertService.alert).toHaveBeenCalledTimes(1);
      });
    });
  });
});

function setupPhrasesWithBottomSelected(component: PhraseOrderingComponent) {
  component.selectedId = 1;
  component.selectedPhraseId = 2;
  component.phraseList = getTestPhraseList();
  const newPhrase = getTestListPhrase();
  newPhrase.phraseId = 2;
  component.phraseList.phrases.push(newPhrase);
  component.pageNr = component.phraseList.pageCount;
}

function setupPhrasesWithTopSelected(component: PhraseOrderingComponent) {
  component.selectedId = 1;
  component.selectedPhraseId = 1;
  component.phraseList = getTestPhraseList();
  const newPhrase = getTestListPhrase();
  newPhrase.phraseId = 2;
  component.phraseList.phrases.push(newPhrase);
  component.pageNr = 1;
}

