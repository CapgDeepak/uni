import { Component, OnInit } from '@angular/core';
import { ToasterService } from 'angular2-toaster';

import { AlertDialogService } from '../shared-components/alert-dialog/alert-dialog.service';
import { CacheService } from '../tools/services/cache.service';
import { ConfirmationDialogService } from '../shared-components/confirmation-dialog/confirmation-dialog.service';
import { SideDialogService } from '../tools/side-dialog/side-dialog.service';

import { AddPhraseComponent } from './add-phrase/add-phrase.component';
import { ApprovePhraseComponent } from './approve-phrase/approve-phrase.component';
import { CopyPhraseComponent } from './copy-phrase/copy-phrase.component';
import { CopyPhraseParameters } from './copy-phrase/copy-phrase.types';
import { EditPhraseComponent } from './edit-phrase/edit-phrase.component';
import { PhraseExcelExportComponent } from './phrase-excel-export/phrase-excel-export.component';
import { PhraseWhereUsedComponent } from '../shared-components/phrase-where-used/phrase-where-used.component';

import { UrlEndpoint, ColumnSortOrder } from '../tools/constants';
import { DetailLevel, SaveResult } from '../tools/common.types';
import { PhraseLibraryFilter, PhraseList, EmptyPhraseList, ListPhrase, Phrase } from './phrase-library.types';
import { AuthorizationService } from '../authorization/authorization.service';
import { DialogService } from '../tools/services/dialog.service';
import { FilterService } from '../tools/services/filter.service';
import { HttpService } from '../tools/services/http.service';
import { Permission } from '../tools/shared-types/permissions/permission';
import { MarketAndUpdScopedPermissions } from '../tools/shared-types/permissions/market-and-upd-scoped-permissions';
import { EditPhraseService } from './edit-phrase/edit-phrase.service';
import { getLinkedPhraseNrsForPhrase } from '../tools/utils';

@Component({
    selector: 'ara-phrase-library',
    templateUrl: './phrase-library.component.html',
    styleUrls: ['./phrase-library.component.scss']
})
export class PhraseLibraryComponent implements OnInit {
    public approvePhrasePermissions: MarketAndUpdScopedPermissions = {
        permissions: [Permission.AraPReFDCT_Phrases_Approve],
        regulatoryMarketId: null,
        unileverProductDivisionId: null
    };
    public addPhrasePermissions: Permission[] = [
        Permission.AraPReFDCT_Phrases_WriteWithAssignments,
        Permission.AraPReFDCT_Phrases_WriteWithoutAssignments,
    ];
    public removePhrasePermissions: Permission[] = [
        Permission.AraPReFDCT_Phrases_Remove,
    ];

    public exportExcelPermissions: Permission[] = [
        Permission.AraPReFDCT_Phrases_Export,
        Permission.AraPReFDCT_PhraseAssignments_Export
    ];

    public whereUsedPermissions: Permission[] = [
        Permission.AraPReFDCT_PhraseAssignments_Read,
    ];

    public phraseList: PhraseList = new EmptyPhraseList();
    public filter: PhraseLibraryFilter = new PhraseLibraryFilter();
    public detailLevels: DetailLevel[] = new Array<DetailLevel>();

    public selectedId: number = -1;
    public selectedPhraseId: number = -1;
    public selectedPhraseMarketId: number = -1;
    public selectedPhraseUpdId: number = -1;
    public selectedPhrase: ListPhrase = null;
    public loadingPhrases = false;
    createModifyLable: string = 'Phase';

    constructor(
        private dialogService: DialogService,
        private alertDialogService: AlertDialogService,
        private cacheService: CacheService,
        private confirmationDialogService: ConfirmationDialogService,
        private sideDialogService: SideDialogService,
        private toasterService: ToasterService,
        private httpService: HttpService,
        private filterService: FilterService,
        private authorizationService: AuthorizationService,
        private editPhraseService: EditPhraseService,
    ) { }

    ngOnInit(): void {
        // load Phrase data after Topics are loaded (fix for performance issue)
        // this.filterChanged();
        this.loadingPhrases = true;

        this.cacheService.getDetailLevels().then(results => {
            this.detailLevels = results;
        });
    }

    public get pageNr(): number {
        return this.filter.pageNr + 1;
    }
    public set pageNr(value: number) {
        this.filter.pageNr = value - 1;
    }

    public get showAssignments(): boolean {
        return this.filter.showAssignments;
    }
    public set showAssignments(value: boolean) {
        if (this.filter.showAssignments != value) {
            this.filter.showAssignments = value;
            this.filterChanged();
        }
    }

    public get showAuditInfo(): boolean {
        return this.filter.showAuditInfo;
    }
    public set showAuditInfo(value: boolean) {
        if (this.filter.showAuditInfo != value) {
            this.filter.showAuditInfo = value;
            this.filterChanged();
        }
    }

    public get showInactive(): boolean {
        return this.filter.showInactive;
    }
    public set showInactive(value: boolean) {
        if (this.filter.showInactive != value) {
            this.filter.showInactive = value;
            this.filterChanged();
        }
    }

    // load Phrase data after Topics are loaded (fix for performance issue)
    callfilterChangedAfterTopicsLoaded(isTopicsLoaded: boolean) {
        if (!isTopicsLoaded) {
            this.filterChanged();
        }
    }

    topicChanged(value: number | null) {
        if (this.filter.topicId != value) {
            this.filter.topicId = value;
            this.filterChanged();
        }
    }

    clearFilter() {
        this.RaOwnerfilte = null;
        this.loadingPhrases = true;
        this.filter = new PhraseLibraryFilter();
        this.phraseList = new EmptyPhraseList();
        // Clear Phrase selection
        this.selectedId = -1;
        this.selectedPhraseId = -1;
        this.selectedPhrase = null;
        // this.filterChanged();

    }

    private keyTimer: any = null;
    filterKeyPress(event: any) {
        if (this.filterService.isKeyCodeFilterable(event.keyCode)) {
            if (this.keyTimer) {
                clearTimeout(this.keyTimer);
                this.keyTimer = null;
            }
            if (event.keyCode == 13) {
                this.filterChanged();
            }
            else {
                this.keyTimer = setTimeout(() => {
                    this.keyTimer = null;
                    this.filterChanged();
                }, 1000);
            }
        }
    }

    loadPhraseData() {
        const currentSelectedPhraseId = this.selectedPhraseId;
        const currentSelectedId = this.selectedId;
        const url = this.filter.showAssignments ? UrlEndpoint.PhraseLibrary_FilterPhraseAssignments : UrlEndpoint.PhraseLibrary_FilterPhrases;
        this.createModifyLable = this.filter.showAssignments ? "Assignment" : "Phrase";
        this.selectedId = -1;
        this.selectedPhraseId = -1;
        this.selectedPhrase = null;
        this.loadingPhrases = true;

        const filterToApply: PhraseLibraryFilter = (this.filter.showAuditInfo) ? this.filter : { ...this.filter, auditText: '' };

        this.httpService.postContentPromise(filterToApply, url).then(result => {
            this.phraseList = result;

            this.selectedPhrase = this.getPhrase(currentSelectedPhraseId);
            if (this.selectedPhrase) {
                this.selectedPhraseId = currentSelectedPhraseId;
            }
            if (this.phraseList.phrases.findIndex(p => p.id == currentSelectedId) >= 0) {
                this.selectedId = currentSelectedId;
            }
            this.loadingPhrases = false;
        }).catch(() => {
            this.loadingPhrases = false;
        });
    }
    RaOwnerfilte = null;
    public filterChanged() {
        if (this.RaOwnerfilte == '' || this.RaOwnerfilte == null) {
            this.filter.raOwner = null;
        } else {
            this.filter.raOwner = this.RaOwnerfilte;
        }
        this.loadPhraseData();
    }

    private getPhrase(phraseId: number): ListPhrase {
        const index = this.phraseList.phrases.findIndex(p => p.phraseId == phraseId);
       //  index >= 0 ? this.phraseList.phrases[index] : undefined;
       const PhraseDetails = index >= 0 ? this.phraseList.phrases[index] : undefined;
        if (PhraseDetails.mrpc == null){
            PhraseDetails.mrpc = [];
        }
        return PhraseDetails;
    }

    setSortOrder(columnName: string) {
        if (this.filter.sortColumn == columnName) {
            this.filter.sortDescending = !this.filter.sortDescending;
        }
        else {
            this.filter.sortColumn = columnName;
            this.filter.sortDescending = false;
        }
        this.filterChanged();
    }

    getSortDirection(columnName: string): string {
        if (this.filter.sortColumn == columnName) {
            return (this.filter.sortDescending ? ColumnSortOrder.Descending : ColumnSortOrder.Ascending);
        }
        return "";
    }
    public getTitleForPhraseOrAssignment(phrase: string): string {
        if (phrase == 'created') {
            if (!this.filter.showAssignments) {
                return 'Phrase Created by';
            }
            else {
                return 'Assignment Created by';
            }
        }
        else if (phrase == 'modified') {
            if (!this.filter.showAssignments) {
                return 'Phrase Modified by';
            }
            else {
                return 'Assignment Modified by';
            }
        }
    }

    selectPhrase(phrase: ListPhrase) {
        this.selectedId = phrase.id;
        this.selectedPhraseId = phrase.phraseId;
        this.selectedPhrase = phrase;
        this.setPermissions(phrase);
    }

    openAddPhraseModal() {
        const modalRef = this.sideDialogService.openWithCallback(AddPhraseComponent, (saveResult) => {
            const resultData = saveResult as SaveResult;
            if (resultData && resultData.success) {
                this.toasterService.pop('success', 'Add phrase', resultData.message);
                this.filterChanged();
            }
        });
        modalRef.componentInstance.preSelectTopicId(this.filter.topicId);
        modalRef.componentInstance.preSelectTopicText(this.filter.topicText);
    }

    openEditPhraseModal() {
        if (!this.phraseEditAllowed) {
            return;
        }
        const modalRef = this.sideDialogService.openWithCallback(EditPhraseComponent, (saveResult) => {
            const resultData = saveResult as SaveResult;
            if (resultData && resultData.success) { // if no changes are made, the message will be empty -> no need to reload phrases displayed
                this.toasterService.pop('success', 'Edit phrase', resultData.message);
                this.filterChanged();
            }
        });
        modalRef.componentInstance.phraseId = this.selectedPhraseId;
    }

    openApprovePhraseModal() {
        const modalRef = this.sideDialogService.openWithCallback(ApprovePhraseComponent, (saveResult) => {
            const resultData = saveResult as SaveResult;
            if (resultData && resultData.success) {
                this.toasterService.pop('success', 'Approve phrase', resultData.message);
                this.filterChanged();
            }
            else {
                const ok = saveResult as boolean;
                if (ok) {
                    this.filterChanged();
                }
            }
        });
        modalRef.componentInstance.phraseId = this.selectedPhraseId;
        modalRef.componentInstance.phrase = this.selectedPhrase;
    }

    openCopyPhraseModal() {
        const modalRef = this.sideDialogService.openWithCallback(CopyPhraseComponent, (copyParameters) => {
            const resultData = copyParameters as CopyPhraseParameters;
            if (resultData) {
                const copyModalRef = this.sideDialogService.openWithCallback(EditPhraseComponent, (saveResult) => {
                    const saveResultData = saveResult as SaveResult;
                    if (saveResultData && saveResultData.success) {
                        this.toasterService.pop('success', 'Edit phrase', saveResultData.message);
                        this.filterChanged();
                    }
                });
                copyModalRef.componentInstance.copyParameters = resultData;
                copyModalRef.componentInstance.phraseId = this.selectedPhraseId;
            }
        });
        modalRef.componentInstance.phraseId = this.selectedPhraseId;
    }

    openPhraseWhereUsedModal() {
        if (this.selectedId > 0) {
            this.loadingPhrases = true;
            this.editPhraseService.loadPhraseData(this.selectedId, false).then((result: Phrase) => {
                const modalRef = this.sideDialogService.open(PhraseWhereUsedComponent);
                modalRef.componentInstance.phrase = result;
                modalRef.componentInstance.phraseId = result.id;
                this.loadingPhrases = false;
            });
        }
    }

    openExcelExportModal() {
        const modalRef = this.dialogService.open(PhraseExcelExportComponent);
        modalRef.componentInstance.filter = this.filter;
    }
    private executeRemovePhrase(phraseId: number) {
        const phrase = this.getPhrase(phraseId);
        if (this.filter.showInactive && !phrase.isActive) {
            this.confirmationDialogService.confirm('Confirmation', `Removing this inactive phrase will permanently delete it from the sytem.`
                + ` Do you really want to remove phrase nr. ${phrase.nr} ?`, 'Remove')
                .then((confirmed) => {
                    if (confirmed) {
                        this.deletePhrase(phrase.phraseId);
                    }
                });
        }
        else {
            this.confirmationDialogService.confirm('Confirmation', `Removing this phrase nr. ${phrase.nr}
            will permanently delete the phrase and cannot be recovered once confirmed. ${phrase.mrpc.length > 0 ? 'Also, the ' : ''}
             ${phrase.mrpc.length > 0 ? phrase.mrpc : ''} ${phrase.mrpc.length > 0 ? 'assignment will be removed forever.' : ''} Are you sure you want to delete this phrase?`, 'Remove')
                .then((confirmed) => {
                    if (confirmed) {
                        this.deletePhrase(phrase.phraseId);
                    }
                });
        }
    }

    deletePhrase(phraseId: number) {
        this.httpService.postContentPromise({ id: phraseId }, UrlEndpoint.PhraseLibrary_RemovePhrase).then(result => {
            if (result.success) {
                this.toasterService.pop('success', 'Remove phrase', result.message);
                this.filterChanged();
            }
            else {
                this.alertDialogService.alert('Error', result.message);
            }
        });
    }

    removePhrase() {
        this.httpService.postContentPromise({ id: this.selectedPhraseId }, UrlEndpoint.PhraseLibrary_AllowRemovePhrase).then(result => {
            if (result.success) {
                this.executeRemovePhrase(this.selectedPhraseId);
            }
            else {
                this.alertDialogService.alert('Error', result.message);
            }
        });
    }

    /**
     * Sets the appropriate permissions objects when a phrase is selected/deselected.
     */
    setPermissions(phrase: ListPhrase): void {
        this.setApprovePhrasePermissions(phrase);
    }

    /**
     * Sets the permission scope object associated with phrase approval for the specified phrase.
     * This object is passed to the appropriate permissions directive in order to determine whether
     * or not the element associated with the directive is to be displayed.
     * @param phrase The phrase for which the approve phrase permission object should be set.
     */
    public setApprovePhrasePermissions(phrase: ListPhrase): void {
        this.approvePhrasePermissions = {
            ...this.approvePhrasePermissions,
            regulatoryMarketId: null,
            unileverProductDivisionId: phrase.unileverProductDivisionId
        };
    }

    public get phraseAdditionAllowed(): boolean {
        return this.authorizationService.checkUserHasAnyPermission(this.addPhrasePermissions);
    }

    public get phraseEditAllowed(): boolean {
        return this.phraseAdditionAllowed && this.selectedPhraseId > 0;
    }

    public get phraseApprovalAllowed(): boolean {
        return this.selectedPhraseId > 0 && this.authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision(
            this.approvePhrasePermissions.permissions,
            this.approvePhrasePermissions.regulatoryMarketId,
            this.approvePhrasePermissions.unileverProductDivisionId);
    }

    public get phraseRemovalAllowed(): boolean {
        return this.selectedPhraseId > 0 && this.authorizationService.checkUserHasAnyPermission(this.removePhrasePermissions);
    }

    public get phraseExportAllowed(): boolean {
        const hasPermissions = this.authorizationService.checkUserHasAnyPermission(this.exportExcelPermissions);
        return hasPermissions;
    }

    linkedPhraseNrs(phrase: any): string {
        return getLinkedPhraseNrsForPhrase(phrase);
    }

    identify(index, item) {
        return item.label;
     }

}