import { NO_ERRORS_SCHEMA, Pipe, PipeTransform } from '@angular/core';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { PhraseLibraryComponent } from './phrase-library.component';
import { DialogService } from '../tools/services/dialog.service';
import { AlertDialogService } from '../shared-components/alert-dialog/alert-dialog.service';
import { CacheService } from '../tools/services/cache.service';
import { ConfirmationDialogService } from '../shared-components/confirmation-dialog/confirmation-dialog.service';
import { SideDialogService } from '../tools/side-dialog/side-dialog.service';
import { ToasterService } from 'angular2-toaster';
import { ListPhrase, EmptyPhraseList, Phrase } from './phrase-library.types';
import { DetailLevel } from '../tools/common.types';
import { FilterService } from '../tools/services/filter.service';
import { getTestListPhrase, getTestPhraseList, getTestPhraseData } from '../testData';
import { HttpService } from '../tools/services/http.service';
import { ColumnSortOrder, UrlEndpoint } from '../tools/constants';
import { AuthorizationService } from '../authorization/authorization.service';
import { Permission } from './../tools/shared-types/permissions/permission';
import { ShowIfUserHasAnyPermissionDirective } from './../authorization/directives/show-if-user-has-any-permission.directive';
import { MarketAndUpdScopedPermissions } from '../tools/shared-types/permissions/market-and-upd-scoped-permissions';
import { EditPhraseService } from './edit-phrase/edit-phrase.service';

@Pipe({name: 'araDateTime'})
class MockDateTimePipe implements PipeTransform {
    transform(value: number): number {
        return 123;
    }
}

class EditPhraseServiceMock {
  loadPhraseData(): Promise<Phrase> {
    return new Promise<Phrase>((resolve) => {
            resolve(getTestPhraseData());
    });
  }
}
class DialogServiceMock { }
class AlertDialogServiceMock { }
class CacheServiceMock {
  getDetailLevels(): Promise<DetailLevel[]> {
    return new Promise<DetailLevel[]>(() => {
      return [{id: 1, description: 'detailLevel1'}];
    });
  }
}
class ConfirmationDialogServiceMock { }
class SideDialogServiceMock { }
class ToasterServiceMock { }

class FilterServiceMock {
  isKeyCodeFilterable() { return true; }
}
class HttpServiceMock {
  postContentPromise(content: any, url: string) {
    switch (url) {
      case UrlEndpoint.PhraseLibrary_FilterPhraseAssignments:
      case UrlEndpoint.PhraseLibrary_FilterPhrases:
        return Promise.resolve(new EmptyPhraseList());

      case UrlEndpoint.PhraseLibrary_AllowRemovePhrase:
      case UrlEndpoint.PhraseLibrary_RemovePhrase:
        const newPhrase = getTestListPhrase();
        newPhrase.id = 2;
        newPhrase.phraseId = 3;
        return Promise.resolve([newPhrase]);
    }
  }
}

let userHasPermission: boolean;
let userHasPermissionForMarketAndProductDivision: boolean;
class AuthorizationServiceMock {
  checkUserHasAnyPermission() {
    return userHasPermission;
  }
  checkUserHasAnyPermissionForMarketAndProductDivision() {
    return userHasPermissionForMarketAndProductDivision;
  }
}

const testPhrase: ListPhrase = {
  id: 1,
  phraseId: 1,
  nr: 1,
  topicId: 1,
  text: "Phrase 1",
  status: 5,
  statusText: "Status text 1",
  phraseTypeText: "Phrase type 1",
  isActive: true,
  isAccepted: false,
  topicDescription: "Topic 1",
  topicPath: "Topic path 1",
  unitOfMeasure: "UOM1",
  assignmentId: 101,
  regulatoryMarket: "GB",
  regulatoryProductClass: "BPC",
  regulatoryProductClassPath: "BPC_Foods",
  detailLevel: "Detailed",
  createdAt: new Date(Date.UTC(96, 1, 2, 3, 4, 5)),
  createdBy: "name",
  lastModifiedAt: new Date(Date.UTC(96, 1, 2, 3, 4, 5)),
  lastModifiedBy: "name1",
  unileverProductDivisionId: 50,
  unileverProductDivisionText: "UPD1",
  linkedPhraseNr: '2',
  linkedGenericPhraseNr: 2,
  mrpc: []
};

describe('PhraseLibraryComponent', () => {
  let component: PhraseLibraryComponent;
  let fixture: ComponentFixture<PhraseLibraryComponent>;
  let injector: TestBed;
  let cacheService: CacheService;
  let httpService: HttpService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        PhraseLibraryComponent,
        MockDateTimePipe,
        ShowIfUserHasAnyPermissionDirective,
      ],
      providers: [
        { provide: DialogService, useClass: DialogServiceMock },
        { provide: AlertDialogService, useClass: AlertDialogServiceMock },
        { provide: CacheService, useClass: CacheServiceMock },
        { provide: ConfirmationDialogService, useClass: ConfirmationDialogServiceMock },
        { provide: SideDialogService, useClass: SideDialogServiceMock },
        { provide: ToasterService, useClass: ToasterServiceMock },
        { provide: FilterService, useClass: FilterServiceMock },
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
        { provide: EditPhraseService, useClass: EditPhraseServiceMock },
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
    .compileComponents();

    injector = getTestBed();
    cacheService = injector.get(CacheService);
    httpService = getTestBed().get(HttpService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhraseLibraryComponent);
    component = fixture.componentInstance;
    jest.spyOn(component, 'filterChanged');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('snapshot tests', () => {
    it('should match snapshot', () => {
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('should match snapshot with assignments', () => {
      component.filter.showAssignments = true;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('should match snapshot with data', () => {
      component.filter.showAssignments = true;
      component.phraseList = getTestPhraseList();
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });
  });

  describe('logic tests', () => {
    it('initialises correctly', () => {
      jest.spyOn(cacheService, 'getDetailLevels');
      jest.spyOn(httpService, 'postContentPromise');

      component.ngOnInit();

      expect(cacheService.getDetailLevels).toHaveBeenCalled();
    // expect(httpService.postContentPromise).toHaveBeenCalled();
    });

    it('topicChanged', () => {
      component.filter.topicId = 1;
      component.topicChanged(2);
      expect(component.filter.topicId).toEqual(2);
      expect(component.filterChanged).toHaveBeenCalled();
    });

    it('clearFilter', () => {
      component.filter.topicId = 1;
      component.topicChanged(2);
      expect(component.filter.topicId).toEqual(2);
      expect(component.filterChanged).toHaveBeenCalled();
    });

    it('setSortOrder sorts correctly when selected column matches current', () => {
      component.filter.sortColumn = 'col1';
      component.filter.sortDescending = false;
      component.setSortOrder('col1');
      expect(component.filter.sortColumn).toEqual('col1');
      expect(component.filter.sortDescending).toEqual(true);
      expect(component.filterChanged).toHaveBeenCalled();
    });

    it('setSortOrder sorts correctly when selected column does not match current', () => {
      component.filter.sortColumn = 'col1';
      component.filter.sortDescending = true;
      component.setSortOrder('col2');
      expect(component.filter.sortColumn).toEqual('col2');
      expect(component.filter.sortDescending).toEqual(false);
      expect(component.filterChanged).toHaveBeenCalled();
    });

    it('getSortDirection returns correct direction with matching column name', () => {
      component.filter.sortColumn = 'col1';
      component.filter.sortDescending = true;
      const result1 = component.getSortDirection('col1');
      expect(result1).toEqual(ColumnSortOrder.Descending);

      component.filter.sortDescending = false;
      const result2 = component.getSortDirection('col1');
      expect(result2).toEqual(ColumnSortOrder.Ascending);
    });

    it('getSortDirection returns empty string with non-matching column name', () => {
      component.filter.sortColumn = 'col1';
      component.filter.sortDescending = true;
      const result1 = component.getSortDirection('col2');
      expect(result1).toEqual('');
    });

    describe('approve/reject phrase button', () => {
      it('should be hidden when user does not have permission to approve phrases', () => {
        // Assemble
        const userPermissions = [];
        userHasPermission = false;
        userHasPermissionForMarketAndProductDivision = false;
        component.approvePhrasePermissions = {
          permissions: userPermissions,
          regulatoryMarketId: null,
          unileverProductDivisionId: 1
        };
        component.selectedPhraseId = 5;
        fixture.detectChanges();

        // Act
        component.selectPhrase(testPhrase);
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#approve-reject-button'));
        expect(button).toBeFalsy();
      });

      it('should be disabled when user with permission to approve phrases does not have permission for the appropriate scope', () => {
        // Assemble
        const userPermissions = [Permission.AraPReFDCT_Phrases_Approve];
        userHasPermission = true;
        userHasPermissionForMarketAndProductDivision = false;
        component.approvePhrasePermissions = {
          permissions: userPermissions,
          regulatoryMarketId: null,
          unileverProductDivisionId: 1
        };
        fixture.detectChanges();

        // Act
        component.selectPhrase(testPhrase);
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#approve-reject-button'));
        expect(button.properties.disabled).toBeTruthy();
      });

      it('should be enabled when user with permission to approve phrases has permission for the appropriate scope', () => {
        // Assemble
        const userPermissions = [Permission.AraPReFDCT_Phrases_Approve];
        userHasPermission = true;
        userHasPermissionForMarketAndProductDivision = true;
        component.approvePhrasePermissions = {
          permissions: userPermissions,
          regulatoryMarketId: null,
          unileverProductDivisionId: 1
        };
        fixture.detectChanges();

        // Act
        component.selectPhrase(testPhrase);
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#approve-reject-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeFalsy();
      });
    });

    describe('add phrase button', () => {
      it('should be hidden when user does not have permission to write phrases', () => {
        // Assemble
        userHasPermission = false;
        component.addPhrasePermissions = [];
        component.selectedPhraseId = 5;
        fixture.detectChanges();

        // Act
        component.selectPhrase(testPhrase);
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#add-phrase-button'));
        expect(button).toBeFalsy();
      });

      describe('should be visible when user', () => {
        it('has permission to write phrases with assignments only', () => {
          // Assemble
          userHasPermission = true;
          component.addPhrasePermissions = [Permission.AraPReFDCT_Phrases_WriteWithAssignments];
          fixture.detectChanges();

          // Assert
          const button = fixture.debugElement.query(By.css('#add-phrase-button'));
          expect(button).toBeTruthy();
          expect(button.properties.disabled).toBeFalsy();
        });

        it('has permission to write phrases without assignments only', () => {
          // Assemble
          userHasPermission = true;
          component.addPhrasePermissions = [Permission.AraPReFDCT_Phrases_WriteWithoutAssignments];
          fixture.detectChanges();

          // Assert
          const button = fixture.debugElement.query(By.css('#add-phrase-button'));
          expect(button).toBeTruthy();
          expect(button.properties.disabled).toBeFalsy();
        });
      });
    });

    describe('remove phrase button', () => {
      it ('should be hidden when user does not have permission to remove phrases', () => {
        // Assemble
        userHasPermission = false;
        component.removePhrasePermissions = [];
        component.selectedPhraseId = 5;
        fixture.detectChanges();

        // Act
        component.selectPhrase(testPhrase);
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#remove-phrase-button'));
        expect(button).toBeFalsy();
      });

      it ('should be visible and enabled when user has permission to remove phrases', () => {
        // Assemble
        userHasPermission = true;
        component.removePhrasePermissions = [Permission.AraPReFDCT_Phrases_Remove];
        component.selectedPhraseId = 5;
        fixture.detectChanges();

        // Act
        component.selectPhrase(testPhrase);
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#remove-phrase-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeFalsy();
      });

      it ('should be visible and disabled when user has permission to remove phrases but no phrase selected', () => {
        // Assemble
        userHasPermission = true;
        component.removePhrasePermissions = [Permission.AraPReFDCT_Phrases_Remove];
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#remove-phrase-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeTruthy();
      });
    });

    describe('excel export button', () => {
      it ('should be hidden when user does not have permission to read phrases', () => {
        // Assemble
        userHasPermission = false;
        component.exportExcelPermissions = [Permission.AraPReFDCT_Phrases_Read];
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#excel-export-button'));
        expect(button).toBeFalsy();
      });

      it ('should be visible and enabled when user has permission to read phrases', () => {
        // Assemble
        userHasPermission = true;
        component.exportExcelPermissions = [Permission.AraPReFDCT_Phrases_Read];
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#excel-export-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeFalsy();
      });
    });

    describe('where used button', () => {
      it ('should be hidden when user does not have permission to read phrase assignments', () => {
        // Assemble
        userHasPermission = false;
        component.whereUsedPermissions = [];
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#where-used-button'));
        expect(button).toBeFalsy();
      });

      it ('should be visible and disabled when user has permission to read phrase assignments but no phrase selected', () => {
        // Assemble
        userHasPermission = true;
        component.whereUsedPermissions = [Permission.AraPReFDCT_PhraseAssignments_Read];
        component.filter.showAssignments = true;
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#where-used-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeTruthy();
      });

      it ('should be visible and enabled when user has permission to read phrase assignments, a phrase selected and the assignments box is unchecked', () => {
        // Assemble
        userHasPermission = true;
        component.selectedPhraseId = 5;
        component.whereUsedPermissions = [Permission.AraPReFDCT_PhraseAssignments_Read];
        fixture.detectChanges();

        // Act
        component.selectPhrase(testPhrase);
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#where-used-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeFalsy();
      });

      it ('should be visible and disabled when user has permission to read phrase assignments, a phrase selected and the assignments box is checked', () => {
        // Assemble
        userHasPermission = true;
        component.selectedPhraseId = 5;
        component.whereUsedPermissions = [Permission.AraPReFDCT_PhraseAssignments_Read];
        component.filter.showAssignments = true;
        fixture.detectChanges();

        // Act
        component.selectPhrase(testPhrase);
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#where-used-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeTruthy();
      });
    });

    describe('approvePhrasePermissions', () => {
      it('should hold appropriate permissions', () => {
        // Assemble
        const expectedPermissions: MarketAndUpdScopedPermissions = {
          permissions: [Permission.AraPReFDCT_Phrases_Approve],
          regulatoryMarketId: null,
          unileverProductDivisionId: null
        };

        // Assert
        expect(component.approvePhrasePermissions).toEqual(expectedPermissions);
      });
    });

    describe('addPhrasePermissions', () => {
      it('should hold appropriate permissions', () => {
        // Assemble
        const expectedPermissions: Permission[] = [
          Permission.AraPReFDCT_Phrases_WriteWithAssignments,
          Permission.AraPReFDCT_Phrases_WriteWithoutAssignments,
        ];

        // Assert
        expect(component.addPhrasePermissions).toEqual(expectedPermissions);
      });
    });

    describe('removePhrasePermissions', () => {
      it('should hold appropriate permissions', () => {
        // Assemble
        const expectedPermissions: Permission[] = [
          Permission.AraPReFDCT_Phrases_Remove,
        ];

        // Assert
        expect(component.removePhrasePermissions).toEqual(expectedPermissions);
      });
    });

    describe('filterChanged', () => {
      it('calls loadPhraseData', () => {
        // Assemble
        component.pageNr = 9;
        const loadPhraseSpy = jest.spyOn(component, 'loadPhraseData');

        // Act
        component.filterChanged();

        // Assert
        expect(loadPhraseSpy).toHaveBeenCalled();
        expect(component.pageNr).toBe(9);
      });
    });

    describe('audit information checkbox', () => {
      it('is ticked by default', () => {
        // Assert
        const checkbox = fixture.debugElement.query(By.css('#show-audit-info'));
        expect(checkbox).toBeTruthy();
        expect(checkbox.properties.ngModel).toEqual(true);
      });
    });

    describe('linkedPhraseNrs', () => {
      it('returns the linkedGenericPhraseNr for detailed phrases', () => {
        // Assemble
        const phrase = { detailLevelDescription: 'Detailed', linkedGenericPhraseNr: 1, linkedSpecificPhraseNrs: [2, 3, 4]};

        // Assert
        expect(component.linkedPhraseNrs(phrase)).toEqual('');
      });

      it('returns the correctly formatted linkedSpecificPhraseNrs for standard phrases', () => {
        // Assemble
        const phrase = { detailLevelDescription: 'Standard', linkedGenericPhraseNr: 1, linkedSpecificPhraseNrs: [2, 3, 4]};

        // Assert
        expect(component.linkedPhraseNrs(phrase)).toEqual('');
      });
    });
  });
});
