import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { BootstrapTemplatesModule } from '../../bootstrap-templates/bootstrap-templates.module';
import { ToolsModule } from '../../tools/tools.module';
import { SharedComponentsModule } from '../../shared-components/shared-components.module';

import { ApprovePhraseComponent } from './approve-phrase.component';
import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';
import { SideDialogService } from '../../tools/side-dialog/side-dialog.service';
import { HttpService } from '../../tools/services/http.service';
import { ListPhrase } from '../phrase-library.types';
import { AuthorizationService } from '../../authorization/authorization.service';
import { Permission } from '../../tools/shared-types/permissions/permission';
import { MarketAndUpdScopedPermissions } from '../../tools/shared-types/permissions/market-and-upd-scoped-permissions';
import { PhraseChangeType, PhraseStatusId } from '../../tools/constants';
import { AuthorizationModule } from '../../authorization/authorization.module';
import { ToasterService } from 'angular2-toaster';

class NgbActiveModalMock { }
class NgbModalMock { }
class AlertDialogServiceMock {
  alert() {}
}
class SideDialogServiceMock { }
class HttpServiceMock {
  getPromise() {}
  postContentPromise(content: any, getUrl: any): Promise<object> {
    return new Promise<object>((resolve, reject) => {
      resolve({});
    });
  }
}
let userHasPermission: boolean;
let userHasPermissionForMarketAndProductDivision: boolean;
class AuthorizationServiceMock {
  checkUserHasAnyPermission() {
    return userHasPermission;
  }
  checkUserHasAnyPermissionForMarketAndProductDivision() {
    return userHasPermissionForMarketAndProductDivision;
  }
}

class ToasterServiceMock { }

const testPhraseUpdId: number = 50;
const testPhrase: ListPhrase = {
  id: 1,
  phraseId: 1,
  nr: 1,
  topicId: 1,
  linkedPhraseNr: '2',
  linkedGenericPhraseNr: 2,
  text: "Phrase 1",
  status: 1,
  statusText: "Status text 1",
  phraseTypeText: "Phrase type 1",
  isActive: true,
  isAccepted: false,
  topicDescription: "Topic 1",
  topicPath: "Topic path 1",
  unitOfMeasure: "UOM1",
  assignmentId: 101,
  regulatoryMarket: "GB",
  regulatoryProductClass: "BPC",
  regulatoryProductClassPath: "BPC_Foods",
  detailLevel: "Detailed",
  createdAt: new Date(Date.UTC(96, 1, 2, 3, 4, 5)),
  createdBy: "name",
  changeType: PhraseChangeType.Significant,
  lastModifiedAt: new Date(Date.UTC(96, 1, 2, 3, 4, 5)),
  lastModifiedBy: "name1",
  unileverProductDivisionId: testPhraseUpdId,
  unileverProductDivisionText: "UPD1",
  mrpc: ['mrpc1']
};

describe('ApprovePhraseComponent', () => {
  let injector: TestBed;
  let component: ApprovePhraseComponent;
  let fixture: ComponentFixture<ApprovePhraseComponent>;
  let httpService: HttpService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ApprovePhraseComponent,
      ],
      imports: [
        AuthorizationModule,
        BootstrapTemplatesModule,
        FormsModule,
        ToolsModule,
        SharedComponentsModule,
      ],
      providers: [
        { provide: NgbActiveModal, useClass: NgbActiveModalMock },
        { provide: NgbModal, useClass: NgbModalMock },
        { provide: AlertDialogService, useClass: AlertDialogServiceMock },
        { provide: SideDialogService, useClass: SideDialogServiceMock },
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
        { provide: ToasterService, useClass: ToasterServiceMock },
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApprovePhraseComponent);
    injector = getTestBed();
    httpService = injector.get(HttpService);
    component = fixture.componentInstance;
    component.phrase = testPhrase;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when loading', () => {
    component.isLoading = true;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot with phrase change', () => {
    component.data.originalText = "originalText";
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  describe('when user does not have permission to approve phrases', () => {
    beforeEach(() => {
      // Assemble user with no permissions
      const userPermissions = [];
      userHasPermission = false;
      userHasPermissionForMarketAndProductDivision = false;
      component.approvePhrasePermissions = {
        permissions: userPermissions,
        regulatoryMarketId: null,
        unileverProductDivisionId: 1
      };
      fixture.detectChanges();
    });

    it('approve button should be hidden', () => {
      // Assert
      const button = fixture.debugElement.query(By.css('#approve-button'));
      expect(button).toBeFalsy();
    });

    it('reject button should be hidden', () => {
      // Assert
      const button = fixture.debugElement.query(By.css('#reject-button'));
      expect(button).toBeFalsy();
    });

    it('where used button should be hidden', () => {
      // Assert
      const button = fixture.debugElement.query(By.css('#where-used-button'));
      expect(button).toBeFalsy();
    });

    it('existing phrases button should be hidden', () => {
      // Assert
      const button = fixture.debugElement.query(By.css('#existing-phrases-button'));
      expect(button).toBeFalsy();
    });
  });

  describe('when user has permission to approve phrases', () => {
    beforeEach(() => {
      // Assemble user with permission to approve phrases
      const userPermissions = [Permission.AraPReFDCT_Phrases_Approve];
      userHasPermission = true;
      component.approvePhrasePermissions = {
        permissions: userPermissions,
        regulatoryMarketId: null,
        unileverProductDivisionId: 1
      };
      fixture.detectChanges();
    });

    describe('approve button', () => {
      it('should be visible and disabled when user does not have the appropriate permission scope', () => {
        // Assemble
        userHasPermissionForMarketAndProductDivision = false;
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#approve-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeTruthy();
      });

      it('should be visible and enabled when user has the appropriate permission scope and phrase is Approved', () => {
        // Assemble
        userHasPermissionForMarketAndProductDivision = true;
        component.phrase.status = PhraseStatusId.Approved;
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#approve-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeFalsy();
      });

      it('should be visible and disabled when user has the appropriate permission scope and phrase is To Be Approved', () => {
        // Assemble
        component.phrase.status = PhraseStatusId.ToBeApproved;
        component.data.originalText = 'originalText';
        userHasPermissionForMarketAndProductDivision = true;
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#approve-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeTruthy();
      });

      it('should be visible and disabled when user has the appropriate permission scope and phrase is Rejected', () => {
        // Assemble
        component.phrase.status = PhraseStatusId.Rejected;
        component.data.originalText = 'originalText';
        userHasPermissionForMarketAndProductDivision = true;
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#approve-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeTruthy();
      });

      it('should be visible and enabled when user has the appropriate permission scope and phrase is new without change type', () => {
        // Assemble
        component.phrase.status = PhraseStatusId.ToBeApproved;
        userHasPermissionForMarketAndProductDivision = true;
        component.data.originalText = null;
        component.newChangeType = null;
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#approve-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeFalsy();
      });
    });

    describe('reject button', () => {
      it('should be visible and disabled when user does not have the appropriate permission scope', () => {
        // Assemble
        userHasPermissionForMarketAndProductDivision = false;
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#reject-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeTruthy();
      });

      it('should be visible and enabled when user has the appropriate permission scope and phrase is not To Be Approved', () => {
        // Assemble
        component.phrase.status = PhraseStatusId.Approved;
        userHasPermissionForMarketAndProductDivision = true;
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#reject-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeFalsy();
      });

      it('should be visible and enabled when user has the appropriate permission scope and phrase is To Be Approved', () => {
        // Assemble
        component.phrase.status = PhraseStatusId.ToBeApproved;
        userHasPermissionForMarketAndProductDivision = true;
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#reject-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeFalsy();
      });

      it('should be visible and enabled when user has the appropriate permission scope and phrase is Rejected', () => {
        // Assemble
        component.phrase.status = PhraseStatusId.Rejected;
        userHasPermissionForMarketAndProductDivision = true;
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#reject-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeFalsy();
      });
    });

    describe('look for existing phrases button', () => {
      it('should be visible and disabled when user does not have the appropriate permission scope', () => {
        // Assemble
        userHasPermissionForMarketAndProductDivision = false;
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#existing-phrases-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeTruthy();
      });

      it('should be visible and enabled when user has the appropriate permission scope', () => {
        // Assemble
        userHasPermissionForMarketAndProductDivision = true;
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#existing-phrases-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeFalsy();
      });
    });

    describe('when the user alters the change type input', () => {
      it('suggested change type text hidden, change type input hidden, approval button enabled, confirmed change type text visible', () => {
        // Assemble
        component._phrase.changeType = PhraseChangeType.Significant;
        component.data.originalText = 'originalText';
        fixture.detectChanges();

        // Pre-assert
        // Check that the suggested change type is 'Significant'
        const element = fixture.debugElement.query(By.css('#suggested-change-type-text'));
        expect(element).toBeTruthy();
        expect(element.nativeElement.innerHTML == PhraseChangeType.Significant);

        // Act (simulate the selection of the Minor option in the change type dropdown)
        const select = fixture.debugElement.query(By.css('#change-type-input'));
        component.newChangeType = PhraseChangeType.Minor;
        fixture.detectChanges();

        // Assert
        // Check that the change type box and suggested change type text disappear
        const validationWrapper = fixture.debugElement.query(By.css('#change-type-validation-wrapper'));
        expect(validationWrapper).toBeFalsy();

        // Check that the approve button is enabled
        const button = fixture.debugElement.query(By.css('#approve-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeFalsy();
      });
    });
  });

  describe('when user has permission to read phrases', () => {
    beforeEach(() => {
      // Assemble
      userHasPermission = true;
      fixture.detectChanges();
    });

    describe('where used button', () => {
      it('should be visible and enabled', () => {
      // Assert
      const button = fixture.debugElement.query(By.css('#where-used-button'));
      expect(button).toBeTruthy();
      expect(button.properties.disabled).toBeFalsy();
      });
    });
  });

  describe('when user does not have permission to read phrases', () => {
    beforeEach(() => {
      // Assemble
      userHasPermission = false;
      component.whereUsedPermissions = [];
      fixture.detectChanges();
    });

    describe('where used button', () => {
      it('should be hidden', () => {
      // Assert
      const button = fixture.debugElement.query(By.css('#where-used-button'));
      expect(button).toBeFalsy();
      });
    });
  });

  describe('approvePhrasePermissions', () => {
    it('should hold appropriate permissions', () => {
      // Assemble
      const expectedPermissions: MarketAndUpdScopedPermissions = {
        permissions: [Permission.AraPReFDCT_Phrases_Approve],
        regulatoryMarketId: null,
        unileverProductDivisionId: testPhraseUpdId
      };

      // Assert
      expect(component.approvePhrasePermissions == expectedPermissions);
    });
  });

  describe('suggested change type text', () => {
    it('has value equal to the initial value of the change type associated with the phrase', () => {
      // Assemble
      component._phrase.changeType = PhraseChangeType.Significant;
      component.data.originalText = 'originalText';
      fixture.detectChanges();

      // Assert
      const element = fixture.debugElement.query(By.css('#suggested-change-type-text'));
      expect(element).toBeTruthy();
      expect(element.nativeElement.innerHTML == PhraseChangeType.Significant);
    });
  });

  describe('change type input', () => {
    it('initially has empty value', () => {
      // Assemble
      component.data.originalText = 'originalText';
      fixture.detectChanges();

      // Assert
      const select = fixture.debugElement.query(By.css('#change-type-input'));
      expect(select).toBeTruthy();
      expect(select.nativeElement.value).toEqual("");
    });
  });
});
