import { Component, Input } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToasterService } from 'angular2-toaster';

import { AlertDialogService } from './../../shared-components/alert-dialog/alert-dialog.service';
import { AuthorizationService } from './../../authorization/authorization.service';
import { SideDialogService } from '../../tools/side-dialog/side-dialog.service';
import { PhraseWhereUsedComponent } from '../../shared-components/phrase-where-used/phrase-where-used.component';
import { RejectPhraseComponent } from '../reject-phrase/reject-phrase.component';
import { FindPhraseComponent } from '../../shared-components/find-phrase/find-phrase.component';
import { PhraseApprovalData } from './approve-phrase.types';
import { UrlEndpoint, PhraseStatusId, MISSING_CHANGE_TYPE_ERROR, MISSING_PERMISSIONS_ERROR, PhraseChangeType } from '../../tools/constants';
import { HttpService } from '../../tools/services/http.service';
import { Permission } from '../../tools/shared-types/permissions/permission';
import { MarketAndUpdScopedPermissions } from '../../tools/shared-types/permissions/market-and-upd-scoped-permissions';
import { ListPhrase, Phrase } from '../phrase-library.types';
import { ApprovePhrasePostModel } from './approve-phrase.types';
import { EditPhraseService } from '../edit-phrase/edit-phrase.service';

@Component({
    selector: 'ara-approve-phrase',
    templateUrl: './approve-phrase.component.html',
    styleUrls: ['./approve-phrase.component.scss']
})
export class ApprovePhraseComponent {
    data: PhraseApprovalData = new PhraseApprovalData();
    @Input() _phrase: ListPhrase;
    public originalChangeType: string;
    public newChangeType: string = "";
    public approvePhrasePermissions: MarketAndUpdScopedPermissions = {
        permissions: [Permission.AraPReFDCT_Phrases_Approve],
        regulatoryMarketId: null,
        unileverProductDivisionId: null
    };

    public whereUsedPermissions: Permission[] = [
        Permission.AraPReFDCT_PhraseAssignments_Read,
    ];

    constructor(
        public activeModal: NgbActiveModal,
        public alertDialogService: AlertDialogService,
        private modalService: NgbModal,
        private sideDialogService: SideDialogService,
        private httpService: HttpService,
        private authorizationService: AuthorizationService,
        private editPhraseService: EditPhraseService,
        private toasterService: ToasterService,
    ) { }

    public isLoading: boolean = false;

    private _phraseId: number = -1;
    get phraseId(): number {
        return this._phraseId;
    }
    set phraseId(value: number) {
        if (this._phraseId != value) {
            this._phraseId = value;
            this.isLoading = true;
            this.httpService.getFilteredPromise({ phraseId: value.toString() }, UrlEndpoint.PhraseLibrary_LoadApprovalData).then(result => {
                this.isLoading = false;
                this.data = result;
            }).catch(error => {
                console.error(error);
                this.isLoading = false;
                this.activeModal.close(error);
            });
        }
    }

    get phrase(): ListPhrase {
        return this._phrase;
    }

    set phrase(value: ListPhrase) {
        this._phrase = value;
        this.originalChangeType = value.changeType;
            if (this.originalChangeType == '0') {
                this.originalChangeType = PhraseChangeType.Minor;
            }else if (this.originalChangeType == '1'){
                this.originalChangeType = PhraseChangeType.Significant;
            }else {
                this.originalChangeType = PhraseChangeType.None;
            }

        // Sets the permission scope object associated with phrase approval for the specified phrase.
        // This object is passed to the appropriate permissions directive in order to determine whether
        // or not the element associated with the directive is to be displayed.
        this.approvePhrasePermissions = {
            ...this.approvePhrasePermissions,
            regulatoryMarketId: null,
            unileverProductDivisionId: this._phrase.unileverProductDivisionId
        };
    }

    openPhraseWhereUsedModal() {
        this.isLoading = true;
        this.editPhraseService.loadPhraseData(this.phraseId, false).then((result: Phrase) => {
            const modalRef = this.sideDialogService.open(PhraseWhereUsedComponent);
            modalRef.componentInstance.phrase = result;
            modalRef.componentInstance.phraseId = result.id;
            this.isLoading = false;
        });
    }

    findPhraseModal() {
        const modalRef = this.sideDialogService.openBig(FindPhraseComponent);
        modalRef.componentInstance.readOnly = true;
    }

    rejectPhrase() {
        const modalRef = this.modalService.open(RejectPhraseComponent, {
            backdrop: 'static'
        });
        modalRef.componentInstance.phraseId = this._phraseId;
        modalRef.result.then((value) => {
            if (value) {
                this.activeModal.close(true);
            }
        });
    }

    approvePhrase() {
        this.isLoading = true;
        return this.httpService.postContentPromise(
            new ApprovePhrasePostModel(this.phraseId, PhraseChangeType[this.newChangeType]),
            UrlEndpoint.PhraseLibrary_ApprovePhrase
        ).then(result => {
            this.isLoading = false;
            if (result.success) {
                this.activeModal.close(result);
            }
            else {
                this.alertDialogService.alert('Error', result.message);
            }
        }, error => {
            console.error("Approve phrase failed:", error);
            this.isLoading = false;
        });
    }

    keepPhrase() {
        this.isLoading = true;
        return this.httpService.postContentPromise({ id: this.phraseId }, UrlEndpoint.WorkList_KeepPhrasesByGramorMarket)
            .then(result => {
                this.isLoading = false;
                if (result) {
                    this.toasterService.pop('success', result.message);
                    this.activeModal.close(true);
                }
                else {
                    this.alertDialogService.alert('Error', result.message);
                }
            }, error => {
                console.error("Keep phrase failed:", error);
                this.isLoading = false;
            });
    }

    deletePhrase() {
        this.isLoading = true;
        return this.httpService.postContentPromise({ id: this.phraseId }, UrlEndpoint.PhraseLibrary_DeletePhrase)
            .then(result => {
                this.isLoading = false;
                if (result.success) {
                    this.toasterService.pop('success', result.message);
                    this.activeModal.close(true);
                }
                else {
                    this.alertDialogService.alert('Error', result.message);
                }
            }, error => {
                console.error("Delete phrase failed:", error);
                this.isLoading = false;
            });
    }

    cancelPhraseApproval() {
        this.activeModal.close('Cancel');
    }

    public get phraseApprovalAllowed(): boolean {
        return this.phrase && this.authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision(
            this.approvePhrasePermissions.permissions,
            this.approvePhrasePermissions.regulatoryMarketId,
            this.approvePhrasePermissions.unileverProductDivisionId);
    }

    public get phraseIsNotApproved() {
        return this.phrase.status != PhraseStatusId.Approved;
    }

    public get changeTypeConfirmed() {
        return this.newChangeType;
    }

    public get isApproveDisabled(): boolean {
        return !this.phraseApprovalAllowed || (!this.changeTypeConfirmed && this.phraseIsNotApproved && !!this.data.originalText);
    }

    public get approveButtonTooltipText() {
        let tooltip = '';
        if (!this.phraseApprovalAllowed) {
            tooltip = MISSING_PERMISSIONS_ERROR;
        } else if (this.isApproveDisabled) {
            tooltip = MISSING_CHANGE_TYPE_ERROR;
        }
        return tooltip;
    }
}
