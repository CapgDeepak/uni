import { PhraseChangeType, PhraseType } from "../../tools/constants";

export class PhraseApprovalData {
    phraseId: number;
    originalText: string;
    diffText: string;
    changeReason: string;
    topicPath: string[];
    createdAt: Date;
    createdBy: string;
    lastModifiedAt: Date;
    lastModifiedBy: string;
    phraseType: PhraseType;
    market: string;
    rpc: string;
    isDeleteRequest: boolean;
    phraseTypeText: string;
}

export class ApprovePhrasePostModel {
    id: number;
    changeType: PhraseChangeType;

    constructor(id: number, changeType: PhraseChangeType) {
        this.id = id;
        this.changeType = changeType;
    }
}