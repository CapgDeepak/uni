export class CopyPhraseParameters {
    phraseId: number = -1;
    includeText: boolean = true;
    includeAssignments: boolean = false;
}