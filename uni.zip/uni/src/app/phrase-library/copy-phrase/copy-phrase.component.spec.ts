import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { CopyPhraseComponent } from './copy-phrase.component';
import { ConfirmationDialogService } from '../../shared-components/confirmation-dialog/confirmation-dialog.service';
import { ToolsModule } from '../../tools/tools.module';
import { SharedComponentsModule } from '../../shared-components/shared-components.module';
import { HttpService } from '../../tools/services/http.service';
import { BootstrapTemplatesModule } from './../../bootstrap-templates/bootstrap-templates.module';

class NgbActiveModalMock {
  close() {
  }
}
class HttpServiceMock {
  getFilteredPromise() {
    return new Promise<any>((resolve) => {
      resolve([{ id: 1, }]);
    });
  }
}
class ConfirmationDialogServiceMock {
  question(): Promise<boolean> {
    return new Promise(() => false);
  }
}

describe('CopyPhraseComponent', () => {
  let component: CopyPhraseComponent;
  let fixture: ComponentFixture<CopyPhraseComponent>;
  let confirmationDialogService: ConfirmationDialogService;
  let activeModal: NgbActiveModal;
  let httpService: HttpService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        BootstrapTemplatesModule,
        ToolsModule,
        SharedComponentsModule,
      ],
      declarations: [
        CopyPhraseComponent
      ],
      providers: [
        { provide: NgbActiveModal, useClass: NgbActiveModalMock },
        { provide: ConfirmationDialogService, useClass: ConfirmationDialogServiceMock },
        { provide: HttpService, useClass: HttpServiceMock }
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
      .compileComponents();

      const injector = getTestBed();
      confirmationDialogService = injector.get(ConfirmationDialogService);
      activeModal = injector.get(NgbActiveModal);
      httpService = injector.get(HttpService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CopyPhraseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot with phrase text', () => {
    component.phraseText = "blah";
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('cancelCopy should prompt user with question', () => {
    jest.spyOn(confirmationDialogService, 'question');
    component.cancelCopy();
    expect(confirmationDialogService.question).toHaveBeenCalled();
  });

  it('copyPhrase should close modal', () => {
    jest.spyOn(activeModal, 'close');
    component.copyPhrase();
    expect(activeModal.close).toHaveBeenCalled();
  });

  it('set phraseId should call http service to load phrase data', () => {
    jest.spyOn(httpService, 'getFilteredPromise');
    component.phraseId = 22;
    expect(httpService.getFilteredPromise).toHaveBeenCalled();
  });

  it('get phraseId should return -1 initially', () => {
    jest.spyOn(httpService, 'getFilteredPromise');
    expect(component.phraseId).toBe(-1);
  });

  it('get phraseId should return correct value when set', () => {
    component.phraseId = 22;
    expect(component.phraseId).toBe(22);
  });
});
