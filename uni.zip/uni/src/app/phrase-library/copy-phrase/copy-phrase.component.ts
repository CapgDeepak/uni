import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CopyPhraseParameters } from './copy-phrase.types';
import { ConfirmationDialogService } from '../../shared-components/confirmation-dialog/confirmation-dialog.service';
import { HttpService } from '../../tools/services/http.service';
import { UrlEndpoint } from '../../tools/constants';

@Component({
    selector: 'ara-copy-phrase',
    templateUrl: './copy-phrase.component.html',
    styleUrls: ['./copy-phrase.component.scss']
})
export class CopyPhraseComponent {

    parameters: CopyPhraseParameters = new CopyPhraseParameters();
    phraseText: string = "";

    constructor(
        public activeModal: NgbActiveModal,
        private confirmationDialogService: ConfirmationDialogService,
        private httpService: HttpService) {
    }

    copyPhrase() {
        this.activeModal.close(this.parameters);
    }

    cancelCopy() {
        this.confirmationDialogService.question("Confirmation", "Are you sure you want to cancel the copying of this phrase?").then(result => {
            if (result) {
                this.activeModal.close(null);
            }
        });
    }

    get phraseId(): number {
        return this.parameters.phraseId;
    }
    set phraseId(value: number) {
        if (this.parameters.phraseId != value) {
            this.parameters.phraseId = value;
            this.httpService.getFilteredPromise({phraseId: value.toString()}, UrlEndpoint.PhraseLibrary_LoadPhraseText).then(result => {
                this.phraseText = result;
            }).catch(error => {
                console.error("Copy phrase - load phrase", error);
            });
        }
    }
}
