import { Component, OnInit } from '@angular/core';

import { AlertDialogService } from '../shared-components/alert-dialog/alert-dialog.service';

import { UrlEndpoint } from '../tools/constants';
import { PhraseOrderFilter, PhraseList, EmptyPhraseList, ListPhrase, IPhraseReOrderModel } from './phrase-library.types';
import { AuthorizationService } from '../authorization/authorization.service';
import { HttpService } from '../tools/services/http.service';
import { Permission } from '../tools/shared-types/permissions/permission';
import { getLinkedPhraseNrsForPhrase } from '../tools/utils';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { ToasterService } from 'angular2-toaster';
import { ConfirmationDialogService } from '../shared-components/confirmation-dialog/confirmation-dialog.service';

@Component({
  selector: 'ara-phrase-ordering',
  templateUrl: './phrase-ordering.component.html',
  styleUrls: ['./phrase-library.component.scss']
})

export class PhraseOrderingComponent implements OnInit {
  public orderPhrasePermissions: Permission[] = [
    Permission.AraPReFDCT_Phrases_Order,
  ];

  productDivision: any = null;
  public phraseList: PhraseList = new EmptyPhraseList();
  public filter: PhraseOrderFilter = new PhraseOrderFilter();
  changedRecordsToReorderPhrase: IPhraseReOrderModel[];

  public selectedId: number = -1;
  public selectedPhraseId: number = -1;
  public selectedPhraseMarketId: number = -1;
  public selectedPhraseUpdId: number = -1;
  public selectedPhrase: ListPhrase = null;
  public loadingPhrases = false;
  originalPhrasesRecords: any;

  constructor(
    private alertDialogService: AlertDialogService,
    private confirmationDialogService: ConfirmationDialogService,
    private httpService: HttpService,
    private toasterService: ToasterService,
    private authorizationService: AuthorizationService,
  ) { }

  ngOnInit(): void {
    // note the table data will be loaded following the load of the topic navigator tree - which will trigger the topicChanged method call
    this.loadingPhrases = true;
  }

  public get pageNr(): number {
    return this.filter.pageNr + 1;
  }
  public set pageNr(value: number) {
    this.filter.pageNr = value - 1;
  }

  topicChanged(value: number | null) {
    if (this.filter.topicId !== value) {
      this.filter.topicId = value;
      // reset product division filter
      this.filter.productId = null;
      this.productDivision = null;
      this.filterChanged();
    }
  }

  loadPhraseData() {
    const currentSelectedPhraseId = this.selectedPhraseId;
    const currentSelectedId = this.selectedId;

    this.selectedId = -1;
    this.selectedPhraseId = -1;
    this.selectedPhrase = null;
    this.loadingPhrases = true;

    this.httpService.postContentPromise(this.filter, UrlEndpoint.PhraseLibrary_FilterOrderedPhrases).then(result => {
      this.phraseList = result;
      this.originalPhrasesRecords = JSON.parse(JSON.stringify(this.phraseList.phrases));
      this.selectedPhrase = this.getPhrase(currentSelectedPhraseId);
      if (this.selectedPhrase) {
        this.selectedPhraseId = currentSelectedPhraseId;
      }
      if (this.phraseList.phrases.findIndex(p => p.id == currentSelectedId) >= 0) {
        this.selectedId = currentSelectedId;
      }
      this.loadingPhrases = false;
    }).catch(() => {
      this.loadingPhrases = false;
    });
  }

  public filterChanged() {
    this.loadPhraseData();
  }

  onPromoteOrderButtonClick() {
    this.promoteOrDemoteTopicOrder(true);
  }

  onDemoteOrderButtonClick() {
    this.promoteOrDemoteTopicOrder(false);
  }

  promoteOrDemoteTopicOrder(isPromoted: boolean) {
    this.loadingPhrases = true;
    const filterToApply: PhraseOrderFilter = {
      topicId: this.selectedPhrase.topicId,
      phraseId: this.selectedPhraseId,
      isPromoted: isPromoted,
      pageNr: this.filter.pageNr,
    };
    if (filterToApply.phraseId > 0) {
      this.httpService.putContent(filterToApply, UrlEndpoint.PhraseLibrary_ReorderPhrase)
        .subscribe(() => {
          this.loadPhraseData();
        },
          response => {
            const errorMessage: string = (response && response.error && response.error.Message) ? response.error.Message : 'An error occured whilst saving the ordering - reload and try again.';
            this.alertDialogService.alert('Error', errorMessage);
            this.loadPhraseData(); // reset ordering by reloading
          }
        );
    }
  }

  private isRowUnselected(): boolean {
    return this.selectedId === -1;
  }

  public get isPromoteDisabled(): boolean {
    return this.isRowUnselected() || this.isPhraseSelectedAndAtTop();
  }

  public get isDemoteDisabled(): boolean {
    return this.isRowUnselected() || this.isPhraseSelectedAndAtBottom();
  }

  public get demoteOrderButtonTooltipText(): string {
    if (this.isPhraseSelectedAndAtBottom()) {
      return "This item is already at the bottom of its Topic group";
    }
    return this.changeSortOrderToolTip('Demote item in the sort order');
  }

  public get promoteOrderButtonTooltipText(): string {
    if (this.isPhraseSelectedAndAtTop()) {
      return "This item is already at the top of its Topic group";
    }
    return this.changeSortOrderToolTip('Promote item in the sort order');
  }

  private changeSortOrderToolTip(defaultToolTip: string): string {
    if (this.isRowUnselected()) {
      return "Select a row in the table";
    }
    return defaultToolTip;
  }

  private getPhrase(phraseId: number): ListPhrase {
    const index = this.phraseList.phrases.findIndex(p => p.phraseId == phraseId);
    return index >= 0 ? this.phraseList.phrases[index] : undefined;
  }

  private isPhraseSelectedAndAtTop(): boolean {
    if (!this.isRowUnselected()) {
      const index = this.phraseList.phrases.findIndex(p => p.phraseId == this.selectedPhraseId);
      return index === 0 && this.pageNr === 1;
    }
    return false;
  }

  private isPhraseSelectedAndAtBottom(): boolean {
    if (!this.isRowUnselected()) {
      const index = this.phraseList.phrases.findIndex(p => p.phraseId == this.selectedPhraseId);
      return index === this.phraseList.phrases.length - 1 && this.pageNr === this.phraseList.pageCount;
    }
    return false;
  }

  selectPhrase(phrase: ListPhrase) {
    this.selectedId = phrase.id;
    this.selectedPhraseId = phrase.phraseId;
    this.selectedPhrase = phrase;
  }

  public get phraseOrderingAllowed(): boolean {
    return this.authorizationService.checkUserHasAnyPermission(this.orderPhrasePermissions);
  }

  linkedPhraseNrs(phrase: any): string {
    return getLinkedPhraseNrsForPhrase(phrase);
  }

  identify(index, item) {
    return item.label;
  }

  onListDrop(event: CdkDragDrop<string[]>) {
    const prevIndex = this.phraseList.phrases.findIndex((d) => d === event.item.data);
    this.changedRecordsToReorderPhrase = [];
    if (prevIndex > event.currentIndex) {
      // drag up
      const changedRecordss = this.originalPhrasesRecords.slice(event.currentIndex, prevIndex + 1);
      changedRecordss.forEach((row, i) => {
        const data: IPhraseReOrderModel = {
          snoIndex: i,
          id: row.id,
          phraseId: row.phraseId,
          topicId: row.topicId,
          order: row.order,
          isDragged: i == (changedRecordss.length - 1) ? true : false
        };
        this.changedRecordsToReorderPhrase.push(data);
      });
      this.sortPhrases(prevIndex, event.currentIndex);
    }
    else if (prevIndex < event.currentIndex) {
      // drag down
      const changedRecords = this.originalPhrasesRecords.slice(prevIndex, event.currentIndex + 1);
      changedRecords.forEach((row, i) => {
        const data1: IPhraseReOrderModel = {
          snoIndex: i,
          id: row.id,
          phraseId: row.phraseId,
          topicId: row.topicId,
          order: row.order,
          isDragged: i == 0 ? true : false
        };
        this.changedRecordsToReorderPhrase.push(data1);
      });
      this.sortPhrases(prevIndex, event.currentIndex);
    }
  }

  sortPhrases(prevIndex, currentIndex) {
    this.confirmationDialogService.question("Confirmation", "Are you sure you want to reorder the phrase?").then(result => {
      if (result) {
        this.callServiceToReOrderPhrase();
        moveItemInArray(this.phraseList.phrases, prevIndex, currentIndex);
      }
    });
  }

  callServiceToReOrderPhrase() {
    this.loadingPhrases = true;
    this.httpService.putContent(this.changedRecordsToReorderPhrase, UrlEndpoint.PhraseLibrary_DragReorderPhrase)
      .subscribe(() => {
        this.toasterService.pop('success', 'Success', 'Phrase reordered successfully');
        this.loadPhraseData();
      },
        error => {
          this.toasterService.pop('error', 'Phrase sort error', error);
        });
  }

  productDivisionFilterChanged() {
    this.filter.productId = JSON.parse(this.productDivision);
    this.filterChanged();
  }
}
