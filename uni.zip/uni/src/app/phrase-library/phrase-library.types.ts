import { PhraseAssignment } from "../shared-components/phrase-assignments/phrase-assignments.types";
import { Confirmation } from "../tools/common.types";
import { PhraseChangeType } from "../tools/constants";

export class PhraseLibraryFilter {
    public nr: string = '';
    public text: string = '';
    public phraseStatus: number | null = null;
    public assignmentStatus: number | null = null;
    public phraseType: number | null = null;
    public topicId: number | null = null;
    public topicText: string = '';
    public assignmentTopicText: string = '';
    public assignedUPDPath: string = '';
    public geographyText: string = '';
    public productDivisionText: string = '';
    public assignedUPDPathText: string = '';
    public regulatoryProductClassText: string = '';
    public detailLevelId: number | null = null;
    public linkedPhraseNr: string = '';
    public auditText: string = '';
    public showAssignments: boolean = false;
    public showAuditInfo: boolean = true;
    public showInactive: boolean = false;
    public pageNr: number = 0;
    public sortColumn: string = 'nr';
    public sortDescending: boolean = true;
    public raOwner: string = null;
    public lastReviewedBy: string = null;
}

export class PhraseOrderFilter {
    public topicId: number;
    public phraseId: number | null = null;
    public productId?: number | null = null;
    public pageNr: number = 0;
    public isPromoted: boolean = true;
}

export interface PhraseList {
    phrases: ListPhrase[];
    totalCount: number;
    selectedCount: number;
    unileverProductDevisions: PhraseUnileverProductDevision[];
    pageCount: number;
}

export class PhraseUnileverProductDevision {
    productUnileverProductDevisionId: number;
    productUnileverProductDevisionDescription: string;
}
export class EmptyPhraseList implements PhraseList {
    phrases: ListPhrase[] = new Array<ListPhrase>();
    totalCount: number = 0;
    selectedCount: number = 0;
    pageCount: number = 0;
    unileverProductDevisions: PhraseUnileverProductDevision[] = new Array<PhraseUnileverProductDevision>();
}

export interface ListPhrase {
    id: number;

    phraseId: number;
    nr: number;
    text: string;
    status: number;
    statusText: string;
    phraseTypeText: string;
    isActive: boolean;
    isAccepted: boolean;
    topicDescription: string;
    topicPath: string;
    topicId: number | null;
    unitOfMeasure: string;

    assignmentId: number;
    regulatoryMarket: string;
    regulatoryProductClass: string;
    regulatoryProductClassPath: string;
    detailLevel: string;
    linkedPhraseNr: string;
    mrpc: string[] | [];
    // assignedUPDPath: string[] | [];

    createdAt: Date;
    createdBy: string;
    lastModifiedAt: Date;
    lastModifiedBy: string;
    changeType?: PhraseChangeType;

    unileverProductDivisionId: number | null;
    unileverProductDivisionText: string;

    linkedGenericPhraseNr: number | null;
}

export interface Phrase extends Confirmation {
    id: number;
    nr: number;
    text: string;
    newText: string;
    status: number;
    statusText: string;
    unileverProductDivisionId: number;
    unileverProductDivisionPath: string[];
    topicId: number | null;
    topicText: string;
    topicPath: string[];
    phraseType: number;
    phraseTypeText: string;
    unitOfMeasure: string;
    phraseTextChanged: boolean;
    isActive: boolean;
    changeType: string;
    rejectedPhraseRemarks: string;
    detailLevelId: number | null;
    detailLevelDescription?: string;
    linkedGenericPhraseNr: number | null;
    linkedSpecificPhraseNrs: number[];
    createdAt: Date | null;
    createdBy: string;
    lastModifiedAt: Date | null;
    lastModifiedBy: string;
    universalEditAllowed: boolean;
    assignments: PhraseAssignment[];
    assignmentIdsToDelete: number[];
    linkedGenericPhraseId: number | null;
    linkedSpecificPhraseIds: number[] | null;
    phraseCanBeRestored: boolean;
    assesmentPageCount?: any;
    selectedAssesment?: any;
    totalAssesment?: any;
}

export class EmptyPhrase implements Phrase, Confirmation {
    id: number = -1;
    nr: number = 0;
    text: string = '';
    newText: string = '';
    status: number = 0;
    statusText: string;
    topicId: number | null = null;
    topicText: string = '';
    topicPath: string[] = new Array<string>();
    unileverProductDivisionId: number | null = null;
    unileverProductDivisionPath: string[] = new Array<string>();
    phraseType: number = 0;
    phraseTypeText: string = '';
    unitOfMeasure: string = '';
    phraseTextChanged: boolean = false;
    isActive: boolean = false;
    changeType: string = '';
    rejectedPhraseRemarks: string = '';
    detailLevelId: number | null;
    detailLevelDescription?: string = "";
    linkedGenericPhraseNr: number | null = null;
    linkedSpecificPhraseNrs: number[] = new Array<number>();
    createdAt: Date | null = null;
    createdBy: string = '';
    lastModifiedAt: Date | null = null;
    lastModifiedBy: string = '';
    assignments: PhraseAssignment[] = new Array<PhraseAssignment>();
    assignmentIdsToDelete: number[] = new Array<number>();
    confirmed: boolean | null = false;
    linkedGenericPhraseId: number | null = null;
    linkedSpecificPhraseIds: number[] = new Array<number>();
    universalEditAllowed: boolean = false;
    phraseCanBeRestored: boolean = false;
    assesmentPageCount: any = 0;
    selectedAssesment: any = 0;
    totalAssesment: any = 0;
}
export class IPhraseReOrderModel {
    snoIndex: number;
    id: number;
    phraseId: number;
    topicId: number;
    order: number;
    isDragged: boolean;
}