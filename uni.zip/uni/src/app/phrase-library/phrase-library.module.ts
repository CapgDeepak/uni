import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { QuillModule } from 'ngx-quill';

import { AuthorizationModule } from './../authorization/authorization.module';
import { BootstrapTemplatesModule } from './../bootstrap-templates/bootstrap-templates.module';
import { ToolsModule } from './../tools/tools.module';
import { SharedComponentsModule } from './../shared-components/shared-components.module';
import { PhraseLibraryComponent } from './phrase-library.component';
import { PhraseOrderingComponent } from './phrase-ordering.component';
import { AddPhraseComponent } from './add-phrase/add-phrase.component';
import { AddPhraseStep1Component } from './add-phrase/add-phrase-step1.component';
import { CopyPhraseComponent } from './copy-phrase/copy-phrase.component';
import { EditPhraseComponent } from './edit-phrase/edit-phrase.component';
import { PhraseAssignmentsComponent } from '../shared-components/phrase-assignments/phrase-assignments.component';
import { ApprovePhraseComponent } from './approve-phrase/approve-phrase.component';
import { PhraseExcelExportComponent } from './phrase-excel-export/phrase-excel-export.component';
import { RejectPhraseComponent } from './reject-phrase/reject-phrase.component';
import { PhraseAuditTrailComponent } from '../shared-components/phrase-audit-trail/phrase-audit-trail.component';
import { CalendarModule } from 'primeng/calendar';
import { TableModule } from 'primeng/table';
import { DragDropModule } from '@angular/cdk/drag-drop';

const routes: Routes = [
  {
    path: '',
    component: PhraseLibraryComponent,
  },
  {
    path: 'ordering',
    component: PhraseOrderingComponent
  }
];

@NgModule({
  imports: [
    AuthorizationModule,
    BootstrapTemplatesModule,
    CommonModule,
    FormsModule,
    NgbModule,
    QuillModule,
    SharedComponentsModule,
    ToolsModule,
    CalendarModule,
    TableModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    DragDropModule
  ],
  declarations: [
    AddPhraseComponent,
    AddPhraseStep1Component,
    ApprovePhraseComponent,
    CopyPhraseComponent,
    EditPhraseComponent,
    PhraseAssignmentsComponent,
    PhraseExcelExportComponent,
    PhraseLibraryComponent,
    PhraseOrderingComponent,
    RejectPhraseComponent,
    PhraseAuditTrailComponent
  ],
  entryComponents: [
    AddPhraseComponent,
    ApprovePhraseComponent,
    CopyPhraseComponent,
    EditPhraseComponent,
    PhraseExcelExportComponent,
    RejectPhraseComponent,
  ],
})

export class PhraseLibraryModule {
}
