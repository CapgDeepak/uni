import { NgModule, APP_INITIALIZER } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BootstrapTemplatesModule } from '././bootstrap-templates/bootstrap-templates.module';
import { TableModule as PrimeTableModule } from 'primeng/table';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ToolsModule } from './tools/tools.module';
import { environment } from '../environments/environment';
import { AppComponent } from './app.component';
import { AppModuleShared } from './app.shared.module';
import { AppRoutingModule } from './app-routing.module';
import { AuthorizationModule } from './authorization/authorization.module';
import { ToasterModule } from 'angular2-toaster';
import { MenubarModule } from 'primeng/menubar';
import { CalendarModule } from 'primeng/calendar';
import { ConfigService } from './tools/services/config.service';
import { PermissionsLoaderService } from './authorization/permissions-loader/permissions-loader.service';
import { AddEditHelpFileComponent } from './navmenu/add-edit-help-file/add-edit-help-file.component';
import { SharedComponentsModule } from './shared-components/shared-components.module';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { IPublicClientApplication, PublicClientApplication, InteractionType, BrowserCacheLocation, LogLevel } from '@azure/msal-browser';
// tslint:disable-next-line: max-line-length
import { MsalGuard, MsalInterceptor, MsalBroadcastService, MsalInterceptorConfiguration, MsalModule, MsalService, MSAL_GUARD_CONFIG, MSAL_INSTANCE, MSAL_INTERCEPTOR_CONFIG, MsalGuardConfiguration } from '@azure/msal-angular';
import { GenaichatbotComponent } from './GENAI/genaichatbot/genaichatbot.component'

const isIE = window.navigator.userAgent.indexOf("MSIE ") > -1 || window.navigator.userAgent.indexOf("Trident/") > -1;
export function loggerCallback(logLevel: LogLevel, message: string) {
    console.log(logLevel, message);
}

export function initializerFactory(env: ConfigService): any {
    const configSettingsData = env.loadAppConfig().then((value) => {
        console.log(value + "config");
    });
    return () => configSettingsData;
}

export function MSALInstanceFactory(config: ConfigService): IPublicClientApplication {
    return new PublicClientApplication({
        auth: {
            clientId: config.getMsalClientId(),
            authority: "https://login.microsoftonline.com/f66fae02-5d36-495b-bfe0-78a6ff9f8e6e",
            redirectUri: window.location.origin + '/home',
            postLogoutRedirectUri: '/'
        },
        cache: {
            cacheLocation: BrowserCacheLocation.LocalStorage,
            storeAuthStateInCookie: isIE, // set to true for IE 11
        },
        system: {
            allowNativeBroker: false, // Disables WAM Broker
            loggerOptions: {
                loggerCallback,
                logLevel: LogLevel.Info,
                piiLoggingEnabled: false
            }
        }
    });
}

export function MSALInterceptorConfigFactory(config: ConfigService): MsalInterceptorConfiguration {
    const env = window.location.origin.split('-').pop().split('.')[0];
    let scopeUri = "";
    if (env == "dev") {
        scopeUri = 'https://Unilever.onmicrosoft.com/8e44cffa-2ab8-4863-83af-7709da1123ef/user_impersonation';
    } else if (env == "test") {
        scopeUri = 'https://Unilever.onmicrosoft.com/ec44c196-433c-49be-8358-275f7dd0f480/user_impersonation';
    } else if (env == "qa") {
        scopeUri = 'https://Unilever.onmicrosoft.com/b70f8b69-4560-45d0-a4b4-74319f903fb9/user_impersonation';
    } else if (env == "regression") {
        scopeUri = 'https://Unilever.onmicrosoft.com/dbb3fe3e-ecf2-46f6-aa7c-241ca1401078/user_impersonation';
    } else if (env == "training") {
        scopeUri = 'https://Unilever.onmicrosoft.com/d9a88ff4-4115-4385-a68f-7cfac27b4d87/user_impersonation';
    } else {
        scopeUri = 'https://Unilever.onmicrosoft.com/2fc7d985-54bd-4cd3-8f98-ba083ee84afb/user_impersonation';
    }

    const protectedResourceMap = new Map<string, Array<string>>();
    protectedResourceMap.set(config.getAraDctUrl(), [scopeUri]);
    protectedResourceMap.set(config.getAraAdminUrl(), [scopeUri]);
    return {
        interactionType: InteractionType.Redirect,
        protectedResourceMap
    };
}
export function MSALGuardConfigFactory(): MsalGuardConfiguration {
    return { interactionType: InteractionType.Redirect };
}
@NgModule({
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        AppModuleShared,
        AuthorizationModule,
        ToasterModule.forRoot(),
        RouterModule,
        MenubarModule,
        NgbModule,
        BootstrapTemplatesModule,
        PrimeTableModule,
        FormsModule,
        CommonModule,
        SharedComponentsModule,
        ToolsModule,
        AppRoutingModule,
        CalendarModule
    ],
    providers: [
        PermissionsLoaderService,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: MsalInterceptor,
            multi: true
        },
        {
            provide: APP_INITIALIZER, useFactory: initializerFactory,
            deps: [ConfigService], multi: true
        },
        {
            provide: MSAL_INSTANCE,
            useFactory: MSALInstanceFactory,
            deps: [ConfigService]
        },
        {
            provide: MSAL_GUARD_CONFIG,
            useFactory: MSALGuardConfigFactory
        },
        {
            provide: MSAL_INTERCEPTOR_CONFIG,
            useFactory: MSALInterceptorConfigFactory,
            deps: [ConfigService]
        },
        MsalService,
        MsalGuard,
        MsalBroadcastService,
    ],
    bootstrap: [AppComponent],
    declarations: [AddEditHelpFileComponent, GenaichatbotComponent],
    entryComponents: [AddEditHelpFileComponent]
})
export class AppModule {
}
