import { TestBed, async, ComponentFixture, getTestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { By } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { PermissionsLoaderService } from './authorization/permissions-loader/permissions-loader.service';
import { TopicToUpdMapping, Permissions } from './authorization/authorization.types';
import { AuthorizationService } from './authorization/authorization.service';
import { MsalService, MsalBroadcastService, MSAL_INSTANCE } from '@azure/msal-angular';
import { ConfigService } from './tools/services/config.service';
import { IPublicClientApplication, PublicClientApplication } from '@azure/msal-browser';

const userHasPermissionToViewPhraseLibrary: boolean = false;
const userHasPermissionToViewPhraseMatrix: boolean = false;
const userHasPermissionToViewGramWorkList: boolean = false;
const userHasPermissionToViewMarketWorkList: boolean = false;
class AuthorizationServiceMock {
  userHasPermissionToViewPhraseLibrary() {
    return userHasPermissionToViewPhraseLibrary;
  }
  userHasPermissionToViewPhraseMatrix() {
    return userHasPermissionToViewPhraseMatrix;
  }
  userHasPermissionToViewGramWorkList() {
    return userHasPermissionToViewGramWorkList;
  }
  userHasPermissionToViewMarketWorkList() {
    return userHasPermissionToViewMarketWorkList;
  }
}

class PermissionsLoaderServiceMock {
  loadPermissions() {
    return new Promise<Permissions>((resolve, reject) => {
      resolve({
        'AraPReFDCT_Phrases_Read': [
          {
            rm: 1,
            tfc: 21,
            upd: 42,
            rpcs: [51],
          },
          {
            rm: 2,
            tfc: 22,
            upd: 42,
            rpcs: [52, 53],
          },
        ],
        'AraPReFDCT_Phrases_WriteWithAssignments': [
          {
            rm: 3,
            tfc: 23,
            upd: 42,
            rpcs: [54, 55],
          },
        ],
      });
    });
  }
  loadTopicToUpdMapping() {
    return new Promise<TopicToUpdMapping>((resolve, reject) => {
      resolve({
        1: [21, 22],
        5: [6, 55, 7]
      });
    });
  }
}

function MSALInstanceFactory(): IPublicClientApplication {
  return new PublicClientApplication({
    auth: {
      clientId: '6226576d-37e9-49eb-b201-ec1eeb0029b6',
      redirectUri: 'http://localhost:4200'
    }
  });
}

xdescribe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let permissionsServiceMock: PermissionsLoaderService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ],
      providers: [
        MsalService,
        MsalBroadcastService,
        ConfigService,
        {
          provide: MSAL_INSTANCE,
          useFactory: MSALInstanceFactory
        },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
        { provide: PermissionsLoaderService, useClass: PermissionsLoaderServiceMock },
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    component.isLoadingPermissions = false;
    component.isLoadingTopicMappings = false;
    component.isLoggedIn = true;
    permissionsServiceMock = getTestBed().get(PermissionsLoaderService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('should match snapshot', () => {
    it('for initial set up', () => {
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });
    it('when permissions are loading', () => {
      component.isLoadingPermissions = true;
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        (expect(fixture) as any).toMatchSnapshot();
      });
    });
  });

  describe('setLogin', () => {
    beforeEach(() => {
      component.isLoggedIn = false;
      fixture.detectChanges();
    });
    it('should not load permissions when not logged in', () => {
      const spy = jest.spyOn(permissionsServiceMock, 'loadPermissions');
      component.setLogin({ isLoggedIn: false });
      expect(spy).not.toHaveBeenCalled();
    });
    it('should not load topic mappings when not logged in', () => {
      const spy = jest.spyOn(permissionsServiceMock, 'loadTopicToUpdMapping');
      component.setLogin({ isLoggedIn: false });
      expect(spy).not.toHaveBeenCalled();
    });
    it('should load permissions when logged in', () => {
      const spy = jest.spyOn(permissionsServiceMock, 'loadPermissions');
      component.setLogin({ isLoggedIn: true });
      expect(spy).toHaveBeenCalled();
    });
    it('should load topic mappings when logged in', () => {
      const spy = jest.spyOn(permissionsServiceMock, 'loadTopicToUpdMapping');
      component.setLogin({ isLoggedIn: true });
      expect(spy).toHaveBeenCalled();
    });
    it('should update loggedin value appropriately', () => {
      component.setLogin({ isLoggedIn: false });
      expect(component.isLoggedIn).toBeFalsy();
      component.setLogin({ isLoggedIn: true });
      expect(component.isLoggedIn).toBeTruthy();
    });
  });

  it('should not render when permissions loading', () => {
    component.isLoadingPermissions = true;
    fixture.detectChanges();
    const divElement = fixture.debugElement.query(By.css('div'));
    expect(divElement).toBeFalsy();
  });

  it('should render when permissions not loading', () => {
    fixture.detectChanges();
    const divElement = fixture.debugElement.query(By.css('div'));
    expect(divElement).toBeTruthy();
  });
});
