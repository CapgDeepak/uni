import { Phrase, EmptyPhrase } from './../phrase-library/phrase-library.types';
import { Item } from "../tools/common.types";

export class ItemSelector {
    public items: Item[] = new Array<Item>();
    public parentId: number | null = null;
    public currentItem: Item = { id: -1, description: "", parentId: null, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false };
    public required: boolean = false;
}

export class MarketPhrases {
    public id: number | null;
    public description: string;
    public parentId: number | null;
    public requiresSubselection: boolean;
    public regulatoryMarketId: number;
    public curRpcId: number;
    public editMarket: boolean;
    public isPhraseAvailable: string;
    public marketHide: string | number;
    public isLoadedRpc: boolean;
    globalHide: number;
    public phrases: any[] = new Array<any>();
}

export class MarketIds {
    public marketid: number | null;
    public isPhraseAvailable: string;
}

export class MarketCell {
    marketId: number = -1;
    isSelected: boolean = false;
    allowModify: boolean = true;
    phrases: CellPhrase[] = new Array<CellPhrase>();
    editMarket: boolean;
    isPhraseAvailable: string;
    marketHide: string | number;
    isLoadedRpc: boolean;
    globalHide: number;
}
export class SelectedMatrixCell {
    regulatoryProductClassId: number;
    regulatoryMarketId: number;
    topicId: number;
}




export class RegulatoryProductClassItemSelector extends ItemSelector {
    public markets: MarketCell[] = new Array<MarketCell>();
    public hasDeclinedTopic: boolean;
}

export interface MatrixData {
    topicId: number;
    regulatoryMarketId: number;
    regulatoryProductClassId: number;
    canModify: boolean;
    rows: MatrixRow[];
}
export interface MatrixRow {
    hasDeclinedTopic: boolean;
    regulatoryProductClassId: number;
    canModify: boolean;
    cells: MatrixCell[];
}
export interface MatrixCell {
    regulatoryMarketId: number;
    canModify: boolean;
    phrases: CellPhrase[];
    allowModify: boolean;
}
export interface CellPhrase {
    rpcId: number;
    assignmentId: number;
    unileverProductDivisionId: number;
    unileverProductDivisionPath: string;
    assignmentStatus: string;
    detailLevelDescription: string;
    detailLevelId: number;
    isActive: boolean;
    isHidden: boolean;
    phraseId: number;
    phraseNr: number;
    phraseStatus: string;
    phraseText: string;
    phraseType: string;
    linkedPhraseNr: number;
}

export enum MatrixDetail {
    Any = 0,
    Standard = 1,
    Detailed = 2,
    InternalRA = 3
}

export enum MatrixStatus {
    Any = 0,
    Approved = 1,
    Rejected = 2,
    NotRelevant = 3,
    ToBeAssessed = 4,
    ToBeApproved = 5
}

export class MatrixFilter {
    public status: MatrixStatus = MatrixStatus.Any;
    public detail: MatrixDetail = MatrixDetail.Any;
}

export class PhraseFilter {
    public nr: string = '';
    public text: string = '';
    public phraseStatus: string = null;
    public assignmentStatus: string = null;
    public phraseType: number | null = null;
    public topicId: number | null = null;
    public topicText: string = '';
    public assignmentTopicText: string = '';
    public geographyText: string = '';
    public regulatoryProductClassText: string = '';
    public assignedUPDPathText: string = '';
    public detailLevelId: number | null = null;
    public linkedPhraseNr: string = '';
    public auditText: string = '';
    public showAssignments: boolean = false;
    public showAuditInfo: boolean = true;
    public showInactive: boolean = false;
    public pageNr: number = 0;
    public sortColumn: string = 'nr';
    public sortDescending: boolean = true;
    public raOwner: string = null;
}

export interface PhraseList {
    phrases: ListPhrase[];
    totalCount: number;
    selectedCount: number;
    pageCount: number;
}

export class EmptyPhraseList implements PhraseList {
    phrases: ListPhrase[] = new Array<ListPhrase>();
    totalCount: number = 0;
    selectedCount: number = 0;
    pageCount: number = 0;
}

export interface ListPhrase {
    id: number;

    phraseId: number;
    nr: number;
    text: string;
    status: number;
    statusText: string;
    phraseType: string;
    isActive: boolean;
    topicDescription: string;
    topicPath: string;
    unitOfMeasure: string;

    assignmentId: number;
    regulatoryMarket: string;
    regulatoryProductClass: string;
    detailLevel: string;

    createdAt: Date;
    createdBy: string;
    lastModifiedAt: Date;
    lastModifiedBy: string;
}

export class SelectedRegulatoryProductClass {
    id: number;
    description: number;
    isSelected: boolean;
}

export class HasChildResult {
    hasChilds: boolean = false;
    regulatoryProductClasses: SelectedRegulatoryProductClass[] = new Array<SelectedRegulatoryProductClass>();
}

export interface MatrixPhrase extends Phrase {
    regulatoryProductClassId: number;
    regulatoryMarketId: number;
}

export class EmptyMatrixPhrase extends EmptyPhrase implements MatrixPhrase {
    detailLevelId: number | null = null;
    regulatoryProductClassId: number = 0;
    regulatoryMarketId: number = 0;
}