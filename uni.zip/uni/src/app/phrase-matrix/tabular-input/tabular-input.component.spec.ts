import { FormsModule, NgForm, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Observable } from 'rxjs';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { TabularInputComponent } from './tabular-input.component';
import { ToolsModule } from '../../tools/tools.module';
import { TabularInputData } from '../matrix-cell-edit/matrix-cell-edit.types';
import { ConfigService } from '../../tools/services/config.service';
import { ToasterService } from 'angular2-toaster';
import { SharedComponentsModule } from '../../shared-components/shared-components.module';

class ToasterServiceMock { }
class MockAdalService {
  userInfo = {
    authenticated: true
  };
  getCachedToken() { return 'token'; }
  acquireToken(clientId: string) {
    return new Observable(observer => {
      observer.next(`token: ${clientId}`);
      observer.complete();
    });
  }
}

class MockAppConfigService {
  getMsalConfigTenant() {
    return 'TenantId';
  }
  getMsalClientId() {
    return 'ClientId';
  }
  getAraDctUrl() {
    return 'http://dct.com';
  }
}

describe('TabularInputComponent', () => {
  let component: TabularInputComponent;
  let fixture: ComponentFixture<TabularInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ToolsModule,
        SharedComponentsModule,
        HttpClientTestingModule,
        ReactiveFormsModule,
        NgbModule
      ],
      declarations: [
        TabularInputComponent,
      ],
      providers: [
        { provide: ConfigService, useClass: MockAppConfigService },
        { provide: ToasterService, useClass: ToasterServiceMock },
        { provide: NgForm, useValue: new NgForm([], []) },
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabularInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display no data when nothing set', () => {
    expect(fixture.debugElement.nativeElement.querySelector('p').textContent).toEqual('No items');
  });

  it('should match snapshot with data set', () => {
    const data = createTabularInputsData();
    component.writeValue(data);
    fixture.detectChanges();

    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot with inactive data set', () => {
    const tabularInputs = createTabularInputsData();
    tabularInputs[0].isActive = false;
    component.writeValue(tabularInputs);
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot with toBeAssessed tabular input', () => {
    const tabularInputs = createTabularInputsData();
    tabularInputs[0].isActive = false;
    tabularInputs[0].phraseStatus = 'Approved';
    tabularInputs[0].phraseAssignmentStatus = 'ToBeAssessed';
    tabularInputs[0].assessmentReason = 'New Assignment';
    component.writeValue(tabularInputs);
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot with data set and allowModify false ', () => {
    const data = createTabularInputsData();
    component.writeValue(data);
    component.allowModify = false;
    fixture.detectChanges();

    (expect(fixture) as any).toMatchSnapshot();
  });

  it('onDataChanged emits event', (done) => {
    jest.spyOn(component.dataChanged, 'emit');
    component.dataChanged.subscribe(e => {
      expect(e).toBeTruthy();
      expect(component.dataChanged.emit).toHaveBeenCalledTimes(1);
      done();
    });
    fixture.detectChanges();
    component.onDataChanged();
  });

  // it('should should emit event when value1 changes', (done) => {
  //   testInputChange(done, '#value1');
  // });

  // it('should should emit event when value2 changes', (done) => {
  //   testInputChange(done, '#value2');
  // });

  // it('should should emit event when uom changes', (done) => {
  //   component.writeValue(createTabularInputsData());
  //   fixture.detectChanges();
  //   testInputChange(done, '#uom');
  // });

  it('should match snapshot with no data set', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  describe('isTabAssignmentEditDisabled', () => {
    it('Should return false given Approved phrase and allowModify true', () => {
      const data = createTabularInputsData();
      component.allowModify = true;
      const result = component.isTabAssignmentEditDisabled(data[0]);
      expect(result).toBeFalsy();
    });
    it('Should return true given Approved phrase and allowModify false', () => {
      const data = createTabularInputsData();
      component.allowModify = false;
      const result = component.isTabAssignmentEditDisabled(data[0]);
      expect(result).toBeTruthy();
    });
    it('Should return true given Rejected phrase and allowModify true', () => {
      const data = createTabularInputsData();
      data[0].phraseStatus = 'Rejected';
      component.allowModify = true;
      const result = component.isTabAssignmentEditDisabled(data[0]);
      expect(result).toBeTruthy();
    });
    it('Should return true given inactive phrase and allowModify true', () => {
      const data = createTabularInputsData();
      data[0].isActive = false;
      component.allowModify = true;
      const result = component.isTabAssignmentEditDisabled(data[0]);
      expect(result).toBeTruthy();
    });
  });

  function testInputChange(done: Function, inputId: string) {
    jest.spyOn(component.dataChanged, 'emit');
    component.dataChanged.subscribe(e => {
      expect(e).toBeTruthy();
      expect(component.dataChanged.emit).toHaveBeenCalledTimes(1);
      done();
    });
    component.writeValue(createTabularInputsData());
    fixture.detectChanges();
    const val1Input = fixture.debugElement.query(By.css(inputId));
    val1Input.triggerEventHandler('change', {});
  }
});

function createTabularInputsData() {
  const inputs = new Array<TabularInputData>();
  inputs.push({
    isRange: true, inputValue1: "2", inputValueType1: 2, inputValue2: "3", inputValueType2: 5,
    phraseId: 2, phraseAssignmentId: 2, unileverProductDivisionId: 9, unileverProductDivisionPath: new Array<string>(), phraseNr: 1, phraseAssignmentStatus: "ToBeAssessed",
    phraseText: "blah", phraseStatus: "Approved", isActive: true,
    phraseDetailLevelDescription: "Detailed", assessmentReason: "something", sourceLocation: "somewhere", inheritedSourceLocation: "somewhere else",
    unitOfMeasure: "kg", isNew: false, linkedPhraseNr: 9
  });
  return inputs;
}