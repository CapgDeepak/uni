import { Component, OnInit, forwardRef, EventEmitter, Output, Input } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR, ControlContainer, NgForm, FormBuilder, FormGroup } from '@angular/forms';
import { TabularInputData } from '../matrix-cell-edit/matrix-cell-edit.types';
import { HttpService } from '../../tools/services/http.service';
import { UrlEndpoint, PhraseStatus } from "../../tools/constants";
import { Item } from "../../shared-components/select-editable/select-editable.component";
import { QuillSettingsService } from '../../tools/services/quill-settings.service';

const noop = () => {
};

@Component({
    selector: 'ara-tabular-input',
    templateUrl: './tabular-input.component.html',
    styleUrls: ['./tabular-input.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => TabularInputComponent),
            multi: true,
        },
    ],
    viewProviders: [
        {
            provide: ControlContainer,
            useExisting: NgForm,
        }
    ],
})
export class TabularInputComponent implements OnInit, ControlValueAccessor {
    // This property is bound to the ngModel of the call site by the writeValue
    // method below. This method is an implementation of the method declared in
    // the ControlValueAccessor interface.
    tabularInputs: TabularInputData[] = new Array<TabularInputData>();
    public uomItems: Item[] = new Array<Item>();
    ChangeItem = [];
    tabularInputDialog: boolean = false;
    assignmentForm: FormGroup;
    @Output() public quillformats;
    @Output() public quillmodules;
    event;
    inputTitle = "Tabular Input Value";
    phraseAssignmentId: any;
    tabInputValuePhraseId: number;
    formatedValue2: any = '';
    type: any = '';
    constructor(private fb: FormBuilder, quillSettings: QuillSettingsService,
        private httpService: HttpService) {
        this.quillformats = quillSettings.quillformats;
        this.quillmodules = quillSettings.quillmodules;
    }

    ngOnInit(): void {
        this.httpService.get('api/' + UrlEndpoint.UnitOfMeasure_AllItems).subscribe(result => {
            this.uomItems = result as Item[];
        }, error => console.error(error)
        );
        localStorage.setItem("changeTabular", '');
        this.assignmentForm = this.fb.group({
            assignment: '',
        });
    }

    @Output()
    enableBtm: EventEmitter<boolean> = new EventEmitter<boolean>();

    @Output()
    selectionChange: EventEmitter<TabularInputData> = new EventEmitter<TabularInputData>();

    @Output()
    dataChanged: EventEmitter<boolean> = new EventEmitter<boolean>();
    @Output() valueChange = new EventEmitter();

    @Input() hasAssessPermission: boolean;
    @Input()
    selected: TabularInputData = null;
    formatedValue: string = '';

    @Input() orgtabulardata;
    selectTabInput(value: TabularInputData) {
        if (value != this.selected) {
            this.selected = value;
            this.selectionChange.emit(value);
        }
    }

    @Input()
    allowModify: boolean = true;

    get value(): any {
        return this.tabularInputs;
    }
    set value(newValue: any) {
        this.writeValue(newValue);
    }

    private onTouchedCallback: () => void = noop;
    private onChangeCallback: (_: any) => void = noop;

    public blur(): void {
        this.onTouchedCallback();
    }

    onDataChanged() {
        this.dataChanged.emit(true);
    }

    onDataChanged1(event, id, type, inputValue?) {
        this.formatedValue = inputValue ? inputValue.replace(/<.*?>/g, '') : '';
        this.dataChanged.emit(true);
        this.checkingChangeTabular(event, id, type, inputValue);
    }

    public isTabAssignmentEditDisabled(tabData: TabularInputData) {
        return !(this.allowModify && tabData && tabData.isActive && tabData.phraseStatus == PhraseStatus.Approved);
    }

    /**
     * This method implements the writeValue method of the ControlValueAccessor interface.
     * It is this method that essentially binds the ngModel of this component
     * (specified at the call site, e.g. MatrixCellEditComponent) to the tabularInputs property.
     */
    writeValue(obj: any): void {
        this.tabularInputs = obj || new Array<TabularInputData>();
    }

    /**
     * This method implements the registerOnChange method of the ControlValueAccessor.
     */
    registerOnChange(fn: any): void {
        this.onChangeCallback = fn;
    }

    /**
     * This method implements the registerOnTouched method of the ControlValueAccessor.
     */
    registerOnTouched(fn: any): void {
        this.onTouchedCallback = fn;
    }

    isAssessmentReasonShown(tabInput: TabularInputData) {
        return tabInput.phraseAssignmentStatus === 'ToBeAssessed' && tabInput.phraseStatus === 'Approved';
    }
    checkingChangeTabular(event, id, type, inputValue: '') {
        const findDetails = this.orgtabulardata.find(x => x.phraseId == id);
        if (type === 'operator1') {
            const val = findDetails['inputValueType1'];
            if (val == null && event.target.value == "") {
                const index: number = this.ChangeItem.indexOf(id + type);
                const Finddata = this.ChangeItem.splice(index, 1);
                this.ChangeItem = this.ChangeItem.filter(item => item !== Finddata);
            }
            else if (val !== event.target.value) {
                this.ChangeItem.push(id + type);
                this.ChangeItem = Array.from(new Set(this.ChangeItem));
            } else {
                const index: number = this.ChangeItem.indexOf(id + type);
                const Finddata = this.ChangeItem.splice(index, 1);
                this.ChangeItem = this.ChangeItem.filter(item => item !== Finddata);
            }
        }
        else if (type === 'operator2') {
            const val = findDetails['inputValueType2'];
            if (val == null && event.target.value == "") {
                const index: number = this.ChangeItem.indexOf(id + type);
                const Finddata = this.ChangeItem.splice(index, 1);
                this.ChangeItem = this.ChangeItem.filter(item => item !== Finddata);
            }
            else if (val !== event.target.value) {
                this.ChangeItem.push(id + type);
                this.ChangeItem = Array.from(new Set(this.ChangeItem));
            } else {
                const index: number = this.ChangeItem.indexOf(id + type);
                const Finddata = this.ChangeItem.splice(index, 1);
                this.ChangeItem = this.ChangeItem.filter(item => item !== Finddata);
            }

        }
        else if (type === 'value1') {
            const val = findDetails['inputValue1'];
            // if (val == null &&  event.target.value == ""){
            if (val == null && inputValue == "") {
                const index: number = this.ChangeItem.indexOf(id + type);
                const Finddata = this.ChangeItem.splice(index, 1);
                this.ChangeItem = this.ChangeItem.filter(item => item !== Finddata);
            }
            // else if (val !== event.target.value.trim()){
            else if (val !== inputValue) {
                this.ChangeItem.push(id + type);
                this.ChangeItem = Array.from(new Set(this.ChangeItem));
            } else {
                const index: number = this.ChangeItem.indexOf(id + type);
                const Finddata = this.ChangeItem.splice(index, 1);
                this.ChangeItem = this.ChangeItem.filter(item => item !== Finddata);
            }

        }
        else if (type === 'value2') {

            const val = findDetails['inputValue2'];
            if (val == null && inputValue == "") {
                const index: number = this.ChangeItem.indexOf(id + type);
                const Finddata = this.ChangeItem.splice(index, 1);
                this.ChangeItem = this.ChangeItem.filter(item => item !== Finddata);
            }
            else if (val !== inputValue) {
                this.ChangeItem.push(id + type);
                this.ChangeItem = Array.from(new Set(this.ChangeItem));
            } else {
                const index: number = this.ChangeItem.indexOf(id + type);
                const Finddata = this.ChangeItem.splice(index, 1);
                this.ChangeItem = this.ChangeItem.filter(item => item !== Finddata);
            }

        }
        else if (type === 'uom') {
            const val = findDetails['unitOfMeasure'];

            if (val !== event.target.value) {
                this.ChangeItem.push(id + type);
                this.ChangeItem = Array.from(new Set(this.ChangeItem));
            } else {
                const index: number = this.ChangeItem.indexOf(id + type);
                const Finddata = this.ChangeItem.splice(index, 1);
                this.ChangeItem = this.ChangeItem.filter(item => item !== Finddata);
            }
        } else if (type === 'checkbox') {
            const val = findDetails['isRange'];
            if (val !== event.target.checked) {
                this.ChangeItem.push(id + type);
                this.ChangeItem = Array.from(new Set(this.ChangeItem));
            } else {
                const index: number = this.ChangeItem.indexOf(id + type);
                const Finddata = this.ChangeItem.splice(index, 1);
                this.ChangeItem = this.ChangeItem.filter(item => item !== Finddata);
            }
        }
        this.valueChange.emit(this.ChangeItem);
    }

    openClarificationTextEditor(event, tabinput, type) {
        this.tabularInputDialog = true;
        this.event = event;
        this.phraseAssignmentId = tabinput.phraseAssignmentId;
        this.type = type;
        if (type == 'value1') {
        // this.assignmentForm.get('assignment').setValue(inputVal);
        setTimeout(() => {
            this.assignmentForm.get('assignment').patchValue(tabinput.inputValue1);
        }, 200);
    } else {
        setTimeout(() => {
            this.assignmentForm.get('assignment').patchValue(tabinput.inputValue2);
        }, 200);
    }
      //  this.enableBtm.emit(false);
    }

    onClickSaveInput() {
        console.log(this.assignmentForm.get('assignment').value);
        this.tabularInputs.forEach(x => {
            if (x.phraseAssignmentId == this.phraseAssignmentId) {
                this.tabInputValuePhraseId = x.phraseId;
                if (this.type == 'value1') {
                    x.inputValue1 = this.assignmentForm.get('assignment').value;
                } else {
                    x.inputValue2 = this.assignmentForm.get('assignment').value;
                }
            }
        });
        this.tabularInputDialog = false;
        const event = {};
        // manually calling on change input value
        if (this.type == 'value1') {
        this.onDataChanged1(event, this.tabInputValuePhraseId, 'value1', this.assignmentForm.get('assignment').value);
        } else {
        this.onDataChanged1(event, this.tabInputValuePhraseId, 'value2', this.assignmentForm.get('assignment').value);
        }
        // commenting below -> after saving input value in rich text editor its causing first row selection inspite of previously selected row
        // const element = document.getElementById('value1') as HTMLElement;
        // element.click();
        // if (this.formatedValue.length < 1501) {
        //    this.enableBtm.emit(true);
        // }
    }

    onClickCancelInput() {
        this.tabularInputDialog = false;
        // if (this.formatedValue.length < 1501) {
        //  this.enableBtm.emit(true);
        // }
    }

    isMaxInputValue(tabInput, type) {
       // const value = tabInput.inputValue1 ? tabInput.inputValue1.replace(/<.*?>/g, '') : '';
        if (type == 'value1') {
            const value = tabInput.inputValue1 ? tabInput.inputValue1.replace(/<.*?>/g, '') : '';
            this.formatedValue = value ? value.replace(/&nbsp;/g, ' ') : '';
            return this.formatedValue ? this.formatedValue.length > 1500 : false;
        } else {
            const value2 = tabInput.inputValue2 ? tabInput.inputValue2.replace(/<.*?>/g, '') : '';
            this.formatedValue2 = value2 ? value2.replace(/&nbsp;/g, ' ') : '';
            return this.formatedValue2 ? this.formatedValue2.length > 1500 : false;
        }
    }

    public get maxValue1TooltipText(): string {
        return 'The value is too long (max 1500 characters, you have entered ' + this.formatedValue.length + ')';
    }

    public get maxValue2TooltipText(): string {
        return 'The value is too long (max 1500 characters, you have entered ' + this.formatedValue2.length + ')';
    }
}
