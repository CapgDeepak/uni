import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { AuthorizationModule } from './../authorization/authorization.module';
import { BootstrapTemplatesModule } from './../bootstrap-templates/bootstrap-templates.module';
import { ToolsModule } from './../tools/tools.module';
import { SharedComponentsModule } from './../shared-components/shared-components.module';

import { MatrixCellDetailsService } from './matrix-cell-edit/matrix-cell-details.service';
import { MatrixCellEditComponent } from './matrix-cell-edit/matrix-cell-edit.component';
import { MatrixCellEditService } from './matrix-cell-edit/matrix-cell-edit.service';
import { PhraseMatrixComponent } from './phrase-matrix.component';
import { TabularInputComponent } from './tabular-input/tabular-input.component';
import { TopicTreeComponent } from './topic-tree/topic-tree.component';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { QuillModule } from 'ngx-quill';
import { PhraseEditListComponent } from './phrase-edit-list/phrase-edit-list.component';

import { MatrixPhraseEditComponent } from './matrix-phrase-edit/matrix-phrase-edit.component';
import { PhraseAssessComponent } from './phrase-assess/phrase-assess.component';
import { PhraseAssessService } from './phrase-assess/phrase-assess.service';
import { TopicAssessComponent } from './topic-assess/topic-assess.component';
import { TopicAssessService } from './topic-assess/topic-assess.service';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { ReactiveFormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        AuthorizationModule,
        BootstrapTemplatesModule,
        ToolsModule,
        SharedComponentsModule,
        NgbModule,
        QuillModule,
        NgMultiSelectDropDownModule.forRoot(),
        ReactiveFormsModule,
        RouterModule.forChild([{
            path: '',
            component: PhraseMatrixComponent
        }]),
        DialogModule,
        ButtonModule
    ],
    declarations: [
        MatrixCellEditComponent,
        MatrixPhraseEditComponent,
        PhraseAssessComponent,
        PhraseEditListComponent,
        PhraseMatrixComponent,
        TabularInputComponent,
        TopicAssessComponent,
        TopicTreeComponent,
    ],
    entryComponents: [
        MatrixCellEditComponent,
        MatrixPhraseEditComponent,
        PhraseAssessComponent,
        TopicAssessComponent,
    ],
    providers: [
        MatrixCellDetailsService,
        MatrixCellEditService,
        PhraseAssessService,
        TopicAssessService,
    ]
})

export class PhraseMatrixModule {
}