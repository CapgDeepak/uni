import { MarketRpcAndTopicScopedPermissions } from '../tools/shared-types/permissions/market-rpc-and-topic-scoped-permissions';
import { Params, ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit, DoCheck , Renderer2  } from '@angular/core';

import { DetailLevel, Item, RegulatoryMarketHierarchyItem } from './../tools/common.types';
import { AuthorizationService } from './../authorization/authorization.service';
import { CacheService } from '../tools/services/cache.service';

import { MatrixCellEditComponent } from './matrix-cell-edit/matrix-cell-edit.component';

import { ItemSelector, RegulatoryProductClassItemSelector, MatrixData, MarketCell,
    SelectedMatrixCell, CellPhrase, MatrixFilter, MatrixDetail, MatrixStatus, MarketPhrases
} from './phrase-matrix.types';
import { TopicTreeNode } from './topic-tree/topic-tree.types';
import { SideDialogService } from '../tools/side-dialog/side-dialog.service';
import { PhraseStatus, AssignmentStatus, DetailLevels, TopicLinkStatus, UrlEndpoint, PhraseStatusToString, AssignmentStatusToString } from '../tools/constants';
import { DialogService } from '../tools/services/dialog.service';
import { TopicAssessComponent } from './topic-assess/topic-assess.component';
import { HttpService } from '../tools/services/http.service';
import { Permission } from '../tools/shared-types/permissions/permission';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { MatrixPhraseEditComponent } from './matrix-phrase-edit/matrix-phrase-edit.component';
import { SelectorContext } from '@angular/compiler';

@Component({
    selector: 'ara-phrase-matrix',
    templateUrl: './phrase-matrix.component.html',
    styleUrls: ['./phrase-matrix.component.scss']
})
export class PhraseMatrixComponent implements OnInit , DoCheck  {
    public filter: MatrixFilter = new MatrixFilter();
    public assessTopicPermissions: MarketRpcAndTopicScopedPermissions = {
        permissions: [Permission.AraPReFDCT_PhraseAssignments_DeclineTopic],
        regulatoryMarketId: null,
        regulatoryProductClassId: null,
        topicId: null
    };
    retiredMarket: boolean = false;
    dummyArray: any[] = [];
    topicId: number;
    regulatoryMarketId: number;
    rpcId: number;
    isMarketPreSelected: boolean = true;
    isDetailLevelSystemSelected: boolean = true;
    isStatusSystemSelected: boolean = true;
    isbtnSystemSelected: boolean = false;
    isLoadPhrase: boolean = false;
    selctedObj: any;
    permissionMarkets: boolean = false;
    filteredMarkets: any[] = [];
    firstSelected: number;
    marketForm: FormGroup;
    markeIds: any[] = [];
    selectedItems = [];
    selectedShowEntireRPCMatrix: boolean = true;
    marketDropdownSettings: any = {
        singleSelection: true,
        enableCheckAll: false,
        allowSearchFilter: true,
        closeDropDownOnSelection: true,
        clearable: false,
        idField: 'id',
        textField: 'description',
        selectAllText: 'Select Market',
        itemsShowLimit: 3,

    };

    clickCount = 0;
    constructor(
        private sideDialogService: SideDialogService,
        private authorizationService: AuthorizationService,
        private dialogService: DialogService,
        private cacheService: CacheService,
        private httpService: HttpService,
        private route: ActivatedRoute,
        private router: Router,
        private fb: FormBuilder,
        private renderer: Renderer2

    ) { }

    marketSelected: any;
    tempArrayRPCS: any[] = [];
    selectedMarketArr: any[];
    MarketArray: MarketPhrases[] = new Array<MarketPhrases>();
    topicFilter: string = '';
    selectedTopic: TopicTreeNode | null = null;

    detailLevels: DetailLevel[] = new Array<DetailLevel>();
    initialSelection: SelectedMatrixCell | null = null;

    allMarkets: RegulatoryMarketHierarchyItem[] = new Array<RegulatoryMarketHierarchyItem>();
    filteredIds: any[];
    marketTree: ItemSelector[] = new Array<ItemSelector>(); // the currently displayed Market hierarchy
    selectedMarketItemId: number = -1;
    selectedRegulatoryMarketId: number = -1;
    newSelectedMarketId: number = 0;

    currentRpcs: Item[] = new Array<Item>(); // current available RPCs - filtered by Topic and Market
    rpcTree: RegulatoryProductClassItemSelector[] = new Array<RegulatoryProductClassItemSelector>(); // the currently displayed RPC hierarchy
    selectedRpcId: number = -1;
    hasDeclinedTopic: boolean = false;
    isbtnEnabled: boolean = false;
    isbtnEditEnabled: boolean = false;
    isbtnViewEnabled: boolean = false;
    isbtnEdit: boolean = false;
    isbtnTopic: boolean = false;
    isRpcSelected: boolean = false;
    marketrpcAndPhrases = {
        rpcId: [],
        marketId: [],
        phrases: []
    };

    matrix: MatrixData = null;

    private _isLoading: boolean = true;
    ngDoCheck(){
     setTimeout(() => {
        const marketHtnl = document.querySelectorAll(".item2 li.multiselect-item-checkbox");
        for (let index = 0; index < marketHtnl.length; index++) {
            const Market = marketHtnl.item(index).textContent;
            const marketStatus = this.marketTree[0]["items"].find(x => x.description.toLowerCase() === Market.toLowerCase());
            const truefalse = marketStatus != undefined && marketStatus['marketStatus'].toLowerCase() == 'RetiredMarket'.toLowerCase() ? true : false;
            if (truefalse){
                this.renderer.setStyle( marketHtnl.item(index), 'font-style', 'italic');
                this.renderer.setStyle( marketHtnl.item(index).getElementsByTagName("div").item(0), 'color', '#dc3545');
              }
        }

     }, 750);
    }
    ngOnInit(): void {
        let selection = null;
        this.route.queryParams.forEach((params: Params) => {
            selection = this.getCellSelection(+sessionStorage.getItem("wl-msel-marketId"), +sessionStorage.getItem("wl-msel-rpcId"), +sessionStorage.getItem("wl-msel-topicId"));
            sessionStorage.removeItem("wl-msel-marketId");
            sessionStorage.removeItem("wl-msel-rpcId");
            sessionStorage.removeItem("wl-msel-topicId");
        });
        this.marketForm = this.fb.group({
            marketName: new FormControl(''),
        });

        if (selection !== null) {
            this.initialSelection = selection;
            localStorage.setItem("selectedTopicId", this.initialSelection.topicId.toString());
            localStorage.setItem("selectedRpcId", this.initialSelection.regulatoryProductClassId.toString());
            localStorage.setItem("topicId", this.initialSelection.topicId.toString());
        }
        // this.loadMarkets() changes ;
        this.checkWhetherTheUserHasEditOrViewPermission("null");

        this.cacheService.getDetailLevels().then(results => {
            this.detailLevels = results;
        });
    }

    public checkWhetherTheUserHasEditOrViewPermission(evt: any) {
        const per = [];
        this._isLoading = true;
        this.isbtnEnabled = false;
        this.isbtnEditEnabled = false;
        this.filteredIds = [];
        this.permissionMarkets = false;
        if (evt != "null" && (evt.target.name == 'btnView' || evt.target.name == 'btnEdit')) {
            per.push(Permission.AraPReFDCT_PhraseAssignments_DeclineTopic);
            per.push(Permission.AraPReFDCT_PhraseAssignments_Assess);
            per.push(Permission.AraPReFDCT_PhraseAssignments_Read);
            this.isbtnEnabled = this.authorizationService.checkUserHasAllPermissions(per) ? true : false;
            this.loadMarkets(evt.target.name);
        }
        else {
            this.isbtnEnabled = this.authorizationService.userHasPermissionToEditPhraseMatrix();
            this.loadMarkets("null");
        }
    }
    private loadMarkets(obj: any) {
        this.cacheService.getRegulatoryMarkets().then(markets => {
            this.allMarkets = markets;
            this.filteredIds = markets;
            if (this.filteredIds.some(s => s.isUserAuthorizedMarket == true)) {
                this.filteredIds = this.filteredIds.filter(val => val.isUserAuthorizedMarket == true);
            }
            else if (this.filteredIds.some(s => s.isMarketTrue == true)) {
                this.filteredIds = this.filteredIds.filter(val => val.isMarketTrue == true);
            }
            // this.filteredIds = this.filteredIds.filter(val => val.isUserAuthorizedMarket == true).length <= 0 ? this.filteredIds.filter(val => val.isMarketTrue == true) : [0];
            if (this.filteredIds.length > 0 && this.allMarkets.length > 0) {
                this.tempArrayRPCS = [];
                this.filteredIds.forEach(c => {
                    // if (this.filteredIds.find(a => c.id == a.parentId)) {
                    this.getHierarchyMarkets(c);
                    // }
                });
                this.permissionMarkets = true;
                this.filteredMarkets = [...this.filteredIds];
                const res = this.tempArrayRPCS != [] ? this.filteredIds.concat(this.tempArrayRPCS) : [];
                this.allMarkets = res != [] || res.length > 0 ? res.filter((item, index) => res.indexOf(item) === index) : this.allMarkets;
            }
            this.filteredIds = [];
            this.tempArrayRPCS = [];
            let selector = new ItemSelector();
            if (this.initialSelection != null) {
                selector.items = this.initialiseMarketTree();
                const index = selector.items.findIndex(myObj => myObj.regulatoryMarketId == this.initialSelection.regulatoryMarketId);
                selector.currentItem.id = selector.items[index].id;
                selector.currentItem.description = selector.items[index].description;
                selector.currentItem.isUserAuthorizedMarket = selector.items[index].isUserAuthorizedMarket;
                selector.currentItem.parentId = selector.items[index].parentId;
                selector.currentItem.regulatoryMarketId = selector.items[index].regulatoryMarketId;
                selector.currentItem.requiresSubselection = selector.items[index].requiresSubselection;
            }
            else {
                selector = JSON.parse(localStorage.getItem("marketSelection")) != null ? JSON.parse(localStorage.getItem("marketSelection")) : selector;
                this.initialiseMarketTree();
            }
            this.newSelectedMarketId = selector.currentItem.id > 0 ? selector.currentItem.id : 0;
            // if previously selected, set the tree back to this selection, otherwise expand it out to the last available item
            this.selctedObj = obj;
            const market = {
                id: selector.currentItem.id,
                description: selector.currentItem.description
            };
            if (selector.currentItem.id > 0) {
                this.selctedObj = obj;
                this.marketForm.controls['marketName'].setValue([market]);
                this.setSelectedMarket(selector.currentItem.regulatoryMarketId, selector.currentItem.id, 1);
            }
            else if ((this.allMarkets.length > 0) && (this.marketTree[0].items.length > 0)) {
                const itemSelector = this.marketTree[this.marketTree.length - 1];
                if (selector.currentItem.id > 0) {
                    this.setCurrentMarketId(selector, selector.currentItem.id, 2);
                    this.marketForm.controls['marketName'].setValue([market]);
                }
                else {
                    this.marketSelected = this.allMarkets.filter(x => x.id == itemSelector.currentItem.id);
                    this.MarketArray = [];
                    this.tempArrayRPCS = [];
                    this.selectedMarketArr = [];
                    this.getHierarchyMarkets(this.marketSelected[0]);
                    this.MarketArray = [...this.tempArrayRPCS].reverse();
                    this.MarketArray.push(this.marketSelected[0]);
                    this.selectedMarketArr = this.MarketArray;
                    const marketItem = {
                        id: itemSelector.currentItem.id,
                        description: itemSelector.currentItem.description
                    };
                    this.marketForm.controls['marketName'].setValue([marketItem]);
                    this.setCurrentMarketId(itemSelector, itemSelector.currentItem.id, 0);
                }
            }
            this._isLoading = false;
        }).catch(() => {
            this._isLoading = false;
        });
    }

    // traverse up market tree to build selected market path
    private getSelectedMarketPath(selection: number[], marketItemId: number) {
        const market = this.allMarkets.find(m => m.id == marketItemId);
        if (market) {
            if (market.parentId && (market.parentId > 0)) {
                this.getSelectedMarketPath(selection, market.parentId);
            }
            selection.push(market.id);
        }
    }

    private setSelectedMarket(marketItemId: number, id: number, isSelected: number) {
        const market = this.find(this.allMarkets, marketItemId, id);
        const newMarket = [];
        if (market.length == 0) {
            this.allMarkets.forEach(function (e) {
                if (e.regulatoryMarketId == marketItemId) {
                    newMarket.push(e);
                }
            });
        }
        this.assessTopicPermissions = {
            ...this.assessTopicPermissions,
            regulatoryMarketId: marketItemId
        };

        const selection = new Array<number>();
        if (market.length > 0) {
            this.getSelectedMarketPath(selection, market[0].id);
        }
        else if (newMarket.length > 0) {
            this.newSelectedMarketId = newMarket[0].id;
            this.getSelectedMarketPath(selection, newMarket[0].id);
        }
        else {
            this.newSelectedMarketId = this.firstSelected;
            this.getSelectedMarketPath(selection, this.firstSelected);
        }
        this.setMarketSelection(selection, isSelected);
    }
    private find(arr, mid, id) {
        const result = [];
        if (mid && id) {
            arr.forEach(function (e) {
                if (e.regulatoryMarketId == mid && e.id == id) {
                    result.push(e);
                }
            });
        }
        return result;
    }

    private setCurrentMarketId(selector: ItemSelector, marketItemId: number, isSelected: number) {
        this._isLoading = true;
        this.selectedMarketItemId = marketItemId;
        const regulatoryMarket = this.allMarkets.find(m => m.id == marketItemId);
        if (regulatoryMarket && regulatoryMarket.regulatoryMarketId) {
            this.selectedRegulatoryMarketId = regulatoryMarket.regulatoryMarketId;
        } else {
            this.selectedRegulatoryMarketId = -1;
        }

        this.assessTopicPermissions = {
            ...this.assessTopicPermissions,
            regulatoryMarketId: this.selectedRegulatoryMarketId
        };
        selector.currentItem = {
            id: -1, description: '', parentId: null, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false
        };
        if (marketItemId > 0) {
            if (isSelected == 2) {
                selector.currentItem.id = selector.items[marketItemId].id;
                selector.currentItem.description = selector.items[marketItemId].description;
                selector.currentItem.regulatoryMarketId = selector.items[marketItemId].regulatoryMarketId;
                selector.currentItem.parentId = selector.items[marketItemId].parentId;
                localStorage.setItem("marketSelection", this.stringifyObj(selector));
                // sessionStorage.setItem("marketSelection", this.stringifyObj(selector));
            }
            const itemIndex = selector.items.findIndex(myObj => myObj.id == marketItemId);
            if (itemIndex >= 0) {
                selector.currentItem.id = selector.items[itemIndex].id;
                selector.currentItem.description = selector.items[itemIndex].description;
                if (isSelected == 1) {
                    selector.currentItem.regulatoryMarketId = selector.items[itemIndex].regulatoryMarketId;
                    selector.currentItem.parentId = selector.items[itemIndex].parentId;
                    selector.currentItem.isUserAuthorizedMarket = selector.items[itemIndex].isUserAuthorizedMarket;
                    localStorage.setItem("marketSelection", this.stringifyObj(selector));
                    // sessionStorage.setItem("marketSelection", this.stringifyObj(selector));
                }
            }
        }
        if (this.selectedMarketArr != null && this.selectedMarketArr != undefined && this.selectedMarketArr != [] && this.selectedMarketArr.length > 0) {
            this.isLoadPhrase = false;
            this.loadRpcs(this.selectedRegulatoryMarketId).then(() => {
                this.loadMatrixPhrasesUsingCurrentSelections(true);
            });
        }
        else {
            this.isLoadPhrase = false;
            this.processLoadedRpcData([], []);
        }
        if (this.selctedObj != "null" && this.selctedObj == 'btnView') {
            this.isbtnEditEnabled = true;
            this.isbtnEdit = false;
            this.isbtnTopic = false;
            this.isbtnSystemSelected = false;
        } else if (this.selctedObj != "null" && this.selctedObj == 'btnEdit') {
            this.isbtnEditEnabled = true;
            this.isbtnEdit = this.isbtnEditEnabled;
            this.isbtnTopic = this.isbtnEditEnabled;
            this.isbtnSystemSelected = false;
        } else {
            const per = [Permission.AraPReFDCT_PhraseAssignments_Read,
            Permission.AraPReFDCT_PhraseAssignments_Write];
            if (this.authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision(per, this.selectedRegulatoryMarketId, null) && this.isbtnEnabled) {
                this.isbtnEditEnabled = true;
            }
            else if (this.isbtnEnabled) {
                this.isbtnEditEnabled = false;
            }
            this.isbtnEdit = this.isbtnEditEnabled;
            this.isbtnTopic = this.isbtnEditEnabled;
            this.isbtnSystemSelected = true;
        }
        this.selctedObj = null;
    }

    private stringifyObj(obj) {
        const cache = [];
        return JSON.stringify(obj, function (key, value) {
            if (typeof value === 'object' && value !== null) {
                if (cache.indexOf(value) !== -1) {
                    // Duplicate reference found, discard key
                    return;
                }
                // Store value in our collection
                cache.push(value);
            }
            return value;
        });
    }

    private initialiseMarketTree() {
        this.allMarkets = [...this.allMarkets].sort((a, b) => a.description > b.description ? 1 : -1);
        this.filteredMarkets = [...this.filteredMarkets].sort((a, b) => a.description > b.description ? 1 : -1);
        const selector = this.createMarketItemSelector();
        this.firstSelected = selector.currentItem.id;
        this.marketTree = new Array<ItemSelector>();
        this.marketTree.push(selector);
        return selector.items;
        // this.marketTree.forEach(market => {
        //     market.items.sort((a, b) => a.description > b.description ? 1 : -1);
        // });
    }

    private createMarketItemSelector() {
        const selector = new ItemSelector();
        // selector.items = this.allMarkets.filter(i => i.parentId == null);
        // selector.items = [...this.allMarkets];
        selector.items = this.filteredMarkets.length > 0 ? [...this.filteredMarkets] : [...this.allMarkets];
        if (selector.items.length > 0) {
            selector.currentItem.id = selector.items[0].id;
            selector.currentItem.description = selector.items[0].description;
        }
        return selector;
    }

    private populateChildMarketItemSelector(parentId: number) {
        const newItems = this.allMarkets.filter(i => i.parentId == parentId);
        if (newItems.length > 0) {
            let selector = this.marketTree.find(s => s.parentId == parentId);
            if (selector == null) {
                selector = new ItemSelector();
                selector.parentId = parentId;
                this.marketTree.push(selector);
            }
            selector.items = newItems;
        }
    }
   private checkMarketStatus(market: string) {
        const marketStatus = this.marketTree[0]["items"].find(x => x.description.toLowerCase() === market.toLowerCase());
        this.retiredMarket = marketStatus != undefined && marketStatus['marketStatus'].toLowerCase() == 'RetiredMarket'.toLowerCase() ? true : false;
    }
    public selectedMarketChanged(itemSelector: any, selectorIndex: number, isSelected: boolean, isMarketPreSelected: boolean) {
        // const description = itemSelector.currentTarget.value;
       this. checkMarketStatus(itemSelector.description);
        const description = itemSelector.description.toLowerCase() == this.marketTree[0].currentItem.description.toLowerCase() ? "" : itemSelector.description;
        const currentItem = { id: -1, description: "", parentId: null, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false };
        if (this.marketTree[0].items.find(u => u.description.trim().toLowerCase() == description.toLowerCase()) != undefined) {
            for (let i = 0; this.marketTree[0].items.length > 0; i++) {
                if (this.marketTree[0].items[i].description.trim().toLowerCase() == description.trim().toLowerCase()) {
                    currentItem.id = this.marketTree[0].items[i].id;
                    currentItem.description = this.marketTree[0].items[i].description;
                    currentItem.isUserAuthorizedMarket = this.marketTree[0].items[i].isUserAuthorizedMarket;
                    currentItem.parentId = this.marketTree[0].items[i].parentId;
                    currentItem.regulatoryMarketId = this.marketTree[0].items[i].regulatoryMarketId;
                    currentItem.requiresSubselection = this.marketTree[0].items[i].requiresSubselection;
                    // itemSelector.currentTarget.value = currentItem.description;
                    break;
                }
            }
        }
        if (currentItem.id > 0) {
            this.marketTree[0].currentItem = currentItem;
            this._isLoading = true;
            this.dummyArray = [];
            this.isMarketPreSelected = isMarketPreSelected;
            if (this.marketTree[0].currentItem.id < 0) {
                this.resetToAnyMarket(selectorIndex, this.marketTree[0]);
            }
            else {
                this.marketSelected = this.allMarkets.filter(x => x.id == this.marketTree[0].currentItem.id);
                this.MarketArray = [];
                this.tempArrayRPCS = [];
                this.selectedMarketArr = [];
                this.getHierarchyMarkets(this.marketSelected[0]);
                this.MarketArray = this.tempArrayRPCS.reverse();
                this.MarketArray.push(this.marketSelected[0]);
                this.selectedMarketArr = this.MarketArray;
                this._isLoading = false;
            }
            this.marketTree = this.marketTree.slice(0, selectorIndex + 1);
            this.marketTree[0] = this.marketTree[this.marketTree.length - 1];
            this.selectedRpcId = -1;
            if (isSelected && this.marketTree[0].currentItem.id > 0) {
                this.setCurrentMarketId(this.marketTree[0], this.marketTree[0].currentItem.id, 1);
            }
            else if (this.marketTree[0].currentItem.id > 0) {
                this.setCurrentMarketId(this.marketTree[0], this.marketTree[0].currentItem.id, 0);
            }
            this.topicFilter = '';
        }
        this.topicFilter = '';
    }

    private resetToAnyMarket(selectorIndex: number, itemSelector: ItemSelector) {
        this.marketTree = this.marketTree.slice(0, selectorIndex + 1);
        let currentMarketId = itemSelector.currentItem.id;
        if (this.marketTree.length > 1) {
            itemSelector = this.marketTree[this.marketTree.length - 1];
            currentMarketId = this.marketTree[this.marketTree.length - 2].currentItem.id;
        }
        this.setCurrentMarketId(itemSelector, currentMarketId, 0);
    }

    private loadRpcs(regulatoryMarketId: number): Promise<boolean> {
        this._isLoading = true;
        sessionStorage.setItem("rpcId", "-1");
        return new Promise<boolean>((resolve, reject) => {
            const currentRpcSelection = this.getCurrentRpcSelection();
            this.currentRpcs = new Array<Item>();
            const filter = { marketId: regulatoryMarketId ? regulatoryMarketId.toString() : '' };
            this._isLoading = true;
            this.httpService.getFilteredPromise(filter, UrlEndpoint.RPCNavigator_AllItems).then(value => {
                if (value.length > 0) {
                    this.MarketArray.forEach(rpc => rpc.isLoadedRpc = true);
                    this.processLoadedRpcData(value, currentRpcSelection);
                }
                else {
                    this.MarketArray.forEach(rpc => rpc.isLoadedRpc = false);
                    this.processLoadedRpcData(value, [-1]);
                    localStorage.setItem("rpcId", this.selectedRpcId.toString());
                }
                sessionStorage.setItem("rpcId", this.selectedRpcId.toString());
                resolve(true);
            }).catch(error => {
                this._isLoading = false;
                reject(error);
            });
        });
    }

    private processLoadedRpcData(value: any, currentRpcSelection: number[]) {
        this.currentRpcs = value;
        if (this.initialSelection && this.initialSelection.regulatoryProductClassId > 0) {
            this.selectFirstItemInRpcTree();
        }
        else {
            this.selectItemInRpcTree(currentRpcSelection);
        }
    }

    private selectItemInRpcTree(currentRpcSelection: number[]) {
        this.setRpcSelection(this.getRpcPath(currentRpcSelection[0]));
        if (this.rpcTree.length > 0) {
            this.populateChildRpcItemSelector(this.rpcTree[0].currentItem.id);
        }
    }

    private selectFirstItemInRpcTree() {
        this.setSelectedRpc(this.initialSelection.regulatoryProductClassId);
        this.initialSelection.regulatoryProductClassId = 0;
    }

    private getCurrentRpcSelection() {
        const selection = new Array<number>();
        // if (+sessionStorage.getItem("rpcId") > 0) {
        if (+localStorage.getItem("rpcId") > 0) {
            // selection.push(+sessionStorage.getItem("rpcId"));
            selection.push(+localStorage.getItem("rpcId"));
        }
        else {
            this.rpcTree.forEach(item => {
                if (item.currentItem.id > 0) {
                    selection.push(item.currentItem.id);
                }
            });
        }
        return selection;
    }

    // recursively build up array representing hierarchy of selected RPC IDs
    private getRpcPath(rpcId: number): Array<number> {
        let selection = new Array<number>();
        const rpc = this.currentRpcs.find(m => m.id == rpcId);
        if (rpc) {
            if (rpc.parentId && rpc.parentId > 0) {
                selection = selection.concat(this.getRpcPath(rpc.parentId));
            }
            selection.push(rpc.id);
        }
        return selection;
    }

    private setSelectedRpc(rpcId: number) {
        const selection = this.getRpcPath(rpcId);
        this.setRpcSelection(selection);
    }

    private createRootLevelRpcItemSelector(): RegulatoryProductClassItemSelector {
        const selector = this.createRpcItemWithMarketsData();
        selector.items = this.currentRpcs.filter(i => i.parentId == null);
        if (selector.items.length > 0) {
            selector.currentItem.id = selector.items[0].id;
            selector.currentItem.description = selector.items[0].description;
        }
        return selector;
    }

    private createRpcItemWithMarketsData(): RegulatoryProductClassItemSelector {
        const selector = new RegulatoryProductClassItemSelector();
        this.addMarketsDataToRpcSelector(selector);
        return selector;
    }

    private initialiseSelectedRpcTree() {
        const selector = this.createRootLevelRpcItemSelector();
        this.rpcTree = new Array<RegulatoryProductClassItemSelector>();
        this.rpcTree.push(selector);
    }

    private populateChildRpcItemSelector(parentId: number) {
        const newItems = this.currentRpcs.filter(i => i.id == parentId);
        if (newItems.length > 0) {
            let selector = this.rpcTree.find(s => s.parentId == parentId);
            if (selector == null) {
                selector = this.createRpcItemWithMarketsData();
                selector.parentId = parentId;
                this.rpcTree.push(selector);
            }
            selector.items = newItems;
        }
    }

    private populateParentRpcItemSelector(currentId: number) {
        const newItems = this.currentRpcs.filter(i => i.id == currentId);
        if (newItems.length > 0) {

         if (newItems[0].parentId != null) {
            const selector = this.createRpcItemWithMarketsData();
            const newParentOne = this.currentRpcs.filter(i => i.id == newItems[0].parentId);
            selector.currentItem.id = newParentOne[0].id;
            selector.currentItem.description = newParentOne[0].description;
            selector.parentId = newParentOne[0].parentId;
            this.rpcTree.push(selector);
            if (newParentOne[0].parentId != null) {
                const selector1 = this.createRpcItemWithMarketsData();
                const newParentTwo = this.currentRpcs.filter(i => i.id == newParentOne[0].parentId);
                selector1.currentItem.id = newParentTwo[0].id;
                selector1.currentItem.description = newParentTwo[0].description;
                selector1.parentId = newParentTwo[0].parentId;
                this.rpcTree.push(selector1);
                if (newParentTwo[0].parentId != null) {
                    const selector2 = this.createRpcItemWithMarketsData();
                    const newParentThree = this.currentRpcs.filter(i => i.id == newParentTwo[0].parentId);
                    selector2.currentItem.id = newParentThree[0].id;
                    selector2.currentItem.description = newParentThree[0].description;
                    selector2.parentId = newParentThree[0].parentId;
                    this.rpcTree.push(selector2);
                }
            }
         }
        }


        // console.log(newItems);
        //  if (newItems.length > 0) {
        //      const parntId = newItems[0].parentId
        //      let selector = this.rpcTree.find(s => s.id == parntId);
        //     if (selector == null) {
        //         selector = this.createRpcItemWithMarketsData();
        //         selector.parentId = currentId;
        //         this.rpcTree.push(selector);
        //     }
        //     selector.items = newItems;
        //  }
    }

    getHierarchyMarkets(selectedMarket: any) {
        if (selectedMarket.parentId != null) {
            const selectedMarketParent = this.allMarkets.find(market => market.id == selectedMarket.parentId);
            this.tempArrayRPCS.push(selectedMarketParent);
            this.getHierarchyMarkets(selectedMarketParent);
        }
    }

    private setMarketSelection(marketSelection: number[], isSelected: number) {
        let index = 0;
        this.MarketArray = [];
        this.tempArrayRPCS = [];
        this.selectedMarketArr = [];
        marketSelection.forEach(selectedItemId => {
            if (index >= 1) {
                const selectedMarketParent = this.allMarkets.find(market => market.id == selectedItemId);
                this.tempArrayRPCS.push(selectedMarketParent);
            }
            else {
                if (this.marketTree.length > index) {
                    // const item1 = this.marketTree[index].items.find(i => i.id == selectedItemId);
                    const item1 = this.allMarkets.find(i => i.id == selectedItemId);
                    const item = this.marketTree[index].items.find(i => i.id == this.newSelectedMarketId);
                    if (item) {
                        this.marketTree[index].currentItem = {
                            id: item.id,
                            description: item.description,
                            parentId: item.parentId,
                            requiresSubselection: false,
                            regulatoryMarketId: item.regulatoryMarketId,
                            isUserAuthorizedMarket: item.isUserAuthorizedMarket
                        };
                        // this.populateChildMarketItemSelector(selectedItemId);
                        this.tempArrayRPCS.push(item1);
                    }
                }
                index++;
            }
        });
        this.MarketArray = [...this.tempArrayRPCS];
        this.selectedMarketArr = [...this.MarketArray];
        if (this.marketTree.length > 0) {
            const selectors = this.marketTree.filter(s => s.currentItem.id > 0);
            const selector = selectors.length > 0 ? selectors[selectors.length - 1] : null;
            if (selector.currentItem.id > 0) {
                isSelected == 1 ? this.setCurrentMarketId(selector, selector.currentItem.id, isSelected) :
                    this.setCurrentMarketId(selector, selector.currentItem.id, 0);
                    this.checkMarketStatus(selector.currentItem.description);
            }
        }
    }

    setRpcSelection(rpcSelection: number[]) {
        this.initialiseSelectedRpcTree();
        this.addCurrentItemsToRpcTree(rpcSelection);
        if (this.rpcTree.length > 0 && this.rpcTree[0].items.length > 0) {
            this.setLastCurrentItemSelectedToBeCurrentRpcId();
            this.populateLastItemInRpcTree(); // every time a new child level is selected in the RPC hierarchy, ensure the selector is appropriately set up
        } else {
            this._isLoading = false; // if no data is loaded, nothing else can proceed from here, so end loading
        }
    }

    private populateLastItemInRpcTree() {
        const lastItemId = this.rpcTree[this.rpcTree.length - 1].currentItem.id;
        if (lastItemId > 0) {
            this.populateChildRpcItemSelector(lastItemId);
        }
    }

    private setLastCurrentItemSelectedToBeCurrentRpcId() {
        const currentItemSelectors = this.rpcTree.filter(s => s.currentItem.id > 0);
        const lastCurrentItemSelector = currentItemSelectors.length > 0 ? currentItemSelectors[currentItemSelectors.length - 1] : null;
        if (lastCurrentItemSelector) {
            this.setCurrentRpcId(lastCurrentItemSelector, lastCurrentItemSelector.currentItem.id);
        }
    }

    private addCurrentItemsToRpcTree(rpcSelection: number[]) {
        let index = 0;
        rpcSelection.forEach(selectedItemId => {
            if (this.rpcTree.length > index) {
                const item = this.rpcTree[index].items.find(i => i.id == selectedItemId);
                if (item) {
                    this.rpcTree[index].currentItem = {
                        id: item.id,
                        description: item.description,
                        parentId: item.parentId,
                        requiresSubselection: false,
                        regulatoryMarketId: item.regulatoryMarketId,
                        isUserAuthorizedMarket: item.isUserAuthorizedMarket
                    };
                    this.populateChildRpcItemSelector(selectedItemId);
                }
            }
            index++;
        });
    }

    private addMarketsDataToRpcSelector(selector: RegulatoryProductClassItemSelector) {
        selector.markets = new Array<MarketCell>();
        this.MarketArray.forEach(m => {
            selector.markets.push(this.createMarketCell(m, selector.hasDeclinedTopic));
        });
    }

    private createMarketCell(item: MarketPhrases, hasDeclinedTopic: boolean): MarketCell {
        const cell = new MarketCell();
        cell.marketId = (item.id > 0) ? this.allMarkets.find(x => x.id == item.id).regulatoryMarketId : -1;
        cell.isSelected = (item.id > 0) && (this.selectedMarketItemId == item.id);
        cell.allowModify = !hasDeclinedTopic && this.matrix && this.matrix.canModify;
        return cell;
    }

    private setCurrentRpcId(selector: RegulatoryProductClassItemSelector, selectedRpcId: number) {
        this.selectedRpcId = selectedRpcId;
        selector.currentItem = {
            id: -1, description: '', parentId: null, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false
        };
        if (selectedRpcId > 0) {
            const itemIndex = selector.items.findIndex(myObj => myObj.id == selectedRpcId);
            if (itemIndex >= 0) {
                selector.currentItem.id = selector.items[itemIndex].id;
                selector.currentItem.description = selector.items[itemIndex].description;
            }
        }
    }

    public selectedRpcChanged(itemId) {
        this.isRpcSelected = true;
         const selector = this.createRpcItemWithMarketsData();
         selector.currentItem.id = itemId.id;
         selector.currentItem.description = itemId.description;
        this.rpcTree = new Array<RegulatoryProductClassItemSelector>();
        this.rpcTree.push(selector);
        localStorage.setItem("rpcId", itemId.id);
        localStorage.setItem("description", itemId.description);
        sessionStorage.setItem("rpcId", itemId.id);
        this.selectedRpcId = itemId.id;
        this.selectedShowEntireRPCMatrix = true;
          //  this.loadMatrixPhrases(itemId.id,this.selectedRegulatoryMarketId,this.selectedTopic.id);
    }


    selectAllRpc(selectedId){
    }

    public selectedTopicChanged(topic: TopicTreeNode | null) {
        if (!topic && this.selectedRpcId > 0) {
            this.selectedTopic = topic;
        }
        else if (this.selectedRpcId > 0) {
            this.selectedTopic = topic;
            this.loadMatrixPhrasesUsingCurrentSelections();
        }
    }

    public loadMatrixPhrasesUsingCurrentSelections(refresh: boolean = false) {
        if (this.selectedRpcId && this.selectedRegulatoryMarketId && this.selectedTopic && this.selectedTopic.id) {
            this.loadMatrixPhrases(this.selectedRpcId, this.selectedRegulatoryMarketId, this.selectedTopic.id, refresh);
        }
    }
    public loadMatrixPhrasesUsingCurrentSelectionsNew(rmId: number, refresh: boolean = false) {
        if (+sessionStorage.getItem("topicId") > 0) {
            this.loadMatrixPhrases(this.selectedRpcId, rmId, +sessionStorage.getItem("topicId"), refresh);
        }
        else if (this.selectedRpcId && rmId > 0 && this.selectedTopic && this.selectedTopic.id) {
            this.loadMatrixPhrases(this.selectedRpcId, this.selectedRegulatoryMarketId, this.selectedTopic.id, refresh);
        }
    }

    public selectedPhraseStatusChanged() {
        this.isStatusSystemSelected = false;
        this.invalidateCellInvisibility(this.matrix);
    }

    public detailLevelChanged() {
        this.isDetailLevelSystemSelected = false;
        this.invalidateCellInvisibility(this.matrix);
    }

    private invalidateCellInvisibility(matrix: MatrixData) {
        matrix.rows.forEach(row => {
            row.cells.forEach(cell => {
                cell.phrases.forEach(phrase => {
                    let isStatusHidden = false,
                        isDetailHidden = false;
                    // Status
                    if (this.filter.status == MatrixStatus.Approved) {
                        isStatusHidden = phrase.phraseStatus != PhraseStatus.Approved
                            || phrase.assignmentStatus != AssignmentStatus.Accepted;
                    }
                    else if (this.filter.status == MatrixStatus.Rejected) {
                        isStatusHidden = phrase.phraseStatus != PhraseStatus.Rejected;
                    }
                    else if (this.filter.status == MatrixStatus.NotRelevant) {
                        isStatusHidden = phrase.phraseStatus != PhraseStatus.Approved
                            || phrase.assignmentStatus != AssignmentStatus.NotRelevant;
                    }
                    else if (this.filter.status == MatrixStatus.ToBeAssessed) {
                        isStatusHidden = phrase.phraseStatus != PhraseStatus.Approved
                            || phrase.assignmentStatus != AssignmentStatus.ToBeAssessed;
                    }
                    else if (this.filter.status == MatrixStatus.ToBeApproved) {
                        isStatusHidden = phrase.phraseStatus != PhraseStatus.ToBeApproved;
                    }

                    // Detail
                    if (this.filter.detail == MatrixDetail.Standard) {
                        isDetailHidden = phrase.detailLevelDescription != DetailLevels.Standard;
                    }
                    else if (this.filter.detail == MatrixDetail.Detailed) {
                        isDetailHidden = phrase.detailLevelDescription != DetailLevels.Detailed;
                    }
                    else if (this.filter.detail == MatrixDetail.InternalRA) {
                        isDetailHidden = phrase.detailLevelDescription != DetailLevels.InternalRA;
                    }
                    phrase.isHidden = isDetailHidden || isStatusHidden;
                });
            });
        });
    }

    public get isLoading() {
        return this._isLoading;
    }

    private isSameMatrixData(selectedRpcId: number, selectedMarketId: number, selectedTopicId: number): boolean {
        return this.matrix != null &&
            selectedRpcId == this.matrix.regulatoryProductClassId &&
            selectedMarketId == this.matrix.regulatoryMarketId &&
            selectedTopicId == this.matrix.topicId;
    }

    onCheckboxChange(e) {
        this.selectedShowEntireRPCMatrix = !e.target.checked;
        if (!this.selectedShowEntireRPCMatrix) {
            this.populateParentRpcItemSelector(this.selectedRpcId);
        }else{
            const selector = this.createRpcItemWithMarketsData();
            selector.currentItem.id = this.selectedRpcId;
            selector.currentItem.description = localStorage.getItem("description");
           this.rpcTree = new Array<RegulatoryProductClassItemSelector>();
           this.rpcTree.push(selector);
        }
        this.loadMatrixPhrases(this.selectedRpcId, this.selectedRegulatoryMarketId, this.selectedTopic.id);
       }


    sortRpcTree(rpcTree){
        rpcTree.sort(function(a, b){
        if (rpcTree != null) {
        if ( a.currentItem.id < b.currentItem.id){ return -1; }
        }
        if ( a.currentItem.id > b.currentItem.id){ return 1; }
        return 0;
        });
    }

    private loadMatrixPhrases(selectedRpcId: number, selectedRegulatoryMarketId: number, selectedTopicId: number, refresh: boolean = false) {
        // if (!refresh && this.isSameMatrixData(selectedRpcId, selectedRegulatoryMarketId, selectedTopicId)) {
        //     this._isLoading = false;
        //     return;
        // }
        if ((selectedTopicId > 0) && (selectedRegulatoryMarketId > 0) && (selectedRpcId > 0)) {
            const postData = {
                regulatoryMarketId: selectedRegulatoryMarketId,
                regulatoryProductClassId: selectedRpcId,
                topicId: selectedTopicId,
                showEntireRPCMatrix: this.selectedShowEntireRPCMatrix
            };
            const rpcId = selectedRpcId;
            this._isLoading = true;
            this.httpService.postContentPromise(postData, UrlEndpoint.PhraseMatrix_GetCells)
                .then(matrix => {
                    // Clear current phrases in matrix:
                    this.clearMatrixPhrases(matrix);
                    // Populate matrix with new phrases
                    this.populateMatrixPhrases(matrix, rpcId);
                    this.invalidateCellInvisibility(matrix);
                    // Publish finalized data
                    this.matrix = matrix;
                    this._isLoading = false; // this is always the last part of the page lifecyle (given all data available and loaded successfully) - so keep loading till we get here
                }).catch(() => {
                    this._isLoading = false;
                });
        }
    }




    private populateMatrixPhrases(matrix: MatrixData, rpcId: number) {
   // for (let index = 0; index < matrix.rows.length; index++) {
    //    if (matrix.rows[index].regulatoryProductClassId==rpcId) {
      //  this.rpcTree[0].currentItem.id=rpcId;
        this.sortRpcTree(this.rpcTree);
        this.hasDeclinedTopic = false; // reset for case where no data is actually loaded
        this.dummyArray = [];
        this.markeIds = [];
        let i = 0;
      //  const rpcNew = this.rpcTree.filter(c => !(matrix.rows.map(r => r.regulatoryProductClassId).includes(c.currentItem.id)));
        this.MarketArray.forEach(matrixMarket => {
            if (matrix.rows.length > 0) {
                matrix.rows.forEach(row => {
                    const selRpcInIf = this.rpcTree.find(c => c.currentItem.id == row.regulatoryProductClassId);
                    selRpcInIf.hasDeclinedTopic = row.hasDeclinedTopic;
                    this.hasDeclinedTopic = selRpcInIf.hasDeclinedTopic;
                    if (row.cells.find(c => c.regulatoryMarketId == matrixMarket.regulatoryMarketId)) {
                        row.cells.forEach(cell => {
                            const rpc = this.rpcTree.find(c => c.currentItem.id == row.regulatoryProductClassId);
                            const marketorFallbackMarkets = {
                                marketId: cell.regulatoryMarketId,
                                phrases: [],
                                rpcId: rpc.currentItem.id,
                                marketHide: '',
                                isPhraseAvailable: ''
                            };
                            // markets can fall outside of currently accessibly ones - e.g. for inherited assignments; ignore these
                            // SelectedMarket Id Have any phrases
                            if (this.selectedRegulatoryMarketId == matrixMarket.regulatoryMarketId && this.selectedRegulatoryMarketId == cell.regulatoryMarketId) {
                                const market1 = rpc.markets.find(m => m.marketId == this.selectedRegulatoryMarketId);
                                if (market1 && !rpc.hasDeclinedTopic) {  // markets can fall outside of currently accessibly ones - e.g. for inherited assignments; ignore these
                                    cell.phrases.forEach(phrase => {
                                        phrase.isHidden = true;
                                        if (rpc.currentItem.id == phrase.rpcId) {
                                            market1.phrases.push(phrase);
                                            marketorFallbackMarkets.phrases.push(phrase);
                                        }
                                    });
                                }
                                matrixMarket.curRpcId = marketorFallbackMarkets.rpcId;
                                matrixMarket.phrases = [...marketorFallbackMarkets.phrases];
                                matrixMarket.marketHide = cell.phrases != [] ? '' : 'No';
                                matrixMarket.isPhraseAvailable = cell.phrases != [] ? '' : 'No';
                                matrixMarket.editMarket = matrixMarket.isPhraseAvailable == '' ? true : false;
                                matrixMarket.isLoadedRpc = true;
                                market1.marketHide = matrixMarket.marketHide;
                                market1.isPhraseAvailable = matrixMarket.isPhraseAvailable;
                                market1.editMarket = matrixMarket.editMarket;
                                market1.isLoadedRpc = matrixMarket.isLoadedRpc;
                            }

                            // Else FallBackMarketId have any Phrases
                            else if (this.selectedRegulatoryMarketId !== matrixMarket.regulatoryMarketId && matrixMarket.regulatoryMarketId == cell.regulatoryMarketId) {
                                const market2 = rpc.markets.find(m => m.marketId == cell.regulatoryMarketId);
                                if (market2 && !rpc.hasDeclinedTopic) {  // markets can fall outside of currently accessibly ones - e.g. for inherited assignments; ignore these
                                    cell.phrases.forEach(phrase => {
                                        phrase.isHidden = true;
                                        if (rpc.currentItem.id == phrase.rpcId) {
                                            market2.phrases.push(phrase);
                                            marketorFallbackMarkets.phrases.push(phrase);
                                        }
                                    });
                                }
                                matrixMarket.curRpcId = marketorFallbackMarkets.rpcId;
                                matrixMarket.phrases = [...marketorFallbackMarkets.phrases];
                                matrixMarket.marketHide = cell.phrases != [] ? 'No' : 'Yes';
                                matrixMarket.isPhraseAvailable = cell.phrases != [] ? 'Yes' : 'No';
                                matrixMarket.editMarket = matrixMarket.isPhraseAvailable == 'Yes' ? true : false;
                                matrixMarket.isLoadedRpc = true;
                                market2.marketHide = matrixMarket.marketHide;
                                market2.isPhraseAvailable = matrixMarket.isPhraseAvailable;
                                market2.editMarket = matrixMarket.editMarket;
                                market2.isLoadedRpc = matrixMarket.isLoadedRpc;
                            }
                        });
                    }
                    else {
                        const rpc1 = this.rpcTree.find(c => c.currentItem.id == row.regulatoryProductClassId);
                        if (this.selectedRegulatoryMarketId == matrixMarket.regulatoryMarketId) {
                            const market3 = rpc1.markets.find(m => m.marketId == this.selectedRegulatoryMarketId);
                            const markethaveNoPhrases = {
                                marketId: matrixMarket.regulatoryMarketId,
                                phrases: [],
                                rpcId: rpc1 != undefined ? rpc1.currentItem.id : matrix.regulatoryProductClassId,
                                marketHide: 'No',
                                isPhraseAvailable: 'No'
                            };
                            matrixMarket.curRpcId = markethaveNoPhrases.rpcId;
                            matrixMarket.phrases = [...markethaveNoPhrases.phrases];
                            matrixMarket.isPhraseAvailable = markethaveNoPhrases.isPhraseAvailable;
                            matrixMarket.marketHide = markethaveNoPhrases.marketHide;
                            matrixMarket.editMarket = matrixMarket.isPhraseAvailable == 'No' ? false : true;
                            matrixMarket.isLoadedRpc = true;

                            market3.phrases = matrixMarket.phrases;
                            market3.isPhraseAvailable = matrixMarket.isPhraseAvailable;
                            market3.marketHide = matrixMarket.marketHide;
                            market3.editMarket = matrixMarket.editMarket;
                        }
                        else if (this.selectedRegulatoryMarketId !== matrixMarket.regulatoryMarketId) {
                            const market4 = rpc1.markets.find(m => m.marketId == matrixMarket.regulatoryMarketId);
                            const markethaveNoPhrasesElse = {
                                marketId: matrixMarket.regulatoryMarketId,
                                phrases: [],
                                rpcId: rpc1 != undefined ? rpc1.currentItem.id : matrix.regulatoryProductClassId,
                                marketHide: 'Yes',
                                isPhraseAvailable: 'No'
                            };
                            matrixMarket.curRpcId = markethaveNoPhrasesElse.rpcId;
                            matrixMarket.phrases = [...markethaveNoPhrasesElse.phrases];
                            matrixMarket.isPhraseAvailable = markethaveNoPhrasesElse.isPhraseAvailable;
                            matrixMarket.marketHide = markethaveNoPhrasesElse.marketHide;
                            matrixMarket.editMarket = matrixMarket.isPhraseAvailable == 'No' ? false : true;
                            matrixMarket.isLoadedRpc = true;

                            market4.phrases = matrixMarket.phrases;
                            market4.isPhraseAvailable = matrixMarket.isPhraseAvailable;
                            market4.marketHide = matrixMarket.marketHide;
                            market4.editMarket = matrixMarket.editMarket;
                        }
                    }
                });
            }
            else {
                const rpc2 = this.rpcTree.find(c => c.currentItem.id == matrix.regulatoryProductClassId);
                const marketorFallbackMarkets = {
                    marketId: matrixMarket.regulatoryMarketId,
                    phrases: [],
                    rpcId: rpc2 != undefined ? rpc2.currentItem.id : matrix.regulatoryProductClassId,
                    marketHide: 'No',
                    isPhraseAvailable: 'No'
                };
                // SelectedMarket Id Have any phrases
                if (this.selectedRegulatoryMarketId == matrixMarket.regulatoryMarketId) {
                    const market3 = rpc2.markets.find(m => m.marketId == this.selectedRegulatoryMarketId);
                    matrixMarket.curRpcId = marketorFallbackMarkets.rpcId;
                    matrixMarket.phrases = [...marketorFallbackMarkets.phrases];
                    matrixMarket.isPhraseAvailable = marketorFallbackMarkets.isPhraseAvailable;
                    matrixMarket.marketHide = marketorFallbackMarkets.marketHide;
                    matrixMarket.isLoadedRpc = true;

                    market3.marketHide = matrixMarket.marketHide;
                    market3.isPhraseAvailable = matrixMarket.isPhraseAvailable;
                    market3.editMarket = matrixMarket.editMarket;
                    market3.isLoadedRpc = matrixMarket.isLoadedRpc;
                }

                // Else FallBackMarketId have any Phrases
                else if (this.selectedRegulatoryMarketId !== matrixMarket.regulatoryMarketId) {
                    const market4 = rpc2.markets.find(m => m.marketId == matrixMarket.regulatoryMarketId);
                    const marketorFallbackMarketsElse = {
                        marketId: matrixMarket.regulatoryMarketId,
                        phrases: [],
                        rpcId: rpc2 != undefined ? rpc2.currentItem.id : matrix.regulatoryProductClassId,
                        marketHide: 'Yes',
                        isPhraseAvailable: 'No'
                    };
                    matrixMarket.curRpcId = marketorFallbackMarketsElse.rpcId;
                    matrixMarket.phrases = [...marketorFallbackMarketsElse.phrases];
                    matrixMarket.isPhraseAvailable = marketorFallbackMarketsElse.isPhraseAvailable;
                    matrixMarket.marketHide = marketorFallbackMarketsElse.marketHide;
                    matrixMarket.isLoadedRpc = true;

                    market4.marketHide = matrixMarket.marketHide;
                    market4.isPhraseAvailable = matrixMarket.isPhraseAvailable;
                    market4.editMarket = matrixMarket.editMarket;
                    market4.isLoadedRpc = matrixMarket.isLoadedRpc;
                }
            }
            i = i + 1;
        });
        i = 0;
        // In "matrix" parameter does'nt have any rpc's which is present in "this.rpcTree"
        // if (rpcNew && rpcNew.length > 0) {
        //     rpcNew.forEach(rpc => {
        //         if (rpc.currentItem.id > 0) {
        //             rpc.markets.forEach(element => {
        //                 if (this.selectedRegulatoryMarketId == element.marketId) {
        //                     element.phrases = [];
        //                     element.marketHide = 'No';
        //                     element.isPhraseAvailable = 'No';
        //                     element.editMarket = false;
        //                 }
        //                 else if (this.selectedRegulatoryMarketId !== element.marketId) {
        //                     element.phrases = [];
        //                     element.marketHide = 'Yes';
        //                     element.isPhraseAvailable = 'No';
        //                     element.editMarket = false;
        //                 }
        //             });
        //         }
        //     });
        // }
        if (!this.selectedTopic.isDeclined) {
            i = 0;
            if (this.rpcTree.length > 1) {
                // Getting All the Market Ids which does'nt have any phrases from all rpc levels (this.rpcTree)
                this.rpcTree.forEach(rpc => {
                    i++;
                    if (rpc.currentItem.id > 0) {
                        this.markeIds.push(rpc.markets.filter(c => (this.selectedRegulatoryMarketId !== c.marketId && c.phrases.length <= 0)).map(id => id.marketId));
                    }
                });
                // Getting the Common Market id which does'nt have any phrases from all rpc levels, Except primary market
                if (this.rpcTree.length == i && this.markeIds.length > 0) {
                    this.markeIds = this.getCommonIds(this.markeIds);
                }
                // If Common Market id's were FOUND Setting the Global hide value either 1 Or 0 for market Hide
                if (this.markeIds.length > 0) {
                    this.markeIds.forEach(id => {
                        this.rpcTree.forEach(rpc => {
                            // if (rpc.currentItem.id > 0) {
                            rpc.markets.forEach(market => {
                                if (market.marketId.toString() == id.toString()) {
                                    return market.globalHide = 1;
                                }
                            });
                            // }
                        });
                        this.MarketArray.forEach(market => {
                            if (market.regulatoryMarketId.toString() == id.toString()) {
                                return market.globalHide = 1;
                            }
                        });
                    });
                }
            }
            else {
                // If User selects 1st Level1 Rpc Setting the Global hide value either 1 Or 0 for market Hide
                this.rpcTree.forEach(rpc => {
                    // if (rpc.currentItem.id > 0) {
                    rpc.markets.forEach(market => {
                        if (market.marketHide == 'Yes') {
                            return market.globalHide = 1;
                        }
                    });
                    // }
                });
                this.MarketArray.forEach(market => {
                    if (market.marketHide == 'Yes') {
                        return market.globalHide = 1;
                    }
                });
            }
        }
        i = 0;
    //  }
   // }
  }

    private getCommonIds(markeIds) {
        // var arr = [[34, 6, 11, 20], [14, 34, 6, 20, 13], [14, 6, 34, 13, 11, 20]];
        let currentValues = {};
        let commonValues = {};
        for (let i = markeIds[0].length - 1; i >= 0; i--) {
            currentValues[markeIds[0][i]] = 1;
        }
        for (let i = markeIds.length - 1; i > 0; i--) {
            const currentArray = markeIds[i];
            for (let j = currentArray.length - 1; j >= 0; j--) {
                if (currentArray[j] in currentValues) {
                    commonValues[currentArray[j]] = 1; // Once again, the `1` doesn't matter
                }
            }
            currentValues = commonValues;
            commonValues = {};
        }
        return Object.keys(currentValues).map(function (value) {
            return +value;
        });
    }

    private clearMatrixPhrases(matrix: MatrixData) {
        this.rpcTree.forEach(rpc => {
            rpc.markets.forEach(m => {
                m.phrases = new Array<CellPhrase>();
                m.allowModify = matrix.canModify;
                m.isPhraseAvailable = '';
                m.marketHide = '';
                m.editMarket = false;
                m.globalHide = 0;
            });
            rpc.hasDeclinedTopic = false;
        });
        this.MarketArray.forEach(market => {
            market.isPhraseAvailable = '';
            market.marketHide = '';
            market.editMarket = false;
            market.globalHide = 0;
        });
    }

    private getSelectedCell(): SelectedMatrixCell | null {
        if ((this.selectedRegulatoryMarketId < 0) || (this.selectedRpcId < 0) || (!this.selectedTopic)) {
            return null;
        }
        return this.getCellSelection(this.selectedRegulatoryMarketId, this.selectedRpcId, this.selectedTopic.id);
    }

    public isCurrentRpc(selector: RegulatoryProductClassItemSelector): boolean {
        return (selector && (selector.currentItem.id == this.selectedRpcId));
    }

    public isMarketEditable(market: MarketCell): boolean {
        const selectedMarket = this.allMarkets.find(m => m.id == this.selectedMarketItemId);
        return market.isSelected && selectedMarket && !this._isLoading && !selectedMarket.isNavigationMarket;
    }

    public userHasWritePermissions(): boolean {
        if (this.selectedTopic == null) {
            return this.authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic(
                [Permission.AraPReFDCT_PhraseAssignments_Write],
                this.selectedRegulatoryMarketId,
                this.selectedRpcId,
                +localStorage.getItem("selectedTopicId") > 0 ? +localStorage.getItem("selectedTopicId") : +localStorage.getItem("topicId") > 0 ? +localStorage.getItem("topicId") : 0);
            // +sessionStorage.getItem("selectedTopicId") > 0 ? +sessionStorage.getItem("selectedTopicId") : +sessionStorage.getItem("topicId") > 0 ? +sessionStorage.getItem("topicId") : 0);
        }
        else {
            return this.authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic(
                [Permission.AraPReFDCT_PhraseAssignments_Write],
                this.selectedRegulatoryMarketId,
                this.selectedRpcId,
                this.selectedTopic.id);
        }
    }

    public isMatrixCellEditable(selector: RegulatoryProductClassItemSelector, market: MarketCell) {
        return this.isCurrentRpc(selector) && this.isMarketEditable(market) && this.userHasWritePermissions() && this.isbtnEdit && !this.selectedTopic.isDeclined;
    }

    public isMatrixCellEditableNew(rpcid: number, market: MarketCell) {
        return this.selectedRpcId == rpcid && this.isbtnEdit;
    }
    public openEditPhrase(phrasesid) {
    const selection = this.getSelectedCell();
      const modalRef = this.sideDialogService.openWithCallback(MatrixPhraseEditComponent, () => {
        });
    modalRef.componentInstance.title = 'Edit';
    modalRef.componentInstance.initEditPhrase(selection, phrasesid);
    }

    public phraseCellClick(regulatoryMarketId: number, rpcId: number) {
        // if (this.isbtnEdit) {
            const selection = this.getSelectedCell();
            if (selection) {
                const allowed =
                    this.isTargetCell(selection, regulatoryMarketId, rpcId) &&
                    this.authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic(
                        [Permission.AraPReFDCT_PhraseAssignments_Write],
                        selection.regulatoryMarketId,
                        selection.regulatoryProductClassId,
                        selection.topicId);

                const contextCell = this.getCellSelection(regulatoryMarketId, rpcId, selection.topicId);

                const modalRef = this.sideDialogService.openWithCallback(MatrixCellEditComponent,
                    () => this.loadMatrixPhrasesUsingCurrentSelections(true));
                modalRef.componentInstance.load(selection, contextCell, this.filter, allowed);
            }
      //  }
    }

    private isTargetCell(selection: SelectedMatrixCell, regulatoryMarketId: number, rpcId: number) {
        return selection.regulatoryMarketId == regulatoryMarketId && selection.regulatoryProductClassId == rpcId;
    }

    private getCellSelection(regulatoryMarketId: number, rpcId: number, topicId: number): SelectedMatrixCell {
        if (regulatoryMarketId && rpcId > 0 && topicId > 0) {
            return {
                regulatoryMarketId: regulatoryMarketId,
                regulatoryProductClassId: rpcId,
                topicId
            };
        }
        else {
            return null;
        }
    }

    // note we can edit a cell either by clicking on the pencil icon or by clicking on the cell
    public editMatrixCell(regulatoryMarketId: number, rpcId: number) {
        const selection = this.getSelectedCell();
        if (selection) {
            selection.regulatoryMarketId = regulatoryMarketId;
            selection.regulatoryProductClassId = rpcId;

            const modalRef = this.sideDialogService.openWithCallback(MatrixCellEditComponent,
                () => this.loadMatrixPhrasesUsingCurrentSelections(true));
            modalRef.componentInstance.load(selection, this.filter);
        }
    }

    private assessTopic(rpcId: number, topicId: number, regulatoryMarketId: number, topicLinkStatus: TopicLinkStatus) {
        const modal = this.dialogService.open(TopicAssessComponent, {
            backdrop: 'static',
            centered: true,
            size: 'lg'
        });
        modal.componentInstance.load(rpcId, topicId, regulatoryMarketId, topicLinkStatus);
        modal.result.then(completed => {
            if (completed) {
                // this.loadMatrixPhrasesUsingCurrentSelections(true);
                this.router.navigateByUrl('/topic-tree', { skipLocationChange: true }).then(() => {
                    this.router.navigate(['/phrase-matrix']);
                });
            }
        });
    }

    public declineTopic(rpcId: number) {
        this.acceptOrDeclineTopic(rpcId, TopicLinkStatus.Declined);
    }

    public acceptTopic(rpcId: number) {
        this.acceptOrDeclineTopic(rpcId, TopicLinkStatus.Accepted);
    }

    private acceptOrDeclineTopic(rpcId: number, linkStatus: TopicLinkStatus) {
        const selection = this.getSelectedCell();
        if (selection) {
            selection.regulatoryProductClassId = rpcId;
            this.assessTopic(selection.regulatoryProductClassId, selection.topicId, selection.regulatoryMarketId, linkStatus);
        }
    }

    public isMarketContentVisible(market: MarketCell): boolean {

        const selectedMarket = this.allMarkets.find(m => m.id == this.selectedMarketItemId);

        if (selectedMarket && market && selectedMarket.isNavigationMarket && selectedMarket.regulatoryMarketId === market.marketId) {
            return false;
        }

        return market && market.phrases && market.phrases.length && market.phrases.some(p => !p.isHidden);
    }

    public assessTopicAllowed() {
        const selection = this.getSelectedCell();
        return selection && selection.regulatoryMarketId && this.authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic(
            this.assessTopicPermissions.permissions,
            selection.regulatoryMarketId,
            selection.regulatoryProductClassId,
            selection.topicId);
    }

    public getMatrixCellPhraseStatus(phraseStatus: string, assignmentStatus: string): string {
        if (phraseStatus == PhraseStatus.Approved) {
            return AssignmentStatusToString(assignmentStatus);
        }
        else {
            return PhraseStatusToString(phraseStatus);
        }
    }
    private editPhrasePermissions: Permission[] = [
        Permission.AraPReFDCT_Phrases_WriteWithAssignments,
        Permission.AraPReFDCT_Phrases_WriteWithoutAssignments,
      ];
    public editPhraseAllowed(unileverProductDivisionId): boolean {
       return this.authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision(this.editPhrasePermissions, null, unileverProductDivisionId);
      }

}
