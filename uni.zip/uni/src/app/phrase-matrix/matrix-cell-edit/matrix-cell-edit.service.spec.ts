import { TestBed, inject } from '@angular/core/testing';

import { MatrixCellEditService } from './matrix-cell-edit.service';
import { HttpService } from '../../tools/services/http.service';
import { createStatementAssignment } from './matrix-cell-edit.component.spec';

class HttpServiceMock {}

describe('MatrixCellEditService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MatrixCellEditService,
        { provide: HttpService, useClass: HttpServiceMock }
      ]
    });
  });

  it('should be created', inject([MatrixCellEditService], (service: MatrixCellEditService) => {
    expect(service).toBeTruthy();
  }));

  it('should return false when InvalidTabularInput is called with null input', inject([MatrixCellEditService], (service: MatrixCellEditService) => {
    const result = service.isInvalidTabularInput(null);
    expect(result).toBe(false);
  }));

  it('should return false when InvalidTabularInput is called with valid tabular input data', inject([MatrixCellEditService], (service: MatrixCellEditService) => {
    const tabInput = {
      ...createStatementAssignment(),
      isRange: true,
      inputValueType1: null,
      inputValue1: "34",
      inputValueType2: null,
      inputValue2: "100"
    };
    const result = service.isInvalidTabularInput(tabInput);
    expect(result).toBe(false);
  }));

  it('should return true when InvalidTabularInput is called with null tabular input value 1', inject([MatrixCellEditService], (service: MatrixCellEditService) => {
    const tabInput = {
      ...createStatementAssignment(),
      isRange: false,
      inputValueType1: null,
      inputValue1: null,
      inputValueType2: null,
      inputValue2: null
    };
    const result = service.isInvalidTabularInput(tabInput);
    expect(result).toBe(true);
  }));

  it('should return true when InvalidTabularInput is called with empty tabular input value 1', inject([MatrixCellEditService], (service: MatrixCellEditService) => {
    const tabInput = {
      ...createStatementAssignment(),
      isRange: false,
      inputValueType1: null,
      inputValue1: "",
      inputValueType2: null,
      inputValue2: null
    };
    const result = service.isInvalidTabularInput(tabInput);
    expect(result).toBe(true);
  }));

  it('should return true when InvalidTabularInput is called with empty tabular input value 2 and isRange is true', inject([MatrixCellEditService], (service: MatrixCellEditService) => {
    const tabInput = {
      ...createStatementAssignment(),
      isRange: true,
      inputValueType1: null,
      inputValue1: "23",
      inputValueType2: null,
      inputValue2: null
    };
    const result = service.isInvalidTabularInput(tabInput);
    expect(result).toBe(true);
  }));

  it('should return true when InvalidTabularInput is called with empty tabular input value 2 and isRange is true', inject([MatrixCellEditService], (service: MatrixCellEditService) => {
    const tabInput = {
      ...createStatementAssignment(),
      isRange: true,
      inputValueType1: null,
      inputValue1: "32",
      inputValueType2: null,
      inputValue2: " "
    };
    const result = service.isInvalidTabularInput(tabInput);
    expect(result).toBe(true);
  }));

  it('should return false when InvalidTabularInput is called with null tabular input value 2 and isRange is false', inject([MatrixCellEditService], (service: MatrixCellEditService) => {
    const tabInput = {
      ...createStatementAssignment(),
      isRange: false,
      inputValueType1: null,
      inputValue1: "32",
      inputValueType2: null,
      inputValue2: null
    };
    const result = service.isInvalidTabularInput(tabInput);
    expect(result).toBe(false);
  }));

  it('should return false when InvalidTabularInput is called with empty tabular input value 2 and isRange is false', inject([MatrixCellEditService], (service: MatrixCellEditService) => {
    const tabInput = {
      ...createStatementAssignment(),
      isRange: false,
      inputValueType1: null,
      inputValue1: "32",
      inputValueType2: null,
      inputValue2: " "
    };
    const result = service.isInvalidTabularInput(tabInput);
    expect(result).toBe(false);
  }));

  it('should return correct data when getTabularInputValueData is called with tabular input data', inject([MatrixCellEditService], (service: MatrixCellEditService) => {
    const tabInput = {
      ...createStatementAssignment(),
      isRange: false,
      inputValueType1: 1,
      inputValue1: "35",
      inputValueType2: null,
      inputValue2: null
    };
    const result = service.getTabularInputValueData(tabInput);
    expect(result.isRange).toEqual(false);
    expect(result.inputValueType1).toEqual(1);
    expect(result.inputValue1).toEqual("35");
    expect(result.inputValueType2).toEqual(null);
    expect(result.inputValue2).toEqual(null);
  }));
});
