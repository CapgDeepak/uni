import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { By } from '@angular/platform-browser';

import { MatrixCellEditComponent } from './matrix-cell-edit.component';
import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';
import { ConfirmationDialogService } from '../../shared-components/confirmation-dialog/confirmation-dialog.service';
import { SideDialogService } from '../../tools/side-dialog/side-dialog.service';
import { MatrixCellEditService } from './matrix-cell-edit.service';
import { DialogService } from '../../tools/services/dialog.service';
import { AssignmentStatus, PhraseStatus, PhraseType, EmptyTabularInputValueWarning } from '../../tools/constants';
import { AuthorizationService } from '../../authorization/authorization.service';
import { Permission } from '../../tools/shared-types/permissions/permission';
import { ShowIfUserHasAnyPermissionDirective } from '../../authorization/directives/show-if-user-has-any-permission.directive';
import { MarketRpcAndTopicScopedPermissions } from '../../tools/shared-types/permissions/market-rpc-and-topic-scoped-permissions';
import { ShowIfUserHasAnyPermissionForMarketProductClassAndTopicDirective } from '../../authorization/directives/show-if-user-has-any-permission-for-market-rpc-and-topic.directive';
import { SelectedMatrixCell, MatrixFilter } from '../phrase-matrix.types';
import { CellDetails, TabularInputData, Statement } from '../matrix-cell-edit/matrix-cell-edit.types';
import { TabularInputValueData } from '../phrase-assess/phrase-assess.types';
import { NotificationService } from '../../tools/services/notification.service';
import { MatrixCellDetailsService } from './matrix-cell-details.service';

export function createStatementAssignment() {
  return {
    phraseId: 1,
    phraseAssignmentId: 2,
    phraseNr: 101,
    unileverProductDivisionId: 9,
    unileverProductDivisionPath: new Array<string>(),
    phraseText: "blah",
    phraseStatus: "something",
    isActive: true,
    phraseAssignmentStatus: "somethingElse",
    phraseDetailLevelDescription: "detailed",
    assessmentReason: "reasons",
    sourceLocation: "location",
    inheritedSourceLocation: "",
    unitOfMeasure: "cm",
    isNew: true,
    isVirtual: false,
    linkedPhraseNr: 9
  };
}

export function createTabularAssignment() {
  return {
    ...createStatementAssignment(),
    isRange: true,
    inputValueType1: 22,
    inputValue1: ">",
    inputValueType2: 100,
    inputValue2: "<"
  };
}

class NgbActiveModalMock { }
class AlertDialogServiceMock { }
class NotificationServiceMock {
  process() { }
}
class SideDialogServiceMock { }
class MatrixCellDetailsServiceMock {
  loadMatrixCellDetailsData() {
    return new Promise<CellDetails>((resolve, reject) => {
      const cellDetails: CellDetails = {
        regulatoryMarket: ["Algeria"],
        regulatoryProductClass: ["Some RPC"],
        topic: null,
        allowModify: true,
        statements: createStatementAssignments(),
        tabularInputs: createTabularAssignments(),
      };

      resolve(cellDetails);
    });
  }
}
class MatrixCellEditServiceMock {
  loadMatrixCellEditData() {
    return new Promise<CellDetails>((resolve, reject) => {
      const cellDetails: CellDetails = {
        regulatoryMarket: ["Algeria"],
        regulatoryProductClass: ["Some RPC"],
        topic: null,
        allowModify: true,
        statements: createStatementAssignments(),
        tabularInputs: createTabularAssignments(),
      };

      resolve(cellDetails);
    });
  }
  isInvalidTabularInput(tabularInput: TabularInputData) {
    return tabularInput && !tabularInput.inputValue1;
  }
  getTabularInputValueData(tabularInput: TabularInputData): TabularInputValueData {
    return (tabularInput == null || tabularInput == undefined) ? null : {
      isRange: tabularInput.isRange,
      inputValueType1: tabularInput.inputValueType1,
      inputValue1: tabularInput.inputValue1,
      inputValueType2: tabularInput.inputValueType2,
      inputValue2: tabularInput.inputValue2,
      unitOfMeasure: tabularInput.unitOfMeasure
    };
  }
  removeAssignment() {
    return new Promise((resolve, reject) => resolve(true));
  }
}
class DialogServiceMock { }
class ConfirmationDialogServiceMock {
  confirm(): Promise<boolean> {
    return new Promise((resolve, reject) => resolve(true));
  }
}
let userHasPermission: boolean;
let userHasPermissionForMarketRpcAndTopic: boolean;
class AuthorizationServiceMock {
  checkUserHasAnyPermission() {
    return userHasPermission;
  }
  checkUserHasAnyPermissionForMarketRpcAndTopic() {
    return userHasPermissionForMarketRpcAndTopic;
  }
}

describe('MatrixCellEditComponent', () => {
  let component: MatrixCellEditComponent;
  let fixture: ComponentFixture<MatrixCellEditComponent>;
  let matrixCellEditService: MatrixCellEditService;
  let matrixCellDetailsService: MatrixCellDetailsService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        HttpClientTestingModule
      ],
      declarations: [
        MatrixCellEditComponent,
        ShowIfUserHasAnyPermissionDirective,
        ShowIfUserHasAnyPermissionForMarketProductClassAndTopicDirective,
      ],
      providers: [
        { provide: NgbActiveModal, useClass: NgbActiveModalMock },
        { provide: AlertDialogService, useClass: AlertDialogServiceMock },
        { provide: SideDialogService, useClass: SideDialogServiceMock },
        { provide: NotificationService, useClass: NotificationServiceMock },
        { provide: MatrixCellEditService, useClass: MatrixCellEditServiceMock },
        { provide: MatrixCellDetailsService, useClass: MatrixCellDetailsServiceMock },
        { provide: DialogService, useClass: DialogServiceMock },
        { provide: ConfirmationDialogService, useClass: ConfirmationDialogServiceMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
      .compileComponents();
  }));

  describe('when user has permissions for market, RPC and topic', () => {
    beforeEach(() => {
      fixture = TestBed.createComponent(MatrixCellEditComponent);
      const injector = getTestBed();
      matrixCellEditService = injector.get(MatrixCellEditService);
      matrixCellDetailsService = injector.get(MatrixCellDetailsService);
      component = fixture.componentInstance;
      userHasPermissionForMarketRpcAndTopic = true;
      fixture.detectChanges();
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should match empty snapshot', () => {
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('should match snapshot when loading', () => {
      component.isLoading = true;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('should match snapshot with data', () => {
      setupComponentWithData(component);
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('should match snapshot with inactive data', () => {
      setupComponentWithData(component);
      component.selectedStatement.isActive = false;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('should match snapshot with tooltips for changed data', () => {
      userHasPermission = true;
      setupComponentWithData(component);
      component.hasChangedData = true;
      component.hasStagedData = true;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('should match snapshot with tooltips for already accepted assignment', () => {
      userHasPermission = true;
      setupComponentWithData(component);
      component.selected.phraseAssignmentStatus = AssignmentStatus.Accepted;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('should match snapshot with tooltips for already not relevant assignment', () => {
      userHasPermission = true;
      setupComponentWithData(component);
      component.selected.phraseAssignmentStatus = AssignmentStatus.NotRelevant;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('should match snapshot with tooltips for already to be assessed assignment', () => {
      userHasPermission = true;
      setupComponentWithData(component);
      component.selected.phraseAssignmentStatus = AssignmentStatus.ToBeAssessed;
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('should match snapshot with tooltips for empty tabular input value', () => {
      userHasPermission = true;
      component.data.allowModify = true;
      component.hasTargetCellAssessPermissions = true;
      component.selectedTabInput = {
        ...createNewPhraseAssignment(),
        isRange: false,
        inputValueType1: null,
        inputValue1: "",
        inputValueType2: null,
        inputValue2: ""
      };
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('should reset selection when tab changes', () => {
      const pa = createNewPhraseAssignment();
      component.selectedStatement = pa;
      expect(component.selectedStatement).toBeTruthy();
      component.tabChange();
      expect(component.selectedStatement).toBeFalsy();
      expect(component.selectedTabInput).toBeFalsy();
    });

    it('allowAssignmentReview is initially false', () => {
      expect(component.allowAssignmentReview).toBeFalsy();
    });

    it('allowAssignmentReview is false for unapproved statement assignment', () => {
      component.selectedStatement = createStatementAssignment();
      component.data.allowModify = true;
      expect(component.allowAssignmentReview).toBeFalsy();
    });

    it('allowAssignmentReview is false for inactive phrase assignment', () => {
      component.selectedStatement = createStatementAssignment();
      component.data.allowModify = true;
      component.selectedStatement.phraseStatus = PhraseStatus.Approved;
      component.selectedStatement.isActive = false;
      expect(component.allowAssignmentReview).toBeFalsy();
    });

    it('allowAssignmentReview is true for approved statement assignment', () => {
      component.selectedStatement = createStatementAssignment();
      component.data.allowModify = true;
      component.selectedStatement.phraseStatus = PhraseStatus.Approved;
      expect(component.allowAssignmentReview).toBeTruthy();
    });

    it('allowAssignmentReview is false for unapproved tabular assignment', () => {
      component.selectedTabInput = createTabularAssignment();
      component.data.allowModify = true;
      expect(component.allowAssignmentReview).toBeFalsy();
    });

    it('allowAssignmentReview is true for approved tabular assignment', () => {
      component.selectedTabInput = createTabularAssignment();
      component.data.allowModify = true;
      component.selectedTabInput.phraseStatus = PhraseStatus.Approved;
      expect(component.allowAssignmentReview).toBeTruthy();
    });

    it('allowAssignmentReview is true for non-target cells', () => {
      component.selectedTabInput = createTabularAssignment();
      component.isTarget = false;
      component.data.allowModify = false;
      component.selectedTabInput.phraseStatus = PhraseStatus.Approved;
      expect(component.allowAssignmentReview).toBeTruthy();
    });

    it('should give assignDisabled is false initially', () => {
      expect(component.assignDisabled).toBeFalsy();
    });

    describe('when a phrase assignment has been selected', () => {
      beforeEach(() => {
        // Assemble the phrase assignment selection for a phrase that is approved and for which
        // modification is allowed.
        component.hasChangedData = false;
        component.selectedStatement = createStatementAssignment();
        component.selectedStatement.phraseStatus = PhraseStatus.Approved;
        component.selectedStatement.isActive = true;
        component.data.allowModify = true;
        fixture.detectChanges();
      });

      describe('when user has permission to assess phrase assignments', () => {
        beforeEach(() => {
          // Assemble user with permission to assess phrase assignments
          const userPermissions = [Permission.AraPReFDCT_PhraseAssignments_Assess];
          userHasPermission = true;
          component.assessAssignmentPermissions = {
            permissions: userPermissions,
            regulatoryMarketId: 5,
            regulatoryProductClassId: 1,
            topicId: 19,
          };
          fixture.detectChanges();
        });

        describe('and the permission has the appropriate scope', () => {
          beforeEach(() => {
            // Assemble the correct scope for the permission
            component.hasTargetCellAssessPermissions = true;
            fixture.detectChanges();
          });

          describe('the accept assignment button', () => {
            it('should be enabled', () => {
              const button = fixture.debugElement.query(By.css('#accept-assignment-button'));
              expect(button).toBeTruthy();
              expect(button.properties.disabled).toBeFalsy();
            });
          });

          describe('the not relevant assignment button', () => {
            it('should be enabled', () => {
              const button = fixture.debugElement.query(By.css('#not-relevant-assignment-button'));
              expect(button).toBeTruthy();
              expect(button.properties.disabled).toBeFalsy();
            });
          });

          describe('and the phrase is an invalid tabular input assignment', () => {
            beforeEach(() => {
              component.selectedTabInput = {
                ...createStatementAssignment(),
                isRange: false,
                inputValueType1: null,
                inputValue1: null,
                inputValueType2: null,
                inputValue2: null
              };
              component.selected.phraseAssignmentStatus = AssignmentStatus.ToBeAssessed;
              component.selectedTabInput.phraseAssignmentStatus = AssignmentStatus.ToBeAssessed;
              component.selectedTabInput.isActive = true;
              component.data.allowModify = true;
              fixture.detectChanges();
            });

            it('accept button should be visible and disabled', () => {
              const acceptButton = fixture.debugElement.query(By.css('#accept-assignment-button'));
              expect(acceptButton).toBeTruthy();
              expect(acceptButton.properties.disabled).toBeTruthy();
              expect(component.acceptButtonTooltip).toEqual(EmptyTabularInputValueWarning);
            });

            it('not relevant button should be visible and enabled', () => {
              const notRelevantButton = fixture.debugElement.query(By.css('#not-relevant-assignment-button'));
              expect(notRelevantButton).toBeTruthy();
              expect(notRelevantButton.properties.disabled).toBeFalsy();
            });
          });
        });
      });

      describe('when user has permission to add/remove phrase assignments', () => {
        beforeEach(() => {
          // Assemble user with permission to add/remove phrase assignments
          const userPermissions = [Permission.AraPReFDCT_PhraseAssignments_Write];
          userHasPermission = true;
          component.writeAssignmentPermissions = {
            permissions: userPermissions,
            regulatoryMarketId: 5,
            regulatoryProductClassId: 1,
            topicId: 19,
          };
          component.isTarget = true;
          component.isEditAllowed = true;
          fixture.detectChanges();
        });

        describe('and the permission has the appropriate scope', () => {
          beforeEach(() => {
            // Assemble an correct scope for the permission
            fixture.detectChanges();
          });

          describe('the remove phrase (assignment) button', () => {
            it('should be enabled', () => {
              // Assert
              const button = fixture.debugElement.query(By.css('#remove-assignment-button'));
              expect(button).toBeTruthy();
              expect(button.properties.disabled).toBeFalsy();
            });
          });

          describe('the assign phrase button', () => {
            it('should be enabled', () => {
              // Assert
              const button = fixture.debugElement.query(By.css('#assign-phrase-button'));
              expect(button).toBeTruthy();
              expect(button.properties.disabled).toBeFalsy();
            });
          });

          describe('the tabular inputs panel', () => {
            it('should be visible', () => {
              // Assemble
              const element = fixture.debugElement.query(By.css('#tabularInputs'));
              expect(element).toBeTruthy();
            });
          });
        });

        describe('and the permission does not have the appropriate scope', () => {
          beforeEach(() => {
            // Assemble an incorrect scope for the permission
            userHasPermissionForMarketRpcAndTopic = false;
            fixture.detectChanges();
          });

          describe('the remove phrase (assignment) button', () => {
            it('should be disabled', () => {
              // Assert
              const button = fixture.debugElement.query(By.css('#remove-assignment-button'));
              expect(button).toBeTruthy();
              expect(button.properties.disabled).toBeTruthy();
            });
          });

          describe('the assign phrase button', () => {
            it('should be disabled', () => {
              // Assert
              const button = fixture.debugElement.query(By.css('#assign-phrase-button'));
              expect(button).toBeTruthy();
              expect(button.properties.disabled).toBeTruthy();
            });
          });
        });
      });

      describe('when user does not have permission to add/remove phrase assignments', () => {
        beforeEach(() => {
          // Assemble user without the permission to add/remove phrase assignments
          const userPermissions = [];
          userHasPermission = false;
          component.writeAssignmentPermissions = {
            permissions: userPermissions,
            regulatoryMarketId: 5,
            regulatoryProductClassId: 1,
            topicId: 19,
          };
          fixture.detectChanges();
        });

        describe('the remove phrase (assignment) button', () => {
          it('should be hidden', () => {
            // Assert
            const button = fixture.debugElement.query(By.css('#remove-assignment-button'));
            expect(button).toBeFalsy();
          });
        });

        describe('the assign phrase button', () => {
          it('should be hidden', () => {
            // Assert
            const button = fixture.debugElement.query(By.css('#assign-phrase-button'));
            expect(button).toBeFalsy();
          });
        });
      });

      describe('when user has permission to edit phrases', () => {
        beforeEach(() => {
          // Assemble user with the permission to edit (write) phrases
          const userPermissions = [Permission.AraPReFDCT_Phrases_WriteWithAssignments, Permission.AraPReFDCT_Phrases_WriteWithoutAssignments];
          userHasPermission = true;
          component.editPhrasePermissions = userPermissions;
          component.isEditAllowed = true;
          fixture.detectChanges();
        });

        it('the edit phrase button should be enabled', () => {
          // Assert
          const button = fixture.debugElement.query(By.css('#edit-phrase-button'));
          expect(button).toBeTruthy();
          expect(button.properties.disabled).toBeFalsy();
        });
      });

      describe('when user does not have permission to edit phrases', () => {
        beforeEach(() => {
          // Assemble user without the permission to write phrases with or without assignments
          const userPermissions = [];
          userHasPermission = false;
          component.editPhrasePermissions = userPermissions;
          fixture.detectChanges();
        });

        it('the edit phrase button should be hidden', () => {
          // Assert
          const button = fixture.debugElement.query(By.css('#edit-phrase-button'));
          expect(button).toBeFalsy();
        });
      });
    });

    describe('editPhrasePermissions', () => {
      it('should hold appropriate permissions', () => {
        // Assemble
        const expectedPermissions: Permission[] = [
          Permission.AraPReFDCT_Phrases_WriteWithAssignments,
          Permission.AraPReFDCT_Phrases_WriteWithoutAssignments,
        ];

        // Assert
        expect(component.editPhrasePermissions).toEqual(expectedPermissions);
      });
    });

    describe('assessAssignmentPermissions', () => {
      it('should hold appropriate permissions', () => {
        // Assemble
        const expectedPermissions: MarketRpcAndTopicScopedPermissions = {
          permissions: [Permission.AraPReFDCT_PhraseAssignments_Assess],
          regulatoryMarketId: null,
          regulatoryProductClassId: null,
          topicId: null,
        };

        // Assert
        expect(component.assessAssignmentPermissions).toEqual(expectedPermissions);
      });
    });

    describe('writeAssignmentPermissions', () => {
      it('should hold appropriate permissions', () => {
        // Assemble
        const expectedPermissions: MarketRpcAndTopicScopedPermissions = {
          permissions: [Permission.AraPReFDCT_PhraseAssignments_Write],
          regulatoryMarketId: null,
          regulatoryProductClassId: null,
          topicId: null,
        };

        // Assert
        expect(component.writeAssignmentPermissions).toEqual(expectedPermissions);
      });
    });

    describe('when statements and tabular inputs have been loaded', () => {
      beforeEach(done => {
        // Assemble
        component.load(createSelectedMatrixCell(), createSelectedMatrixCell(), new MatrixFilter, true).then(() => {
          fixture.detectChanges();
          done();
        });
      });

      describe('removeAssignment', () => {
        describe('calls service with correct params', () => {
          it('when statement removed', done => {
            // Assemble
            jest.spyOn(matrixCellEditService, 'removeAssignment');
            const removedAssignmentId = component.data.statements[2].phraseAssignmentId;
            component.statementSelected(component.data.statements[2]);

            // Act
            component.removeAssignment().then(() => {
              // Assert
              expect(matrixCellEditService.removeAssignment).toHaveBeenCalledWith(removedAssignmentId);
              done();
            });
          });

          it('when tabular input removed', done => {
            // Assemble
            jest.spyOn(matrixCellEditService, 'removeAssignment');
            const removedAssignmentId = component.data.tabularInputs[1].phraseAssignmentId;
            component.tabInputSelected(component.data.tabularInputs[1]);

            // Act
            component.removeAssignment().then(() => {
              // Assert
              expect(matrixCellEditService.removeAssignment).toHaveBeenCalledWith(removedAssignmentId);
              done();
            });
          });
        });
      });

      describe('load calls the correct service method', () => {
        it('for a target cell', done => {
          const selectedCell = createSelectedMatrixCell();
          const contextCell = createSelectedMatrixCell();
          jest.spyOn(matrixCellEditService, 'loadMatrixCellEditData');

          component.load(selectedCell, contextCell, new MatrixFilter, true).then(() => {
            expect(matrixCellEditService.loadMatrixCellEditData).toHaveBeenCalled();
            done();
          });
        });

        it('for a non-target cell', done => {
          const selectedCell = createSelectedMatrixCell();
          const contextCell = createSelectedMatrixCell();
          contextCell.regulatoryMarketId = 1000;
          jest.spyOn(matrixCellDetailsService, 'loadMatrixCellDetailsData');

          component.load(selectedCell, contextCell, new MatrixFilter, true).then(() => {
            expect(matrixCellDetailsService.loadMatrixCellDetailsData).toHaveBeenCalled();
            done();
          });
        });
      });
    });

    describe('when user does not have permissions for market, RPC and topic', () => {
      beforeEach(() => {
        fixture = TestBed.createComponent(MatrixCellEditComponent);
        const injector = getTestBed();
        component = fixture.componentInstance;
        userHasPermissionForMarketRpcAndTopic = false;
        fixture.detectChanges();
      });

      it('should create', () => {
        expect(component).toBeTruthy();
      });

      it('should match snapshot with data', () => {
        setupComponentWithData(component);
        fixture.detectChanges();
        (expect(fixture) as any).toMatchSnapshot();
      });

      describe('when a phrase assignment has been selected', () => {
        beforeEach(() => {
          // Assemble the phrase assignment selection for a phrase that is approved and for which
          // modification is allowed.
          component.hasChangedData = false;
          component.selectedStatement = createStatementAssignment();
          component.selectedStatement.phraseStatus = PhraseStatus.Approved;
          component.selectedStatement.isActive = true;
          component.data.allowModify = true;
          fixture.detectChanges();
        });

        describe('when user does not have permission to assess phrase assignments', () => {
          beforeEach(() => {
            // Assemble user without the permission to assess phrase assignments
            const userPermissions = [Permission.AraPReFDCT_Phrases_Read];
            userHasPermission = false;
            component.assessAssignmentPermissions = {
              permissions: userPermissions,
              regulatoryMarketId: null,
              regulatoryProductClassId: null
            };
            fixture.detectChanges();
          });

          describe('the accept assignment button', () => {
            it('should be hidden', () => {
              const button = fixture.debugElement.query(By.css('#accept-assignment-button'));
              expect(button).toBeFalsy();
            });
          });

          describe('the not relevant assignment button', () => {
            it('should be hidden', () => {
              const button = fixture.debugElement.query(By.css('#not-relevant-assignment-button'));
              expect(button).toBeFalsy();
            });
          });
        });
      });
    });
  });
});

function setupComponentWithData(newComponent: MatrixCellEditComponent) {
  newComponent.data.allowModify = true;
  const pa = createNewPhraseAssignment();
  newComponent.selectedStatement = pa;
}

function createNewPhraseAssignment(): Statement {
  const pa: Statement = new Statement();
  pa.phraseId = 1;
  pa.phraseNr = 101;
  pa.phraseText = "texty";
  pa.phraseStatus = PhraseStatus.Approved;
  pa.phraseAssignmentStatus = AssignmentStatus.ToBeAssessed;
  pa.isActive = true;
  pa.unitOfMeasure = "frogs/cm^3";
  pa.phraseDetailLevelDescription = "detailed";
  pa.sourceLocation = "somewhere";
  pa.isNew = true;
  return pa;
}

export function createSelectedMatrixCell(): SelectedMatrixCell {
  return {
    regulatoryProductClassId: 500,
    regulatoryMarketId: 750,
    topicId: 10,
  };
}

export function createStatementAssignments() {
  return [...[
    {
      phraseId: 1,
      unileverProductDivisionId: 9,
      unileverProductDivisionPath: new Array<string>(),
      phraseAssignmentId: 10,
      phraseNr: 505,
      phraseText: "test text 1",
      phraseStatus: "test status 1",
      isActive: true,
      phraseAssignmentStatus: "test PA status 1",
      phraseDetailLevelDescription: "test description 1",
      assessmentReason: "test reason 1",
      sourceLocation: "test location 1",
      inheritedSourceLocation: "",
      unitOfMeasure: "cm",
      isNew: false,
      isVirtual: true,
      linkedPhraseNr: 9
    },
    {
      phraseId: 2,
      unileverProductDivisionId: 9,
      unileverProductDivisionPath: new Array<string>(),
      phraseAssignmentId: 11,
      phraseNr: 506,
      phraseText: "test text 2",
      phraseStatus: "test status 2",
      isActive: true,
      phraseAssignmentStatus: "test PA status 2",
      phraseDetailLevelDescription: "test description 2",
      assessmentReason: "test reason 2",
      sourceLocation: "test location 2",
      inheritedSourceLocation: "",
      unitOfMeasure: "cm",
      isNew: false,
      isVirtual: true,
      linkedPhraseNr: 9
    },
    {
      phraseId: 3,
      unileverProductDivisionId: 9,
      unileverProductDivisionPath: new Array<string>(),
      phraseAssignmentId: 12,
      phraseNr: 507,
      phraseText: "test text 3",
      phraseStatus: "test status 3",
      isActive: true,
      phraseAssignmentStatus: "test PA status 3",
      phraseDetailLevelDescription: "test description 3",
      assessmentReason: "test reason 3",
      sourceLocation: "test location 3",
      inheritedSourceLocation: "",
      unitOfMeasure: "cm",
      isNew: false,
      isVirtual: true,
      linkedPhraseNr: 9
    },
  ]];
}

export function createTabularAssignments() {
  const statements = createStatementAssignments();
  return [
    {
      ...statements[0],
      isRange: true,
      inputValueType1: 22,
      inputValue1: ">",
      inputValueType2: 100,
      inputValue2: "<"
    },
    {
      ...statements[1],
      isRange: true,
      inputValueType1: 52,
      inputValue1: ">",
      inputValueType2: 500,
      inputValue2: "<"
    },
    {
      ...statements[2],
      isRange: true,
      inputValueType1: 60,
      inputValue1: ">",
      inputValueType2: 600,
      inputValue2: "<"
    },
  ];
}

export function getCellDetails() {
  const cellDetails: CellDetails = {
    regulatoryMarket: ["Algeria"],
    regulatoryProductClass: ["Some RPC"],
    topic: null,
    allowModify: true,
    statements: createStatementAssignments(),
    tabularInputs: createTabularAssignments(),
  };

  return cellDetails;
}