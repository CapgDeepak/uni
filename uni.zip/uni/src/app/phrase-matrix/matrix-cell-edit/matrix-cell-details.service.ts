import { Injectable } from '@angular/core';
import { CellDetails } from './matrix-cell-edit.types';
import { MatrixStatus } from '../phrase-matrix.types';
import { PhraseStatus, AssignmentStatus, UrlEndpoint } from '../../tools/constants';
import { HttpService } from '../../tools/services/http.service';

@Injectable()
export class MatrixCellDetailsService {
    constructor(
        private httpService: HttpService) { }

    loadMatrixCellDetailsData(
        regulatoryMarketId: number,
        regulatoryProductClassId: number,
        topicId: number,
        status: MatrixStatus,
        selectedRegulatoryMarketId: number,
        selectedRegulatoryProductClassId: number
    ): Promise<CellDetails> {
        // Translate view status to phrase/assignment status
        let phraseStatus: PhraseStatus = null;
        let assignmentStatus: AssignmentStatus = null;
        if (status == MatrixStatus.Approved) {
            phraseStatus = PhraseStatus.Approved;
            assignmentStatus = AssignmentStatus.Accepted;
        }
        else if (status == MatrixStatus.NotRelevant) {
            phraseStatus = PhraseStatus.Approved;
            assignmentStatus = AssignmentStatus.NotRelevant;
        }
        else if (status == MatrixStatus.Rejected) {
            phraseStatus = PhraseStatus.Rejected;
        }
        else if (status == MatrixStatus.ToBeApproved) {
            phraseStatus = PhraseStatus.ToBeApproved;
        }
        else if (status == MatrixStatus.ToBeAssessed) {
            phraseStatus = PhraseStatus.Approved;
            assignmentStatus = AssignmentStatus.ToBeAssessed;
        }

        return new Promise<CellDetails>((resolve, reject) => {
            const postData = {
                regulatoryMarketId: regulatoryMarketId,
                regulatoryProductClassId: regulatoryProductClassId,
                topicId: topicId,
                phraseStatus: phraseStatus,
                assignmentStatus: assignmentStatus,
                selectedRegulatoryMarketId: selectedRegulatoryMarketId,
                selectedRegulatoryProductClassId: selectedRegulatoryProductClassId
            };
            this.httpService.postContent(JSON.stringify(postData), UrlEndpoint.PhraseMatrix_GetCellDetailData).subscribe(result => {
                resolve(result);
            }, error => {
                console.error(error);
                reject(error);
            });
        });
    }
}