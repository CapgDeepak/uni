import { Injectable } from '@angular/core';
import { CellDetails, TabularInputData } from './matrix-cell-edit.types';
import { SaveResult } from './../../tools/common.types';
import { PhraseStatus, AssignmentStatus, UrlEndpoint } from '../../tools/constants';
import { MatrixStatus } from '../phrase-matrix.types';
import { HttpService } from '../../tools/services/http.service';
import { TabularInputValueData } from '../phrase-assess/phrase-assess.types';
import { isNullOrWhitespace } from '../../tools/utils';

@Injectable()
export class MatrixCellEditService {
    constructor(
        private httpService: HttpService) { }

    loadMatrixCellEditData(
        regulatoryMarketId: number,
        regulatoryProductClassId: number,
        topicId: number,
        status: MatrixStatus
    ): Promise<CellDetails> {
        // Translate view status to phrase/assignment status
        let phraseStatus: PhraseStatus = null;
        let assignmentStatus: AssignmentStatus = null;
        if (status == MatrixStatus.Approved) {
            phraseStatus = PhraseStatus.Approved;
            assignmentStatus = AssignmentStatus.Accepted;
        }
        else if (status == MatrixStatus.NotRelevant) {
            phraseStatus = PhraseStatus.Approved;
            assignmentStatus = AssignmentStatus.NotRelevant;
        }
        else if (status == MatrixStatus.Rejected) {
            phraseStatus = PhraseStatus.Rejected;
        }
        else if (status == MatrixStatus.ToBeApproved) {
            phraseStatus = PhraseStatus.ToBeApproved;
        }
        else if (status == MatrixStatus.ToBeAssessed) {
            phraseStatus = PhraseStatus.Approved;
            assignmentStatus = AssignmentStatus.ToBeAssessed;
        }

        return new Promise<CellDetails>((resolve, reject) => {
            const postData = {
                regulatoryMarketId: regulatoryMarketId,
                regulatoryProductClassId: regulatoryProductClassId,
                topicId: topicId,
                phraseStatus: phraseStatus,
                assignmentStatus: assignmentStatus
            };
            this.httpService.postContent(JSON.stringify(postData), UrlEndpoint.PhraseMatrix_GetCellEditData).subscribe(result => {
                resolve(result);
            }, error => {
                console.error(error);
                reject(error);
            });
        });
    }

    public createAssignmentForExistingPhrase(
        phraseId: number,
        regulatoryMarketId: number,
        regulatoryProductClassId: number,
        topicId: number
    ): Promise<SaveResult> {
        return new Promise<SaveResult>((resolve, reject) => {
            const postData = Object.assign({
                phraseId,
                regulatoryMarketId,
                regulatoryProductClassId,
                topicId
            });

            this.httpService.postContent(JSON.stringify(postData), UrlEndpoint.PhraseMatrix_CreateAssignment)
            .subscribe(result => {
                resolve(result);
            }, error => {
                reject(error);
            });
        });
    }

    public isInvalidTabularInput(tabularInput: TabularInputData): boolean {
        // Returns true for a tabular input phrase that lacks an input value
        return !!tabularInput && (isNullOrWhitespace(tabularInput.inputValue1) || (tabularInput.isRange && isNullOrWhitespace(tabularInput.inputValue2)));
    }

    public getTabularInputValueData(tabularInput: TabularInputData): TabularInputValueData {
        return (tabularInput == null || tabularInput == undefined) ? null : {
            isRange: tabularInput.isRange,
            inputValueType1: tabularInput.inputValueType1,
            inputValue1: tabularInput.inputValue1,
            inputValueType2: tabularInput.inputValueType2,
            inputValue2: tabularInput.inputValue2,
            unitOfMeasure: tabularInput.unitOfMeasure
        };
    }

    public removeAssignment(assignmentId: number): Promise<SaveResult> {
        return new Promise<SaveResult>((resolve, reject) => {
            this.httpService.postContent(assignmentId, UrlEndpoint.PhraseMatrix_RemoveAssignment).subscribe(result => {
                resolve(result);
            }, error => {
                reject(error);
            });
        });
    }
}