import { TestBed, inject } from '@angular/core/testing';

import { MatrixCellDetailsService } from './matrix-cell-details.service';
import { HttpService } from '../../tools/services/http.service';

class HttpServiceMock{}

describe('MatrixCellDetailsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MatrixCellDetailsService,
        { provide: HttpService, useClass: HttpServiceMock },
      ]
    });
  });

  it('should be created', inject([MatrixCellDetailsService], (service: MatrixCellDetailsService) => {
    expect(service).toBeTruthy();
  }));
});
