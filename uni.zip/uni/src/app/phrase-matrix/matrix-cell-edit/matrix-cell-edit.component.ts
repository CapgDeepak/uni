import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import * as cloneDeep from 'lodash.clonedeep';

import { SelectedMatrixCell, MatrixFilter, MatrixDetail } from '../phrase-matrix.types';
import { EmptyCellDetails, StatementData, Statement, TabularInputData, CellDetails, TabularInput } from './matrix-cell-edit.types';
import { MatrixCellEditService } from './matrix-cell-edit.service';
import { SideDialogService } from '../../tools/side-dialog/side-dialog.service';
import { FindPhraseComponent } from '../../shared-components/find-phrase/find-phrase.component';
import { ConfirmationDialogService } from '../../shared-components/confirmation-dialog/confirmation-dialog.service';
import { MatrixPhraseEditComponent } from '../matrix-phrase-edit/matrix-phrase-edit.component';
import { PhraseAssessComponent } from '../phrase-assess/phrase-assess.component';
import { DialogService } from '../../tools/services/dialog.service';
import { NotificationService } from '../../tools/services/notification.service';
import { DetailLevels, TabType, AssignmentStatus, PhraseStatus, EmptyTabularInputValueWarning } from '../../tools/constants';
import { Permission } from '../../tools/shared-types/permissions/permission';
import { MarketRpcAndTopicScopedPermissions } from '../../tools/shared-types/permissions/market-rpc-and-topic-scoped-permissions';
import { AuthorizationService } from '../../authorization/authorization.service';
import { MatrixCellDetailsService } from './matrix-cell-details.service';

@Component({
    selector: 'app-matrix-cell-edit',
    templateUrl: './matrix-cell-edit.component.html',
    styleUrls: ['./matrix-cell-edit.component.scss']
})

export class MatrixCellEditComponent implements OnInit {
    // these are used directly in the html template, so do not remove
    assignmentAccepted: string = AssignmentStatus.Accepted;
    regulatoryMarketStatus = [];
    assignmentNotRelevant: string = AssignmentStatus.NotRelevant;
    countStatements: any;
    counttabularInputs: any;
    ordtabulardata: any;
    display: boolean = false;
    public writeAssignmentPermissions: MarketRpcAndTopicScopedPermissions = {
        permissions: [Permission.AraPReFDCT_PhraseAssignments_Write],
        regulatoryMarketId: null,
        regulatoryProductClassId: null,
        topicId: null
    };
    public assessAssignmentPermissions: MarketRpcAndTopicScopedPermissions = {
        permissions: [Permission.AraPReFDCT_PhraseAssignments_Assess],
        regulatoryMarketId: null,
        regulatoryProductClassId: null,
        topicId: null
    };
    public editPhrasePermissions: Permission[] = [
        Permission.AraPReFDCT_Phrases_WriteWithAssignments,
        Permission.AraPReFDCT_Phrases_WriteWithoutAssignments,
    ];
    hasChangedData: boolean = false;
    hasStagedData: boolean = false;
    showUpd: boolean = false;
    hasTargetCellAssessPermissions: boolean = false;

    activeTabId: string = TabType.StatementsTabId;

    // Represents the cell details data to display
    data: CellDetails = new EmptyCellDetails();

    // Represents the cell details data that were initially loaded.
    // This acts as an initial cache of the data, and is used to determine
    // which statements and tabular inputs have been updated when the user performs
    // the save operation.
    originalData: CellDetails = new EmptyCellDetails();

    // Note that we do not keep track of the statements/tabular inputs to update here.
    // The entities to update are handled by two-way data binding followed by a difference
    // between the most recent data (represented by the data property above) and the initially
    // loaded data (represented by the originalData property above), before being sent to
    // the backend when the user completes a save operation.
    statementsToCreate: Statement[] = [];
    statementsToDelete: Statement[] = [];
    tabularInputsToCreate: TabularInput[] = [];
    tabularInputsToDelete: TabularInput[] = [];

    public isLoading: boolean = false;
    enbBtn: boolean = true;

    constructor(
        public activeModal: NgbActiveModal,
        private confirmationDialogService: ConfirmationDialogService,
        private sideDialogService: SideDialogService,
        private notification: NotificationService,
        private matrixCellEditService: MatrixCellEditService,
        private matrixCellDetailsService: MatrixCellDetailsService,
        private dialogService: DialogService,
        private authorizationService: AuthorizationService,
    ) { }

    ngOnInit(): void {
        this.setPermissions();
    }

    private _selectedCell: SelectedMatrixCell | null = null;
    public get selectedCell(): SelectedMatrixCell {
        return this._selectedCell;
    }
    public set selectedCell(value: SelectedMatrixCell) {
        if (this._selectedCell != value) {
            this._selectedCell = value;
            this.setPermissions();
        }
    }

    private contextCell: SelectedMatrixCell | null = null;

    filteredStatements: StatementData[];
    filteredTabularInputs: StatementData[];
    private filter: MatrixFilter = new MatrixFilter();

    public get detailLevel(): number {
        return this.filter.detail;
    }
    public set detailLevel(value: number) {
        if (this.filter.detail != value) {
            this.filter.detail = value;
            this.detailLevelChanged();
        }
    }

    public isEditAllowed: boolean;
    public isTarget: boolean;

    tabChange() {
        // reset selections when changing tab to avoid buttons being enabled for wrong assignment
        this.selectedStatement = null;
        this.selectedTabInput = null;
        this.showUpd = false;
    }

    detailLevelChanged() {
        this.filteredStatements = this.filterStatements(this.data.statements);
        this.filteredTabularInputs = this.filterStatements(this.data.tabularInputs);

        if (!this.filteredStatements.length || !this.filteredTabularInputs.length) {
            if ((this.filteredStatements.length == 0) && (this.filteredTabularInputs.length > 0)) {
                this.activeTabId = TabType.TabularInputsTabId;
            }
            else {
                this.activeTabId = TabType.StatementsTabId;
            }
        }
    }

    private filterStatements<T extends StatementData>(list: Array<T>): Array<T> {
        return list.filter(s => {
            // Detail
            if (this.filter.detail == MatrixDetail.Standard) {
                return s.phraseDetailLevelDescription == DetailLevels.Standard;
            }
            else if (this.filter.detail == MatrixDetail.Detailed) {
                return s.phraseDetailLevelDescription == DetailLevels.Detailed;
            }
            else if (this.filter.detail == MatrixDetail.InternalRA) {
                return s.phraseDetailLevelDescription == DetailLevels.InternalRA;
            }
            else {
                return true;
            }
        });
    }

    public load(selectedCell: SelectedMatrixCell, contextCell: SelectedMatrixCell, filter: MatrixFilter, isAllowed: boolean): Promise<void> {
        this.selectedCell = selectedCell;
        this.contextCell = contextCell;
        this.filter.detail = filter.detail;
        this.filter.status = filter.status;
        this.isEditAllowed = isAllowed;
        this.isTarget = contextCell != null &&
            selectedCell != null &&
            contextCell.regulatoryMarketId == selectedCell.regulatoryMarketId &&
            contextCell.regulatoryProductClassId == selectedCell.regulatoryProductClassId;
        return this.loadData();
    }

    private loadData(): Promise<void> {
        return (this.isTarget && this.isEditAllowed) ? this.loadMatrixCellEditData()
            : this.loadMatrixCellDetailsData();
    }

    private loadMatrixCellEditData(): Promise<void> {
        if (this._selectedCell && this.contextCell) {
            this.isLoading = true;
            return this.matrixCellEditService.loadMatrixCellEditData(
                this._selectedCell.regulatoryMarketId,
                this._selectedCell.regulatoryProductClassId,
                this._selectedCell.topicId,
                this.filter.status
            ).then(value => {
                this.populateData(value);
            });
        }
    }

    private loadMatrixCellDetailsData(): Promise<void> {
        return this.matrixCellDetailsService.loadMatrixCellDetailsData(
            this.contextCell.regulatoryMarketId,
            this.contextCell.regulatoryProductClassId,
            this.contextCell.topicId,
            this.filter.status,
            this._selectedCell.regulatoryMarketId,
            this._selectedCell.regulatoryProductClassId).then(data => {
                this.populateData(data);
            });
    }
    private checkMarketStatus(market: string) {
        const marketStatus = this.regulatoryMarketStatus["description"].find(x => x.description.toLowerCase() === market.toLowerCase());
        return marketStatus != undefined && marketStatus['status'].toLowerCase() == 'RetiredMarket'.toLowerCase() ? true : false;
    }
    private populateData(data) {
        this.regulatoryMarketStatus = data.regulatoryMarketsStatus;
        this.countStatements = Object.keys(data.statements).length;
        this.counttabularInputs = Object.keys(data.tabularInputs).length;
        this.ordtabulardata = data.tabularInputs;
        this.data = cloneDeep(data) as CellDetails;
        this.originalData = cloneDeep(data) as CellDetails;
        // Filter and publish
        data.statements = this.filterStatements(data.statements);
        data.tabularInputs = this.filterStatements(data.tabularInputs);
        // Select filled tab
        if (data.statements.length == 0 && data.tabularInputs.length > 0) {
            this.activeTabId = TabType.TabularInputsTabId;
        }
        else {
            this.activeTabId = TabType.StatementsTabId;
        }
        this.detailLevelChanged();
        this.isLoading = false;
        this.selectedStatement = null;
        this.selectedTabInput = null;
    }

    selectedStatement: StatementData = null;
    statementSelected(value: StatementData) {
        this.selectedTabInput = null;
        this.showUpd = false;
        if (this.selectedStatement != value) {
            this.selectedStatement = value;
            this.showUpd = true;
        }
    }

    selectedTabInput: TabularInputData = null;
    tabInputSelected(value: TabularInputData) {
        this.selectedStatement = null;
        this.showUpd = false;
        if (this.selectedTabInput != value) {
            this.selectedTabInput = value;
            this.showUpd = true;
        }
    }

    public get assignDisabled(): boolean {
        return this.hasStagedData;
    }

    public get acceptButtonTooltip(): string {
        if (this.matrixCellEditService.isInvalidTabularInput(this.selectedTabInput)) {
            return EmptyTabularInputValueWarning;
        }
        else {
            return '';
        }
    }

    get isSelected(): boolean {
        return !!this.selectedStatement || !!this.selectedTabInput;
    }

    get selected(): StatementData | TabularInputData {
        return this.selectedStatement || this.selectedTabInput;
    }

    get allowAssignmentReview(): boolean {
        const phrase = this.selected;
        return this.data && (!this.isTarget || this.data.allowModify)
            && phrase && phrase.isActive && phrase.phraseStatus == PhraseStatus.Approved;
    }

    assignAnotherPhrase() {
        const findDialog = this.sideDialogService.openBigWithCallback(FindPhraseComponent,
            result => {
                if (result && result.phraseId) {
                    this.isLoading = true;
                    this.matrixCellEditService.createAssignmentForExistingPhrase(
                        result.phraseId,
                        this._selectedCell.regulatoryMarketId,
                        this._selectedCell.regulatoryProductClassId,
                        this._selectedCell.topicId)
                        .then(value => {
                            this.loadData();
                            this.selectedStatement = null;
                            this.selectedTabInput = null;
                        })
                        .catch(error => {
                            if (error && error.status >= 400 && error.error && error.error.Message) {
                                this.notification.error(error.statusText, error.error.Message);
                            }

                            this.isLoading = false;
                        });
                }
            }
        );

        findDialog.componentInstance.selectedCell = this.selectedCell;
    }

    removeAssignment(): Promise<void> {
        if (this.isSelected) {
            this.isLoading = true;
            return this.confirmationDialogService.confirm(
                'Remove phrase assignment',
                'Do you want to remove the selected phrase assignment?',
                'Remove').then(result => {
                    if (result) {
                        let assignmentId = 0;
                        if (this.selectedStatement) {
                            const index = this.data.statements.indexOf(this.selectedStatement);
                            if (index >= 0) {
                                assignmentId = this.data.statements[index].phraseAssignmentId;

                                // We must also remove the statement from the data object, as this is used
                                // as the collection of statements and tabular inputs to display.
                                this.data.statements.splice(index, 1);
                                this.selectedStatement = null;
                            }
                        } else if (this.selectedTabInput) {
                            const index = this.data.tabularInputs.indexOf(this.selectedTabInput);

                            if (index >= 0) {
                                assignmentId = this.data.tabularInputs[index].phraseAssignmentId;

                                // We must also remove the tabular inputs from the data object, as this is used
                                // as the collection of statements and tabular inputs to display.
                                this.data.tabularInputs.splice(index, 1);
                                this.selectedTabInput = null;
                            }
                        }
                        this.matrixCellEditService.removeAssignment(assignmentId).then(removeResult => {
                            this.notification.process(removeResult);
                            this.isLoading = false;
                            this.detailLevelChanged();
                            this.hasChangedData = true;
                        });
                    } else {
                        this.isLoading = false;
                    }
                });
        }
    }

    editPhrase() {
        if (!this.phraseEditAllowed) {
            return;
        }
        const selected = this.selected;
        if (selected) {
            const modalRef = this.sideDialogService.openWithCallback(MatrixPhraseEditComponent, () => {
                this.loadData();
            });
            modalRef.componentInstance.title = 'Edit';
            modalRef.componentInstance.initEditPhrase(this._selectedCell, selected.phraseId);
        }
    }

    get isApproveEnabled(): boolean {
        return this.isSelected && this.selected.phraseStatus != PhraseStatus.Approved;
    }

    get isValid(): boolean {
        return !!this.data;
    }

    acceptAssignment() {
        this.assessAssignment(AssignmentStatus.Accepted);
    }

    notRelevantAssignment() {
        this.assessAssignment(AssignmentStatus.NotRelevant);
    }

    private assessAssignment(assignmentStatus: AssignmentStatus) {
        const selected = this.selected;
        if (!selected) {
            return;
        }

        const tabularInputValue = this.matrixCellEditService.getTabularInputValueData(this.selectedTabInput);
        const modal = this.dialogService.open(PhraseAssessComponent, {
            backdrop: 'static',
            centered: true,
            size: 'lg'
        });

        modal.componentInstance.load(
            this.contextCell.regulatoryProductClassId,
            this._selectedCell.regulatoryProductClassId,
            this._selectedCell.topicId,
            this.contextCell.regulatoryMarketId,
            this._selectedCell.regulatoryMarketId,
            this.selected.phraseId,
            null,
            assignmentStatus,
            tabularInputValue,
            this.selectedLocalSource());

        modal.result.then(completed => {
            if (completed) {
                // reflect changes
                // todo: preserve changes
                this.loadData();
            }
        });
    }

    /**
     * Find the correct local source entry for the selected assignment
     */
    private selectedLocalSource() {
        if (this.selectedStatement && this.selectedStatement.sourceLocation) {
            return this.selectedStatement.sourceLocation;
        }
        else if (this.selectedTabInput && this.selectedTabInput.sourceLocation) {
            return this.selectedTabInput.sourceLocation;
        }
        return null;
    }

    setPermissions() {
        this.setAssessAssignmentPermissions();
        this.setWriteAssignmentPermissions();
        this.hasTargetCellAssessPermissions = this.authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic(
            this.assessAssignmentPermissions.permissions,
            this.assessAssignmentPermissions.regulatoryMarketId,
            this.assessAssignmentPermissions.regulatoryProductClassId,
            this.assessAssignmentPermissions.topicId);
    }

    setAssessAssignmentPermissions(): void {
        this.assessAssignmentPermissions = {
            ...this.assessAssignmentPermissions,
            regulatoryMarketId: this.selectedCell && this.selectedCell.regulatoryMarketId,
            regulatoryProductClassId: this.selectedCell && this.selectedCell.regulatoryProductClassId,
            topicId: this.selectedCell && this.selectedCell.topicId
        };
    }

    setWriteAssignmentPermissions(): void {
        this.writeAssignmentPermissions = {
            ...this.writeAssignmentPermissions,
            regulatoryMarketId: this.selectedCell && this.selectedCell.regulatoryMarketId,
            regulatoryProductClassId: this.selectedCell && this.selectedCell.regulatoryProductClassId,
            topicId: this.selectedCell && this.selectedCell.topicId
        };
    }

    public get phraseEditAllowed(): boolean {
        return this.authorizationService.checkUserHasAnyPermission(this.editPhrasePermissions);
    }

    public get acceptAssignmentAllowed() {
        const tabInputValueCount = this.selectedTabInput != null && this.selectedTabInput.inputValue1 != null ? this.selectedTabInput.inputValue1.replace(/<.*?>/g, '') : '';
        this.enbBtn = tabInputValueCount.length < 1501;
        return this.selected && !this.matrixCellEditService.isInvalidTabularInput(this.selectedTabInput)
            && this.hasTargetCellAssessPermissions
            && (tabInputValueCount.length < 1501);
    }

    public get removeAssignmentAllowed() {
        return this.selected &&
            this.selected.phraseAssignmentStatus != this.assignmentAccepted &&
            this.writeAssignmentAllowed;
    }

    public get writeAssignmentAllowed() {
        return this.isValid && this.authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic(
            this.writeAssignmentPermissions.permissions,
            this.writeAssignmentPermissions.regulatoryMarketId,
            this.writeAssignmentPermissions.regulatoryProductClassId,
            this.writeAssignmentPermissions.topicId);
    }

    public get assessAssignmentAllowed() {
        return this.isValid && this.authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic(
            this.assessAssignmentPermissions.permissions,
            this.assessAssignmentPermissions.regulatoryMarketId,
            this.assessAssignmentPermissions.regulatoryProductClassId,
            this.assessAssignmentPermissions.topicId);
    }

    public checkChangeItem(changeitem) {
        localStorage.setItem("changeTabular", changeitem);
    }
    public closePopup() {

        const changeTabular = localStorage.getItem("changeTabular");
        if (changeTabular !== '' || Object.keys(changeTabular).length !== 0) {
            this.display = true;
        } else {
            this.activeModal.close('Close');
        }
    }
    public CloseSideBar() {
        this.display = false;
        localStorage.setItem("changeTabular", '');
        this.activeModal.close('Close');
    }

    enableDisableBtn(value) {
      //  this.enbBtn = value;
    }
}