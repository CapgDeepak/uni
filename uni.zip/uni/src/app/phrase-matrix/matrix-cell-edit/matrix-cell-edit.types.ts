export interface ICreateDeleteUpdateEntitiesModel<T> {
    entitiesToCreate: T[];
    entitiesToDelete: T[];
    entitiesToUpdate: T[];
}

export class CreateDeleteUpdateEntitiesModel<T> implements ICreateDeleteUpdateEntitiesModel<T> {
    entitiesToCreate: T[];
    entitiesToDelete: T[];
    entitiesToUpdate: T[];

    constructor(entitiesToCreate?: T[], entitiesToDelete?: T[], entitiesToUpdate?: T[]) {
        this.entitiesToCreate = entitiesToCreate ? entitiesToCreate : [];
        this.entitiesToDelete = entitiesToDelete ? entitiesToDelete : [];
        this.entitiesToUpdate = entitiesToUpdate ? entitiesToUpdate : [];
    }
}

export interface StatementData {
    phraseId: number;
    phraseAssignmentId: number;
    unileverProductDivisionId: number;
    unileverProductDivisionPath: string[];
    phraseNr: number;
    phraseText: string;
    phraseStatus: string;
    isActive: boolean;
    phraseAssignmentStatus: string;
    phraseDetailLevelDescription: string;
    assessmentReason: string;
    sourceLocation: string;
    inheritedSourceLocation: string;
    unitOfMeasure: string;
    isNew: boolean;
    linkedPhraseNr: number;
}
export interface TabularInputData extends StatementData {
    isRange: boolean;
    inputValueType1: number;
    inputValue1: string;
    inputValueType2: number;
    inputValue2: string;
}

export interface CellDetails {
    regulatoryMarket: string[];
    regulatoryProductClass: string[];
    topic: string[];
    allowModify: boolean;
    statements: StatementData[];
    tabularInputs: TabularInputData[];
}

export class EmptyCellDetails implements CellDetails {
    regulatoryMarket: string[] = new Array<string>();
    regulatoryProductClass: string[] = new Array<string>();
    topic: string[] = new Array<string>();
    allowModify: boolean = false;
    statements: Statement[];
    tabularInputs: TabularInput[];
}

export class Statement implements StatementData {
    phraseAssignmentId: number;
    unileverProductDivisionId: number;
    unileverProductDivisionPath: string[] = new Array<string>();
    phraseId: number;
    phraseNr: number;
    phraseText: string;
    phraseStatus: string;
    isActive: boolean;
    phraseAssignmentStatus: string;
    phraseDetailLevelDescription: string;
    assessmentReason: string;
    sourceLocation: string;
    inheritedSourceLocation: string;
    unitOfMeasure: string;
    isNew: boolean = false;
    linkedPhraseNr: number;
}

export class TabularInput extends Statement implements TabularInputData {
    isRange: boolean;
    inputValueType1: number;
    inputValue1: string;
    inputValueType2: number;
    inputValue2: string;
}