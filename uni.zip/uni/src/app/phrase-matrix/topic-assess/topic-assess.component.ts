import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TopicAssessService } from './topic-assess.service';
import { TopicAssessRequestModel, RegulatoryMarket, AssessRow,
    TopicAssessImpactRequestModel, Step, RegulatoryMarketRPC,
    TopicAssessPerformRequestModel, TopicAssessViewModel, TopicAssessImpactViewModel } from './topic-assess.types';
import { TopicLinkStatus, UrlEndpoint } from '../../tools/constants';
import { HttpService } from '../../tools/services/http.service';

@Component({
    selector: 'app-topic-assess',
    templateUrl: './topic-assess.component.html',
    styleUrls: ['./topic-assess.component.scss']
})
export class TopicAssessComponent {
    details: TopicAssessViewModel;
    impact: TopicAssessImpactViewModel;
    private _isLoading: boolean = true;
    private step: Step = Step.edit;
    showAccepted: boolean = true;
    constructor(
        public activeModal: NgbActiveModal,
        private httpService: HttpService,
        private topicAssessService: TopicAssessService) {
    }

   load(
        regulatoryProductClassId: number,
        topicId: number,
        regulatoryMarketId: number,
        topicLinkStatus: TopicLinkStatus) {
        this.step = Step.edit;
        this._isLoading = true;

        const request = new TopicAssessRequestModel();
        request.regulatoryProductClassId = regulatoryProductClassId;
        request.topicId = topicId;
        request.regulatoryMarketId = regulatoryMarketId;
        request.topicLinkStatus = topicLinkStatus;

       this.topicAssessService.getDetails(request).then(result => {
          this.details = result;
        this.checklowerlabelRpc(result, request);
            this._isLoading = false;
        }).catch(() => {
            this.details = null;
            this._isLoading = false;
            this.close();
        });
    }
    public async checklowerlabelRpc2(result: any, req){
        const postData = {
            regulatoryMarketId: req.regulatoryMarketId,
            regulatoryProductClassId: req.regulatoryProductClassId,
            topicId: req.topicId
        };

        await result['conflicts'].forEach(async (num, index) => {
            postData.regulatoryProductClassId =  num.rpcId;
            await  this.httpService.postContentPromise(postData, UrlEndpoint.PhraseMatrix_GetCells)
            .then(xy => {
                if (Object.keys(xy['rows']).length != 0){
                    try{
                        xy['rows'].forEach(element => {
                        if (element['regulatoryProductClassId'] === num.rpcId){
                            if (element['hasDeclinedTopic'] == true){
                                result.conflicts[index]['lowerlabelRpc'] = "";
                             }else{
                            const CellData = element['cells'].find(xx => xx['regulatoryMarketId'] === postData.regulatoryMarketId);
                            result.conflicts[index]['lowerlabelRpc'] = CellData != undefined ? "!" : "";
                         }
                        }
                    });
                }catch (ex){
                    console.log(ex);
                }
                }else{
                    result.conflicts[index]['lowerlabelRpc'] = "";
                }
                this.impact = result;

            });
        });
    }
    public async checklowerlabelRpc(result: any, req){
        const postData = {
            regulatoryMarketId: req.regulatoryMarketId,
            regulatoryProductClassId: req.regulatoryProductClassId,
            topicId: req.topicId
        };
        await result.rows.forEach(async (num, index) => {
        postData.regulatoryProductClassId =  num.rpc.id;
        await  this.httpService.postContentPromise(postData, UrlEndpoint.PhraseMatrix_GetCells)
        .then(x => {
         if (Object.keys(x['rows']).length != 0){
             x['rows'].forEach(element => {
                 if (element['regulatoryProductClassId'] === num.rpc.id){
                     if (element['hasDeclinedTopic'] == true){
                        result.rows[index].rpc['lowerlabelRpc'] = "";
                     }else{
                    const CellData = element['cells'].find(xx => xx['regulatoryMarketId'] === postData.regulatoryMarketId);
                    result.rows[index].rpc['lowerlabelRpc'] = CellData != undefined ? "!" : "";
                     }
                 }
             });
         }else{
            result.rows[index].rpc['lowerlabelRpc'] = "";
         }
         this.details = result;
        }).catch(() => {
            this._isLoading = false;
            this.close();
        });
    });
    }
    public async checklowerlabelRpc1(result: any, req){
       await result.rows.forEach(async (num, index) => {
            req.regulatoryProductClassId = num.rpc.id;
             await this.topicAssessService.getDetails(req).then(x  => {
              result.rows[index].rpc['lowerlabelRpc'] = Object.keys(x["rpcs"]).length > 1 ? "!" : "";
              this.details = result;
            }).catch(() => {
            this._isLoading = false;
            this.close();
            });

        } );
    }
    ok() {
        this._isLoading = true;
        this.step = Step.apply;

        const request = new TopicAssessPerformRequestModel();

        // original request
        request.regulatoryProductClassId = this.details.regulatoryProductClassId;
        request.topicId = this.details.topicId;
        request.regulatoryMarketId = this.details.regulatoryMarketId;
        request.topicLinkStatus = this.details.topicLinkStatus;

        // include impact
        if (this.impact != null) {
            request.conflicts = this.impact.conflicts;
            request.conflictCount = this.impact.conflictCount;
            request.fullPropagationTargetCount = this.impact.fullPropagationTargetCount;
            request.scopeCount = this.impact.scopeCount;
            request.createCount = this.impact.createCount;
            request.ignoreCount = this.impact.ignoreCount;
            request.propagationTargets = this.impact.propagationTargets;
        }
        else {
            request.conflicts = [];
            request.propagationTargets = [];
        }

        this.httpService.postContentPromise(request, UrlEndpoint.PhraseMatrix_PerformTopicAssess).then(() => {
            this._isLoading = false;
            this.step = Step.done;
        }).catch(() => {
            this._isLoading = false;
        });
    }

    back() {
        this.step = Step.edit;
    }

    next() {
        this._isLoading = true;

        const request = new TopicAssessImpactRequestModel();
        request.regulatoryProductClassId = this.details.regulatoryProductClassId;
        request.topicId = this.details.topicId;
        request.regulatoryMarketId = this.details.regulatoryMarketId;
        request.topicLinkStatus = this.details.topicLinkStatus;
        request.propagationTargets = this.details.rows
            .map(r => r.cells.filter(c => c.isEditable && c.isSelected))
            .reduce((a, b) => a.concat(b))
            .map(r => {
                const selection = new RegulatoryMarketRPC();
                selection.regulatoryMarketId = r.regulatoryMarketId;
                selection.regulatoryProductClassId = r.regulatoryProductClassId;
                return selection;
            });
            request['declineTopic'] = true;
        this.httpService.postContentPromise(request, UrlEndpoint.PhraseMatrix_GetTopicAssessImpact).then(result => {
             this.impact = result;
           this.checklowerlabelRpc2(result, request);
            this._isLoading = false;
            this.step = Step.review;
        }).catch(() => {
            this.impact = null;
            this._isLoading = false;
        });
    }

    close() {
        this.activeModal.close(true);
    }

    cancel() {
        this.activeModal.close(false);
    }

    get title(): string {
        return this.isReady
            ? `Assess topic as ${this.assessmentLabel}`
            : 'Loading assessment...';
    }

    get assessmentLabel(): string {
        return !this.isReady
            ? ''
            : this.details.topicLinkStatus == TopicLinkStatus.Accepted
            ? 'accepted'
            : 'declined';
    }

    get isLoading(): boolean {
        return this._isLoading;
    }

    get isReady(): boolean {
        return !this.isLoading && this.details != null;
    }

    get canPropagate(): boolean {
        // we can propagate when loaded and at least a single market-rpc is editable
        return this.isReady && this.details.rows.some(r => r.cells.some(c => c.isEditable));
    }

    get propagationCount(): number | null {
        return this.canPropagate
            ? this.details.rows
                .map(r => r.cells.filter(c => c.isEditable && c.isSelected).length)
                .reduce((a, b) => a + b)
            : null;
    }

    isRowSelected(row: AssessRow) {
        return !row.cells.some(c => c.isEditable && !c.isSelected);
    }

    toggleRow(row: AssessRow) {
        const isSelected = !this.isRowSelected(row);
        row.cells
            .filter(c =>
                c.isEditable &&
                c.isSelected != isSelected)
            .forEach(c => c.isSelected = isSelected);
    }

    isMarketSelected(market: RegulatoryMarket): boolean {
        return !market.cells.some(c => c.isEditable && !c.isSelected);
    }

    toggleMarket(market: RegulatoryMarket) {
        const isSelected = !this.isMarketSelected(market);
        market.cells
            .filter(c =>
                c.isEditable &&
                c.isSelected != isSelected)
            .forEach(c => c.isSelected = isSelected);
    }

    isAllSelected(): boolean {
        return !this.details.rows.some(r => r.cells.some(x => x.isEditable && !x.isSelected));
    }

    toggleAll() {
        const isSelected = !this.isAllSelected();
        this.details.rows.forEach(r => r.cells
            .filter(c => c.isEditable && c.isSelected != isSelected)
            .forEach(c => c.isSelected = isSelected));
    }

    trackMarket(index: number, market: RegulatoryMarket): number {
        return market.id;
    }

    trackRow(index: number, row: AssessRow): number {
        return row.rpc.id;
    }

    public buildAssessmentToolTip(assessmentStatus: string) {
        if (assessmentStatus === null || assessmentStatus === undefined) {
            return  "Unassigned";
        }

        let status = assessmentStatus;
        if (status === TopicLinkStatus.Declined) {
            status = "Declined";
        }
        else if (status === TopicLinkStatus.Accepted) {
            status = "Accepted";
        }

        if (assessmentStatus === this.details.topicLinkStatus) {
            return "Already " + status;
        }
        return status;
    }

    get isEditStep(): boolean {
        return this.step == Step.edit;
    }

    get isReviewStep(): boolean {
        return this.step == Step.review;
    }

    get isApplyStep(): boolean {
        return this.step == Step.apply;
    }

    get isDoneStep(): boolean {
        return this.step == Step.done;
    }
}