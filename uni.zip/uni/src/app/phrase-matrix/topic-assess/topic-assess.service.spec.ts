import { TestBed, inject } from '@angular/core/testing';

import { TopicAssessService } from './topic-assess.service';
import { HttpService } from '../../tools/services/http.service';

class MockHttpService {
}

describe('TopicAssessService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                TopicAssessService,
                { provide: HttpService, useClass: MockHttpService }
            ]
        });
    });

    it('should be created', inject([TopicAssessService], (service: TopicAssessService) => {
        expect(service).toBeTruthy();
    }));
});