import { TopicLinkStatus } from "../../tools/constants";
import { Topic } from "../topic-tree/topic-tree.types";

export class RegulatoryMarket {
    public id: number;
    public isoCode: string;
    public description: string;
    public cells: AssessCell[] = [];
}

export interface RegulatoryProductClass {
    id: number;
    description: string;
    searchValue: string;
    isHazard: boolean;
}

export class AssessCell {
    public regulatoryMarketId: number;
    public regulatoryProductClassId: number;
    public hasConflict: boolean;
    public isEditable: boolean;
    public isDeclined: boolean;
    public isSelected: boolean;
    public isValid: boolean;
    public topicLinkStatus: TopicLinkStatus;
}

export class AssessRow {
    public rpc: RegulatoryProductClass;
    public cells: AssessCell[];
    public isSelectedRpc: boolean;
}

export class TopicAssessRequestModel {
    public topicId: number;
    public regulatoryProductClassId: number;
    public regulatoryMarketId: number;
    public topicLinkStatus: TopicLinkStatus;
}

export class TopicAssessViewModel extends TopicAssessRequestModel {
    // result
    public topic: Topic;
    public marketPath: string;
    public rpc: RegulatoryProductClass;
    public markets: RegulatoryMarket[];
    // state
    public rows: AssessRow[];
}

export class RegulatoryMarketRPC {
    public regulatoryMarketId: number;
    public regulatoryProductClassId: number;
}

export class TopicAssessImpactRequestModel extends TopicAssessRequestModel {
    public propagationTargets: RegulatoryMarketRPC[];
}

export class TopicLinkDetail {
    public regulatoryMarketDescription: string;
    public regulatoryProductClassDescription: string;
    public topicLinkStatus: TopicLinkStatus;
    public topicLinkStatusText: string;
}

export class TopicAssessImpactViewModel extends TopicAssessImpactRequestModel {
    public conflicts: TopicLinkDetail[];
    public conflictCount: number;
    public fullPropagationTargetCount: number;
    public scopeCount: number;
    public createCount: number;
    public ignoreCount: number;
}

export enum Step {
    edit,
    review,
    apply,
    done
}

export class TopicAssessPerformRequestModel extends TopicAssessImpactViewModel {
}