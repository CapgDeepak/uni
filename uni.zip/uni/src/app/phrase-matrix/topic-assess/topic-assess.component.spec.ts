import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';

import { BootstrapTemplatesModule } from './../../bootstrap-templates/bootstrap-templates.module';
import { Topic } from "../topic-tree/topic-tree.types";
import { ToolsModule } from '../../tools/tools.module';
import { TopicAssessComponent } from './topic-assess.component';
import { TopicAssessRequestModel, TopicAssessViewModel, AssessRow, RegulatoryMarket, AssessCell } from '../topic-assess/topic-assess.types';
import { TopicLinkStatus } from "../../tools/constants";
import { RouterTestingModule } from '@angular/router/testing';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TopicAssessService } from './topic-assess.service';
import { HttpService } from '../../tools/services/http.service';
import { SharedComponentsModule } from '../../shared-components/shared-components.module';

class NgbActiveModalMock { }
class HttpServiceMock { }
class TopicAssessServiceMock {
  getDetails(request: TopicAssessRequestModel)
  {
    const returnObject = new TopicAssessViewModel();
    returnObject.regulatoryProductClassId = 1;
    returnObject.regulatoryMarketId = 2;
    returnObject.topicId = 3;
    returnObject.topic = new Topic();
    returnObject.topic.description = "topic1";
    returnObject.topicLinkStatus = request.topicLinkStatus;
    const cell = new AssessCell();
    cell.isEditable = true;
    cell.isSelected = true;
    const row1 = new AssessRow();
    row1.cells = [ cell ];
    row1.rpc = { id: 1, isHazard: false, description: "rpc1", searchValue: 'blah' };
    returnObject.rpc = row1.rpc;
    const row2 = new AssessRow();
    row2.cells = [ cell ];
    row2.rpc = { id: 2, isHazard: false, description: "rpc2", searchValue: 'blah2' };

    returnObject.rows = [row1, row2];
    const market = new RegulatoryMarket();
    market.description = "marketA";
    market.id = 1;
    returnObject.markets = [market];

    return new Promise<TopicAssessViewModel>((resolve, reject) => {
      resolve(returnObject);
    });
  }
}

describe('TopicAssessComponent', () => {
  let component: TopicAssessComponent;
  let fixture: ComponentFixture<TopicAssessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        BootstrapTemplatesModule,
        FormsModule,
        RouterTestingModule,
        ToolsModule,
        SharedComponentsModule,
      ],
      declarations: [
        TopicAssessComponent
      ],
      providers: [
        { provide: NgbActiveModal, useClass: NgbActiveModalMock },
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: TopicAssessService, useClass: TopicAssessServiceMock }
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA,
        NO_ERRORS_SCHEMA
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TopicAssessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  describe('load should match snapshot with basic data - for', () => {
    it('no status', (done) => {
      component.load(1, 2, 3, null);
      setTimeout(function() {
        // Wait for 100ms for async sub-call to complete (component.load is not itself async)
        fixture.detectChanges();
        (expect(fixture) as any).toMatchSnapshot();
        done();
      }, 100);
    });

    it('Accepted status', (done) => {
      component.load(1, 2, 3, TopicLinkStatus.Accepted);
      setTimeout(function() {
        // Wait for 100ms for async sub-call to complete (component.load is not itself async)
        fixture.detectChanges();
        (expect(fixture) as any).toMatchSnapshot();
        done();
      }, 100);
    });
    it('Declined status', (done) => {
      component.load(1, 2, 3, TopicLinkStatus.Declined);
      setTimeout(function() {
        // Wait for 100ms for async sub-call to complete (component.load is not itself async)
        fixture.detectChanges();
        (expect(fixture) as any).toMatchSnapshot();
        done();
      }, 100);
    });
  });

  describe('buildAssessmentToolTip returns expected tooltip - ', () => {
    it('buildAssessmentToolTip returns expected tooltip', (done) => {
      component.load(1, 2, 3, TopicLinkStatus.Accepted);

      setTimeout(function() {
          // Wait for 100ms for async sub-call to complete (component.load is not itself async)
          expect(component.buildAssessmentToolTip("Accepted")).toEqual("Already Accepted");
          expect(component.buildAssessmentToolTip(null)).toEqual("Unassigned");
          expect(component.buildAssessmentToolTip(undefined)).toEqual("Unassigned");
          expect(component.buildAssessmentToolTip("Declined")).toEqual("Declined");
          done();
      }, 100);
    });

    it('when declined', (done) => {
      component.load(1, 2, 3, TopicLinkStatus.Declined);

      setTimeout(function() {
          // Wait for 100ms for async sub-call to complete (component.load is not itself async)
          expect(component.buildAssessmentToolTip("Accepted")).toEqual("Accepted");
          expect(component.buildAssessmentToolTip(null)).toEqual("Unassigned");
          expect(component.buildAssessmentToolTip(undefined)).toEqual("Unassigned");
          expect(component.buildAssessmentToolTip("Declined")).toEqual("Already Declined");
          done();
      }, 100);
    });

    it('when null', (done) => {
      component.load(1, 2, 3, null);

      setTimeout(function() {
          // Wait for 100ms for async sub-call to complete (component.load is not itself async)
          expect(component.buildAssessmentToolTip("Accepted")).toEqual("Accepted");
          expect(component.buildAssessmentToolTip(null)).toEqual("Unassigned");
          expect(component.buildAssessmentToolTip(undefined)).toEqual("Unassigned");
          expect(component.buildAssessmentToolTip("Declined")).toEqual("Declined");
          done();
      }, 100);
    });
  });
});