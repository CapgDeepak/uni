import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Observable, of } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { when } from 'jest-when';
import { By } from '@angular/platform-browser';

import { ToolsModule } from '../../tools/tools.module';
import { getTestPhraseData } from '../../testData';
import { PhraseChangeType, PhraseStatusId, MISSING_CHANGE_TYPE_ERROR, MISSING_CHANGE_ERROR, DetailLevels } from '../../tools/constants';
import { MISSING_TEXT_ERROR } from '../../phrase-library/add-phrase/add-phrase.component';
import { MatrixPhraseEditComponent } from './matrix-phrase-edit.component';
import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';
import { AuthorizationService } from '../../authorization/authorization.service';
import { HttpService } from '../../tools/services/http.service';
import { Permission } from '../../tools/shared-types/permissions/permission';
import { SharedComponentsModule } from '../../shared-components/shared-components.module';
import { DetailLevel } from '../../tools/common.types';
import { CacheService } from '../../tools/services/cache.service';
import { PhraseSimpleModel } from '../../tools/shared-types/phrase.types';
import { PhraseService } from '../../tools/services/phrase.service';
import { BootstrapTemplatesModule } from './../../bootstrap-templates/bootstrap-templates.module';
import { SelectedMatrixCell, EmptyMatrixPhrase } from '../phrase-matrix.types';
import { SideDialogService } from '../../tools/side-dialog/side-dialog.service';

class NgbActiveModalMock { }
class AlertDialogServiceMock { }
class SideDialogServiceMock { }
class HttpServiceMock {
  getFiltered() {
    return of([]);
  }
  getFilteredPromise(filter: { [param: string]: string | string[] }, getUrl: string): Promise<any> {
    return new Promise<any>((resolve) => {
      resolve(getTestPhraseData());
    });
  }
}

const validDetailLevels: DetailLevel[] = [
  {
    id: 0,
    description: DetailLevels.Standard
  },
  {
    id: 2,
    description: "Detailed"
  },
  {
    id: 3,
    description: "Internal RA"
  },
];
const invalidDetailLevels: DetailLevel[] = [
  {
    id: 1,
    description: "This is not a standard detail level"
  },
  {
    id: 2,
    description: "This one isn't either"
  },
  {
    id: 3,
    description: "Better luck next time"
  },
];
let detailLevels = validDetailLevels;
class CacheServiceMock {
  getDetailLevels(): Promise<DetailLevel[]> {
    return new Promise<DetailLevel[]>((resolve, reject) => {
      resolve(detailLevels);
    });
  }
}
class PhraseServiceMock {
  getPhrasesToLinkAgainst(): Observable<PhraseSimpleModel[]> {
    return of([
      {
        phraseId: 1,
        nr: 9001,
      },
      {
        phraseId: 2,
        nr: 9002,
      },
      {
        phraseId: 3,
        nr: 9003,
      }
    ]);
  }
  isDetailedPhrase() {
    return true;
  }
}
class AuthorizationServiceMock {
  checkUserHasAnyPermission = jest.fn();
  checkUserHasAnyPermissionForMarketAndProductDivision = jest.fn();
}

describe('MatrixPhraseEditComponent', () => {
  let component: MatrixPhraseEditComponent;
  let injector: TestBed;
  let fixture: ComponentFixture<MatrixPhraseEditComponent>;
  let testPhrase: EmptyMatrixPhrase;
  let authorizationService: AuthorizationService;
  let phraseService: PhraseService;
  const defaultSelectedMatrixCell = new SelectedMatrixCell();
  defaultSelectedMatrixCell.regulatoryMarketId = 2;
  defaultSelectedMatrixCell.regulatoryProductClassId = 4;
  defaultSelectedMatrixCell.topicId = 5;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        SharedComponentsModule,
        BootstrapTemplatesModule,
        FormsModule,
        ToolsModule,
        HttpClientTestingModule,
        NgbModule,
      ],
      declarations: [
        MatrixPhraseEditComponent,
      ],
      providers: [
        { provide: NgbActiveModal, useClass: NgbActiveModalMock },
        { provide: AlertDialogService, useClass: AlertDialogServiceMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
        { provide: SideDialogService, useClass: SideDialogServiceMock },
        { provide: CacheService, useClass: CacheServiceMock },
        { provide: PhraseService, useClass: PhraseServiceMock },
        { provide: HttpService, useClass: HttpServiceMock },
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
      .compileComponents();
  }));

  const buildComponent = () => {
    fixture = TestBed.createComponent(MatrixPhraseEditComponent);
    injector = getTestBed();
    phraseService = injector.get(PhraseService);
    component = fixture.componentInstance;
    component.phrase = testPhrase;
    fixture.detectChanges();
  };

  const mockAuthorizationService = (returnValue: boolean) => {
    when(authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision)
      .calledWith([Permission.AraPReFDCT_Phrases_WriteWithAssignments, Permission.AraPReFDCT_Phrases_WriteWithoutAssignments], null, testPhrase.unileverProductDivisionId)
      .mockReturnValue(returnValue);
    buildComponent(); // it is necessary to rebuild the component following a call to 'when'
  };

  const mockAuthServiceForActiveStatePermission = (returnValue: boolean) => {
    when(authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision)
      .calledWith([Permission.AraPReFDCT_Phrases_ChangeActiveState], null, testPhrase.unileverProductDivisionId)
      .mockReturnValue(returnValue);
    buildComponent(); // it is necessary to rebuild the component following a call to 'when'
  };


  beforeEach(() => {
    injector = getTestBed();
    authorizationService = injector.get(AuthorizationService);
    testPhrase = new EmptyMatrixPhrase();
    testPhrase.unileverProductDivisionId = 3;
    detailLevels = validDetailLevels;
    mockAuthorizationService(true);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot for new phrase', () => {
    component.isAdd = true;
    component.isLoading = false;
    component.phrase.regulatoryMarketId = 1;
    component.phrase.regulatoryProductClassId = 2;
    component.unileverProductDivisionId$ = of(3);

    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot for copy phrase', () => {
    component.isCopy = true;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot for inactive phrase', () => {
    component.phrase.isActive = false;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot for inactive phrase which is not new', () => {
    component.phrase.isActive = false;
    component.phrase.universalEditAllowed = true;
    component.isAdd = false;
    component.isCopy = false;
    component.isLoading = false;
    component.phrase.status = PhraseStatusId.ToBeApproved;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when loading', () => {
    component.isLoading = true;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when phrase text is not set to something new', () => {
    component.phrase.text = "New phrase";
    component.originalText = "New phrase";
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  // it('isModified should return true when original text changed', () => {
  //   component.originalText = 'fred';
  //   fixture.detectChanges();
  //   expect(component.isModified).toBeTruthy();
  // });

  it('isModified should return true when phrase type changed', () => {
    component.loadPhrase(2);
    component.phrase.phraseType = 3;
    fixture.detectChanges();
    expect(component.isModified).toBeTruthy();
  });

  it('initAddPhrase initialises things correctly for adding new phrases', () => {
    component.initAddPhrase(defaultSelectedMatrixCell, 1);
    fixture.detectChanges();
    expect(component.phrase.isActive).toBeTruthy();
    expect(component.phrase.regulatoryMarketId).toBe(2);
    expect(component.phrase.regulatoryProductClassId).toBe(4);
    expect(component.phrase.topicId).toBe(5);
    expect(component.phrase.detailLevelId).toBe(1);
    expect(component.phrase.changeType).toBe(PhraseChangeType.None);
  });

  it('isModified should return true when unitOfMeasure changed', () => {
    component.loadPhrase(2);
    component.phrase.unitOfMeasure = "bat wings";
    fixture.detectChanges();
    expect(component.isModified).toBeTruthy();
  });

  it('isModified should return false on initial load', () => {
    component.loadPhrase(2);
    fixture.detectChanges();
    expect(component.isModified).toBeFalsy();
  });

  it('isPhraseModified should clear out change type when false', () => {
    component.phrase.changeType = PhraseChangeType.Significant;
    component.loadPhrase(2);
    fixture.detectChanges();
    expect(component.isModified).toBeFalsy();
    expect(component.phrase.changeType).toBe(PhraseChangeType.None);
  });

  it('isTextModified should return false on initial load', () => {
    component.loadPhrase(2);
    fixture.detectChanges();
    expect(component.isTextModified).toBeFalsy();
  });

  it('isTextModified should return true when original text changed', () => {
    component.originalText = 'fred';
    fixture.detectChanges();
    expect(component.isTextModified).toBeTruthy();
  });

  it('needsChangeType should return false on non approved phrase without lastModifiedUser', () => {
    component.phrase = testPhrase;
    fixture.detectChanges();
    expect(component.needsChangeType).toBeFalsy();
    component.phrase.status = PhraseStatusId.ToBeApproved;
    fixture.detectChanges();
    expect(component.needsChangeType).toBeFalsy();
  });

  it('needsChangeType should return true for approved phrase with non-copied, non-new changes', () => {
    component.phrase = testPhrase;
    component.phrase.status = PhraseStatusId.Approved;
    component.originalText = "blah";
    component.isCopy = false;
    component.isAdd = false;
    component.originalPhrase.text = "text";
    fixture.detectChanges();
    expect(component.needsChangeType).toBeTruthy();
  });

  it('needsChangeType should return true for non-approved phrase with lastModifiedUser and non-copied changes', () => {
    component.phrase = testPhrase;
    component.phrase.status = PhraseStatusId.ToBeApproved;
    component.phrase.universalEditAllowed = true;
    component.originalText = "blah";
    component.originalPhrase.text = "text";
    component.isCopy = false;
    component.isAdd = false;
    expect(component.needsChangeType).toBeTruthy();
  });

  it('needsChangeType should return false for approved phrase with copied changes', () => {
    component.phrase = testPhrase;
    component.phrase.status = PhraseStatusId.Approved;
    component.originalText = "blah";
    component.isCopy = true;
    fixture.detectChanges();
    expect(component.needsChangeType).toBeFalsy();
  });

  it('needsChangeType should return false for approved phrase with added changes', () => {
    component.phrase = testPhrase;
    component.phrase.status = PhraseStatusId.Approved;
    component.originalText = "blah";
    component.isAdd = true;
    fixture.detectChanges();
    expect(component.needsChangeType).toBeFalsy();
  });

  it('needsChangeType should return false for approved phrase with no changes', () => {
    component.phrase = testPhrase;
    component.originalText = testPhrase.text;
    component.phrase.status = PhraseStatusId.Approved;
    fixture.detectChanges();
    expect(component.needsChangeType).toBeFalsy();
  });

  it('needsChangeType should return false for new phrase', () => {
    component.originalPhrase.text = null;
    fixture.detectChanges();
    expect(component.needsChangeType).toBeFalsy();
  });

  it('isSaveEnabled should return true when all data available', () => {
    component.phrase.changeType = PhraseChangeType.Minor;
    component.phrase.text = "New phrase";
    component.originalText = "old phrase";
    component.isAdd = false;
    component.phrase.detailLevelId = 1;
    fixture.detectChanges();
    expect(component.isSaveEnabled).toBeTruthy();
  });

  it('isSaveEnabled should return true for new phrases with defined text', () => {
    component.phrase.text = "New phrase";
    component.isAdd = true;
    component.phrase.detailLevelId = 1;
    fixture.detectChanges();
    expect(component.isSaveEnabled).toBeTruthy();
  });

  it('isSaveEnabled should return true when adding phrase and all data available but no change type specified', () => {
    component.phrase.changeType = PhraseChangeType.None;
    component.phrase.text = "New phrase";
    component.isAdd = true;
    component.phrase.detailLevelId = 1;
    fixture.detectChanges();
    expect(component.isSaveEnabled).toBeTruthy();
  });

  it('isSaveEnabled should return true when all data available but no change type specified, but modification made for unapproved phrase', () => {
    component.phrase.changeType = PhraseChangeType.None;
    component.originalText = 'fred';
    component.phrase.text = "New phrase";
    component.isAdd = false;
    component.phrase.detailLevelId = 1;
    fixture.detectChanges();
    expect(component.isSaveEnabled).toBeTruthy();
  });

  it('isSaveEnabled should return false when all data available but no change type specified, but modification made for approved phrase', () => {
    component.phrase.changeType = PhraseChangeType.None;
    component.originalText = 'fred';
    component.originalPhrase.text = "fred";
    component.phrase.text = "New phrase";
    component.phrase.status = PhraseStatusId.Approved;
    component.isAdd = false;
    component.phrase.detailLevelId = 1;
    fixture.detectChanges();
    expect(component.isSaveEnabled).toBeFalsy();
  });

  it('isSaveEnabled should return false when all data available but no change type specified, but no modification made', () => {
    component.phrase.changeType = PhraseChangeType.None;
    component.phrase.text = "New phrase";
    component.originalText = component.phrase.text;
    component.isAdd = false;
    component.phrase.detailLevelId = 1;
    component.originalPhrase.detailLevelId = 1;
    fixture.detectChanges();
    expect(component.isSaveEnabled).toBeFalsy();
  });

  it('isSaveEnabled should return true when all data available but no modification made but phrase active state changed', () => {
    component.phrase.text = "New phrase";
    component.originalText = component.phrase.text;
    component.phrase.isActive = true;
    component.isAdd = false;
    component.phrase.detailLevelId = 1;
    fixture.detectChanges();
    expect(component.isSaveEnabled).toBeTruthy();
  });

  it('isSaveEnabled should return false when phrase text missing', () => {
    component.phrase.text = '';
    component.isAdd = false;
    fixture.detectChanges();
    expect(component.isSaveEnabled).toBeFalsy();
  });

  it('saveButtonTooltipText should return empty when all data available', () => {
    component.originalText = component.phrase.text;
    component.phrase.text = "Some new phrase text";
    component.phrase.detailLevelId = 1;
    fixture.detectChanges();
    expect(component.saveButtonTooltipText).toBeFalsy();
  });

  it('saveButtonTooltipText should return message when phrase text missing', () => {
    component.phrase.text = '';
    fixture.detectChanges();
    expect(component.saveButtonTooltipText).toBe(MISSING_TEXT_ERROR);
  });

  it('saveButtonTooltipText should return message when data changes and no change type specified', () => {
    component.phrase.text = "New phrase";
    component.originalText = "New phrasexxxx";
    component.originalPhrase.text = "text";
    component.phrase.changeType = PhraseChangeType.None;
    component.isAdd = false;
    component.phrase.status = PhraseStatusId.Approved;
    component.phrase.detailLevelId = 1;
    fixture.detectChanges();
    expect(component.saveButtonTooltipText).toBe(MISSING_CHANGE_TYPE_ERROR);
  });

  it('saveButtonTooltipText should return message when no data changes', () => {
    component.phrase = testPhrase;
    component.phrase.text = "New phrase";
    component.originalText = "New phrase";
    component.originalPhrase = component.phrase;
    component.isAdd = false;
    fixture.detectChanges();
    expect(component.saveButtonTooltipText).toBe(MISSING_CHANGE_ERROR);
  });

  it('saveButtonTooltipText should return no message when data changes when adding or copying phrase and no change type specified', () => {
    component.phrase.text = "New phrase";
    component.originalText = "New phrasexxxx";
    component.phrase.changeType = PhraseChangeType.None;
    component.phrase.detailLevelId = 2;
    fixture.detectChanges();
    expect(component.saveButtonTooltipText).toBeFalsy();
  });

  it('windowTitle should correct title when copying', () => {
    component.isCopy = true;
    fixture.detectChanges();
    expect(component.windowTitle).toBe('Copy');
  });

  it('windowTitle should correct title when adding new phrase', () => {
    component.isAdd = true;
    fixture.detectChanges();
    expect(component.windowTitle).toBe('Add');
  });

  it('windowTitle should correct title when editing', () => {
    mockAuthServiceForActiveStatePermission(true);
    component.isAdd = false;
    component.phrase.isActive = true;
    fixture.detectChanges();
    expect(component.windowTitle).toBe('Edit');
  });

  describe('when adding a new phrase', () => {
    beforeEach(() => {
      component.isAdd = true;
      component.isCopy = false;
      component.initAddPhrase(defaultSelectedMatrixCell, null);
      fixture.detectChanges();
    });

    describe('detail level control', () => {
      it('should be empty by default', () => {
        // Assemble
        component.isLoading = false;
        fixture.detectChanges();

        // Assert
        const control = fixture.debugElement.query(By.css('#detail-level-control'));
        expect(control).toBeTruthy();
        expect(control.nativeElement.value).toBeFalsy();
        // We can assert that something is not falsy, but 0 is also falsy, and
        // so we must check that the dropdown value does not equal zero.
        expect(control.nativeElement.value).not.toEqual(0);
      });
    });

    describe('upd filter', () => {
      it('should be set up correctly', () => {
        expect(component.updNavigatorFilter.filterId1).toEqual(defaultSelectedMatrixCell.regulatoryMarketId);
        expect(component.updNavigatorFilter.filterId2).toEqual(defaultSelectedMatrixCell.regulatoryProductClassId);
      });
    });

    describe('topic filter', () => {
      it('should be set up correctly', () => {
        expect(component.topicNavigatorFilter.filterId1).toEqual(testPhrase.unileverProductDivisionId);
        expect(component.topicNavigatorFilter.filterId2).toEqual(defaultSelectedMatrixCell.regulatoryMarketId);
        expect(component.topicNavigatorFilter.filterId3).toEqual(defaultSelectedMatrixCell.regulatoryProductClassId);
      });

      it('should be updated with new UPD ID when UPD updated', () => {
        // Act
        component.onUpdNavigatorModelChange(567);

        // Assert
        expect(component.topicNavigatorFilter.filterId1).toEqual(567);
        expect(component.topicNavigatorFilter.filterId2).toEqual(defaultSelectedMatrixCell.regulatoryMarketId);
        expect(component.topicNavigatorFilter.filterId3).toEqual(defaultSelectedMatrixCell.regulatoryProductClassId);
      });
    });

    describe('detail level display', () => {
      it('should not be visible', () => {
        // Assemble
        component.isLoading = false;
        fixture.detectChanges();

        // Assert
        const display = fixture.debugElement.query(By.css('#detail-level-display'));
        expect(display).toBeFalsy();
      });
    });

    describe('save button', () => {
      it('visible and disabled when detail level not specified', () => {
        // Assemble
        component.phrase.detailLevelId = null;
        fixture.detectChanges();

        // Assert
        const button = fixture.debugElement.query(By.css('#save-button'));
        expect(button).toBeTruthy();
        expect(button.properties.disabled).toBeTruthy();
      });
    });
  });

  describe('when copying a phrase', () => {
    beforeEach(done => {
      component.isAdd = true;
      component.isCopy = true;
      component.initCopyPhrase(defaultSelectedMatrixCell, 2).then(() => {
        fixture.detectChanges();
        done();
      });
    });

    describe('upd filter', () => {
      // it('should be set up correctly', () => {
      //   expect(component.updNavigatorFilter.filterId1).toEqual(defaultSelectedMatrixCell.regulatoryMarketId);
      //   expect(component.updNavigatorFilter.filterId2).toEqual(defaultSelectedMatrixCell.regulatoryProductClassId);
      // });
    });

    describe('topic filter', () => {
      // it('should be set up correctly', () => {
      //   expect(component.topicNavigatorFilter.filterId1).toEqual(testPhrase.unileverProductDivisionId);
      //   expect(component.topicNavigatorFilter.filterId2).toEqual(defaultSelectedMatrixCell.regulatoryMarketId);
      //   expect(component.topicNavigatorFilter.filterId3).toEqual(defaultSelectedMatrixCell.regulatoryProductClassId);
      // });
    });

    // describe('detail level control', () => {
    //   it('should be visible and have value equal to existing phrase detail level by default', () => {
    //     // Assemble
    //     component.isLoading = false;
    //     fixture.detectChanges();

    //     // Assert
    //     const control = fixture.debugElement.query(By.css('#detail-level-control'));
    //     expect(control).toBeTruthy();
    //     expect(control.nativeElement.value).toEqual(component.phrase.detailLevelId.toString());
    //   });
    // });

    // describe('detail level display', () => {
    //   it('should not be visible', () => {
    //     // Assemble
    //     component.isLoading = false;
    //     fixture.detectChanges();

    //     // Assert
    //     const display = fixture.debugElement.query(By.css('#detail-level-display'));
    //     expect(display).toBeFalsy();
    //   });
    // });
  });

  describe('when editing an existing phrase', () => {
    beforeEach(done => {
      component.isAdd = false;
      component.isCopy = false;
      component.initEditPhrase(defaultSelectedMatrixCell, 2).then(() => {
        fixture.detectChanges();
        done();
      });
    });

    // describe('detail level display', () => {
    //   it('should be visible and have value equal to existing phrase detail level by default', () => {
    //     // Assemble
    //     component.isLoading = false;
    //     fixture.detectChanges();

    //     // Assert
    //     const display = fixture.debugElement.query(By.css('#detail-level-display'));
    //     expect(display).toBeTruthy();
    //     expect(display.nativeElement.textContent).toEqual(component.phraseDetailLevel);
    //   });
    // });

    // describe('detail level control', () => {
    //   it('should not be visible', () => {
    //     // Assemble
    //     component.isLoading = false;
    //     fixture.detectChanges();

    //     // Assert
    //     const control = fixture.debugElement.query(By.css('#detail-level-control'));
    //     expect(control).toBeFalsy();
    //   });
    // });
  });

  describe('when user has permission to change the active status of a phrase', () => {
    beforeEach(() => {
      mockAuthServiceForActiveStatePermission(true);
      component.isAdd = false;
      component.phrase.id = 1;
      component.phrase.universalEditAllowed = true;
      fixture.detectChanges();
    });

    it('should match snapshot', () => {
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('activeStatusTooltipText should return no message', () => {
      fixture.detectChanges();
      expect(component.activeStatusTooltipText).toBeFalsy();
    });

    it('active checkbox should be enabled', () => {
      fixture.detectChanges();
      const checkBox = fixture.debugElement.query(By.css('#phrase-active'));
      expect(checkBox.properties.disabled).toBeFalsy();
    });
  });

  describe('when user has permission to change the active status of a phrase but not for current UPD', () => {
    beforeEach(() => {
      when(authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision)
        .calledWith([Permission.AraPReFDCT_Phrases_ChangeActiveState], null, 22)
        .mockReturnValue(true);
      buildComponent(); // it is necessary to rebuild the component following a call to 'when'
      component.isAdd = false;
      component.phrase.id = 1;
      fixture.detectChanges();
    });

    it('should match snapshot', () => {
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('activeStatusTooltipText should return a message', () => {
      fixture.detectChanges();
      expect(component.activeStatusTooltipText).toBeTruthy();
    });

    it('active checkbox should not be enabled', () => {
      fixture.detectChanges();
      const checkBox = fixture.debugElement.query(By.css('#phrase-active'));
      expect(checkBox.properties.disabled).toBeTruthy();
    });
  });

  describe('when user does not have permission to change the active status of a phrase', () => {
    beforeEach(() => {
      mockAuthServiceForActiveStatePermission(false);
      component.isAdd = false;
      component.phrase.id = 1;
      fixture.detectChanges();
    });

    it('should match snapshot', () => {
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('activeStatusTooltipText should return message', () => {
      fixture.detectChanges();
      expect(component.activeStatusTooltipText).toBeTruthy();
    });

    it('active checkbox should be disabled', () => {
      fixture.detectChanges();
      const checkBox = fixture.debugElement.query(By.css('#phrase-active'));
      expect(checkBox.properties.disabled).toBeTruthy();
    });
  });

  it('windowTitle should correct title when editing inactive phrase without permission to change active status', () => {
    mockAuthServiceForActiveStatePermission(false);
    component.isAdd = false;
    component.phrase.isActive = false;
    fixture.detectChanges();
    expect(component.windowTitle).toBe('View');
  });

  it('editorBackgroundColour should be blank for active phrases', () => {
    component.isAdd = false;
    component.phrase.isActive = true;
    fixture.detectChanges();
    expect(component.editorBackgroundColour).toBe('');
  });

  it('editorBackgroundColour should be blank for new phrases', () => {
    component.isAdd = true;
    component.phrase.isActive = true;
    fixture.detectChanges();
    expect(component.editorBackgroundColour).toBe('');
  });

  it('editorBackgroundColour should be lightgrey for inactive phrases', () => {
    mockAuthorizationService(true);
    component.isAdd = false;
    component.phrase.isActive = false;
    fixture.detectChanges();
    expect(component.editorBackgroundColour).toBe('lightgrey');
  });

  it('editorBackgroundColour should be lightgrey for non-editable phrases', () => {
    mockAuthorizationService(false);
    component.isAdd = true;
    component.phrase.isActive = true;
    fixture.detectChanges();
    expect(component.editorBackgroundColour).toBe('lightgrey');
  });

  it('isPhraseEditable should return true when phrase active and not rejected and user has write access', () => {
    component.isAdd = false;
    component.phrase.isActive = true;
    component.phrase.status = PhraseStatusId.ToBeApproved;
    fixture.detectChanges();
    expect(component.isPhraseEditable).toBeTruthy();
  });

  it('isPhraseEditable should return false when phrase active and not rejected and user has no write access', () => {
    mockAuthorizationService(false);
    component.isAdd = false;
    component.phrase.isActive = true;
    component.phrase.status = PhraseStatusId.ToBeApproved;
    fixture.detectChanges();
    expect(component.isPhraseEditable).toBeFalsy();
  });

  it('isPhraseEditable should return false when phrase inactive', () => {
    component.isAdd = false;
    component.phrase.isActive = false;
    fixture.detectChanges();
    expect(component.isPhraseEditable).toBeFalsy();
  });

  it('isPhraseEditable should return true when phrase is new and user has write access', () => {
    component.isAdd = true;
    component.phrase.isActive = true;
    fixture.detectChanges();
    expect(component.isPhraseEditable).toBeTruthy();
  });

  it('isPhraseEditable should return false when phrase is new and user has no write access', () => {
    mockAuthorizationService(false);
    component.isAdd = true;
    component.phrase.isActive = false;
    fixture.detectChanges();
    expect(component.isPhraseEditable).toBeFalsy();
  });

  describe('when user does not have permission to edit phrases', () => {
    beforeEach(() => {
      mockAuthorizationService(false);
    });

    describe('isPhraseEditable', () => {
      it('should return false when phrase is new', () => {
        component.isAdd = true;
        component.phrase.isActive = true;
        fixture.detectChanges();
        expect(component.isPhraseEditable).toBeFalsy();
      });
      it('should return false when phrase active and not rejected', () => {
        component.isAdd = false;
        component.phrase.isActive = true;
        component.phrase.status = PhraseStatusId.ToBeApproved;
        fixture.detectChanges();
        expect(component.isPhraseEditable).toBeFalsy();
      });
    });
    it('shouldnt be able to edit the linked phrase', () => {
      component.isAdd = false;
      component.phrase.isActive = true;
      component.phrase.status = PhraseStatusId.ToBeApproved;
      fixture.detectChanges();
      const select = fixture.debugElement.query(By.css('#linked-phrase-control'));
      expect(select).toBeFalsy();
    });
  });

  describe("getPhrasesToLinkAgainst", () => {
    beforeEach(() => {
      jest.spyOn(phraseService, 'getPhrasesToLinkAgainst');
      fixture.detectChanges();
    });

    describe('when there is no standard detail level', () => {
      it('should not call getPhrasesToLinkAgainst', () => {
        // Assemble
        detailLevels = invalidDetailLevels;
        buildComponent();

        // Act
        component.getPhrasesToLinkAgainst(component.phrase.topicId);

        // Assert
        expect(phraseService.getPhrasesToLinkAgainst).not.toHaveBeenCalled();
      });
    });
    describe('when there is a standard detail level', () => {
      it('should call getPhrasesToLinkAgainst', () => {
        // Act
        component.getPhrasesToLinkAgainst(component.phrase.topicId);

        // Assert
        expect(phraseService.getPhrasesToLinkAgainst).toHaveBeenCalledWith(0, component.phrase.topicId);
      });
    });
  });

  describe("onTopicChange", () => {
    beforeEach(() => {
      jest.spyOn(phraseService, 'getPhrasesToLinkAgainst');
      fixture.detectChanges();
    });

    describe('when there is no standard detail level', () => {
      it('should not call getPhrasesToLinkAgainst', () => {
        // Asssemble
        detailLevels = invalidDetailLevels;
        buildComponent();

        // Act
        component.onTopicChange(component.phrase.topicId);

        // Assert
        expect(phraseService.getPhrasesToLinkAgainst).not.toHaveBeenCalled();
      });
    });

    describe('when there is a standard detail level', () => {
      it('should call getPhrasesToLinkAgainst', () => {
        // Act
        component.onTopicChange(component.phrase.topicId);

        // Assert
        expect(phraseService.getPhrasesToLinkAgainst).toHaveBeenCalledWith(0, component.phrase.topicId);
      });
    });
  });

  describe('when user has permission to edit phrases', () => {
    beforeEach(() => {
      mockAuthorizationService(true);
    });

    it('should be able to edit the linked phrase when phrase is active', () => {
      component.isAdd = false;
      component.isCopy = true;
      component.phrase.isActive = true;
      component.phrase.status = PhraseStatusId.ToBeApproved;
      component.phrase.universalEditAllowed = true;
      fixture.detectChanges();
      const select = fixture.debugElement.query(By.css('#linked-phrase-control'));
      expect(select).toBeNull();
    });

    it('should not be able to edit the linked phrase when phrase is inactive', () => {
      component.isAdd = false;
      component.phrase.isActive = false;
      component.phrase.status = PhraseStatusId.ToBeApproved;
      component.phrase.universalEditAllowed = true;
      fixture.detectChanges();
      const select = fixture.debugElement.query(By.css('#linked-phrase-control'));
      expect(select).toBeFalsy();
    });

  });

  describe('restore phrase', () => {
    it('button should be present when phrase can be restored', () => {
      component.phrase.phraseCanBeRestored = true;
      component.isAdd = false;
      component.isCopy = false;
      fixture.detectChanges();

      const button = fixture.debugElement.query(By.css('#restore-button'));
      expect(button).toBeTruthy();
    });

    it('button should not be present when phrase can not be restored', () => {
      component.phrase.phraseCanBeRestored = false;
      fixture.detectChanges();

      const button = fixture.debugElement.query(By.css('#restore-button'));
      expect(button).toBeFalsy();
    });

    it('button should not be present when phrase is copied', () => {
      component.phrase.phraseCanBeRestored = true;
      component.isCopy = true;
      fixture.detectChanges();

      const button = fixture.debugElement.query(By.css('#restore-button'));
      expect(button).toBeFalsy();
    });

    it('button should not be present when phrase is newly added', () => {
      component.phrase.phraseCanBeRestored = true;
      component.isAdd = true;
      fixture.detectChanges();

      const button = fixture.debugElement.query(By.css('#restore-button'));
      expect(button).toBeFalsy();
    });
  });

  describe('onTextContentChange', () => {
    it('sets originalText if it is null', () => {
      component.originalText = null;
      const event = { html: 'newText' };
      component.onTextContentChange(event);
      fixture.detectChanges();
      expect(component.originalText).toBe(event.html);
    });

    it('does not set originalText if it is not null', () => {
      component.originalText = 'blah';
      const event = { html: 'newText' };
      component.onTextContentChange(event);
      fixture.detectChanges();
      expect(component.originalText).toBe('blah');
    });
  });
});