import { Component, OnInit, Output } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Observable, of } from 'rxjs';

import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';
import { ConfirmationDialogService } from '../../shared-components/confirmation-dialog/confirmation-dialog.service';
import { SelectedMatrixCell, MatrixPhrase, EmptyMatrixPhrase } from '../phrase-matrix.types';
import { PhraseStatusId, PhraseChangeType, UrlEndpoint, MISSING_CHANGE_TYPE_ERROR, MISSING_CHANGE_ERROR, MISSING_DETAIL_LEVEL_ERROR, PhraseStatus, DetailLevels } from '../../tools/constants';
import { SideDialogService } from '../../tools/side-dialog/side-dialog.service';
import { QuillSettingsService } from '../../tools/services/quill-settings.service';
import { HttpService } from '../../tools/services/http.service';
import { Permission } from '../../tools/shared-types/permissions/permission';
import { AuthorizationService } from '../../authorization/authorization.service';
import { MISSING_TEXT_ERROR } from '../../phrase-library/add-phrase/add-phrase.component';
import { CacheService } from '../../tools/services/cache.service';
import { DetailLevel, FilterObject } from '../../tools/common.types';
import { PhraseWhereUsedComponent } from '../../shared-components/phrase-where-used/phrase-where-used.component';
import { Phrase } from '../../phrase-library/phrase-library.types';
import { EditPhraseService } from '../../phrase-library/edit-phrase/edit-phrase.service';
import { PhraseService } from '../../tools/services/phrase.service';
import { PhraseSimpleModel } from '../../tools/shared-types/phrase.types';

@Component({
  selector: 'app-matrix-phrase-edit',
  templateUrl: './matrix-phrase-edit.component.html',
  styleUrls: ['./matrix-phrase-edit.component.scss']
})
export class MatrixPhraseEditComponent implements OnInit {
  @Output() public quillmodules;
  @Output() public quillformats;
  public detailLevels: DetailLevel[] = [];
  public standardDetailLevelId: number;
  public phrasesToLinkAgainst$: Observable<PhraseSimpleModel[]>;
  public linkedGenericPhraseId$: Observable<number | null>;
  public phrasesToLinkAgainstLoading$: Observable<boolean>;
  public topicsLoading: boolean = false;
  public topicPathList: any[] = [];
  newTopicId: number;
  originalTopicId: any;
  isTopicsLoaded: boolean = true;
  constructor(
    public activeModal: NgbActiveModal,
    private alertDialogService: AlertDialogService,
    private confirmationDialogService: ConfirmationDialogService,
    private sideDialogService: SideDialogService,
    private httpService: HttpService,
    quillSettings: QuillSettingsService,
    private authorizationService: AuthorizationService,
    private cacheService: CacheService,
    private editPhraseService: EditPhraseService,
    private phraseService: PhraseService,
  ) {
    this.quillformats = quillSettings.quillformats;
    this.quillmodules = quillSettings.quillmodules;
    this.isLoading = true;
    this.cacheService.getDetailLevels()
      .then((detailLevels: DetailLevel[]) => {
        this.detailLevels = detailLevels;
        const standardDetailLevel = this.detailLevels.filter(dl => dl.description == DetailLevels.Standard)[0];
        this.standardDetailLevelId = standardDetailLevel ? this.detailLevels.filter(dl => dl.description == DetailLevels.Standard)[0].id : null;
      })
      .catch((err: any) => {
        console.log('err', err);
      });
  }

  originalPhrase: MatrixPhrase = new EmptyMatrixPhrase();

  public phrase: MatrixPhrase = new EmptyMatrixPhrase();
  public isAdd: boolean = true; // note, copied phrases also have the 'isAdd' flag set to true
  public isCopy: boolean = false;
  public selectedMatrixCell: SelectedMatrixCell = new SelectedMatrixCell();
  public isLoading: boolean = true;
  originalText: string = null;

  private editPhrasePermissions: Permission[] = [
    Permission.AraPReFDCT_Phrases_WriteWithAssignments,
    Permission.AraPReFDCT_Phrases_WriteWithoutAssignments,
  ];
  private changeActiveStatePermissions: Permission[] = [Permission.AraPReFDCT_Phrases_ChangeActiveState];
  public updNavigatorFilter: FilterObject = new FilterObject();
  public topicNavigatorFilter: FilterObject = new FilterObject();

  ngOnInit() {
  }

  initAddPhrase(selectedCell: SelectedMatrixCell, detailLevelId: number | null) {
    this.setupComponent(true, selectedCell, false);
    this.setupPhraseAndFilterWithMatrixSelection();
    this.phrase.detailLevelId = detailLevelId;
    this.phrase.changeType = PhraseChangeType.None;
    this.phrase.isActive = true;
    console.log(this.phrase);
    this.cacheService.getDetailLevels().then((detailLevels: DetailLevel[]) => {
      this.detailLevels = detailLevels;
      this.getPhrasesToLinkAgainst(this.phrase.topicId);
    })
      .catch((err: any) => {
        console.log('err', err);
      });
    const url = 'api/TopicNavigator/AllItems';
    this.httpService.getFiltered({ topicId: this.phrase.topicId.toString() }, url).subscribe((res: any) => {
      this.phrase.topicPath = [...res];
      console.log(this.phrase.topicPath);
      this.isLoading = false;
      this.topicsLoading = false;
    }, (err: any) => this.isLoading = false);

  }

  initCopyPhrase(selectedCell: SelectedMatrixCell, phraseId: number) {
    this.setupComponent(false, selectedCell, true);
    return this.loadPhraseAndLinkablePhrases(phraseId);
  }

  initEditPhrase(selectedCell: SelectedMatrixCell, phraseId: number): Promise<void> {
    this.setupComponent(false, selectedCell, false);
    return this.loadPhraseAndLinkablePhrases(phraseId);
  }

  private setupComponent(isAdd: boolean, selectedCell: SelectedMatrixCell, isCopy: boolean) {
    this.isLoading = true;
    this.isAdd = isAdd;
    this.isCopy = isCopy;
    this.selectedMatrixCell = selectedCell;
  }

  private loadPhraseAndLinkablePhrases(phraseId: number): Promise<void> {
    return this.loadPhrase(phraseId).then(() => {
      this.getPhrasesToLinkAgainst(this.phrase.topicId);
      console.log(this.phrase);
    });
  }

  getPhrasesToLinkAgainst(topicId: any) {
    if (!this.standardDetailLevelId && this.standardDetailLevelId != 0) {
      this.isLoading = false;
      return;
    }
    this.phraseService.getPhrasesToLinkAgainst(this.standardDetailLevelId, topicId)
      .subscribe((res: PhraseSimpleModel[]) => {
        this.phrasesToLinkAgainst$ = of(res);
        this.linkedGenericPhraseId$ = of(this.phrase.linkedGenericPhraseId);
        this.isLoading = false;
      }, (err: any) => this.isLoading = false);
  }

  get isShowingOldAndNewText(): boolean {
    return (!this.isPhraseApproved && !this.isCopy && !this.isAdd);
  }

  onTextContentChange(event: any) {
    // retrieve the phrase text after it has been initially bound to the quill editor
    // - as this process can change the content - especially if it includes html elements
    if (this.originalText == null) {
      this.originalText = event.html;
      this.phrase.text = this.originalText; // note, this avoids change types showing up due to quill reformatting the text content
    } else if (this.isShowingOldAndNewText) {
      this.phrase.text = event.html;
    }
  }

  unileverProductDivisionId$: Observable<number>;

  /**
   * Emit an observable so that the topic navigator can pick up the latest UPD ID,
   * which it uses the retrieve the list of all available topics.
   */
  onUpdNavigatorModelChange(updId: any) {
    this.unileverProductDivisionId$ = of(updId);

    // When the UPD is updated, we want to update the topic navigator filter with this
    // new ID, without wiping the other filter fields in the object.
    this.topicsLoading = true;
    this.topicNavigatorFilter = {
      ...this.topicNavigatorFilter,
      filterId1: updId,
    };
  }

  public getTopicNavigatorFilterObject(): FilterObject {
    return {
      filterId1: this.phrase.unileverProductDivisionId,
    };
  }

  get editorBackgroundColour(): string {
    return this.isPhraseEditable ? '' : 'lightgrey';
  }

  get isTextModified(): boolean {
    return this.originalText != null && this.phrase.text != this.originalText;
  }

  get needsChangeType(): boolean {
    return ((this.phrase.status != PhraseStatusId.ToBeApproved || this.phrase.universalEditAllowed) &&
      this.isModified &&
      this.hasPhraseModificationThatRequiresChangeTypeOccured &&
      this.originalPhrase.text &&
      !this.isAdd && !this.isCopy);
  }

  get phraseDetailLevelSpecified(): boolean {
    return !!(this.phrase.detailLevelId || this.phrase.detailLevelId == 0);
  }

  get phraseDetailLevel(): string {
    const detailLevel = this.detailLevels.find(dl => dl.id == this.phrase.detailLevelId);
    return detailLevel && detailLevel.description || "";
  }

  get isModified(): boolean {
    if (this.hasPhraseModificationThatRequiresChangeTypeOccured ||
      this.hasPhraseModificationThatDoesNotRequireChangeTypeOccured) {
      return true;
    }

    this.phrase.changeType = PhraseChangeType.None; // reset this to ensure old selections are preserved
    return false;
  }

  private get hasPhraseModificationThatRequiresChangeTypeOccured() {
    return this.isTextModified ||
      (this.phrase.phraseType != this.originalPhrase.phraseType) ||
      (this.phrase.unitOfMeasure != this.originalPhrase.unitOfMeasure);
  }

  private get hasPhraseModificationThatDoesNotRequireChangeTypeOccured() {
    return this.phrase.linkedGenericPhraseId != this.originalPhrase.linkedGenericPhraseId;
  }

  get isSaveEnabled(): boolean {
    return this.phrase.text &&
      ((this.isAdd && this.phraseDetailLevelSpecified) ||
        !this.isAdd && (
          (this.isModified && (!this.needsChangeType || this.phrase.changeType != PhraseChangeType.None)) ||
          (!this.isModified && (this.hasActiveStatusChanged ||
            this.hasDetailLevelChanged ||
            this.hasLinkedPhraseIdsChanged ||
            this.hasTopicChanged)))
      );
  }

  get hasTopicChanged() {
    return this.phrase.topicId != this.originalPhrase.topicId;
  }

  get hasLinkedPhraseIdsChanged() {
    return (this.phrase.linkedSpecificPhraseNrs.length != this.originalPhrase.linkedSpecificPhraseNrs.length) ||
      JSON.stringify(this.phrase.linkedSpecificPhraseNrs.sort()) != JSON.stringify(this.originalPhrase.linkedSpecificPhraseNrs.sort());
  }

  get hasDetailLevelChanged() {
    return this.phrase.detailLevelId != this.originalPhrase.detailLevelId;
  }

  get hasActiveStatusChanged(): boolean {
    return this.phrase.isActive != this.originalPhrase.isActive;
  }

  get isPhraseEditable(): boolean {
    return this.editPhraseAllowed && (this.isAdd || this.phrase.isActive);
  }

  public get isComponentEditable() {
    return (!this.isPhraseApproved && this.phrase.universalEditAllowed && this.originalPhrase.text === null) || this.isCopy || this.isAdd;
  }

  public get saveButtonTooltipText(): string {
    let tooltip = '';
    if (!this.isSaveEnabled) {
      if (!this.phrase.text) {
        tooltip = MISSING_TEXT_ERROR;
      } else if (!this.isModified) {
        tooltip = MISSING_CHANGE_ERROR;
      } else if (!this.isAdd &&
        this.hasPhraseModificationThatRequiresChangeTypeOccured &&
        (this.phrase.changeType == PhraseChangeType.None)) {
        tooltip = MISSING_CHANGE_TYPE_ERROR;
      } else if (this.isAdd && !this.phraseDetailLevelSpecified) {
        tooltip = MISSING_DETAIL_LEVEL_ERROR;
      }
    }
    return tooltip;
  }

  public get activeStatusTooltipText(): string {
    return this.changeActiveStatusAllowed ? '' : "You do not have permission to change the Active status of this phrase.";
  }

  public get windowTitle(): string {
    if (this.isCopy) {
      return 'Copy';
    } else if (this.isAdd) {
      return 'Add';
    } else if (this.isPhraseFixedAsInactive) {
      return 'View';
    }
    return 'Edit';
  }

  get isPhraseFixedAsInactive(): boolean {
    return !this.phrase.isActive && !this.changeActiveStatusAllowed;
  }

  get showRemarks(): boolean {
    return this.phrase.status == PhraseStatusId.Rejected ||
      (this.phrase.status == PhraseStatusId.ToBeApproved && !!this.phrase.rejectedPhraseRemarks);
  }

  loadPhrase(phraseId: number): Promise<void> {
    this.isLoading = true;
    if (this.isAdd) {
      this.topicsLoading = true;
    }
    return this.httpService.getFilteredPromise({ phraseId: phraseId.toString(), isCopy: this.isCopy.toString() }, UrlEndpoint.PhraseMatrix_LoadPhrase).then(result => {
      if (this.isCopy) {
        result.text = result.newText || result.text;
        result.id = 0;
        this.setupPhraseAndFilterWithMatrixSelection();
      }
      this.phrase = result;
      this.newTopicId = this.phrase.topicId;
      this.originalTopicId = JSON.parse(JSON.stringify(this.phrase.topicId));
      this.phrase.changeType = PhraseChangeType.None;
      this.isLoading = false;
      this.topicsLoading = false;
      this.originalPhrase = { ...result };
    })
      .catch((err: any) => {
        this.isLoading = false;
        this.topicsLoading = false;
      });
  }

  private setupPhraseAndFilterWithMatrixSelection() {
    this.phrase.regulatoryMarketId = this.selectedMatrixCell.regulatoryMarketId;
    this.phrase.regulatoryProductClassId = this.selectedMatrixCell.regulatoryProductClassId;
    this.phrase.topicId = this.selectedMatrixCell.topicId;
    this.updNavigatorFilter = { // need to set these as new objects to get the related tree navigators to pick up the change
      filterId1: this.phrase.regulatoryMarketId,
      filterId2: this.phrase.regulatoryProductClassId,
      filterId3: this.phrase.topicId
    };
    this.topicNavigatorFilter = {
      filterId1: this.phrase.unileverProductDivisionId,
      filterId2: this.phrase.regulatoryMarketId,
      filterId3: this.phrase.regulatoryProductClassId
    };
  }

  savePhrase() {
    this.updatePhraseDetails();
    this.phrase.phraseTextChanged = this.isTextModified;
    const url = this.isAdd || this.isCopy ? UrlEndpoint.PhraseMatrix_AddSavePhrase : UrlEndpoint.PhraseMatrix_EditSavePhrase;
    this.isLoading = true;
    this.httpService.postContentPromise(this.phrase, url).then(result => {
      this.isLoading = false;
      // note, it is legitimate for this to return nothing - specifically when a save has been done changing nothing
      if (result) {
        if (result.success != false) {
          if (result.needsConfirmation) {
            this.confirmationDialogService.question("Question", result.message)
              .then(resultData => {
                if (resultData) {
                  this.phrase.confirmed = true;
                  this.savePhrase();
                }
              }).catch(error => this.handlePhraseSaveError(error));
          } else {
            const phraseId = this.isAdd ? result : this.phrase.id;
            this.activeModal.close(phraseId);
          }
        }
        else {
          this.alertDialogService.alert('Error', result.message);
        }
      }
      else {
        this.activeModal.close(this.phrase.id);
      }
    }).catch(error => this.handlePhraseSaveError(error));
  }

  updatePhraseDetails() {
    this.phrase.linkedSpecificPhraseIds = this.phrase.linkedSpecificPhraseNrs == null ? [] : this.phrase.linkedSpecificPhraseNrs;
    this.phrase.detailLevelDescription = this.detailLevels.filter(x => x.id == this.phrase.detailLevelId)[0].description;
    // if detail level is not detailed, pass empty for linked phrase list
    if (this.phrase.detailLevelId != 2) {
      this.phrase.linkedSpecificPhraseIds = [];
      this.phrase.linkedSpecificPhraseNrs = [];
    }
    if (this.newTopicId != undefined && this.newTopicId != null && this.newTopicId != 0){
        this.phrase.topicId = this.newTopicId;
    }

  }
  private handlePhraseSaveError(error: any): void {
    console.error("Error when saving phrase", error);
    this.isLoading = false;
  }

  phraseWhereUsed() {
    if (this.phrase.id > 0) {
      this.isLoading = true;
      this.editPhraseService.loadPhraseData(this.phrase.id, false).then((result: Phrase) => {
        const modalRef = this.sideDialogService.open(PhraseWhereUsedComponent);
        modalRef.componentInstance.phrase = result;
        this.isLoading = false;
      });
    }
  }

  public get editPhraseAllowed(): boolean {
    return !this.isPhraseFixedAsInactive &&
      this.authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision(this.editPhrasePermissions, null, this.phrase.unileverProductDivisionId);
  }

  public get changeActiveStatusAllowed(): boolean {
    return this.authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision(this.changeActiveStatePermissions, null, this.phrase.unileverProductDivisionId)
      && (this.isPhraseApproved || this.phrase.universalEditAllowed);
  }

  public get isPhraseApproved(): boolean {
    return this.phrase.statusText == PhraseStatus.Approved;
  }

  /**
   * Returns true if the phrase is Detailed. False otherwise.
   */
  public get isDetailedPhrase() {
    return this.phraseService.isDetailedPhrase(this.phrase.detailLevelId, this.detailLevels);
  }

  /**
   * Handles the change of a linked phrase ID.
   */
  public linkedPhraseIdChange(linkedPhraseId: any) {
    this.phrase.linkedGenericPhraseId = null;
    this.phrase.linkedSpecificPhraseIds = (linkedPhraseId != null && linkedPhraseId.length > 0) ? [...linkedPhraseId.map(function (a) { return a.phraseId; })] : null;
    this.phrase.linkedSpecificPhraseNrs = (linkedPhraseId != null && linkedPhraseId.length > 0) ? [...linkedPhraseId.map(function (a) { return a.phraseId; })] : null;
    if (this.phrase.linkedSpecificPhraseNrs == null) {
      this.phrase.linkedSpecificPhraseNrs = [];
      this.phrase.linkedSpecificPhraseIds = [];
    }
  }

  restorePhrase(isConfirmed: boolean = false) {
    this.isLoading = true;
    this.editPhraseService.restorePhrase(this.phrase.id, isConfirmed)
      .then(result => {
        if (result.success) {
          if (result.needsConfirmation) {
            this.confirmationDialogService.question("Question", result.message)
              .then(resultData => {
                if (resultData) {
                  this.restorePhrase(resultData);
                }
              }).catch((error) => this.isLoading = false);
          } else {
            this.activeModal.close(result);
          }
        } else {
          this.alertDialogService.alert('Error', result.message);
        }
        this.isLoading = false;
      })
      .catch(error => {
        this.isLoading = false;
      });
  }
  onLoadTopics(event) {
    this.isTopicsLoaded = event;
    }
  /**
   * Handle a  user selecting a new topic in the tree navigator (any level).
   * Retrieves the appropriate phrases to link against based on the new topic Id.
   * @param topicId the ID of the topic for which to retrieve the phrases to link against.
   */
  public onTopicChange(topicId: number | null) {
    this.newTopicId = topicId;
    this.topicsLoading = false;
    this.linkedGenericPhraseId$ = of(null);
    this.phrasesToLinkAgainstLoading$ = of(true);
    if (!this.standardDetailLevelId && this.standardDetailLevelId != 0) {
      return;
    }
    this.phraseService.getPhrasesToLinkAgainst(this.standardDetailLevelId, topicId)
      .subscribe((res: PhraseSimpleModel[]) => {
        this.phrasesToLinkAgainst$ = of(res);
        this.phrasesToLinkAgainstLoading$ = of(false);
        // Check if already selected linked phrase id exists in updated phrasesToLinkAgainst list
        // If exists, keep the selection, else remove it
        const phrasesToLink = res;
        let linkedSpecificPhrases = this.phrase.linkedSpecificPhraseNrs;
        this.phrase.linkedSpecificPhraseNrs = null;
        this.phrase.linkedSpecificPhraseIds = null;
        linkedSpecificPhrases.forEach(linkedPhrase => {
          if (phrasesToLink.filter(x => x.phraseId == linkedPhrase).length < 1) {
            linkedSpecificPhrases = linkedSpecificPhrases.filter(y => y != linkedPhrase);
          }
        });
        this.phrase.linkedSpecificPhraseNrs = this.newTopicId == this.originalTopicId ? this.originalPhrase.linkedSpecificPhraseNrs : linkedSpecificPhrases;
        this.phrase.linkedSpecificPhraseIds = this.newTopicId == this.originalTopicId ? this.originalPhrase.linkedSpecificPhraseNrs : linkedSpecificPhrases;
      }, (err: any) => {
        this.phrasesToLinkAgainst$ = of([]);
        this.phrasesToLinkAgainstLoading$ = of(false);
      });
  }

  identify(index, item) {
    return item.label;
 }
}