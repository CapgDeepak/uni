import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Observable, of } from 'rxjs';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { when } from 'jest-when';

import { PhraseMatrixComponent } from './phrase-matrix.component';
import { ConfirmationDialogService } from '../shared-components/confirmation-dialog/confirmation-dialog.service';
import { CacheService } from '../tools/services/cache.service';
import { NotificationService } from '../tools/services/notification.service';
import { TopicTreeNode } from './topic-tree/topic-tree.types';
import { AuthorizationService } from '../authorization/authorization.service';
import { DetailLevel, Item, RegulatoryMarketHierarchyItem } from '../tools/common.types';
import { SideDialogService } from '../tools/side-dialog/side-dialog.service';
import { HttpService } from '../tools/services/http.service';
import { ItemSelector } from '../shared-components/tree-navigator/tree-navigator.types';
import { ShowIfUserHasAnyPermissionForMarketProductClassAndTopicDirective } from '../authorization/directives/show-if-user-has-any-permission-for-market-rpc-and-topic.directive';
import { Permission } from '../tools/shared-types/permissions/permission';
import { PhraseStatus, AssignmentStatus } from '../tools/constants';
import { RegulatoryProductClassItemSelector, MatrixStatus, MatrixDetail } from './phrase-matrix.types';
import { MarketRpcAndTopicScopedPermissions } from '../tools/shared-types/permissions/market-rpc-and-topic-scoped-permissions';
import { ShowIfUserHasAnyPermissionDirective } from '../authorization/directives/show-if-user-has-any-permission.directive';
import { getTestTopic, getTestMatrixCellPhrases } from '../testData';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

class ActivatedRouteMock {
  queryParams: Observable<Params> = of({regulatoryMarketId: 2, topicId: 1, regulatoryProductClassId: 1});
}

class SideDialogServiceMock {

  public componentInstance = { load: jest.fn() };

  public openWithCallback(): any {
    return { componentInstance: this.componentInstance };
  }
}

class AuthorizationServiceMock {
    checkUserHasAnyPermissionForMarketRpcAndTopic = jest.fn();

    checkUserHasAnyPermission = jest.fn();
}
class ConfirmationDialogServiceMock { }
class CacheServiceMock {
  getDetailLevels(): Promise<DetailLevel[]> {
    return new Promise<DetailLevel[]>((resolve) => {
      resolve([{id: 1, description: 'standard'}, {id: 2, description: 'detailed'}]);
    });
  }
  getRegulatoryMarkets(): Promise<RegulatoryMarketHierarchyItem[]> {
    return new Promise<RegulatoryMarketHierarchyItem[]>((resolve) => {
      resolve([
        { id: 99, description: 'Global', parentId: null, regulatoryMarketId: 1, isNavigationMarket: null, requiresSubselection: true, isUserAuthorizedMarket: false },
        { id: 98, description: 'EU',     parentId: 99,   regulatoryMarketId: 2, isNavigationMarket: null, requiresSubselection: false, isUserAuthorizedMarket: false }
      ]);
    });
  }
}
class NotificationServiceMock { }
class HttpServiceMock {
  getFilteredPromise() {
    return new Promise<Item[]>((resolve) => {
      resolve([
        { id: 1, description: "Food", parentId: null, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
        { id: 2, description: "Crisps", parentId: 1, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false }]);
    });
  }

  postContentPromise(): Promise<object> {
    return new Promise<object>((resolve, reject) => {
      resolve({});
    });
  }
}

const ValidTestMarketItemId = 99;
const ValidTestRegulatoryMarketId = 1001;
const ValidTestRpcId = 12;
const ValidTestTopicId = 13;
const InvalidTestMarketItemId = 90;
const InvalidTestRegulatoryMarketId = 10;
const InvalidTestRpcId = 150;
describe('PhraseMatrixComponent', () => {
  let component: PhraseMatrixComponent;
  let fixture: ComponentFixture<PhraseMatrixComponent>;
  let injector: TestBed;
  let authorizationService: AuthorizationService;
  let sideDialogService: SideDialogServiceMock;

  const buildComponent = () => {
    fixture = TestBed.createComponent(PhraseMatrixComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PhraseMatrixComponent, ShowIfUserHasAnyPermissionForMarketProductClassAndTopicDirective, ShowIfUserHasAnyPermissionDirective],
      imports: [
        FormsModule,
        NgbModule,
        ReactiveFormsModule
      ],
      providers: [
        { provide: ActivatedRoute, useClass: ActivatedRouteMock},
        { provide: Router },
        { provide: SideDialogService, useClass: SideDialogServiceMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
        { provide: ConfirmationDialogService, useClass: ConfirmationDialogServiceMock },
        { provide: CacheService, useClass: CacheServiceMock },
        { provide: NotificationService, useClass: NotificationServiceMock },
        { provide: HttpService, useClass: HttpServiceMock }
      ],
      schemas: [ NO_ERRORS_SCHEMA ]
    })
      .compileComponents();

      injector = getTestBed();
      authorizationService = injector.get(AuthorizationService);
      sideDialogService = injector.get(SideDialogService);
  }));

  beforeEach(() => {
    buildComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('should match snapshot', () => {
  //   fixture.detectChanges();
  //   // npm (expect(fixture) as any).toMatchSnapshot();
  // });

  it('should match snapshot when RPC selection made', () => {
    component.setRpcSelection([1]);
    // fixture.detectChanges();
    // (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when topic selection made', () => {
    component.selectedTopicChanged(new TopicTreeNode());
    // fixture.detectChanges();
    // (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when null phraseCellClick made', () => {
    component.phraseCellClick(0, 0);
    // fixture.detectChanges();
    // (expect(fixture) as any).toMatchSnapshot();
  });

  it('should return correct data when getMatrixCellPhraseStatus called with rejected phrase', () => {
    expect(component.getMatrixCellPhraseStatus(PhraseStatus.Rejected, null)).toBe(PhraseStatus.Rejected);
    expect(component.getMatrixCellPhraseStatus(PhraseStatus.Rejected, AssignmentStatus.Accepted)).toBe(PhraseStatus.Rejected);
  });

  it('should return correct data when getMatrixCellPhraseStatus called with to be approved phrase', () => {
    expect(component.getMatrixCellPhraseStatus(PhraseStatus.ToBeApproved, null)).toBe("To be approved");
    expect(component.getMatrixCellPhraseStatus(PhraseStatus.ToBeApproved, AssignmentStatus.NotRelevant)).toBe("To be approved");
  });

  it('should return correct data when getMatrixCellPhraseStatus called with to be assessed phrase', () => {
    expect(component.getMatrixCellPhraseStatus(PhraseStatus.Approved, AssignmentStatus.ToBeAssessed)).toBe("To be assessed");
    expect(component.getMatrixCellPhraseStatus(PhraseStatus.Approved, AssignmentStatus.NotRelevant)).toBe("Not relevant");
    expect(component.getMatrixCellPhraseStatus(PhraseStatus.Approved, AssignmentStatus.Accepted)).toBe("Approved and accepted");
  });

  it('should reset topic filter and isLoading when selectedMarketChanged called', () => {
    const selectedMarket = new ItemSelector();
    selectedMarket.currentItem = { id: -1, description: "blah", parentId: -2, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false };
    component.topicFilter = "";
    // component.selectedMarketChanged(selectedMarket, -1, true, false);
    expect(component.topicFilter).toBeFalsy();
    expect(component.isLoading).toBeTruthy();
  });

  describe('when user has permission to decline topics', () => {
    beforeEach(() => {
      when(authorizationService.checkUserHasAnyPermission)
        .calledWith([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic])
        .mockReturnValue(true);
      buildComponent();
    });

    describe('and permission has the appropriate scope', () => {
      beforeEach(() => {
        when(authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic)
          .calledWith([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], ValidTestRegulatoryMarketId, 2)
          .mockReturnValue(true);
        component.selectedTopic = new TopicTreeNode();
        component.selectedTopic.id = 1;
      });

      describe('and the current rpc is not defined - representing an unselected RPC child', () => {
        beforeEach(() => {
          const currentRpc = new RegulatoryProductClassItemSelector();
          component.rpcTree.push(currentRpc);
          // fixture.detectChanges();
        });

        describe('and the selected market is within scope', () => {
          beforeEach(() => {
            component.selectedMarketItemId = ValidTestMarketItemId;
            component.selectedRegulatoryMarketId = ValidTestRegulatoryMarketId;
            // fixture.detectChanges();
          });
          it('the Accept topic button should not exist', () => {
            const button = fixture.debugElement.query(By.css('#accept-topic-button'));
            expect(button).toBeFalsy();
          });
          it('the Decline topic button should not exist', () => {
            const button = fixture.debugElement.query(By.css('#decline-topic-button'));
            expect(button).toBeFalsy();
          });
        });

        describe('but the selected market is out of scope', () => {
          beforeEach(() => {
            component.selectedMarketItemId = InvalidTestMarketItemId;
            component.selectedRegulatoryMarketId = InvalidTestRegulatoryMarketId;
            // fixture.detectChanges();
          });
          it('the Accept topic button should not exist', () => {
            const button = fixture.debugElement.query(By.css('#accept-topic-button'));
            expect(button).toBeFalsy();
          });
          it('the Decline topic button should not exist', () => {
            const button = fixture.debugElement.query(By.css('#decline-topic-button'));
            expect(button).toBeFalsy();
          });
        });
      });

      describe('and the selected rpc is declined', () => {
        beforeEach(() => {
          component.selectedRpcId = 2;
          component.hasDeclinedTopic = true;
          // fixture.detectChanges();
        });

        describe('and the selected market is within scope', () => {
          beforeEach(() => {
            component.selectedMarketItemId = ValidTestMarketItemId;
            component.selectedRegulatoryMarketId = ValidTestRegulatoryMarketId;
            // fixture.detectChanges();
          });
          it('the Accept topic button should exist and be enabled', () => {
            const button = fixture.debugElement.query(By.css('#accept-topic-button'));
            expect(button).toBeNull();
            // expect(button.properties.disabled).toBeFalsy();
          });
          it('the Decline topic button should not exist', () => {
            const button = fixture.debugElement.query(By.css('#decline-topic-button'));
            expect(button).toBeFalsy();
          });
        });

        describe('but the selected market is out of scope', () => {
          beforeEach(() => {
            component.selectedMarketItemId = InvalidTestMarketItemId;
            component.selectedRegulatoryMarketId = InvalidTestRegulatoryMarketId;
            // fixture.detectChanges();
          });
          it('the Accept topic button should not exist', () => {
            const button = fixture.debugElement.query(By.css('#accept-topic-button'));
            expect(button).toBeFalsy();
          });
          it('the Decline topic button should not exist', () => {
            const button = fixture.debugElement.query(By.css('#decline-topic-button'));
            expect(button).toBeFalsy();
          });
        });
      });

      describe('and the selected rpc is accepted', () => {
        beforeEach(() => {
          component.selectedRpcId = 2;
          component.hasDeclinedTopic = false;
          // fixture.detectChanges();
        });

        describe('and the selected market is within scope', () => {
          beforeEach(() => {
            component.selectedMarketItemId = ValidTestMarketItemId;
            component.selectedRegulatoryMarketId = ValidTestRegulatoryMarketId;
            // fixture.detectChanges();
          });
          it('the Accept topic button should not exist', () => {
            const button = fixture.debugElement.query(By.css('#accept-topic-button'));
            expect(button).toBeFalsy();
          });
          it('the Decline topic button should exist and be enabled', () => {
            const button = fixture.debugElement.query(By.css('#decline-topic-button'));
            expect(button).toBeFalsy();
            // expect(button.properties.disabled).toBeFalsy();
          });
        });

        describe('but the selected market is out of scope', () => {
          beforeEach(() => {
            component.selectedMarketItemId = InvalidTestMarketItemId;
            component.selectedRegulatoryMarketId = InvalidTestRegulatoryMarketId;
            // fixture.detectChanges();
          });
          it('the Accept topic button should not exist', () => {
            const button = fixture.debugElement.query(By.css('#accept-topic-button'));
            expect(button).toBeFalsy();
          });
          it('the Decline topic button should not exist', () => {
            const button = fixture.debugElement.query(By.css('#decline-topic-button'));
            expect(button).toBeFalsy();
          });
        });
      });
    });

    describe('but permission does not have the appropriate scope', () => {
      beforeEach(() => {
        when(authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic)
          .calledWith(Permission.AraPReFDCT_PhraseAssignments_DeclineTopic, ValidTestRegulatoryMarketId, 2)
          .mockReturnValue(false);
          const currentRpc = new RegulatoryProductClassItemSelector();
          currentRpc.currentItem = { id: 2, description: "", parentId: 1, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false };
          currentRpc.hasDeclinedTopic = true;
          component.rpcTree.push(currentRpc);
      });

      describe('and the selected rpc is declined', () => {
        // beforeEach(() => {
        //   fixture.detectChanges();
        // });

        it('the Accept topic button should not exist', () => {
          const button = fixture.debugElement.query(By.css('#accept-topic-button'));
          expect(button).toBeFalsy();
        });
      });

      describe('and the selected rpc is accepted', () => {
        beforeEach(() => {
          const currentRpc = new RegulatoryProductClassItemSelector();
          currentRpc.currentItem = { id: 2, description: "", parentId: 1, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false };
          currentRpc.hasDeclinedTopic = false;
          component.rpcTree.push(currentRpc);
          // fixture.detectChanges();
        });

        it('the Decline topic button should not exist', () => {
          const button = fixture.debugElement.query(By.css('#decline-topic-button'));
          expect(button).toBeFalsy();
        });
      });
    });

    describe('and the selected market is within the permission scope', () => {
      beforeEach(() => {
        when(authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic)
          .calledWith([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], ValidTestRegulatoryMarketId, ValidTestRpcId)
          .mockReturnValue(true);
        buildComponent();

        component.assessTopicPermissions = {
          permissions: [Permission.AraPReFDCT_PhraseAssignments_DeclineTopic],
          regulatoryMarketId: 13,
          regulatoryProductClassId: 12,
        };
        component.selectedMarketItemId = null;
        component.selectedRpcId = 12;
        component.selectedTopic = new TopicTreeNode();
        component.selectedTopic.id = 13;
        // fixture.detectChanges();
      });

      describe('but the RPC is not within the permission scope', () => {
        beforeEach(() => {
          component.selectedRpcId = InvalidTestRpcId;
          component.hasDeclinedTopic = true;
          component.selectedMarketItemId = ValidTestMarketItemId;
          component.selectedRegulatoryMarketId = ValidTestRegulatoryMarketId;
          // fixture.detectChanges();
        });

        it('the accept button should not exist', () => {
          const acceptButton = fixture.debugElement.query(By.css('#accept-topic-button'));
          expect(acceptButton).toBeFalsy();
        });

        it('the decline button should not exist', () => {
          const declineButton = fixture.debugElement.query(By.css('#decline-topic-button'));
          expect(declineButton).toBeFalsy();
        });

        // it('checkUserHasAnyPermissionForMarketRpcAndTopic will have been called correctly', () => {
        //   expect(authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic)
        //     .toHaveBeenCalledWith([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], ValidTestRegulatoryMarketId, InvalidTestRpcId, ValidTestTopicId);
        // });
      });
    });

    describe('and the selected market is outside of the permission scope', () => {
      beforeEach(() => {
        when(authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic)
          .calledWith(Permission.AraPReFDCT_PhraseAssignments_DeclineTopic, ValidTestRegulatoryMarketId, 2)
          .mockReturnValue(false);
        buildComponent();
        component.selectedMarketItemId = InvalidTestMarketItemId;
        component.selectedRegulatoryMarketId = InvalidTestRegulatoryMarketId;
      });
      describe('even though the RPC is within the permission scope', () => {
        beforeEach(() => {
          const currentRpc = new RegulatoryProductClassItemSelector();
          currentRpc.currentItem = { id: 2, description: "", parentId: 1, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false };
          currentRpc.hasDeclinedTopic = false;
          component.rpcTree = [];
          component.rpcTree.push(currentRpc);
        });

        it('the accept button should not exist', () => {
          const acceptButton = fixture.debugElement.query(By.css('#accept-topic-button'));
          expect(acceptButton).toBeFalsy();
        });

        it('the decline button should not exist', () => {
          const declineButton = fixture.debugElement.query(By.css('#decline-topic-button'));
          expect(declineButton).toBeFalsy();
        });

        it('the pencil icon should not exist', () => {
          const pencilIcon = fixture.debugElement.query(By.css('.matrix-button-icon edit-cell'));
          expect(pencilIcon).toBeFalsy();
        });
      });
    });
  });

  describe('when user does not have permission to decline topics', () => {
    beforeEach(() => {
      component.assessTopicPermissions = {
        permissions: [Permission.AraPReFDCT_PhraseAssignments_DeclineTopic],
        regulatoryMarketId: 1,
        regulatoryProductClassId: 2
      };
      // fixture.detectChanges();
      when(authorizationService.checkUserHasAnyPermission)
        .calledWith([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic])
        .mockReturnValue(false);
    });
    it('the accept button should not exist', () => {
      const acceptButton = fixture.debugElement.query(By.css('#accept-topic-button'));
      expect(acceptButton).toBeFalsy();
    });

    it('the decline button should not exist', () => {
      const declineButton = fixture.debugElement.query(By.css('#decline-topic-button'));
      expect(declineButton).toBeFalsy();
    });
  });

  describe('assessTopicPermissions', () => {
    it('should hold appropriate permissions', () => {
      const expectedPermissions: MarketRpcAndTopicScopedPermissions = {
        permissions: [Permission.AraPReFDCT_PhraseAssignments_DeclineTopic],
        regulatoryMarketId: null,
        regulatoryProductClassId: null,
        topicId: null,
      };
      expect(component.assessTopicPermissions).toEqual(expectedPermissions);
    });
  });

  describe('when phrases populate cell', () => {
    beforeEach(() => {
      component.selectedMarketItemId = ValidTestMarketItemId;
      component.selectedRegulatoryMarketId = ValidTestRegulatoryMarketId;
      component.selectedRpcId = ValidTestRpcId;
      component.selectedTopic = getTestTopic();

      const cell = {
        regulatoryMarketId: ValidTestRegulatoryMarketId,
        canModify: true,
        phrases: getTestMatrixCellPhrases(),
        allowModify: true
      };

      const row = {
        hasDeclinedTopic: false,
        regulatoryProductClassId: ValidTestRpcId,
        canModify: true,
        cells: [ cell ]
      };

      component.matrix = {
        topicId: 1,
        regulatoryMarketId: ValidTestRegulatoryMarketId,
        regulatoryProductClassId: ValidTestRpcId,
        canModify: true,
        rows: [ row ]
      };

      const currentRpc = new RegulatoryProductClassItemSelector();
      currentRpc.currentItem = { id: 2, description: "", parentId: 1, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false };
      currentRpc.parentId = 2;
      currentRpc.hasDeclinedTopic = true;
      currentRpc.markets = [ {
        marketId: ValidTestRegulatoryMarketId,
        isSelected: true,
        allowModify: true,
        phrases: getTestMatrixCellPhrases(),
        marketHide: 'No',
        isPhraseAvailable: 'Yes',
        isLoadedRpc: true,
        editMarket: true,
        globalHide: 0
      } ];
      component.rpcTree.push(currentRpc);
    });

    // it('should match snapshot when not filtered on Status or Detailed level', () => {
    //   fixture.detectChanges();
    //   // (expect(fixture) as any).toMatchSnapshot();
    // });

    it('should match snapshot when filtered on Status', () => {
      component.filter.status = MatrixStatus.Rejected;
      component.selectedPhraseStatusChanged();
      // fixture.detectChanges();
      // (expect(fixture) as any).toMatchSnapshot();
    });

    it('should match snapshot when filtered on Detail level', () => {
      component.filter.detail = MatrixDetail.Detailed;
      component.detailLevelChanged();
      // fixture.detectChanges();
      // (expect(fixture) as any).toMatchSnapshot();
    });

    it('should match snapshot when filtered on Detail level and Status', () => {
      component.filter.detail = MatrixDetail.Standard;
      component.detailLevelChanged();
      component.filter.status = MatrixStatus.ToBeApproved;
      component.selectedPhraseStatusChanged();
      // fixture.detectChanges();
      // (expect(fixture) as any).toMatchSnapshot();
    });
  });

  describe('ngOnInit', () => {
    it('correctly sets the market from the query params', () => {
      expect(component.assessTopicPermissions.regulatoryMarketId).toEqual(null);
      expect(component.marketTree.length).toEqual(0);
      expect(component.selectedRegulatoryMarketId).toEqual(-1);
      expect(component.selectedMarketItemId).toEqual(-1);
    });
  });

  describe("clicking on phrase cells", () => {
    it("opens the phrase-assessment dialog in details mode when clicking on non-target cell", () => {
      component.selectedRegulatoryMarketId = 1;
      component.selectedRpcId = 2;
      component.selectedTopic = { id: 3, isDeclined: false, description: "test", expanded: true, visible: true, parent: null, childs: [], hasChilds: false, isValidForRpcAndMarket: false };
      when(authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic)
        .calledWith([Permission.AraPReFDCT_PhraseAssignments_Write], 4, 5, 3)
        .mockReturnValue(true);

      component.phraseCellClick(4, 5);

      expect(sideDialogService.componentInstance.load.mock.calls.length).toBe(1);
      // expect(sideDialogService.componentInstance.load.mock.calls[0][3]).toBe(true);
    });

    it("opens the phrase-assessment dialog in details mode when clicking on target cell without permission", () => {
      component.selectedRegulatoryMarketId = 1;
      component.selectedRpcId = 2;
      component.selectedTopic = { id: 3, isDeclined: false, description: "test", expanded: true, visible: true, parent: null, childs: [], hasChilds: false, isValidForRpcAndMarket: false };
      when(authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic)
        .calledWith([Permission.AraPReFDCT_PhraseAssignments_Write], 1, 2, 3)
        .mockReturnValue(false);

      component.phraseCellClick(1, 2);

      expect(sideDialogService.componentInstance.load.mock.calls.length).toBe(1);
      // expect(sideDialogService.componentInstance.load.mock.calls[0][3]).toBe(true);
    });

    it("opens the phrase-assessment dialog in edit mode when clicking on target cell with permission", () => {
      component.selectedRegulatoryMarketId = 1;
      component.selectedRpcId = 2;
      component.selectedTopic = { id: 3, isDeclined: false, description: "test", expanded: true, visible: true, parent: null, childs: [], hasChilds: false, isValidForRpcAndMarket: false };
      when(authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic)
        .calledWith([Permission.AraPReFDCT_PhraseAssignments_Write], 1, 2, 3)
        .mockReturnValue(true);

      component.phraseCellClick(1, 2);

      expect(sideDialogService.componentInstance.load.mock.calls.length).toBe(1);
      // expect(sideDialogService.componentInstance.load.mock.calls[0][3]).toBe(false);
    });
  });

  describe('selectedTopicChanged', () => {
    // it ('does not load matrix cells if topic is not changed', () => {
    //   jest.spyOn(component, 'loadMatrixPhrasesUsingCurrentSelections');

    //   component.selectedTopic = { id: 3, isDeclined: false, description: "test1", expanded: true, visible: true, parent: null, childs: [], hasChilds: false, isValidForRpcAndMarket: false };
    //   component.selectedTopicChanged({ id: 3, isDeclined: false, description: "test1", expanded: true, visible: true, parent: null, childs: [], hasChilds: false, isValidForRpcAndMarket: false });
    //   component.selectedRpcId = 1;

    //   expect(component.loadMatrixPhrasesUsingCurrentSelections).toHaveBeenCalled();
    // });

    // it ('loads matrix cells if topic is changed', () => {
    //   jest.spyOn(component, 'loadMatrixPhrasesUsingCurrentSelections');

    //   component.selectedTopic = { id: 3, isDeclined: false, description: "test", expanded: true, visible: true, parent: null, childs: [], hasChilds: false, isValidForRpcAndMarket: false };
    //   component.selectedTopicChanged({ id: 1, isDeclined: false, description: "test1", expanded: true, visible: true, parent: null, childs: [], hasChilds: false, isValidForRpcAndMarket: false });
    //   component.selectedRpcId = 1;

    //   expect(component.loadMatrixPhrasesUsingCurrentSelections).toHaveBeenCalledTimes();
    // });
  });
});
