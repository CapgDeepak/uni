import { TestBed, inject} from '@angular/core/testing';

import { PhraseAssessService } from './phrase-assess.service';
import { HttpService } from '../../tools/services/http.service';

class HttpServiceMock {}

describe('PhraseAssessService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: HttpService, useClass: HttpServiceMock },
                PhraseAssessService
            ]
        });
    });

    it('should be created', inject([PhraseAssessService], (service: PhraseAssessService) => {
        expect(service).toBeTruthy();
    }));
});
