import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { PhraseAssessService } from './phrase-assess.service';
import { PhraseAssessRequestModel, PhraseAssessViewModel, AssessCell, RegulatoryMarket, AssessRow, PhraseAssessImpactRequestModel, PhraseAssessImpactViewModel,
    Step, RegulatoryMarketRPC, PhraseAssessPerformRequestModel, PhraseAssignment, TabularInputValueData } from './phrase-assess.types';
import { AssignmentStatus, UrlEndpoint } from '../../tools/constants';
import { HttpService } from '../../tools/services/http.service';
import { TabularInput } from './phrase-assess.types';
import { isNullOrWhitespace } from '../../tools/utils';

@Component({
    selector: 'app-phrase-assess',
    templateUrl: './phrase-assess.component.html',
    styleUrls: ['./phrase-assess.component.scss']
})
export class PhraseAssessComponent {
    details: PhraseAssessViewModel;
    impact: PhraseAssessImpactViewModel;
    private _isLoading: boolean = true;
    private step: Step = Step.edit;
    private _localSource: string;
    showAccepted: boolean = true;
    constructor(
        public activeModal: NgbActiveModal,
        private phraseAssessService: PhraseAssessService,
        private httpService: HttpService) {
    }

    load(
        sourceRegulatoryProductClassId: number,
        destinationRegulatoryProductClassId: number,
        topicId: number,
        sourceMarketId: number,
        destinationMarketId: number,
        phraseId: number,
        detailLevelId: number | null,
        assignmentStatus: AssignmentStatus,
        tabularInputData: TabularInputValueData,
        localSource: string) {
        this.step = Step.edit;
        this._isLoading = true;
        this._localSource = localSource;

        const request = new PhraseAssessRequestModel();
        request.sourceRegulatoryProductClassId = sourceRegulatoryProductClassId;
        request.destinationRegulatoryProductClassId = destinationRegulatoryProductClassId;
        request.topicId = topicId;
        request.sourceMarketId = sourceMarketId;
        request.destinationMarketId = destinationMarketId;
        request.phraseId = phraseId;
        request.detailLevelId = detailLevelId;
        request.phraseAssignmentStatus = assignmentStatus;
        request.tabularInputData = tabularInputData;

        this.phraseAssessService.getDetails(request).then(result => {
            this.details = result;
            this.details.tabularInputData = request.tabularInputData;
            this._isLoading = false;
        }).catch(error => {
            this._isLoading = false;
            this.details = null;
            this.cancel();
        });
    }

    completeAssessment() {
        this._isLoading = true;
        this.step = Step.apply;

        const request = new PhraseAssessPerformRequestModel();

        // original request
        request.sourceRegulatoryProductClassId = this.details.sourceRegulatoryProductClassId;
        request.destinationRegulatoryProductClassId = this.details.destinationRegulatoryProductClassId;
        request.topicId = this.details.topicId;
        request.sourceMarketId = this.details.sourceMarketId;
        request.destinationMarketId = this.details.destinationMarketId;
        request.phraseId = this.details.phraseId;
        request.phraseAssignmentStatus = this.details.phraseAssignmentStatus;
        request.detailLevelId = this.details.detailLevelId;
        request.tabularInputData = this.details.tabularInputData;
        request.localSource = this._localSource;

        // include impact
        if (this.impact != null) {
            request.childAssignmentConflicts = this.impact.childAssignmentConflicts;
            request.childAssignmentConflictCount = this.impact.childAssignmentConflictCount;
            request.fullPropagationTargetCount = this.impact.fullPropagationTargetCount;
            request.childAssignmentCount = this.impact.childAssignmentCount;
            request.childAssignmentCreateCount = this.impact.childAssignmentCreateCount;
            request.childAssignmentIgnoreCount = this.impact.childAssignmentIgnoreCount;
            request.propagationTargets = this.impact.propagationTargets;
        }
        else {
            request.childAssignmentConflicts = [];
            request.propagationTargets = [];
        }

        this.httpService.postContentPromise(request, UrlEndpoint.PhraseMatrix_PerformPhraseAssess).then(() => {
            this._isLoading = false;
            this.step = Step.done;
            localStorage.setItem("changeTabular", '');
        }).catch(() => {
            this._isLoading = false;
        });
    }

    back() {
        this.step = Step.edit;
    }

    next() {
        this._isLoading = true;
        const request = new PhraseAssessImpactRequestModel();
        request.sourceRegulatoryProductClassId = this.details.sourceRegulatoryProductClassId;
        request.destinationRegulatoryProductClassId = this.details.destinationRegulatoryProductClassId;
        request.topicId = this.details.topicId;
        request.sourceMarketId = this.details.sourceMarketId;
        request.destinationMarketId = this.details.destinationMarketId;
        request.phraseId = this.details.phraseId;
        request.detailLevelId = this.details.detailLevelId;
        request.phraseAssignmentStatus = this.details.phraseAssignmentStatus;
        request.propagationTargets = this.details.rows
            .map(r => r.cells.filter(c => c.isEditable && c.isSelected))
            .reduce((a, b) => a.concat(b))
            .map(r => {
                const selection = new RegulatoryMarketRPC();
                selection.regulatoryMarketId = r.regulatoryMarketId;
                selection.regulatoryProductClassId = r.regulatoryProductClassId;
                return selection;
            });

        this.httpService.postContentPromise(request, UrlEndpoint.PhraseMatrix_GetPhraseAssessImpact).then(result => {
            this.impact = result;
            this._isLoading = false;
            this.step = Step.review;
            const acceptedItem = result.childAssignmentConflicts.find(c => c.status === "Accepted");
            this.showAccepted = acceptedItem != undefined && Object.keys(acceptedItem).length != 0 ? true : false;
        }).catch(() => {
            this.impact = null;
            this._isLoading = false;
        });
    }

    close() {
        this.activeModal.close(true);
    }

    cancel() {
        this.activeModal.close(false);
    }

    get title(): string {
        return this.isReady
            ? `Assess phrase as ${this.assessmentLabel}`
            : 'Loading assessment...';
    }

    get assessmentLabel(): string {
        return !this.isReady
            ? ''
            : this.details.phraseAssignmentStatus == AssignmentStatus.Accepted
            ? 'accepted'
            : 'not relevant';
    }

    get isLoading(): boolean {
        return this._isLoading;
    }

    get isReady(): boolean {
        return !this.isLoading && this.details != null;
    }

    get canPropagate(): boolean {
        // we can propogate when loaded and at least a single market-rpc is editable
        return this.isReady && this.details.rows.some(r => r.cells.some(c => c.isEditable));
    }

    get propagationCount(): number | null {
        return this.canPropagate
            ? this.details.rows
                .map(r => r.cells.filter(c => c.isEditable && c.isSelected).length)
                .reduce((a, b) => a + b)
            : null;
    }

    isRowSelected(row: AssessRow) {
        return !row.cells.some(c => c.isEditable && !c.isSelected) && row.cells.some(c => c.isEditable);
    }

    toggleRow(row: AssessRow) {
        const isSelected = !this.isRowSelected(row);
        row.cells
            .filter(c =>
                c.isEditable &&
                c.isSelected != isSelected)
            .forEach(c => c.isSelected = isSelected);
    }

    isMarketSelected(market: RegulatoryMarket): boolean {
        return !market.cells.some(c => c.isEditable && !c.isSelected) && market.cells.some(c => c.isEditable);
    }

    toggleMarket(market: RegulatoryMarket) {
        const isSelected = !this.isMarketSelected(market);
        market.cells
            .filter(c =>
                c.isEditable &&
                c.isSelected != isSelected)
            .forEach(c => c.isSelected = isSelected);
    }

    isAllSelected(): boolean {
        return !this.details.rows.some(r => r.cells.some(x => x.isEditable && !x.isSelected));
    }

    toggleAll() {
        const isSelected = !this.isAllSelected();
        this.details.rows.forEach(r => r.cells
            .filter(c => c.isEditable && c.isSelected != isSelected)
            .forEach(c => c.isSelected = isSelected));
    }

    checkBoxVisible(cellAssignment: PhraseAssignment, assessViewModel: PhraseAssessViewModel): boolean {
        if (cellAssignment === null) {
            return true;
        }

        if (this._localSource && cellAssignment.source !== this._localSource) {
            return true;
        }

        if (cellAssignment.tabularInput === null) {
            return cellAssignment.status !== assessViewModel.phraseAssignmentStatus;
        }

        else {
            // Beware inputValue1 and inputValue2 are declared as numbers, but in the view model may be set to strings by the DDL.
            return cellAssignment.status !== assessViewModel.phraseAssignmentStatus ||
                cellAssignment.tabularInput.isRange !== assessViewModel.tabularInputData.isRange ||
                this.areStringsDifferent(cellAssignment.tabularInput.inputValue1, assessViewModel.tabularInputData.inputValue1) ||
                this.areStringsDifferent(cellAssignment.tabularInput.unitOfMeasure, assessViewModel.tabularInputData.unitOfMeasure) ||
                this.areStringsDifferent(this.toString(cellAssignment.tabularInput.inputValueType1), this.toString(assessViewModel.tabularInputData.inputValueType1)) ||
                (assessViewModel.tabularInputData.isRange &&
                    this.areStringsDifferent(cellAssignment.tabularInput.inputValue2, assessViewModel.tabularInputData.inputValue2)) ||
                (assessViewModel.tabularInputData.isRange &&
                    this.areStringsDifferent(this.toString(cellAssignment.tabularInput.inputValueType2), this.toString(assessViewModel.tabularInputData.inputValueType2)));
        }
    }

    areStringsDifferent(text1: string, text2: string): boolean {
        if (isNullOrWhitespace(text1) && isNullOrWhitespace(text2)) {
            return false;
        }
        else {
            return text1 !== text2;
        }
    }

    tabularInputValueChanged(cellAssignment: PhraseAssignment, assessViewModel: PhraseAssessViewModel): boolean {
        if (cellAssignment === null || cellAssignment === undefined ||
            cellAssignment.tabularInput === null || cellAssignment.tabularInput === undefined) {
            return false;
        }
        else {
            return this.isTabularInputValueDifferent(cellAssignment.tabularInput, assessViewModel.tabularInputData);
        }
    }

    toString(value: any): string {
        if (value === null || value === undefined) {
            return null;
        }

        return String(value);
    }

    isTabularInputValueDifferent(existingTabularInput: TabularInput, newTabularInput: TabularInputValueData): boolean {
        if (isNullOrWhitespace(existingTabularInput.inputValue1) ||
            (existingTabularInput.isRange && isNullOrWhitespace(existingTabularInput.inputValue2))) {
            return false;
        }

        // Beware inputValue1 and inputValue2 are declared as numbers, but in the view model may be set to strings by the DDL.
        return existingTabularInput.isRange !== newTabularInput.isRange ||
            this.areStringsDifferent(this.toString(existingTabularInput.inputValueType1), this.toString(newTabularInput.inputValueType1)) ||
            this.areStringsDifferent(existingTabularInput.inputValue1, newTabularInput.inputValue1) ||
            this.areStringsDifferent(existingTabularInput.unitOfMeasure, newTabularInput.unitOfMeasure) ||
            (newTabularInput.isRange && this.areStringsDifferent(existingTabularInput.inputValue2, newTabularInput.inputValue2)) ||
            (newTabularInput.isRange
                && this.areStringsDifferent(this.toString(existingTabularInput.inputValueType2), this.toString(newTabularInput.inputValueType2)));
    }

    get showTabularInputChangedLegend(): boolean {
        return this.details.rows.some(t => t.cells.some(c => (this.tabularInputValueChanged(c.assignment, this.details) && !c.isDeclined)));
    }

    trackMarket(index: number, market: RegulatoryMarket): number {
        return market.id;
    }

    trackRow(index: number, row: AssessRow): number {
        return row.rpc.id;
    }

    trackCell(index: number, cell: AssessCell): number {
        return cell.assignment != null ? cell.assignment.id : cell.regulatoryMarketId;
    }

    public buildAssignmentToolTip(assignmentStatus: string) {
        if (assignmentStatus === null || assignmentStatus === undefined) {
            return  "Unassigned";
        }

        let status = assignmentStatus;
        if (status === AssignmentStatus.NotRelevant) {
            status = "Not Relevant";
        }
        else if (status === AssignmentStatus.ToBeAssessed) {
            status = "To Be Assessed";
        }

        if (assignmentStatus === this.details.phraseAssignmentStatus) {
            return "Already " + status;
        }

        return status;
    }

    get isEditStep(): boolean {
        return this.step == Step.edit;
    }

    get isReviewStep(): boolean {
        return this.step == Step.review;
    }

    get isApplyStep(): boolean {
        return this.step == Step.apply;
    }

    get isDoneStep(): boolean {
        return this.step == Step.done;
    }
    change = [{ "RPC": "", "change": false}];
  public  checkChangesTabula(RPC, change: boolean){
    const data = this.change.find(x => x.RPC === RPC);
    if (data == undefined && change){
      this.change.push({
        "RPC": RPC,
        "change": change
      });
    }
  }
  public exclamation(RPC){
      const  data = this.change.find(x => x.RPC === RPC && x.change == true);
      return data != undefined ? true : false;
  }
}