import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { BootstrapTemplatesModule } from './../../bootstrap-templates/bootstrap-templates.module';

import { ToolsModule } from '../../tools/tools.module';
import { HttpService } from '../../tools/services/http.service';
import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';
import { AssignmentStatus } from '../../tools/constants';
import { getTestListPhrase } from '../../testData';
import { Topic } from "../topic-tree/topic-tree.types";
import { PhraseAssessComponent } from './phrase-assess.component';
import { PhraseAssessService } from './phrase-assess.service';
import { PhraseAssessViewModel, AssessRow, RegulatoryMarket, AssessCell, PhraseAssignment, TabularInput } from './phrase-assess.types';
import { SharedComponentsModule } from '../../shared-components/shared-components.module';

class NgbActiveModalMock { }
class AlertDialogServiceMock { }
class PhraseAssessServiceMock {
  getDetails()
  {
    const model = new PhraseAssessViewModel();
    model.phraseId = 1;
    model.destinationMarketId = 2;
    model.destinationRegulatoryProductClassId = 3;
    model.topicId = 4;
    model.topic = new Topic();
    model.topic.description = "topic1";
    model.phraseAssignmentStatus = AssignmentStatus.Accepted;

    model.phrase = { ...getTestListPhrase(), phraseType: "1" };

    const cell = new AssessCell();
    cell.isEditable = true;
    cell.isSelected = true;
    cell.assignment = { id: 1, regulatoryMarketId: 2, regulatoryProductClassId: 3,
      status: AssignmentStatus.ToBeAssessed, hasValue: false, source: "", tabularInput: null };

    const row1 = new AssessRow();
    row1.cells = [ cell ];
    row1.rpc = { id: 1, isHazard: false, description: "rpc1", searchValue: 'blah' };
    model.sourceRpc = row1.rpc;
    const row2 = new AssessRow();
    row2.cells = [ cell ];
    row2.rpc = { id: 2, isHazard: false, description: "rpc2", searchValue: 'blah2' };
    model.destinationRpc = row2.rpc;

    model.rows = [row1, row2];
    const market = new RegulatoryMarket();
    market.description = "marketA";
    market.id = 1;
    model.markets = [market];

    return new Promise<PhraseAssessViewModel>((resolve, reject) => {
      resolve(model);
    });
  }
}

class HttpServiceMock { }



describe('PhraseAssessComponent', () => {
  let component: PhraseAssessComponent;
  let fixture: ComponentFixture<PhraseAssessComponent>;

  const cellEditableSelected = new AssessCell();
  cellEditableSelected.isEditable = true;
  cellEditableSelected.isSelected = true;

  const cellNotEditable = new AssessCell();
  cellNotEditable.isEditable = false;
  cellNotEditable.isSelected = false;

  const cellEditableNotSelected = new AssessCell();
  cellEditableNotSelected.isEditable = true;
  cellEditableNotSelected.isSelected = false;

  const cellRPCDeclined = new AssessCell();
  cellRPCDeclined.isEditable = false;
  cellRPCDeclined.isSelected = false;
  cellRPCDeclined.isDeclined = true;

  const cellRPCOkay = new AssessCell();
  cellRPCOkay.isEditable = true;
  cellRPCOkay.isSelected = false;
  cellRPCOkay.isDeclined = false;

  let existingTabInput: TabularInput = createTabularInput();
  let cellAssignment: PhraseAssignment = createPhraseAssignment();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        BootstrapTemplatesModule,
        FormsModule,
        RouterTestingModule,
        ToolsModule,
        SharedComponentsModule,
      ],
      declarations: [
        PhraseAssessComponent
      ],
      providers: [
        { provide: NgbActiveModal, useClass: NgbActiveModalMock },
        { provide: AlertDialogService, useClass: AlertDialogServiceMock },
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: PhraseAssessService, useClass: PhraseAssessServiceMock }
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA,
        NO_ERRORS_SCHEMA
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhraseAssessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot with basic data', (done) => {
    component.load(1, 2, 3, 4, 5, 6, 7, AssignmentStatus.Accepted, null, "local");
    setTimeout(function() {
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
      done();
    }, 100);
  });

  it ('should match snapshot with tabular input data', (done) => {
    const tabularInputData = {
      isRange: false,
      inputValueType1: 1,
      inputValue1: "34",
      inputValueType2: null,
      inputValue2: null,
      unitOfMeasure: "g"
    };
    component.load(1, 2, 3, 4, 5, 6, 7, AssignmentStatus.Accepted, tabularInputData, "local");
    setTimeout(function() {
      fixture.detectChanges();
      (expect(fixture) as any).toMatchSnapshot();
      done();
    }, 100);
  });

  it('buildAssignmentToolTip returns expected tooltip', (done) => {
    component.load(1, 2, 3, 4, 5, 6, 7, AssignmentStatus.Accepted, null, "local");

    setTimeout(function() {
        // Wait for 100ms for async sub-call to complete (component.load is not itself async)
        expect(component.buildAssignmentToolTip("Accepted")).toEqual("Already Accepted");
        expect(component.buildAssignmentToolTip(null)).toEqual("Unassigned");
        expect(component.buildAssignmentToolTip("NotAccepted")).toEqual("NotAccepted");
        expect(component.buildAssignmentToolTip("NotRelevant")).toEqual("Not Relevant");
        expect(component.buildAssignmentToolTip("ToBeAssessed")).toEqual("To Be Assessed");
        done();
    }, 100);
  });

  it('should return false when one RPC is declined', () => {

    const marketWithDeclinedCell = new RegulatoryMarket();
    marketWithDeclinedCell.cells = [cellRPCDeclined , cellRPCOkay];

    expect(component.isMarketSelected(marketWithDeclinedCell)).toBeFalsy();
  });

  it('should return false when all RPCs are declined', () => {
    const marketWithDeclinedCell = new RegulatoryMarket();
    marketWithDeclinedCell.cells = [cellRPCDeclined , cellRPCDeclined];

    expect(component.isMarketSelected(marketWithDeclinedCell)).toBeFalsy();
  });

  it('should return true when isRowSelected called with editable cells all selected', () => {
    const rowWithSelectedEditableCell = new AssessRow();
    rowWithSelectedEditableCell.cells = [ cellEditableSelected ];

    const rowWithSelectedOrNotEditableCells = new AssessRow();
    rowWithSelectedOrNotEditableCells.cells = [ cellEditableSelected, cellNotEditable ];

    expect(component.isRowSelected(rowWithSelectedEditableCell)).toBeTruthy();
    expect(component.isRowSelected(rowWithSelectedOrNotEditableCells)).toBeTruthy();
  });

  it('should return false when isRowSelected called without any editable not selected cells', () => {
    const rowWithEditableUnselectedCell = new AssessRow();
    rowWithEditableUnselectedCell.cells = [ cellEditableNotSelected ];

    const rowWithoutEditableCells = new AssessRow();
    rowWithoutEditableCells.cells = [ cellNotEditable, cellNotEditable ];

    const rowWithEditableUnselectedCells = new AssessRow();
    rowWithEditableUnselectedCells.cells = [ cellEditableSelected, cellNotEditable, cellEditableNotSelected ];

    expect(component.isRowSelected(rowWithEditableUnselectedCell)).toBeFalsy();
    expect(component.isRowSelected(rowWithoutEditableCells)).toBeFalsy();
    expect(component.isRowSelected(rowWithEditableUnselectedCells)).toBeFalsy();
  });

  describe('isTabularInputValueDifferent method', () => {
    beforeEach(() => {
      existingTabInput = createTabularInput();
    });

    it('should return true for different inputValue1', () => {
      const newTabInput =
      {
        inputValue1 : '12',
        inputValue2 : '100',
        isRange : true,
        inputValueType1 : null,
        inputValueType2 : null,
        unitOfMeasure : null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return true for different isRange', () => {
      const newTabInput =
      {
        inputValue1 : '25',
        inputValue2 : '100',
        isRange : false,
        inputValueType1 : null,
        inputValueType2 : null,
        unitOfMeasure : null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return true for different inputValue2 given isRange true', () => {
      const newTabInput =
      {
        inputValue1 : '25',
        inputValue2 : '101',
        isRange : true,
        inputValueType1 : null,
        inputValueType2 : null,
        unitOfMeasure : null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return true for different input value 1, input value 2 and isRange', () => {
      const newTabInput =
      {
        inputValue1 : '12',
        inputValue2 : '101',
        isRange : false,
        inputValueType1 : null,
        inputValueType2 : null,
        unitOfMeasure : null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return false for the same input value 1, input value 2 and isRange', () => {
      const newTabInput =
      {
        inputValue1 : '25',
        inputValue2 : '100',
        isRange : true,
        inputValueType1 : null,
        inputValueType2 : null,
        unitOfMeasure : null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return false for same input value 1, but different input value 2 when isRange is false and the same', () => {
      existingTabInput.isRange = false;
      const newTabInput =
      {
        inputValue1 : '25',
        inputValue2 : '101',
        isRange : false,
        inputValueType1 : null,
        inputValueType2 : null,
        unitOfMeasure : null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return false for a null input value 1 of the existing assignment', () => {
      existingTabInput.inputValue1 = null;
      existingTabInput.isRange = false;
      const newTabInput = {
        inputValue1 : '25',
        inputValue2 : '101',
        isRange : false,
        inputValueType1 : null,
        inputValueType2 : null,
        unitOfMeasure : null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return false for a blank input value 1 of the existing assignment', () => {
      existingTabInput.inputValue1 = '';
      existingTabInput.isRange = false;
      const newTabInput = {
        inputValue1 : '25',
        inputValue2 : '101',
        isRange : false,
        inputValueType1 : null,
        inputValueType2 : null,
        unitOfMeasure : null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return false for a null input value 2 of the existing assignment given isRange is true', () => {
      existingTabInput.inputValue2 = null;
      const newTabInput = {
        inputValue1 : '25',
        inputValue2 : '101',
        isRange : true,
        inputValueType1 : null,
        inputValueType2 : null,
        unitOfMeasure : null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return false for a blank input value 2 of the existing assignment given isRange is true', () => {
      existingTabInput.inputValue2 = '';
      const newTabInput = {
        inputValue1 : '25',
        inputValue2 : '101',
        isRange : true,
        inputValueType1 : null,
        inputValueType2 : null,
        unitOfMeasure : null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return false for updating tabular input with same equality comparers', () => {
      existingTabInput.inputValueType1 = 1;
      existingTabInput.inputValueType2 = 2;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return false for updating tabular input with same equality comparers in string form', () => {
      existingTabInput.inputValueType1 = 1;
      existingTabInput.inputValueType2 = 2;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return false for updating tabular input with first equality comparers change from null to empty string', () => {
      existingTabInput.inputValueType1 = null;
      existingTabInput.inputValueType2 = 2;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return true for updating tabular input with initial first equality comparer null, when the initial input value field is not null', () => {
      existingTabInput.inputValueType1 = null;
      existingTabInput.inputValueType2 = 2;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return false for updating tabular input with initial first equality comparer null, when the initial and final input value field is null', () => {
      existingTabInput.inputValueType1 = null;
      existingTabInput.inputValue1 = null;
      existingTabInput.inputValueType2 = 2;
      const newTabInput = {
          inputValue1: null,
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return true for updating tabular input with initial first equality comparer empty, when the initial input value field has a value', () => {
      existingTabInput.inputValueType1 = undefined;
      existingTabInput.inputValueType2 = 2;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return true for updating tabular input with initial first equality comparer zero', () => {
      existingTabInput.inputValueType1 = 0;
      existingTabInput.inputValueType2 = 2;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return true for updating tabular input with new first equality comparer empty string', () => {
      existingTabInput.inputValueType1 = 0;
      existingTabInput.inputValueType2 = 2;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return true for updating tabular input with initial second equality comparer null and second value field not null', () => {
      existingTabInput.inputValueType1 = 1;
      existingTabInput.inputValueType2 = null;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return false for updating tabular input with initial second equality comparer null and second value field null', () => {
      existingTabInput.inputValueType1 = 1;
      existingTabInput.inputValueType2 = null;
      existingTabInput.inputValue2 = null;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: null,
          isRange: true,
          inputValueType1: 1,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return true for updating tabular input with initial second equality comparer undefined', () => {
      existingTabInput.inputValueType1 = 1;
      existingTabInput.inputValueType2 = undefined;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return false for updating tabular input with second equality comparers change from null to empty string', () => {
      existingTabInput.inputValueType1 = 1;
      existingTabInput.inputValueType2 = null;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: null,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return true for updating tabular input with initial second equality comparer zero', () => {
      existingTabInput.inputValueType1 = 1;
      existingTabInput.inputValueType2 = 0;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return true for updating tabular input with new second equality comparer empty string', () => {
      existingTabInput.inputValueType1 = 1;
      existingTabInput.inputValueType2 = 0;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: null,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return true for updating tabular input with first equality comparer different', () => {
      existingTabInput.inputValueType1 = 1;
      existingTabInput.inputValueType2 = 2;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 2,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return true for updating tabular input with second equality comparer different', () => {
      existingTabInput.inputValueType1 = 1;
      existingTabInput.inputValueType2 = 2;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: 3,
          unitOfMeasure: null
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return false for updating tabular input with UoM same', () => {
      existingTabInput.unitOfMeasure = "UoM1";
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: "UoM1"
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return true for updating tabular input with UoM different', () => {
      existingTabInput.unitOfMeasure = "UoM1";
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: "UoM2"
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return true for updating tabular input with existing UoM null', () => {
      existingTabInput.unitOfMeasure = null;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: "UoM2"
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return false for updating tabular input with existing UoM null, when value field 1 is not null and value field 2 is null', () => {
      existingTabInput.unitOfMeasure = null;
      existingTabInput.inputValue2 = null;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: null,
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: "UoM2"
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return false for updating tabular input with existing UoM null, when value field 1 is null and value field 2 is not null', () => {
      existingTabInput.unitOfMeasure = null;
      existingTabInput.inputValue1 = null;
      const newTabInput = {
          inputValue1: null,
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: "UoM2"
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return false for updating tabular input with existing UoM null, when value field 1 is null and value field 2 is not null and is Range is false', () => {
      existingTabInput.unitOfMeasure = null;
      existingTabInput.inputValue2 = null;
      existingTabInput.isRange = false;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: null,
          isRange: false,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: "UoM2"
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return false for updating tabular input with existing UoM null and both value fields null', () => {
      existingTabInput.unitOfMeasure = null;
      existingTabInput.inputValue1 = null;
      existingTabInput.inputValue2 = null;

      const newTabInput = {
          inputValue1: null,
          inputValue2: null,
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: "UoM2"
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(false);
    });

    it('should return true for updating tabular input with existing UoM undefined', () => {
      existingTabInput.unitOfMeasure = undefined;
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: "UoM2"
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return true for updating tabular input with existing UoM empty string', () => {
      existingTabInput.unitOfMeasure = '';
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: "UoM2"
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });

    it('should return true for updating tabular input with existing UoM whitespaces string', () => {
      existingTabInput.unitOfMeasure = '   ';
      const newTabInput = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: "UoM2"
      };
      const result = component.isTabularInputValueDifferent(existingTabInput, newTabInput);
      expect(result).toBe(true);
    });
  });

  describe('checkBoxVisible method', () => {
    beforeEach(() => {
      cellAssignment = createPhraseAssignment();
    });

    it('should return true for null cell Assignment', () => {
      const result = component.checkBoxVisible(null, new PhraseAssessViewModel());
      expect(result).toBe(true);
    });

    it('should return true for statement with different assessment status', () => {
      cellAssignment.tabularInput = null;
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.NotRelevant;

      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return false for statement with same assessment status', () => {
      cellAssignment.tabularInput = null;
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;

      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(cellAssignment.tabularInput).toBe(null);
      expect(cellAssignment.status).toBe(viewModel.phraseAssignmentStatus);
      expect(result).toBe(false);
    });

    it('should return false for tabular input with same assessment status and tabular input values', () => {
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: null
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(false);
    });

    it('should return true for tabular input with only different assessment status', () => {
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.NotRelevant;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: null
      };

      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return true for tabular input with only different input value 1', () => {
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '12',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: null
      };

      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return true for tabular input with only different isRange', () => {
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: false,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: null
      };

      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return true for tabular input with only different inputValue2 given isRange true', () => {
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '103',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: null
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return true for different status, input value 1, input value 2 and isRange', () => {
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.NotRelevant;
      viewModel.tabularInputData = {
          inputValue1: '12',
          inputValue2: '103',
          isRange: false,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: null
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return false for same status and input value 1, but different input value 2 when isRange is false and the same', () => {
      cellAssignment.tabularInput.isRange = false;
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '103',
          isRange: false,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: null
      };

      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(false);
    });

    it('should return true for updating a null input value 1 of the existing assignment', () => {
      cellAssignment.tabularInput.inputValue1 = null;
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: null
      };

      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return true for updating a blank input value 1 of the existing assignment', () => {
      cellAssignment.tabularInput.inputValue1 = '';
            const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: null
      };

      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return true for updating a null input value 2 of the existing assignment', () => {
      cellAssignment.tabularInput.inputValue2 = null;
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: null
      };

      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return true for updating a blank input value 2 of the existing assignment', () => {
      cellAssignment.tabularInput.inputValue1 = '';
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: null
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return false for updating tabular input with null input value 1 to blank input value 1', () => {
      cellAssignment.tabularInput.inputValue1 = null;
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: null
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(false);
    });

    it('should return false for updating tabular input with blank input value 1 to null input value 1', () => {
      cellAssignment.tabularInput.inputValue1 = '';
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: null,
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: null
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(false);
    });

    it('should return false for updating tabular input with null input value 2 to blank input value 2 when isRange is true and the same', () => {
      cellAssignment.tabularInput.inputValue2 = null;
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: null
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(false);
    });

    it('should return false for updating tabular input with blank input value 1 to null input value 1 when isRange is true and the same', () => {
      cellAssignment.tabularInput.inputValue1 = '';
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: null,
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: null
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(false);
    });

    it('should return false for updating tabular input with same equality comparers', () => {
      cellAssignment.tabularInput.inputValueType1 = 1;
      cellAssignment.tabularInput.inputValueType2 = 2;
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(false);
    });

    it('should return true for updating tabular input with first equality comparer different', () => {
      cellAssignment.tabularInput.inputValueType1 = 1;
      cellAssignment.tabularInput.inputValueType2 = 2;
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 2,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return true for updating tabular input with first equality comparer changed to null', () => {
      cellAssignment.tabularInput.inputValueType1 = 0;
      cellAssignment.tabularInput.inputValueType2 = 2;
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return true for updating tabular input with first equality comparer changed to empty string', () => {
      cellAssignment.tabularInput.inputValueType1 = 0;
      cellAssignment.tabularInput.inputValueType2 = 2;
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: 2,
          unitOfMeasure: null
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return true for updating tabular input with second equality comparer different', () => {
      cellAssignment.tabularInput.inputValueType1 = 1;
      cellAssignment.tabularInput.inputValueType2 = 2;
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: 3,
          unitOfMeasure: null
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return true for updating tabular input with second equality comparer updated to null', () => {
      cellAssignment.tabularInput.inputValueType1 = 1;
      cellAssignment.tabularInput.inputValueType2 = 0;
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: null,
          unitOfMeasure: null
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return true for updating tabular input with second equality comparer updated to empty string', () => {
      cellAssignment.tabularInput.inputValueType1 = 1;
      cellAssignment.tabularInput.inputValueType2 = 0;
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: 1,
          inputValueType2: null,
          unitOfMeasure: null
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });

    it('should return false for updating tabular input with UoM same', () => {
      cellAssignment.tabularInput.unitOfMeasure = "UoM1";
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: "UoM1"
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(false);
    });

    it('should return true for updating tabular input with UoM different', () => {
      cellAssignment.tabularInput.unitOfMeasure = "UoM1";
      const viewModel = new PhraseAssessViewModel();
      viewModel.phraseAssignmentStatus = AssignmentStatus.Accepted;
      viewModel.tabularInputData = {
          inputValue1: '25',
          inputValue2: '100',
          isRange: true,
          inputValueType1: null,
          inputValueType2: null,
          unitOfMeasure: "UoM2"
      };
      const result = component.checkBoxVisible(cellAssignment, viewModel);
      expect(result).toBe(true);
    });
  });
});

export function createTabularInput(): TabularInput {
  return {
    inputValue1 : '25',
    inputValue2 : '100',
    isRange : true,
    inputValueType1 : null,
    inputValueType2 : null,
    unitOfMeasure : null
  };
}

export function createPhraseAssignment(): PhraseAssignment {
  return {
    id : 1,
    regulatoryMarketId : 101,
    regulatoryProductClassId : 13,
    status : AssignmentStatus.Accepted,
    hasValue : true,
    source : "A source",
    tabularInput : {
      inputValue1 : '25',
      inputValue2 : '100',
      isRange : true,
      inputValueType1 : null,
      inputValueType2 : null,
      unitOfMeasure : null
    }
  };
}