import { Injectable } from '@angular/core';
import { PhraseAssessViewModel, PhraseAssessRequestModel } from './phrase-assess.types';
import { HttpService } from '../../tools/services/http.service';
import { UrlEndpoint } from '../../tools/constants';

@Injectable()
export class PhraseAssessService {
    constructor(private httpService: HttpService) { }

    getDetails(request: PhraseAssessRequestModel): Promise<PhraseAssessViewModel> {
        return new Promise<PhraseAssessViewModel>((resolve, reject) => {
            this.httpService.postContent(request, UrlEndpoint.PhraseMatrix_GetPhraseAssessDetails).subscribe(result => {
                // reference cells to markets with the goal to improve lookup performance
                result.markets.forEach(m => m.cells = result.rows
                    .map(r => r.cells.filter(c => c.regulatoryMarketId == m.id))
                    .reduce((a, b) => a.concat(b)));
                resolve(result);
            }, error => {
                reject(error);
            });
        });
    }
}