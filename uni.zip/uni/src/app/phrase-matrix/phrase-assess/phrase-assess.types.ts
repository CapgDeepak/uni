import { AssignmentStatus } from "../../tools/constants";
import { ListPhrase } from "../phrase-matrix.types";
import { Topic } from "../topic-tree/topic-tree.types";

export class RegulatoryMarket {
    public id: number;
    public isoCode: string;
    public description: string;
    public cells: AssessCell[] = [];
}

export interface RegulatoryProductClass {
    id: number;
    description: string;
    searchValue: string;
    isHazard: boolean;
}

export interface TabularInput {
    isRange: boolean;
    inputValueType1: number;
    inputValue1: string;
    inputValueType2: number;
    inputValue2: string;
    unitOfMeasure: string;
}

export interface PhraseAssignment {
    id: number;
    regulatoryMarketId: number;
    regulatoryProductClassId: number;
    status: AssignmentStatus;

    hasValue: boolean;
    source: string;
    tabularInput: TabularInput;
}

export interface PhraseAssignmentDetail extends PhraseAssignment {
    regulatoryMarketDescription: string;
    regulatoryProductClassDescription: string;
    regulatoryProductClassSearchValue: string;
    regulatoryProductClassFormattedSearchValue: string;
}

export class AssessCell {
    public regulatoryMarketId: number;
    public regulatoryProductClassId: number;
    public assignment: PhraseAssignment;
    public hasConflict: boolean;
    public isEditable: boolean;
    public isDeclined: boolean;
    public isSelected: boolean;
    public isValid: boolean;
}

export class AssessRow {
    public rpc: RegulatoryProductClass;
    public cells: AssessCell[];
    public isDestinationRpc: boolean;
}

export class PhraseAssessRequestModel {
    public sourceRegulatoryProductClassId: number;
    public destinationRegulatoryProductClassId: number;
    public topicId: number;
    public sourceMarketId: number;
    public destinationMarketId: number;
    public phraseId: number;
    public detailLevelId: number | null;
    public tabularInputData: TabularInputValueData;
    public phraseAssignmentStatus: AssignmentStatus;
}

export class PhraseAssessViewModel extends PhraseAssessRequestModel {
    // result
    public phrase: ListPhrase;
    public topic: Topic;
    public sourceMarketPath: string;
    public sourceRpc: RegulatoryProductClass;
    public destinationRpc: RegulatoryProductClass;
    public destinationMarketPath: string;
    public markets: RegulatoryMarket[];
    // state
    public rows: AssessRow[];
}

export class RegulatoryMarketRPC {
    public regulatoryMarketId: number;
    public regulatoryProductClassId: number;
}

export class PhraseAssessImpactRequestModel extends PhraseAssessRequestModel {
    public propagationTargets: RegulatoryMarketRPC[];
}

export class PhraseAssessImpactViewModel extends PhraseAssessImpactRequestModel {
    public childAssignmentConflicts: PhraseAssignmentDetail[];
    public childAssignmentConflictCount: number;
    public fullPropagationTargetCount: number;
    public childAssignmentCount: number;
    public childAssignmentCreateCount: number;
    public childAssignmentIgnoreCount: number;
}

export enum Step {
    edit,
    review,
    apply,
    done
}

export class PhraseAssessPerformRequestModel extends PhraseAssessImpactViewModel {
    public localSource: string;
}

export interface TabularInputValueData {
    isRange: boolean;
    inputValueType1: number | null;
    inputValue1: string;
    inputValueType2: number | null;
    inputValue2: string;
    unitOfMeasure: string;
}