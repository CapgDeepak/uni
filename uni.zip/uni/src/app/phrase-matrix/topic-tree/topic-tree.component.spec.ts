import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { ActivatedRoute, Params } from '@angular/router';
import { Observable } from 'rxjs';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { TopicTreeComponent } from './topic-tree.component';
import { TopicTreeNode, Topic } from "./topic-tree.types";
import { HttpService } from '../../tools/services/http.service';
import { getTestTopic } from '../../testData';

class ActivatedRouteMock {
  queryParams: Observable<Params> = new Observable<Params>(subscriber => {
    subscriber.complete();
  });
}
class HttpServiceMock {
  getFilteredPromise() {
    return new Promise<Topic[]>((resolve) => {
      resolve([
        { id: 1, description: "Topic1", parentId: null, isDeclined: true, order: 1, isValidForRpcAndMarket: false },
        { id: 2, description: "Topic2", parentId: 1, isDeclined: false, order: 2, isValidForRpcAndMarket: false }
      ]);
    });
  }
}

describe('TopicTreeComponent', () => {
  let component: TopicTreeComponent;
  let fixture: ComponentFixture<TopicTreeComponent>;
  let httpService: HttpService;

  let topics: Array<TopicTreeNode>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        TopicTreeComponent
      ],
      providers: [
        { provide: ActivatedRoute, useClass: ActivatedRouteMock },
        { provide: HttpService, useClass: HttpServiceMock }
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA
      ]
    })
      .compileComponents();
    const injector = getTestBed();
    httpService = injector.get(HttpService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TopicTreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should not call GetList whilst data no marketId is specified', () => {
    fixture.detectChanges();
    jest.spyOn(httpService, 'getFilteredPromise');
    component.regulatoryProductClassId = 3;
    expect(httpService.getFilteredPromise).toHaveBeenCalledTimes(0);
  });

  it('should not call GetList whilst data no rpcId is specified', () => {
    fixture.detectChanges();
    jest.spyOn(httpService, 'getFilteredPromise');
    component.regulatoryMarketId = 3;
    expect(httpService.getFilteredPromise).toHaveBeenCalledTimes(0);
  });

  it('should call GetList when rpc and market data specified', () => {
    fixture.detectChanges();
    jest.spyOn(httpService, 'getFilteredPromise');
    component.regulatoryMarketId = 3;
    component.regulatoryProductClassId = 3;
    expect(httpService.getFilteredPromise).toHaveBeenCalledTimes(0);
  });

  it('should not emit event when node selection set to null', () => {
    fixture.detectChanges();
    jest.spyOn(component.selectionChange, 'emit');
    component.selectNode(null, true);
    expect(component.selectionChange.emit).toHaveBeenCalledTimes(0);
  });

  it('should not emit event when node selection set to same value', () => {
    fixture.detectChanges();
    jest.spyOn(component.selectionChange, 'emit');
    const node = new TopicTreeNode();
    component.selectNode(node, false);
    component.selectNode(node, false);
    component.selectNode(node, false);
    expect(component.selectionChange.emit).toHaveBeenCalledTimes(0);
  });

  describe('filterNodes', () => {
    beforeEach(() => {
      topics = new Array<TopicTreeNode>();
      topics.push(getTestTopic());
      topics.push(getTestTopic());
      topics.push(getTestTopic());
    });

    it('should filter matches correctly for case insensitive valid search', () => {
      const searchString = "AiM";
      topics[1].description = "nothing";
      component.allNodes = topics;
      component.filterNodes(searchString);

      component.allNodes.forEach(element => {
        if (element.visible) {
          expect(element.description.toLowerCase()).toContain(searchString.toLowerCase());
          expect(element.expanded).toBeTruthy();
        }
      });
      expect(component.allNodes.filter(x => x.visible).length).toEqual(2);
    });

    it('should filter matches correctly for valid search', () => {
      const searchString = "aim";
      topics[1].description = "nothing";
      component.allNodes = topics;
      component.filterNodes(searchString);

      component.allNodes.forEach(element => {
        if (element.visible) {
          expect(element.description.toLowerCase()).toContain(searchString.toLowerCase());
          expect(element.expanded).toBeTruthy();
        }
      });
      expect(component.allNodes.filter(x => x.visible).length).toEqual(2);
    });

    it('should filter matches correctly for invalid search', () => {
      const searchString = "AIMx";
      component.filterNodes(searchString);
      expect(component.allNodes.filter(x => x.visible).length).toEqual(0);
    });

    it('should filter matches correctly for no data', () => {
      const searchString = "AIM";
      component.allNodes = [];
      component.filterNodes(searchString);
      expect(component.allNodes.filter(x => x.visible).length).toEqual(0);
    });
  });

  describe('sortTopicsByOrder', () => {
    let topicSet: Array<Topic>;
    beforeEach(() => {
      topicSet = new Array<Topic>();
      topicSet.push({ id: 1, order: 6, description: '', parentId: null, isDeclined: false, isValidForRpcAndMarket: false });
      topicSet.push({ id: 2, order: 3, description: '', parentId: null, isDeclined: false, isValidForRpcAndMarket: false });
      topicSet.push({ id: 3, order: 2, description: '', parentId: null, isDeclined: false, isValidForRpcAndMarket: false });
      topicSet.push({ id: 4, order: 5, description: '', parentId: null, isDeclined: false, isValidForRpcAndMarket: false });
      topicSet.push({ id: 5, order: 1, description: '', parentId: null, isDeclined: false, isValidForRpcAndMarket: false });
    });

    it('should sort topics correctly', () => {
      const result = component.sortTopicsByOrder(topicSet);
      const ids = result.map(x => x.id);

      expect(ids.length).toEqual(5);
      expect(ids).toEqual([5, 3, 2, 4, 1]);
    });
  });
});
