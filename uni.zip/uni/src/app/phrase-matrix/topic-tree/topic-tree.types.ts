export class Topic {
    id: number;
    description: string;
    parentId: number;
    isDeclined: boolean;
    order: number;
    isValidForRpcAndMarket: boolean;
}

export class TopicTreeNode {
    id: number = 0;
    description: string = '';
    isDeclined: boolean = false;

    expanded: boolean = false;
    visible: boolean = true;
    isValidForRpcAndMarket = false;

    parent: TopicTreeNode | null = null;
    childs: TopicTreeNode[] = new Array<TopicTreeNode>();

    get hasChilds(): boolean {
        return this.childs.length > 0;
    }
}