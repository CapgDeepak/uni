import { Component, OnInit, Output, EventEmitter, Input } from "@angular/core";
import { Params, ActivatedRoute } from '@angular/router';

import { TopicTreeNode, Topic } from "./topic-tree.types";
import { HttpService } from '../../tools/services/http.service';
import { UrlEndpoint } from '../../tools/constants';

@Component({
    selector: 'ara-topic-tree',
    templateUrl: './topic-tree.component.html',
    styleUrls: ['./topic-tree.component.scss']
})
export class TopicTreeComponent implements OnInit {

    private initialTopicIdSelection: number;

    private _regulatoryMarketId: number | null = null;
    isSystemSelected: boolean = true;
    isTopicLoaded: boolean = true;
    get regulatoryMarketId(): number | null {
        return this._regulatoryMarketId;
    }
    @Input() set regulatoryMarketId(newValue: number | null) {
        if (newValue != this._regulatoryMarketId) {
            this._regulatoryMarketId = newValue;
            if (this._regulatoryMarketId > 0) {
                this.loadTopicsIfDataAvailable();
            }
        }
    }

    private _regulatoryProductClassId: number | null = null;
    get regulatoryProductClassId(): number | null {
        return this._regulatoryProductClassId;
    }
    @Input() set regulatoryProductClassId(newValue: number | null) {
        if (newValue != this._regulatoryProductClassId) {
            this._regulatoryProductClassId = newValue;
            this.loadTopicsIfDataAvailable();
        }
    }
    private topicFilter: string | number | null = null;
    get filter(): string | number | null {
        return this.topicFilter;
    }
    @Input() set filter(value: string | number | null) {
        this.topicFilter = value;
    }

    public allNodes: TopicTreeNode[] = new Array<TopicTreeNode>();
    public tree: TopicTreeNode[] = new Array<TopicTreeNode>();
    public selectedNode: TopicTreeNode | null = null;
    public tempNode: TopicTreeNode | null = null;
    public newSelectedNode: TopicTreeNode | null = null;

    @Output()
    selectionChange: EventEmitter<TopicTreeNode | null> = new EventEmitter<TopicTreeNode | null>();

    constructor(
        private httpService: HttpService,
        private route: ActivatedRoute) {
    }

    ngOnInit(): void {
        this.route.queryParams.forEach((params: Params) => {
            this.storeInitialSelection(params);
        });
    }

    private storeInitialSelection(params: Params) {
        // Note: the '+' on params here converts the string id to a number
        // - also: the RPC and Market IDs will be passed in via the matrix component - so no need to extract these here
        const topicId = +params['topicId'];
        if (topicId > 0) {
            this.initialTopicIdSelection = topicId;
        }
    }

    private loadTopicsIfDataAvailable() {
        if (this._regulatoryMarketId && this._regulatoryProductClassId > 0 && +sessionStorage.getItem("rpcId") > 0) {
            this.loadTopics(this._regulatoryMarketId, this._regulatoryProductClassId);
        }
        else {
            const selectedNodeId = this.getCurrentlySelectedTopic();
            const expandedNodes = this.getExistingExpandedNodesAndCollapseTree();
            this.setupLoadedTopicsData([], expandedNodes, selectedNodeId);
        }
    }
    public getClass(node: TopicTreeNode) {
        let classList = '';
        if (this.isSystemSelected && this.selectedNode != null && this.selectedNode.id == node.id && this.selectedNode.description.toLowerCase() == node.description.toLowerCase()) {
            classList = 'node-system-selected';
            if (!node.visible) {
                classList += 'node-invisible';
            }
        }
        else if (this.newSelectedNode != null && this.newSelectedNode.id == node.id && this.newSelectedNode.description.toLowerCase() == node.description.toLowerCase()) {
            if (classList != '') {
                classList = 'node-selected';
            }
            else {
                classList += 'node-selected';
            }
            if (!node.visible) {
                classList += 'node-invisible';
            }
        }
        if ((this.topicFilter != null || this.topicFilter != '') && !node.visible) {
            if (classList != '') {
                classList = 'node-invisible';
            }
            else {
                classList += 'node-invisible';
            }
        }
        return classList;
    }

    private loadTopics(regulatoryMarketId: number, regulatoryProductClassId: number) {
        this.isTopicLoaded = true;
        const selectedNodeId = this.getCurrentlySelectedTopic();
        const expandedNodes = this.getExistingExpandedNodesAndCollapseTree();
        if (regulatoryMarketId && regulatoryMarketId > -1) {
            this.httpService.getFilteredPromise(
                { regulatoryMarketId: regulatoryMarketId.toString(), regulatoryProductClassId: regulatoryProductClassId.toString() },
                UrlEndpoint.PhraseMatrix_GetTopicList)
                .then(topics => {
                    this.isTopicLoaded = false;
                    this.setupLoadedTopicsData(topics, expandedNodes, selectedNodeId);
                    if (!topics || topics.length == 0) {
                        this.selectionChange.emit(null);
                    }
                });
        } else {
            this.isTopicLoaded = false;
            this.setupLoadedTopicsData([], expandedNodes, selectedNodeId);
        }
    }

    private getCurrentlySelectedTopic() {
        if (+localStorage.getItem("selectedTopicId") > 0) {
            this.initialTopicIdSelection = +localStorage.getItem("selectedTopicId");
        }
        else {
            this.initialTopicIdSelection = +localStorage.getItem("topicId");
        }
        let selectedNodeId: number | null = null;
        if (this.initialTopicIdSelection && (this.initialTopicIdSelection > 0)) {
            selectedNodeId = this.initialTopicIdSelection;
        }
        else if (this.selectedNode) {
            selectedNodeId = this.selectedNode.id;
        }
        return selectedNodeId;
    }

    private getExistingExpandedNodesAndCollapseTree() {
        const expandedNodes = new Array<number>();
        this.allNodes.filter(node => node.expanded).forEach(expanded => {
            expandedNodes.push(expanded.id);
        });
        this.allNodes = new Array<TopicTreeNode>();
        return expandedNodes;
    }

    private setupLoadedTopicsData(topics: Topic[], expandedNodes: number[], selectedNodeId: number) {
        this.isTopicLoaded = true;
        this.buildTreeRoot(topics, expandedNodes);
        const currentNode = this.getNodeOrDefault(selectedNodeId);
        this.expandAndSelectNode(currentNode);
        this.isTopicLoaded = false;
    }

    private getNodeOrDefault(selectedNodeId: number) {
        let currentNode: TopicTreeNode | null;
        if (selectedNodeId) {
            currentNode = this.allNodes.find(n => n.id == selectedNodeId);
        }
        if (currentNode == null && this.tree.length > 0) { // select the first available node, if the current selection is not found
            currentNode = this.tree[0];
        }
        return currentNode;
    }

    private buildTreeRoot(topics: Topic[], expandedNodes: number[]) {
        this.tree = new Array<TopicTreeNode>();
        const rootTopics = this.sortTopicsByOrder(topics.filter(i => i.parentId == null));
        rootTopics.forEach(topic => {
            const node = this.createTopicTreeNode(topic, expandedNodes);
            this.tree.push(node);
            this.addChildNodes(node, topics, expandedNodes);
        });
    }

    private addChildNodes(node: TopicTreeNode, topics: Topic[], expandedNodes: number[]) {
        this.allNodes.push(node);
        this.fillChildNodes(node, topics, expandedNodes);
    }

    private createTopicTreeNode(topic: Topic, expandedNodes: number[]) {
        const node = new TopicTreeNode();
        node.id = topic.id;
        node.description = topic.description;
        node.isDeclined = topic.isDeclined;
        node.isValidForRpcAndMarket = topic.isValidForRpcAndMarket;
        node.expanded = (expandedNodes.findIndex(value => value == topic.id) >= 0);
        return node;
    }

    private fillChildNodes(parentNode: TopicTreeNode, topics: Topic[], expandedNodes: number[]) {
        const childTopics = this.sortTopicsByOrder(topics.filter(i => i.parentId == parentNode.id));
        childTopics.forEach(topic => {
            const node = this.createTopicTreeNode(topic, expandedNodes);
            node.parent = parentNode;
            parentNode.childs.push(node);
            this.addChildNodes(node, topics, expandedNodes);
        });
    }

    toggleNode(node: TopicTreeNode) {
        node.expanded = !node.expanded;
    }

    expandNode(node: TopicTreeNode) {
        node.expanded = true;
        if (node.expanded) {
            this.expandParentNodes(node.parent); // ensure the parent nodes are also expanded - needed if navigating to the page from a work list selection
        }
    }

    expandAndSelectNode(node: TopicTreeNode) {
        if (node) {
            this.selectNode(node, false);
            this.expandNode(node);
        }
    }

    // isSystemSelected will be passed as false when user selects any node in the tree view
    // isSystemSelected is used in user selection and system selection
    selectNode(node: TopicTreeNode, isSel: boolean) {
        if (node != null) {
            if (isSel) {
                this.newSelectedNode = node;
                localStorage.setItem("selectedTopicId", node.id.toString());
                this.selectedNode = null;
                if (this._regulatoryProductClassId > 0) {
                    this.selectionChange.emit(this.newSelectedNode);
                }
            }
            else if (this.selectedNode != node && !isSel) {
                this.selectedNode = node;
                this.newSelectedNode = null;
                localStorage.removeItem("selectedTopicId");
                if (this._regulatoryProductClassId > 0) {
                    this.selectionChange.emit(this.selectedNode);
                }
            }
            localStorage.setItem("topicId", node.id.toString());
        }
    }

    public filterNodes(filter: string) {
        this.allNodes.forEach(element => {
            element.visible = filter == '' ||
                element.description.toLowerCase().includes(filter.toLowerCase());
        });

        if (filter != '') {
            this.allNodes.forEach(element => {
                if (element.visible) {
                    this.expandParentNodes(element.parent);
                }
            });
        } else {
            // reset the tree to the current selection
            this.allNodes.forEach(element => {
                element.expanded = false;
            });
            if (this.selectedNode != null || this.newSelectedNode) {
                this.expandAndSelectNode(this.selectedNode);
            }
            this.selectedNode != null ? this.expandAndSelectNode(this.selectedNode) : this.expandAndSelectNode(this.newSelectedNode);
        }
    }

    /**
     * Sort an array of topics by order
     * @param topics The array of topics to be sorted
     */
    public sortTopicsByOrder(topics: Topic[]): Topic[] {
        return topics.sort((x, y) => (x.order > y.order) ? 1 : (x.order < y.order) ? -1 : 0);
    }

    private expandParentNodes(parentNode: TopicTreeNode) {
        while (parentNode != null) {
            parentNode.visible = true;
            parentNode.expanded = true;
            parentNode = parentNode.parent;
        }
        return parentNode;
    }
}