import { Component, forwardRef, Output, EventEmitter, Input } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { StatementData } from '../matrix-cell-edit/matrix-cell-edit.types';

const noop = () => {
};

@Component({
    selector: 'ara-phrase-edit-list',
    templateUrl: './phrase-edit-list.component.html',
    styleUrls: ['./phrase-edit-list.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => PhraseEditListComponent),
            multi: true
        }
    ]
})
export class PhraseEditListComponent {
    statements: StatementData[] = new Array<StatementData>();

    constructor() { }

    @Output()
    selectionChange: EventEmitter<StatementData> = new EventEmitter<StatementData>();

    @Input() hasAssessPermission: boolean;
    @Input()
    selected: StatementData = null;
    selectStatement(value: StatementData) {
        if (value != this.selected) {
            this.selected = value;
            this.selectionChange.emit(value);
        }
    }

    get value(): any {
        return this.statements;
    }
    set value(newValue: any) {
        this.writeValue(newValue);
    }

    private onTouchedCallback: () => void = noop;
    private onChangeCallback: (_: any) => void = noop;

    public blur(): void {
        this.onTouchedCallback();
    }

    writeValue(obj: any): void {
        this.statements = obj || new Array<StatementData>();
    }

    registerOnChange(fn: any): void {
        this.onChangeCallback = fn;
    }

    registerOnTouched(fn: any): void {
        this.onTouchedCallback = fn;
    }

    isAssessmentReasonShown(statement: StatementData) {
        return statement.phraseAssignmentStatus === 'ToBeAssessed' && statement.phraseStatus === 'Approved';
    }
}