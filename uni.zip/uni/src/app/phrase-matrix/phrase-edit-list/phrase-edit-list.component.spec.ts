import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PhraseEditListComponent } from './phrase-edit-list.component';
import { createStatementAssignment } from '../matrix-cell-edit/matrix-cell-edit.component.spec';

describe('PhraseEditListComponent', () => {
  let component: PhraseEditListComponent;
  let fixture: ComponentFixture<PhraseEditListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        PhraseEditListComponent
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhraseEditListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    component.statements = [createStatementAssignment()];
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot with selected phrase', () => {
    const statement = createStatementAssignment();
    component.statements = [statement];
    component.selected = statement;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot with selected toBeAssessed phrase', () => {
    const statement = createStatementAssignment();
    statement.phraseStatus = 'Approved';
    statement.phraseAssignmentStatus = 'ToBeAssessed';
    statement.assessmentReason = 'New Assignment';
    component.statements = [statement];
    component.selected = statement;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

});
