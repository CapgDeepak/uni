import { Component, OnInit } from '@angular/core';
import { ToasterConfig } from 'angular2-toaster';
import { MenuItem } from 'primeng/api';

import { MarketWorkListType } from './tools/constants';
import { AuthorizationService } from './authorization/authorization.service';
import { PermissionsLoaderService } from './authorization/permissions-loader/permissions-loader.service';
import { Permission } from './tools/shared-types/permissions/permission';
import { ConfigService } from './tools/services/config.service';
import { MsalService, MsalBroadcastService } from '@azure/msal-angular';
import { EventMessage, EventType } from '@azure/msal-browser';
import { filter, takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  constructor(
    private authService: MsalService,
    private msalBroadcastService: MsalBroadcastService,
    private authorizationService: AuthorizationService,
    private permissionsLoaderService: PermissionsLoaderService,
    private appConfig: ConfigService) {
  }
  public Roles = [];
  public lastindex = 0;
  title = 'ARA PReF DC';
  loginDisplay: boolean;
  isIframe: boolean;
  private readonly _destroying$ = new Subject<void>();

  public toasterConfig: ToasterConfig = new ToasterConfig({
    animation: 'fade',
    positionClass: 'toast-bottom-right',
    showCloseButton: true
  });
  public isLoggedIn = false;
  public isLoadingPermissions = false;
  public isLoadingTopicMappings = false;

  // SEP2020 to test
  menuItems: MenuItem[] = [];
  public isMenuOpen: boolean;
  public userName = '';
  public menuLinks = '';
  public shortName = '';
  // SEP2020

  ngOnInit(): void {
    this.appConfig.loadAppConfig().then(() => {
    });
    this.isIframe = window !== window.parent && !window.opener;
    this.setLoginDisplay();
    this.msalBroadcastService.msalSubject$
      .pipe(
        filter((msg: EventMessage) => msg.eventType === EventType.LOGIN_SUCCESS || msg.eventType === EventType.ACQUIRE_TOKEN_SUCCESS),
        takeUntil(this._destroying$)
      )
      .subscribe((result) => {
        console.log(result.payload + 'app.component');
        this.setLoginDisplay();
      });
  }
  setLoginDisplay() {
    this.loginDisplay = this.authService.instance.getAllAccounts().length > 0;
  }

  setLogin($event) {
    if (!this.isLoggedIn && $event.isLoggedIn) {
      this.getUserPermissions(); // only load data once we've actually logged in
      this.getTopicMappings();
    }
    this.isLoggedIn = $event.isLoggedIn;
  }
  /**
   *SEP2020 MENU
   */
  isMenu($event) {
    this.isMenuOpen = $event.isMenu;
    const f = $event.userName.split('.');
    const l = f[1].split('@');
    this.shortName = f[0].substring(0, 1) + l[0].substring(0, 1);
    this.userName = $event.userName;
    this.menuLinks = $event.menuLinks;
  }
  /**
   * Retrieve the current user's permissions from the backend, and build the menu items
   * to display based on these permissions.
   */
  private getUserPermissions() {
    this.isLoadingPermissions = true;
    this.permissionsLoaderService.loadPermissions()
      .then(() => {
        this.isLoadingPermissions = false;
        this.buildMenuItems();
      })
      .catch(err => {
        this.isLoadingPermissions = false;
      });
  }

  private getTopicMappings() {
    this.isLoadingTopicMappings = true;
    this.permissionsLoaderService.loadTopicToUpdMapping()
      .then(() => {
        this.isLoadingTopicMappings = false;
      })
      .catch(err => {
        this.isLoadingTopicMappings = false;
      });
  }

  private buildMenuItems() {
    this.menuItems.push({ label: 'Home', routerLink: '/home' });

    if (this.authorizationService.userHasPermissionToViewPhraseLibrary()) {
      // removed default phrase-library load on click menu drop down
      // since menu item hover wasnt showing list
      // const phraseLibraryItem: MenuItem = { label: 'Phrase Library', items: [] };
      if (this.authorizationService.checkUserHasAnyPermission([Permission.AraPReFDCT_Phrases_Order])) {
        // const itemsList: MenuItem[] = [
        //   { label: 'Phrase Library', routerLink: '/phrase-library', routerLinkActiveOptions: { exact: true } },
        //  // {  label: 'Phrase Ordering', routerLink: '/phrase-library/ordering', routerLinkActiveOptions: { exact: true } }
        // ];
        // phraseLibraryItem.items = itemsList;
        this.menuItems.push({ label: 'Phrase Library', routerLink: '/phrase-library', routerLinkActiveOptions: { exact: true } });
      }
    }

    if (this.authorizationService.userHasPermissionToViewPhraseMatrix()) {
      this.menuItems.push({ label: 'Assignment Matrix', routerLink: '/phrase-matrix' });
    }

    // If the user has permissions for the GRAM or Market work lists, then build up the work list menu,
    // and add the appropriate items.
    const userHasPermissionForGramWorkList = this.authorizationService.userHasPermissionToViewGramWorkList();
    const userHasPermissionForMarketWorkList = this.authorizationService.userHasPermissionToViewMarketWorkList();
    if (userHasPermissionForGramWorkList || userHasPermissionForMarketWorkList) {
      const workListItem: MenuItem = { label: 'Work Lists', items: [] };
      const itemsList: MenuItem[] = [];
      if (userHasPermissionForGramWorkList) {
        itemsList.push({ label: 'GRAM', routerLink: '/work-list/grams' });
      }
      if (userHasPermissionForMarketWorkList) {
        itemsList.push({ label: 'Market - Assess', routerLink: '/work-list/markets/' + MarketWorkListType.Assess });
        itemsList.push({ label: 'Market - Create', routerLink: '/work-list/' + MarketWorkListType.Create });
        itemsList.push({ label: 'Market - Review', routerLink: '/work-list/markets/' + MarketWorkListType.Review });
      }
      workListItem.items = itemsList;
      this.menuItems.push(workListItem);
    }
  }
  public RenameSideManu(Name) {
    if (Name == "PReF/FAsT") {
      return "PReF";
    } else {
      return Name;
    }
  }
  public setRoles(data) {
    this.Roles = [];
    data.forEach(role => {
      if (this.Roles.filter(x => x.roleId == role.roleId).length < 1) {
        this.Roles.push(role);
      }
    });
    this.lastindex = (this.Roles.length) - 1;
  }
}