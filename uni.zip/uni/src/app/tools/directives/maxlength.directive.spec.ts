import { MaxLengthDirective } from './maxlength.directive';
import { FormControl } from '@angular/forms';

describe('AraMaxLengthDirective', () => {
    it('should create an instance', () => {
        const directive = new MaxLengthDirective();
        expect(directive).toBeTruthy();
    });

    it('should return null if value is null', () => {
        const directive = new MaxLengthDirective();
        directive.maxLength = 10;
        expect(directive.validate(new FormControl(null))).toBeNull();
    });

    it('should return null if value is shorter than max length', () => {
        const directive = new MaxLengthDirective();
        directive.maxLength = 10;
        expect(directive.validate(new FormControl("123456"))).toBeNull();
    });

    it('should return null if value has max length', () => {
        const directive = new MaxLengthDirective();
        directive.maxLength = 10;
        expect(directive.validate(new FormControl("1234567890"))).toBeNull();
    });

    it('should return error if value is over max length', () => {
        const directive = new MaxLengthDirective();
        directive.maxLength = 10;
        expect(directive.validate(new FormControl("12345678901234567890"))).not.toBeNull();
    });
});