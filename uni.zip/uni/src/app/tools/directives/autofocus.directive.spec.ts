import { AutofocusDirective } from './autofocus.directive';

describe('AutofocusDirective', () => {
    it('should create an instance', () => {
        const directive = new AutofocusDirective(undefined);
        expect(directive).toBeTruthy();
    });
});