import { Directive, Input } from "@angular/core";
import { NG_VALIDATORS, Validator, AbstractControl, ValidationErrors } from "@angular/forms";

/**
 * Directive for permissive max-length validation on fields.  This directive
 * allows users to type too much data and shows the error when they do.
 * (Using the HTML5 maxlength="..." attribute prevents users from typing too
 * much data, truncates pasted content and gives no feedback to the user.)
 */
@Directive({
    selector: '[AraMaxLength]',
    providers: [{provide: NG_VALIDATORS, useExisting: MaxLengthDirective, multi: true}]
})
export class MaxLengthDirective implements Validator {
    @Input("AraMaxLength") maxLength: number;

    validate(control: AbstractControl): ValidationErrors | null {
        const tooLong: boolean = control.value && control.value.length > this.maxLength;
        return tooLong ? {'overMaxLength': {value: control.value}} : null;
    }
}