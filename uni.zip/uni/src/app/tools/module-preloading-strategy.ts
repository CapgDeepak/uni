
import { of as observableOf, Observable } from 'rxjs';
import { Route, PreloadingStrategy } from '@angular/router';

export class ModulePreloadingStrategy implements PreloadingStrategy {

  preload(route: Route, load: Function): Observable<any> {
    return route.data && route.data['preload'] ? load() : observableOf(null);
  }

}