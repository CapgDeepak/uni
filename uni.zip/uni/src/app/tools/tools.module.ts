import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { AuthorizationModule } from '../authorization/authorization.module';

import { SideDialogService } from './side-dialog/side-dialog.service';

import { CacheService } from './services/cache.service';
import { QuillSettingsService } from './services/quill-settings.service';

import { AraDate } from './pipes/ara-date-pipe';
import { AraDateTime } from './pipes/ara-datetime-pipe';

import { JsonHttpInterceptor } from './interceptor/json-http-interceptor';

import { AutofocusDirective } from './directives/autofocus.directive';
import { NotificationService } from './services/notification.service';
import { DialogService } from './services/dialog.service';
import { FilterService } from './services/filter.service';
import { MockDateTimePipe } from './testTools/mockDateTimePipe';
import { ConfigService } from './services/config.service';
import { PhraseService } from './services/phrase.service';
import { LinkService } from './services/link.service';
import { MaxLengthDirective } from './directives/maxlength.directive';
import { MsalInterceptor } from '@azure/msal-angular';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        AuthorizationModule,
        NgbModule,
    ],
    declarations: [
        AraDate,
        AraDateTime,
        AutofocusDirective,
        MockDateTimePipe,
        MaxLengthDirective
    ],
    entryComponents: [
    ],
    providers: [
        DialogService,
        CacheService,
        NotificationService,
        QuillSettingsService,
        SideDialogService,
        FilterService,
        ConfigService,
        LinkService,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: JsonHttpInterceptor,
            multi: true
        },
        {
            provide: HTTP_INTERCEPTORS,
            useClass: MsalInterceptor,
            multi: true
        },
        PhraseService,
    ],
    exports: [
        AraDate,
        AraDateTime,
        AutofocusDirective,
        MaxLengthDirective,
    ]
})
export class ToolsModule {
}