import { PhraseStatusToString, AssignmentStatusToString, PhraseStatus, AssignmentStatus } from './constants';

describe('constants', () => {
  it('PhraseStatusToString returns original statuses when suitable', () => {
    expect(PhraseStatusToString(PhraseStatus.Approved)).toBe(PhraseStatus.Approved);
    expect(PhraseStatusToString(PhraseStatus.Rejected)).toBe(PhraseStatus.Rejected);
  });

  it('PhraseStatusToString returns appropriately derived status when suitable', () => {
    expect(PhraseStatusToString(PhraseStatus.ToBeApproved)).toBe("To be approved");
  });

  it('PhraseStatusToString returns appropriate default status', () => {
    expect(PhraseStatusToString(null)).toBe("To be approved");
    expect(PhraseStatusToString(undefined)).toBe("To be approved");
    expect(PhraseStatusToString('')).toBe("To be approved");
    expect(PhraseStatusToString("")).toBe("To be approved");
  });

  it('AssignmentStatusToString returns appropriately derived statuses', () => {
    expect(AssignmentStatusToString(AssignmentStatus.Accepted)).toBe("Approved and accepted");
    expect(AssignmentStatusToString(AssignmentStatus.NotRelevant)).toBe("Not relevant");
    expect(AssignmentStatusToString(AssignmentStatus.ToBeAssessed)).toBe("To be assessed");
  });

  it('AssignmentStatusToString returns appropriate default status', () => {
    expect(AssignmentStatusToString(null)).toBe("To be assessed");
    expect(AssignmentStatusToString(undefined)).toBe("To be assessed");
    expect(AssignmentStatusToString('')).toBe("To be assessed");
    expect(AssignmentStatusToString("")).toBe("To be assessed");
  });
});
