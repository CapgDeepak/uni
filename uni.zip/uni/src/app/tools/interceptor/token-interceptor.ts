
import { Observable, from } from 'rxjs';
import { Injectable } from "@angular/core";
import { HttpInterceptor, HttpRequest, HttpHandler, HttpSentEvent, HttpHeaderResponse, HttpProgressEvent, HttpResponse, HttpUserEvent } from "@angular/common/http";
import { switchMap, } from 'rxjs/operators';
import { AuthenticationService } from '../../authorization/authentication.service';

@Injectable()
export class TokenInterceptor {
// implements HttpInterceptor {
    constructor(private authService: AuthenticationService
    ) { }

    // intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpSentEvent | HttpHeaderResponse | HttpProgressEvent | HttpResponse<any> | HttpUserEvent<any>> {
    //   if (req.url != "/assets/json/endPoints.json") {
    //     return from((this.authService.getToken()).pipe(
    //       switchMap(token => {
    //         req = req.clone({
    //           setHeaders: {
    //             Authorization: `Bearer ${token}`
    //           }
    //         });
    //         return next.handle(req);
    //       })
    //     ));
    //   } else {
    //     return next.handle(req);
    //   }
    // }
}