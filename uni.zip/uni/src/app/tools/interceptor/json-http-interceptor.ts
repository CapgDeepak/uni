
import { Observable } from 'rxjs';
import { Injectable } from "@angular/core";
import { HttpInterceptor, HttpRequest, HttpHandler, HttpSentEvent, HttpHeaderResponse, HttpProgressEvent, HttpResponse, HttpUserEvent } from "@angular/common/http";

@Injectable()
export class JsonHttpInterceptor implements HttpInterceptor {
    constructor(
    ) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpSentEvent | HttpHeaderResponse | HttpProgressEvent | HttpResponse<any> | HttpUserEvent<any>> {
        let jsonReq = req;
        if (!(req.url.indexOf("Upload") > 0))
        {
            jsonReq = req.clone({
                headers: req.headers.append('Content-Type', 'application/json; charset=utf-8')
            });
        }

        return next.handle(jsonReq);
    }

}