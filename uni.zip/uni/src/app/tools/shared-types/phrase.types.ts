export class PhraseSimpleModel {
    phraseId: number;
    nr: number;
}