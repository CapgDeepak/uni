export class MarketAndUpdAndRpcsIds {
    marketId: number | null;
    updId: number | null;
    rpcIds: number[];
}