export class RegulatoryMarketAndRegulatoryProductClassIds {
    constructor(regulatoryMarketId: number, regulatoryProductClassId: number) {
        this.regulatoryMarketId = regulatoryMarketId;
        this.regulatoryProductClassId = regulatoryProductClassId;
    }

    regulatoryMarketId: number;
    regulatoryProductClassId: number;
}
