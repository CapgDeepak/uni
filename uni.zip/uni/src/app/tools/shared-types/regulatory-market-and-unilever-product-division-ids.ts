export class RegulatoryMarketAndUnileverProductDivisionIds {
    constructor(regulatoryMarketId: number, unileverProductDivisionId: number) {
        this.regulatoryMarketId = regulatoryMarketId;
        this.unileverProductDivisionId = unileverProductDivisionId;
    }

    regulatoryMarketId: number;
    unileverProductDivisionId: number;
}
