import { Permission } from './permission';

export class MarketRpcAndTopicScopedPermissions {
    permissions: Permission[];
    regulatoryMarketId?: number;
    regulatoryProductClassId?: number;
    topicId?: number;
}