import { Permission } from './permission';

export class MarketAndUpdScopedPermissions {
    permissions: Permission[];
    regulatoryMarketId?: number;
    unileverProductDivisionId?: number;
}