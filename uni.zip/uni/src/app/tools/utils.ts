import { DetailLevels } from './constants';

// Given an input array of data, and a filter with a similar structure
// to the objects in the data array, apply the filter and return any matching elements.
// Note, matches are case insensitive and partial - and are aggregated as ANDs.
export function applyFiltersToArray(array, filters) {
    if (!filters) {
        return array;
    }
    return array.filter(o =>
        Object.entries(filters).every(([k, val]) =>
            (filterIsDefined(val) && hasMatchingKeyVal(val, o, k)) ||
             !filterIsDefined(val))); // note, include values if the related filter has not been set
}

function filterIsDefined(val: {}) {
    return (val || val === false);
}

function hasMatchingKeyVal(val: {}, o: any, k: string): boolean {
    return [].concat(val).some(v => hasKeyDefined(o, k) && keyValueMatches(o, k, v));
}

function keyValueMatches(o: any, k: string, v: any): boolean {
    return o[k].toString().toLowerCase().includes(v.toString().toLowerCase());
}

function hasKeyDefined(o: any, k: string) {
    return o[k] !== undefined && o[k] !== null;
}

export function joinArrayValues(options: any[]): string {
    // If options is truthy, then join all distinct options with a comma,
    // otherwise return an empty string.
    if (!options) {
        return '';
    }
    return Array.from(new Set(options)).join(', ');
}

// given a phrase, return either the directly linked generic phrase number, for detailed phrases, or the set of
// available detailed phrases, for standard phrases
export function getLinkedPhraseNrsForPhrase(phrase: any): string {
    return getLinkedPhraseNrs(phrase.detailLevelDescription, phrase.linkedGenericPhraseNr, phrase.linkedGenericPhraseIds);
}

export function getLinkedPhraseNrs(detailLevel: DetailLevels, linkedGenericPhraseId: number | null, linkedSpecificPhraseIds: number[] | null): string {
    // if (detailLevel == DetailLevels.Detailed) {
    //     return linkedGenericPhraseId ? '' + linkedGenericPhraseId : '';
    // }
    return joinArrayValues(linkedSpecificPhraseIds);
}

export function isNullOrWhitespace(input: string): boolean {
    return !input || !input.trim();
}