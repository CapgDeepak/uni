import { TestBed, inject } from '@angular/core/testing';

import { DialogService } from '../services/dialog.service';
import { SideDialogService } from './side-dialog.service';

class DialogServiceMock { }

describe('SideDialogService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        SideDialogService,
        { provide: DialogService, useClass: DialogServiceMock }
      ]
    });
  });

  it('should be created', inject([SideDialogService], (service: SideDialogService) => {
    expect(service).toBeTruthy();
  }));
});
