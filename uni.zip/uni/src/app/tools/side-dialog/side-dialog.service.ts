import { Injectable } from '@angular/core';
import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DialogService } from '../services/dialog.service';

@Injectable()
export class SideDialogService {
    constructor(private dialogService: DialogService) { }

    /**
     * Open a modal side dialog displaying the provided content.  This sets up no callbacks
     * - which means clicking away will have no knock-on consequences.
     * Note, to disable click away from closing the dialog, set, "backdrop: 'static'"
     * @param content - content to display in dialog
     */
    public open(content: any): NgbModalRef {
        return this.dialogService.open(content, {
            windowClass: 'side-dialog',
            backdropClass: 'side-backdrop',
            backdrop: 'static',
            keyboard: false
        });
    }

    /**
     * Open a modal side dialog displaying the provided content and providing callbacks when the dialog is closed.
     * Note, the default error callback is set to be empty - this swallows the response triggered by clicking
     * away from the dialog.
     * @param content - content to display in dialog
     * @param onFullfilled - callback to trigger when the dialog is closed - e.g. by a 'Save' button click.
     */
    public openWithCallback(content: any, onFullfilled: (data: any) => void): NgbModalRef {
        const modalRef = this.open(content);
        modalRef.result.then(onFullfilled, () => {});
        return modalRef;
    }

    /**
     * Open a big modal side dialog displaying the provided content.  This sets up no callbacks
     * - which means clicking away will have no knock-on consequences.
     * @param content - content to display in dialog
     */
    public openBig(content: any): NgbModalRef {
        return this.dialogService.open(content, {
            windowClass: 'side-dialog-big',
            backdropClass: 'side-backdrop',
            backdrop: 'static',
            keyboard: false
        });
    }

    /**
     * Open a big modal side dialog displaying the provided content and providing callbacks when the dialog is closed.
     * Note, the default error callback is set to be empty - this swallows the response triggered by clicking
     * away from the dialog.
     * @param content - content to display in dialog
     * @param onFullfilled - callback to trigger when the dialog is closed - e.g. by a 'Save' button click.
     */
    public openBigWithCallback(content: any, onFullfilled: (data: any) => void): NgbModalRef {
        const modalRef = this.openBig(content);
        modalRef.result.then(onFullfilled, () => {});
        return modalRef;
    }
}