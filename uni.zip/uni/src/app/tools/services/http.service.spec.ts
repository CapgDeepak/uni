import { TestBed, getTestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { NotificationBuilderSet, Notification, LogLevel } from '../common.types';
import { ConfigService } from './config.service';
import { HttpService } from './http.service';
import { FilterService } from './filter.service';
import { NotificationService } from './notification.service';

const baseUrl = 'TEST_URL/';

class MockAppConfigService {
  getAraDctUrl() {
    return baseUrl;
  }
}

class MockNotificationService {
  success() { }
  error () { }
}

describe('HttpService', () => {
  let injector: TestBed;
  let service: HttpService;
  let filterService: FilterService;
  let httpMock: HttpTestingController;
  let notificationService: NotificationService;

  const dummyContent = [
    { login: 'John' },
    { login: 'Doe' }
  ];

  const dummyFilteredContent = [
    { login: 'John' },
  ];

  const dummyDownloadContent: Blob = new Blob([]);

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        { provide: FilterService, useClass: FilterService },
        { provide: ConfigService, useClass: MockAppConfigService },
        { provide: NotificationService, useClass: MockNotificationService },
      ]
    });
    injector = getTestBed();
    service = injector.get(HttpService);
    filterService = injector.get(FilterService);
    notificationService = injector.get(NotificationService);
    httpMock = injector.get(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  describe('get', () => {
    it('should ask for all results', async(done) => {
      service.get('getUrl').subscribe(content => {
        expect(content.length).toBe(2);
        expect(content).toEqual(dummyContent);
        done();
      });

      const req = httpMock.expectOne(`${baseUrl}getUrl`);
      expect(req.request.method).toBe('GET');
      req.flush(dummyContent);
    });

    it('calls handleError when error is caught', async(done) => {
      // Assemble
      const mockErrorResponse = {
        status: 400,
        statusText: 'Bad Request'
      };
      const handleErrorSpy = spyOn(service, 'handleError').and.callThrough();

      // Act
      service.get('getUrl').subscribe(res => {}, err => {
        // Assert
        expect(handleErrorSpy).toHaveBeenCalledTimes(1);
        done();
      });

      httpMock.expectOne(`${baseUrl}getUrl`).flush({}, mockErrorResponse);
    });
  });

  describe('getFiltered', () => {
    it('should ask for filtered results', async(done) => {
      jest.spyOn(filterService, 'filterNullsFromFilter');
      service.getFiltered({filter: 'filterstring'}, 'getUrl').subscribe(content => {
        expect(content.length).toBe(1);
        expect(content).toEqual(dummyFilteredContent);
        expect(filterService.filterNullsFromFilter).toHaveBeenCalled();
        done();
      });

      const req = httpMock.expectOne(`${baseUrl}getUrl?filter=filterstring`);
      expect(req.request.method).toBe('GET');
      req.flush(dummyFilteredContent);
    });

    it('should not change the filter object on filterNullsFromFilter', async(done) => {
      jest.spyOn(filterService, 'filterNullsFromFilter');
      const filter = {filter: null};
      service.getFiltered(filter, 'getUrl').subscribe(content => {
        expect(content.length).toBe(1);
        expect(content).toEqual(dummyFilteredContent);
        expect(filterService.filterNullsFromFilter).toHaveBeenCalled();
        expect(filter.filter).toBeNull();
        done();
      });

      const req = httpMock.expectOne(`${baseUrl}getUrl`);
      expect(req.request.method).toBe('GET');
      req.flush(dummyFilteredContent);
    });

    it('calls handleError when error is caught', async(done) => {
      // Assemble
      const mockErrorResponse = {
        status: 400,
        statusText: 'Bad Request'
      };
      const handleErrorSpy = spyOn(service, 'handleError').and.callThrough();

      // Act
      service.getFiltered({filter: 'filterstring'}, 'getUrl').subscribe(res => {}, err => {
        // Assert
        expect(handleErrorSpy).toHaveBeenCalledTimes(1);
        done();
      });

      httpMock.expectOne(`${baseUrl}getUrl?filter=filterstring`).flush({}, mockErrorResponse);
    });
  });

  describe('downloadFile', () => {
    it('should include filter in url', async(done) => {
      jest.spyOn(filterService, 'filterNullsFromFilter');
      window.URL.createObjectURL = jest.fn();
      service.downloadFile('Url', {filter: 'filterstring'}).subscribe(content => {
        expect(content).toEqual(true);
        expect(filterService.filterNullsFromFilter).toHaveBeenCalledTimes(1);
        expect(window.URL.createObjectURL).toHaveBeenCalledTimes(1);
        done();
      });

      const req = httpMock.expectOne(`${baseUrl}Url?filter=filterstring`);
      expect(req.request.method).toBe('GET');
      req.flush(dummyDownloadContent);
    });

    it('should remove null filters from in url', async(done) => {
      jest.spyOn(filterService, 'filterNullsFromFilter');
      window.URL.createObjectURL = jest.fn();
      service.downloadFile('Url', {filter1: 'filterstring', filter2: null, filter3: null, filter4: 'blah'}).subscribe(content => {
        expect(content).toEqual(true);
        expect(filterService.filterNullsFromFilter).toHaveBeenCalledTimes(1);
        expect(window.URL.createObjectURL).toHaveBeenCalledTimes(1);
        done();
      });

      const req = httpMock.expectOne(`${baseUrl}Url?filter1=filterstring&filter4=blah`);
      expect(req.request.method).toBe('GET');
      req.flush(dummyDownloadContent);
    });

    it('should remove all null filters from in url', async(done) => {
      jest.spyOn(filterService, 'filterNullsFromFilter');
      window.URL.createObjectURL = jest.fn();
      service.downloadFile('Url', {filter1: null, filter2: null, filter3: null}).subscribe(content => {
        expect(content).toEqual(true);
        expect(filterService.filterNullsFromFilter).toHaveBeenCalledTimes(1);
        expect(window.URL.createObjectURL).toHaveBeenCalledTimes(1);
        done();
      });

      const req = httpMock.expectOne(`${baseUrl}Url`);
      expect(req.request.method).toBe('GET');
      req.flush(dummyDownloadContent);
    });

    it('returns false when error is caught', async(done) => {
      // Assemble
      const mockErrorResponse = {
        status: 400,
        statusText: 'Bad Request'
      };
      const handleErrorSpy = spyOn(service, 'handleError').and.callThrough();

      // Act
      service.downloadFile('Url', {filter: 'filterstring'}).subscribe(res => {}, err => {
        // Assert
        expect(err).toBeTruthy();
        expect(err.status).toBe(400);
        expect(handleErrorSpy).toHaveBeenCalledTimes(1);
        done();
      });

      httpMock.expectOne(`${baseUrl}Url?filter=filterstring`).flush(dummyDownloadContent, mockErrorResponse);
    });
  });

  describe('postContent', () => {
    it('should post content', async(done) => {
      service.postContent(dummyContent, 'postUrl').subscribe();
      const req = httpMock.expectOne(`${baseUrl}postUrl`);
      expect(req.request.method).toBe('POST');
      expect(req.request.body).toEqual(dummyContent);
      done();
    });

    it('calls handleError when error is caught', async(done) => {
      // Assemble
      const mockErrorResponse = {
        status: 400,
        statusText: 'Bad Request'
      };
      const handleErrorSpy = spyOn(service, 'handleError').and.callThrough();

      // Act
      service.postContent(dummyContent, 'postUrl').subscribe(res => {}, err => {
        // Assert
        expect(handleErrorSpy).toHaveBeenCalledTimes(1);
        done();
      });

      httpMock.expectOne(`${baseUrl}postUrl`).flush({}, mockErrorResponse);
    });
  });

  describe('putContent', () => {
    it('should put content', async(done) => {
      service.putContent(dummyContent, 'putUrl').subscribe();
      const req = httpMock.expectOne(`${baseUrl}putUrl`);
      expect(req.request.method).toBe('PUT');
      expect(req.request.body).toEqual(dummyContent);
      done();
    });

    it('calls handleError when error is caught', async(done) => {
      // Assemble
      const mockErrorResponse = {
        status: 400,
        statusText: 'Bad Request'
      };
      const handleErrorSpy = spyOn(service, 'handleError').and.callThrough();

      // Act
      service.putContent(dummyContent, 'putUrl').subscribe(res => {}, err => {
        // Assert
        expect(handleErrorSpy).toHaveBeenCalledTimes(1);
        done();
      });

      httpMock.expectOne(`${baseUrl}putUrl`).flush({}, mockErrorResponse);
    });
  });

  describe('handleError', () => {
    it('should raise appropriate default error when no notification builder set is provided', done => {
      // Assemble
      const error = {
        status: 500
      };
      const notificationSpy = jest.spyOn(service, 'raiseNotification');
      const getDefaultSpy = jest.spyOn(service, 'getDefaultNotificationBuilderSet');

      // Act
      service.handleError(error, null).subscribe(() => {}, (err: any) => {
        // Assert that the default notification method has been called
        expect(notificationSpy).toHaveBeenCalledTimes(1);
        expect(getDefaultSpy).toHaveBeenCalledTimes(1);
        // Assert that the input error is returned from the method
        expect(err).toEqual(error);
        done();
      });
    });

    it('should raise appropriate default error when empty notification builder set is provided', done => {
      // Assemble
      const error = {
        status: 500
      };
      const notificationSpy = jest.spyOn(service, 'raiseNotification');
      const getDefaultSpy = jest.spyOn(service, 'getDefaultNotificationBuilderSet');

      // Act
      service.handleError(error, {}).subscribe(() => {}, (err: any) => {
        // Assert that the default notification method has been called
        expect(notificationSpy).toHaveBeenCalledTimes(1);
        expect(getDefaultSpy).toHaveBeenCalledTimes(1);
        // Assert that the input error is returned from the method
        expect(err).toEqual(error);
        done();
      });
    });

    it('should raise appropriate default error when notification builder set is provided without key that matches error code', done => {
      // Assemble
      const error = {
        status: 404
      };
      const notificationSpy = jest.spyOn(service, 'raiseNotification');
      const notificationErrorSpy = jest.spyOn(notificationService, 'error');
      const getDefaultSpy = jest.spyOn(service, 'getDefaultNotificationBuilderSet');

      // Act
      service.handleError(error, ).subscribe(() => {}, (err: any) => {
        // Assert that the default notification method has been called
        expect(notificationSpy).toHaveBeenCalledTimes(1);
        expect(notificationErrorSpy).not.toHaveBeenCalled();
        expect(getDefaultSpy).toHaveBeenCalledTimes(1);
        // Assert that the input error is returned from the method
        expect(err).toEqual(error);
        done();
      });
    });

    it('should raise appropriate custom error when a notification builder set is provided', done => {
      // Assemble
      const error = {
        status: 400,
        error: {
          Message: 'You entered something wrong'
        }
      };
      const title = 'Bad Request';
      const notificationBuilderSet: NotificationBuilderSet = {
        400: (errMessage?: string) => new Notification(title, errMessage , LogLevel.Error)
      };
      const notificationSpy = jest.spyOn(service, 'raiseNotification');
      const notificationErrorSpy = jest.spyOn(notificationService, 'error');
      const getDefaultSpy = jest.spyOn(service, 'getDefaultNotificationBuilderSet');

      // Act
      service.handleError(error, notificationBuilderSet).subscribe(() => {}, (err: any) => {
        // Assert that the default notification method has been called
        expect(notificationSpy).toHaveBeenCalledTimes(1);
        expect(notificationSpy).toHaveBeenCalledWith(notificationBuilderSet, error.status, error.error.Message);
        expect(notificationErrorSpy).toHaveBeenCalledTimes(1);
        expect(notificationErrorSpy).toHaveBeenCalledWith(title, error.error.Message);
        expect(getDefaultSpy).not.toHaveBeenCalled();

        // Assert that the input error is returned from the method
        expect(err).toEqual(error);
        done();
      });
    });
  });

  describe('raiseNotification', () => {
    it('should raise error when supplied LogLevel equal to error', () => {
      // Assemble
      const title = 'Bad Request';
      const errorMessage = 'You did something wrong.';
      const notificationBuilderSet: NotificationBuilderSet = {
        400: (errMessage?: string) => new Notification(title, errMessage , LogLevel.Error)
      };
      const notificationErrorSpy = jest.spyOn(notificationService, 'error');

      // Act
      service.raiseNotification(notificationBuilderSet, 400, errorMessage);

      // Assert
      expect(notificationErrorSpy).toHaveBeenCalledTimes(1);
      expect(notificationErrorSpy).toHaveBeenCalledWith(title, errorMessage);
    });

    it('should raise success when supplied LogLevel equal to Success', () => {
      // Assemble
      const title = 'OK';
      const responseMessage = 'You did something right.';
      const notificationBuilderSet: NotificationBuilderSet = {
        200: (message?: string) => new Notification(title, message , LogLevel.Success)
      };
      const notificationSuccessSpy = jest.spyOn(notificationService, 'success');

      // Act
      service.raiseNotification(notificationBuilderSet, 200, responseMessage);

      // Assert
      expect(notificationSuccessSpy).toHaveBeenCalledTimes(1);
      expect(notificationSuccessSpy).toHaveBeenCalledWith(title, responseMessage);
    });
  });
});
