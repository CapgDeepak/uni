import { Injectable } from '@angular/core';

import { HttpService } from './http.service';
import { PhraseSimpleModel } from '../shared-types/phrase.types';
import { Observable, of } from 'rxjs';
import { UrlEndpoint, DetailLevels } from '../constants';
import { DetailLevel } from '../common.types';

@Injectable()
export class PhraseService {
  constructor(private httpService: HttpService) { }

  /**
   * Gets a collection of simplified models, representing all phrases that can
   * be linked against a phrase with the specified detail level and topic.
   * @param detailLevelId the ID of the detail level for the phrase to link against.
   * @param topicId the ID of the topic for the phrase to link against.
   */
  public getPhrasesToLinkAgainst(detailLevelId: number, topicId: number): Observable<PhraseSimpleModel[]> {
    if ((!detailLevelId && detailLevelId != 0)) {
      return of([]);
    }

    return this.httpService.getFiltered(
                          {
                            detailLevelId: detailLevelId.toString(),
                            topicId: topicId.toString(),
                          },
                          UrlEndpoint.Phrases_GetPhrasesToLinkAgainst);
  }

  /**
   * Returns true if the phrase is Detailed. False otherwise.
   * @param detailLevelId the ID of the phrase for which to check the detail level.
   * @param detailLevels the collection of all detail levels to check against.
   */
  public isDetailedPhrase(detailLevelId: number, detailLevels: DetailLevel[]): boolean {
    const detailedDetailLevel = detailLevels && detailLevels.filter(dl => dl.description == DetailLevels.Detailed);
    return !!detailedDetailLevel && !!detailedDetailLevel.length && (detailedDetailLevel[0].id == detailLevelId);
  }
}