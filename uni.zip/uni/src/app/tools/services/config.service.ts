import { Injectable } from '@angular/core';
import { HttpBackend, HttpClient } from '@angular/common/http';

export class EndPointProviders {
  AraDct: string;
  AraAdminDev: string;
  AraAdminQA: string;
  AraAdminTest: string;
  AraAdminRegression: string;
  AraAdminTraining: string;
  AraAdminProduction: string;
}

export class MsalConfig {
  tenant: string;
  clientIdDev: string;
  clientIdTest: string;
  clientIdQA: string;
  clientIdRegression: string;
  clientIdTraining: string;
  clientIdProduction: string;
  redirectUri: string;
}

export class AppConfigSettings {
  constructor(public providers: EndPointProviders, public msalConfig: MsalConfig) {
  }
}

@Injectable()
export class ConfigService {
  public appConfig: any;
  private httpClient: HttpClient;

  constructor(httpBackend: HttpBackend) {
    this.httpClient = new HttpClient(httpBackend);
  }

  /**
   * Loads the app config data from the endPoints.json file.
   */
  loadAppConfig() {
    return this.httpClient.get('/assets/json/endPoints.json', { responseType: 'json' })
      .toPromise()
      .then(data => {
        this.appConfig = data;
      });
  }

  getConfig() {
    return this.appConfig;
  }

  getAraAdminUrl() {
    debugger;
    const env = window.location.origin.split('-').pop().split('.')[0];
    if (env == "dev") {
      return this.appConfig.providers.AraAdminDev;
    }
    else if (env == "test") {
      return this.appConfig.providers.AraAdminTest;
    }
    else if (env == "qa") {
      return this.appConfig.providers.AraAdminQA;
    }
    else if (env == "regression") {
      return this.appConfig.providers.AraAdminRegression;
    }
    else if (env == "training") {
      return this.appConfig.providers.AraAdminTraining;
    }
    else {
      return this.appConfig.providers.AraAdminProduction;
    }
  }

  getAraDctUrl() {
    return this.appConfig.providers.AraDct;
  }

  getMsalConfigTenant() {
    return this.appConfig.msalConfig.tenant;
  }

  getMsalClientId() {
    debugger;
    const env = window.location.origin.split('-').pop().split('.')[0];
    if (env == "dev") {
      return this.appConfig.msalConfig.clientIdDev;
    }
    else if (env == "test") {
      return this.appConfig.msalConfig.clientIdTest;
    }
    else if (env == "qa") {
      return this.appConfig.msalConfig.clientIdQA;
    }
    else if (env == "regression") {
      return this.appConfig.msalConfig.clientIdRegression;
    }
    else if (env == "training") {
      return this.appConfig.msalConfig.clientIdTraining;
    }
    else {
     // return this.appConfig.msalConfig.clientIdProduction;
     return this.appConfig.msalConfig.clientIdDev;
    }
  }
}
