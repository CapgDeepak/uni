import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Observable } from 'rxjs';
import { HttpBackend, HttpClient } from '@angular/common/http';

import { ConfigService } from './config.service';

const json: any = {
  providers: {
    AraDct: "https://pref-dct.com/services"
  },
  msalConfig: {
    tenant: 'f66fae02-5d36-495b-bfe0-78a6ff9f8e6e',
    clientId: '0cfe1f98-00f0-4087-9eb1-bc077b311332'
  }
};

xdescribe('ConfigService', () => {
  let configService: ConfigService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        ConfigService,
        HttpBackend,
        // setup the return observable.
        {
          provide: HttpClient, useValue: {
            get: jest.fn(() => new Observable(observer => {
              observer.next(json);
              observer.complete();
            }))
          }
        },
      ]
    });

    configService = TestBed.get(ConfigService);
  });

  it('should be created', inject([ConfigService], (service: ConfigService) => {
    expect(service).toBeTruthy();
  }));

  describe('loadAppConfig method', () => {
    it('should not throw', () => {
      expect(() => configService.loadAppConfig()).not.toThrow();
    });
  });

  describe('get methods', () => {
    beforeEach(() => {
      configService.loadAppConfig();
    });

    it('- getConfig should return expected json', () => {
      expect(configService.getConfig()).toEqual(json);
    });

    it('- getAraDctUrl should return expected json', () => {
      expect(configService.getAraDctUrl()).toEqual(json.providers.AraDct);
    });

    it('- getMsalClientId should return expected json', () => {
      expect(configService.getMsalClientId()).toEqual(json.msalConfig.clientId);
    });

    it('- getMsalConfigTenant should return expected json', () => {
      expect(configService.getMsalConfigTenant()).toEqual(json.msalConfig.tenant);
    });
  });
});
