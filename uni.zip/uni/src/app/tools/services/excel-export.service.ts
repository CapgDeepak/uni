import { Injectable } from '@angular/core';
import { ConfirmationDialogService } from '../../shared-components/confirmation-dialog/confirmation-dialog.service';
import { DialogService } from './dialog.service';
import { HttpService } from './http.service';
import { BatchExportDialogComponent } from './../../shared-components/batch-export-dialog/batch-export-dialog.component';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ExcelExportLimits } from '../constants';

@Injectable({
  providedIn: 'root'
})
export class ExcelExportService {
  constructor(
    private confirmationDialogService: ConfirmationDialogService,
    private dialogService: DialogService,
    private httpService: HttpService
    ) { }

  exportContent(dataType: string, urlEndpoint: string, filter: any = {}, isBatchable: boolean): Observable<void> {
    const url = `${urlEndpoint}/ExcelExport/${dataType}`;
    const countUrl = `${urlEndpoint}/ExcelExport/Get${dataType}Count`;
    return this.httpService.getFiltered(filter, countUrl).pipe(map(dataCount => {
      // Default to export everything in one go - if we have to use batching, this value will be updated by the dialog.
      if (!filter) {
        filter = {};
      }
      filter.startIndex = 0;
      filter.endIndex = dataCount;
      if (dataCount >= ExcelExportLimits.WarningLimit) {
        if (dataCount > ExcelExportLimits.BatchLimit && isBatchable) {
          this.displayBatchDialog(dataCount, filter, url);
        } else {
          this.confirmationDialogService.question('Confirmation', 'Are you sure you want to export this selection? This may take a while.')
            .then(result => {
              if (result == true) {
                this.downloadContent(url, filter);
              }
            });
        }
      } else {
        this.downloadContent(url, filter);
      }
    }));
  }

  private downloadContent(url: string, filter: any) {
    this.httpService.downloadFile(url, filter).subscribe();
  }

  private displayBatchDialog(dataCount: number, filter: any, url: string): Promise<any> {
    const modalRef = this.dialogService.open(BatchExportDialogComponent, {
        size: 'sm',
        backdrop: 'static',
        centered: true
    });

    modalRef.componentInstance.totalCount = dataCount;
    modalRef.componentInstance.filter = filter;
    modalRef.componentInstance.url = url;
    return modalRef.result;
  }
}
