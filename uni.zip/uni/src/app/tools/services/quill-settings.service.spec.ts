import { TestBed, inject } from '@angular/core/testing';

import { QuillSettingsService } from './quill-settings.service';

describe('QuillSettingsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [QuillSettingsService]
    });
  });

  it('should be created', inject([QuillSettingsService], (service: QuillSettingsService) => {
    expect(service).toBeTruthy();
  }));
});
