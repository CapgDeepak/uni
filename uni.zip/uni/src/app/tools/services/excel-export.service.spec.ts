import { TestBed, getTestBed } from '@angular/core/testing';

import { ExcelExportService } from './excel-export.service';
import { HttpService } from './http.service';
import { Observable } from 'rxjs';
import { ConfirmationDialogService } from '../../shared-components/confirmation-dialog/confirmation-dialog.service';
import { DialogService } from './dialog.service';
import { CUSTOM_ELEMENTS_SCHEMA, Component } from '@angular/core';

let dataCount = 0;
let confirmDialog = true;
const fileError = false;

class HttpServiceMock {
  getFiltered() {
    return new Observable( observer => {
      observer.next(dataCount);
      observer.complete();
    });
  }
  downloadFile() {
    if (fileError == false) {
      return new Observable( observer => {
        observer.next();
        observer.complete();
      });
    } else {
      return new Observable( observer => {
        observer.error();
        observer.complete();
      });
    }
  }
}

class ConfirmationDialogServiceMock {
  question() {
    return new Promise((resolve) => {
      return resolve(confirmDialog);
    });
  }
}

class DialogServiceMock {
  open() {
    return {componentInstance: {}};
  }
}

@Component({
  selector: 'app-batch-export-dialog',
  template: '<p>Not a component</p>'
})
class BatchExportDialogComponent {}

describe('ExcelExportService', () => {
  let service: ExcelExportService;
  let httpService: HttpService;
  let confirmationDialogService: ConfirmationDialogService;
  let dialogService: DialogService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [BatchExportDialogComponent],
      providers: [
        { provide: DialogService, useClass: DialogServiceMock },
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: ConfirmationDialogService, useClass: ConfirmationDialogServiceMock },
      ]
    });
    const injector = getTestBed();
    service = injector.get(ExcelExportService);
    httpService = injector.get(HttpService);
    confirmationDialogService = injector.get(ConfirmationDialogService);
    dialogService = injector.get(DialogService);
  }
  );

  it('shows confirmation if needed and downloads file on confirm', async(done) => {
    dataCount = 1000;
    confirmDialog = true;
    jest.spyOn(httpService, 'getFiltered');
    jest.spyOn(confirmationDialogService, 'question');
    jest.spyOn(httpService, 'downloadFile');
    const filter = {endIndex: dataCount, startIndex: 0};

    service.exportContent('Type', 'url', filter, false).subscribe(() => {
      expect(httpService.getFiltered).toHaveBeenCalledWith(filter, 'url/ExcelExport/GetTypeCount');
      expect(confirmationDialogService.question).toHaveBeenCalled();
      done();
    });
  });

  it('shows confirmation if needed and does not download file on non-confirm', async(done) => {
    dataCount = 1000;
    confirmDialog = false;
    jest.spyOn(httpService, 'getFiltered');
    jest.spyOn(confirmationDialogService, 'question');
    jest.spyOn(httpService, 'downloadFile');

    const filter = {endIndex: dataCount, startIndex: 0};
    service.exportContent('Type', 'url', filter, false).subscribe(() => {
      expect(httpService.getFiltered).toHaveBeenCalledWith(filter, 'url/ExcelExport/GetTypeCount');
      expect(confirmationDialogService.question).toHaveBeenCalled();
      expect(httpService.downloadFile).toHaveBeenCalledTimes(0);
      done();
    });
  });

  it('does not show confirmation if not needed and downloads file', async(done) => {
    dataCount = 0;
    jest.spyOn(httpService, 'getFiltered');
    jest.spyOn(confirmationDialogService, 'question');
    jest.spyOn(httpService, 'downloadFile');

    const filter = {endIndex: 0, startIndex: 0};
    service.exportContent('Type', 'url', filter, false).subscribe(() => {
      expect(httpService.getFiltered).toHaveBeenCalledWith(filter, 'url/ExcelExport/GetTypeCount');
      expect(confirmationDialogService.question).toHaveBeenCalledTimes(0);
      done();
    });
  });

  it('shows confirmation if needed and downloads file on confirm, with filter', async(done) => {
    dataCount = 1000;
    confirmDialog = true;
    const filter = {text: 'filterText'};
    jest.spyOn(httpService, 'getFiltered');
    jest.spyOn(confirmationDialogService, 'question');
    jest.spyOn(httpService, 'downloadFile');

    service.exportContent('Type', 'url', filter, false).subscribe(() => {
      expect(httpService.getFiltered).toHaveBeenCalledWith(filter, 'url/ExcelExport/GetTypeCount');
      expect(confirmationDialogService.question).toHaveBeenCalled();
      done();
    });
  });

  it('opens batch dialog if number of rows exceeds limit', async(done) => {
    dataCount = 50001;
    const filter = {text: 'filterText'};
    jest.spyOn(dialogService, 'open');

    service.exportContent('Type', 'url', filter, true).subscribe(() => {
      expect(dialogService.open).toHaveBeenCalled();
      done();
    });
  });

  it('does not open batch dialog if number of rows exceeds limit but not batched', async(done) => {
    dataCount = 50001;
    const filter = {text: 'filterText'};
    jest.spyOn(dialogService, 'open');

    service.exportContent('Type', 'url', filter, false).subscribe(() => {
      expect(dialogService.open).toHaveBeenCalledTimes(0);
      done();
    });
  });

  it('sets start and end indexes correctly when not using batches', async(done) => {
    dataCount = 50001;
    const filter = {text: 'filterText', startIndex: 9, endIndex: 6 };
    jest.spyOn(dialogService, 'open');

    service.exportContent('Type', 'url', filter, false).subscribe(() => {
      expect(dialogService.open).toHaveBeenCalledTimes(0);
      expect(filter.startIndex).toBe(0);
      expect(filter.endIndex).toBe(dataCount);
      done();
    });
  });
});
