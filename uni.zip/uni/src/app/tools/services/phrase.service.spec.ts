import { TestBed, getTestBed } from '@angular/core/testing';
import { Observable } from 'rxjs';

import { HttpService } from './http.service';
import { PhraseService } from './phrase.service';
import { DetailLevel } from '../common.types';
import { PhraseSimpleModel } from '../shared-types/phrase.types';

const phrasesToLinkAgainst: PhraseSimpleModel[] = [
    {
        phraseId: 1,
        nr: 51,
    },
    {
        phraseId: 2,
        nr: 52,
    },
];
class HttpServiceMock {
    getFiltered() {
        return new Observable( observer => {
            observer.next(phrasesToLinkAgainst);
            observer.complete();
          });
    }
}
const detailLevels: DetailLevel[] = [
    {
        id: 0,
        description: "Standard",
    },
    {
        id: 1,
        description: "Detailed",
    },
];

describe('PhraseService', () => {
    let service: PhraseService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                PhraseService,
                {provide: HttpService, useClass: HttpServiceMock}
            ]
        });

        const injector = getTestBed();
        service = injector.get(PhraseService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    describe('getPhrasesToLinkAgainst', () => {
        it('calls httpService getFiltered with appropriate URL and payload', done => {
            // Act
            service.getPhrasesToLinkAgainst(5, 6).subscribe(result => {
                // Assert
                expect(result).toEqual(phrasesToLinkAgainst);
                done();
            });
        });
    });

    describe('isDetailedPhrase', () => {
        it('returns true when phrase is detailed', () => {
            // Act
            const result = service.isDetailedPhrase(1, detailLevels);

            // Assert
            expect(result).toEqual(true);
        });

        it('returns false when phrase is not detailed', () => {
            // Act
            const result = service.isDetailedPhrase(0, detailLevels);

            // Assert
            expect(result).toEqual(false);
        });

        it('returns false when detail level not found', () => {
            // Act
            const result = service.isDetailedPhrase(5, detailLevels);

            // Assert
            expect(result).toEqual(false);
        });

        it('returns false when empty detail levels provided', () => {
            // Act
            const result = service.isDetailedPhrase(5, []);

            // Assert
            expect(result).toEqual(false);
        });
    });
});