import { TestBed, getTestBed } from '@angular/core/testing';
import each from 'jest-each';

import { FilterService } from './filter.service';

describe('FilterService', () => {
  let injector: TestBed;
  let service: FilterService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FilterService]
    });
    injector = getTestBed();
    service = injector.get(FilterService);
  });

  describe('isKeyCodeFilterable', () => {
    each([46, 55, 90, 106, 109, 111, 186, 191, 222, 8, 13, 32]).it ('returns true for a valid keyCode', (keyCode) => {
      expect(service.isKeyCodeFilterable(keyCode)).toBeTruthy();
    });

    each([-1, 0, 5, 9, 45, 91, 96, 112, 185, 223, 9999, 2.5]).it ('returns false for an invalid keyCode', (keyCode) => {
      expect(service.isKeyCodeFilterable(keyCode)).toBeFalsy();
    });
  });

  describe('filterNullsFromFilter', () => {
    it('does not filter non-null objects', () => {
      let filter = {};
      filter['filter1'] = 'one';
      filter['filter2'] = 2;

      filter = service.filterNullsFromFilter(filter);
      expect(filter['filter1']).toEqual('one');
      expect(filter['filter2']).toEqual(2);
    });

    it('does filters null objects', () => {
      let filter = {};
      filter['filter1'] = null;
      filter['filter2'] = 2;
      filter['filter3'] = null;
      filter['filter4'] = 'filter';

      filter = service.filterNullsFromFilter(filter);
      expect(Object.keys(filter).length).toEqual(2);
      expect(filter['filter2']).toEqual(2);
      expect(filter['filter4']).toEqual('filter');
    });
  });
});
