import { Injectable } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

@Injectable({
    providedIn: 'root'
})
export class DialogService {
    constructor(private modalService: NgbModal) { }

    public open(content: any, options?: NgbModalOptions): NgbModalRef {
        const modal = this.modalService.open(content, options);

        // support stacked modals
        modal.result.catch(() => { })
            .then(() => {
                if (document.querySelector('body > .modal')) {
                    document.body.classList.add('modal-open');
                }
            });
        return modal;
    }
}