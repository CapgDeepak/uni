import { Injectable } from '@angular/core';
import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';

@Injectable()
export class LinkService {
  constructor(private alertDialogService: AlertDialogService) { }

  openLink(url: string) {
    if (url) {
        if (url.indexOf("://") > 0) {
            url = url.trim();
            window.open(url, "_blank");
        }
        else {
            this.alertDialogService.alert("Error", "This link cannot be opened. URLs should be of the form 'https://www.example.com'.");
        }
    }
}
}