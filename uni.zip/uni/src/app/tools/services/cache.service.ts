import { Injectable } from "@angular/core";

import { DetailLevel, RegulatoryMarketHierarchyItem } from './../common.types';
import { HttpService } from './http.service';
import { UrlEndpoint } from '../constants';

@Injectable({
    providedIn: 'root'
})
export class CacheService {
    constructor(
        private httpService: HttpService) { }

    private _detailLevels: DetailLevel[] | null = null;
    getDetailLevels(): Promise<DetailLevel[]> {
        return new Promise<DetailLevel[]>((resolve, reject) => {
            if (!this._detailLevels || !this._detailLevels.length) {
                this.httpService.get(UrlEndpoint.DetailLevelLookup_Items).subscribe(result => {
                    this._detailLevels = result;
                    resolve(this._detailLevels);
                }, error => {
                    console.error("CacheService.getDetailLevels", error);
                    reject(error);
                });
            }
            else {
                resolve(this._detailLevels);
            }
        });
    }

    private _regulatoryMarkets: RegulatoryMarketHierarchyItem[] | null;
    getRegulatoryMarkets(): Promise<RegulatoryMarketHierarchyItem[]> {
        // this._regulatoryMarkets = null;
        return new Promise<RegulatoryMarketHierarchyItem[]>((resolve, reject) => {
            if (this._regulatoryMarkets == null) {
                this.httpService.get(UrlEndpoint.RegulatoryMarketNavigator_AllItems).subscribe(result => {
                    this._regulatoryMarkets = result;
                    resolve(this._regulatoryMarkets);
                }, error => {
                    console.error("CacheService.getRegulatoryMarkets", error);
                    reject(error);
                });
            }
            else {
                resolve(this._regulatoryMarkets);
            }
        });
    }
}
