import { TestBed, inject } from '@angular/core/testing';

import { DialogService } from './dialog.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

class NgbModalMock { }

describe('DialogService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        DialogService,
        { provide: NgbModal, useClass: NgbModalMock }
      ]
    });
  });

  it('should be created', inject([DialogService], (service: DialogService) => {
    expect(service).toBeTruthy();
  }));
});
