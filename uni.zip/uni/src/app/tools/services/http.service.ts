import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { saveAs as importedSaveAs } from "file-saver";
import { map, catchError } from 'rxjs/operators';

import { NotificationBuilderSet, Notification, LogLevel } from '../common.types';
import { ConfigService } from './config.service';
import { FilterService } from './filter.service';
import { NotificationService } from './notification.service';
import { HelpDetailsList } from '../../navmenu/navmenu.types';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(
    private http: HttpClient,
    private filterService: FilterService,
    private configService: ConfigService,
    private notificationService: NotificationService) {
  }

  get(getUrl: string, notificationBuilderSet?: NotificationBuilderSet): Observable<any> {
    const baseUrl = this.configService.getAraDctUrl();
    return this.http.get(`${baseUrl}${getUrl}`).pipe(map(result => {
      return result;
    }), catchError(error => {
      return this.handleError(error, notificationBuilderSet);
    }));
  }

  getWithBaseUrl(baseUrl: string, getUrl: string, notificationBuilderSet?: NotificationBuilderSet): Observable<any> {
    return this.http.get(`${baseUrl}/${getUrl}`).pipe(map(result => {
      return result;
    }), catchError(error => {
      return this.handleError(error, notificationBuilderSet);
    }));
  }

  getdownload(getUrl: string, notificationBuilderSet?: NotificationBuilderSet): Observable<any> {
    const baseUrl = this.configService.getAraDctUrl();
    return this.http.get(`${baseUrl}${getUrl}`, { responseType: 'blob' }).pipe(map(result => {
      return result;
    }), catchError(error => {
      return this.handleError(error, notificationBuilderSet);
    }));
  }
  getFiltered(filter: { [param: string]: string | string[] }, getUrl: string, notificationBuilderSet?: NotificationBuilderSet): Observable<any> {
    // Before sending request, filter out all null values in filter,
    // as these are converted to strings in the request.
    // Clone the filter here, as changing it results in weird changes elsewhere.
    const newFilter = this.filterService.filterNullsFromFilter({ ...filter });
    const baseUrl = this.configService.getAraDctUrl();
    return this.http.get(`${baseUrl}${getUrl}`, { params: newFilter }).pipe(map(result => {
      return result;
    }), catchError(error => {
      return this.handleError(error, notificationBuilderSet);
    }));
  }

  postContent(content: any, postUrl: string, notificationBuilderSet?: NotificationBuilderSet): Observable<any> {
    const baseUrl = this.configService.getAraDctUrl();
    return this.http.post(`${baseUrl}${postUrl}`, content).pipe(map(result => {
      return result;
    }), catchError(error => {
      return this.handleError(error, notificationBuilderSet);
    }));
  }

  putContent(content: any, putUrl: string, notificationBuilderSet?: NotificationBuilderSet): Observable<any> {
    const baseUrl = this.configService.getAraDctUrl();
    return this.http.put(`${baseUrl}${putUrl}`, content).pipe(map(result => {
      return result;
    }), catchError(error => {
      return this.handleError(error, notificationBuilderSet);
    }));
  }

  getPromise(getUrl: string): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      this.get(getUrl).toPromise().then(result => {
        resolve(result);
      }).catch(error => {
        reject(error);
      });
    });
  }

  getFilteredPromise(filter: { [param: string]: string | string[] }, getUrl: string): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      this.getFiltered(filter, getUrl).toPromise().then(result => {
        resolve(result);
      }).catch(error => {
        reject(error);
      });
    });
  }

  postContentPromise(content: any, getUrl: string, notificationBuilderSet?: NotificationBuilderSet): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      this.postContent(content, getUrl, notificationBuilderSet).toPromise().then(result => {
        resolve(result);
      }).catch(error => {
        reject(error);
      });
    });
  }

  postContentPromisee(content: { supportsection: HelpDetailsList, fileToUpload: any }, getUrl: string, notificationBuilderSet?: NotificationBuilderSet): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      this.postContent(content, getUrl, notificationBuilderSet).toPromise().then(result => {
        resolve(result);
      }).catch(error => {
        reject(error);
      });
    });
  }

  downloadFile(url: string, filter: any, notificationBuilderSet?: NotificationBuilderSet): Observable<boolean> {
    // Before sending request, filter out all null values in filter, as these are
    // converted to strings in the request - leading to model validation failure on server.
    // Clone the filter here, as changing it results in weird changes elsewhere.
    const newFilter = this.filterService.filterNullsFromFilter({ ...filter });
    const baseUrl = this.configService.getAraDctUrl();
    return this.http.get(
      `${baseUrl}${url}`,
      {
        observe: 'response',
        responseType: 'blob',
        params: newFilter
      })
      .pipe(
        map((response: HttpResponse<Blob>) => {
          const blob = response.body;
          const filename = this.getFileNameFromHeader(response.headers);
          importedSaveAs(blob, filename);
          return true;
        }), catchError(error => {
          return this.handleError(error, notificationBuilderSet);
        })
      );
  }

  private getFileNameFromHeader(headers: HttpHeaders): string {
    const header = headers.get('content-disposition');
    if (!header) {
      return null;
    }

    const result: string = header.split(";")[1].trim().split("=")[1];
    return result.replace(/"/g, '');
  }

  /**
   * A method to handle errors returned by Http calls in this service.
   * The method raises a toast for 401, 403 and 500 errors.
   * @param error The error to handle N.B. We are being purposefully not
   *              type safe here, as the error could be a large number of types,
   *              and we would not like the application to fall over and not log
   *              the error.
   * @param notificationBuilderSet A set of notification builders that allow
   *                               the call site to generate custom notifications
   *                               at the point of use.
   */
  handleError(
    error: any,
    notificationBuilderSet?: NotificationBuilderSet
  ): Observable<any> {
    // If a notification set has not been provided OR if it is empty
    // OR if it has been provided but does not contain a key that matches
    // the error status, then use the default notification set instead.
    // Otherwise, use the provided builder set.
    if (!(notificationBuilderSet && Object.keys(notificationBuilderSet) &&
      Object.keys(notificationBuilderSet).some(k => k == error.status.toString()))) {
      notificationBuilderSet = this.getDefaultNotificationBuilderSet();
    }
    this.raiseNotification(notificationBuilderSet, error.status, this.getErrorMessage(error));

    // Return the error to the method that called it
    return throwError(error);
  }

  /**
   * Raises a toast style notification based on the provided notification builder set
   * @param notificationBuilderSet a set of notification builders. This allows for
   *                               customisation of the notifications for any http response.
   * @param statusCode the status code of the Http response to raise a notification for.
   * @param errorMessage the error message to display
   */
  raiseNotification(notificationBuilderSet: NotificationBuilderSet, statusCode: number, errorMessage: string): void {
    // Depending on the log level of the notification option object,
    // raise an error or success toast
    const notification: Notification = notificationBuilderSet[statusCode] && notificationBuilderSet[statusCode](errorMessage);
    if (notification) {
      switch (notification.logLevel) {
        case LogLevel.Error: {
          this.notificationService.error(
            notification.title,
            notification.message
          );
          break;
        }
        case LogLevel.Success: {
          this.notificationService.success(
            notification.title,
            notification.message
          );
          break;
        }
        default: {
          break;
        }
      }
    }
  }

  /**
   * Attempts to grab the error message from the provided error response.
   * We attempt to grab the message via error.error.message first -
   * this is how errors will be stored when backend errors are dealt
   * with by the global exception handler. Failing this, we grab
   * error.message - this is how errors will be stored in the old regime,
   * where Ok(), BadRequest() results etc. are stored.
   */
  private getErrorMessage(response: any): string {
    if (response && response.error) {
      return response.error.Message || response.error;
    } else {
      return response.message || '';
    }
  }

  /**
   * Raises a default notification based on the provided Http status code
   * @param errorStatus the status code of the Http response for which to
   *                    raise a notification.
   */
  getDefaultNotificationBuilderSet(): NotificationBuilderSet {
    // Generate the default notification builder set
    return {
      401: (error) => new Notification('Unauthorized', error || 'You are not authorized to use this application. Please contact an administrator for assistance.', LogLevel.Error),
      // 403: (error) => new Notification('Forbidden', error || 'You are not permitted to perform this action. Please contact an administrator for assistance.', LogLevel.Error),
      500: (error) => new Notification('Unexpected Error', error || 'An unexpected error occured. If this problem persists, please contact an administrator.', LogLevel.Error),
      504: (error) => new Notification('Server Error', error || 'The server appears to be down. Please refresh the page and try again.', LogLevel.Error),
    };
  }
}
