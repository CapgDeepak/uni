import { Injectable } from '@angular/core';

const numberLetterStart = 46;
const numberLetterEnd = 90;
const numpadStart = 97;
const numpadEnd = 111;
const punctuationStart = 186;
const punctuationEnd = 222;
const backspaceKey = 8;
const enterKey = 13;
const spaceKey = 32;

@Injectable()
export class FilterService {
  isKeyCodeFilterable(keyCode: Number): boolean {
    if ((keyCode >= numberLetterStart && keyCode <= numberLetterEnd)
      || (keyCode >= numpadStart && keyCode <= numpadEnd)
      || (keyCode >= punctuationStart && keyCode <= punctuationEnd)
      || (keyCode == backspaceKey || keyCode == enterKey || keyCode == spaceKey)) {
        return true;
    }
    return false;
  }

  filterNullsFromFilter(filter: {[param: string]: string | string[]}) {
    for (const key in filter) {
      if (filter[key] == null) {
        delete filter[key];
      }
    }
    return filter;
  }
}