import { TestBed, getTestBed } from '@angular/core/testing';
import { LinkService } from './link.service';
import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';

class AlertDialogServiceMock {
  alert() {}
}

describe('LinkService', () => {
  let injector: TestBed;
  let service: LinkService;
  let alertDialogService: AlertDialogService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        LinkService,
        {provide: AlertDialogService, useClass: AlertDialogServiceMock}
      ]
    });
    injector = getTestBed();
    service = injector.get(LinkService);
    alertDialogService = injector.get(AlertDialogService);
  });

  describe('openLink', () => {
    it('does nothing with a null link', () => {
      alertDialogService.alert = jest.fn();
      window.open = jest.fn();
      service.openLink(null);
      expect(alertDialogService.alert).toHaveBeenCalledTimes(0);
      expect(window.open).toHaveBeenCalledTimes(0);
    });

    it('raises alert with a broken link', () => {
      alertDialogService.alert = jest.fn();
      window.open = jest.fn();
      service.openLink("notalink.com");
      expect(alertDialogService.alert).toHaveBeenCalledTimes(1);
      expect(window.open).toHaveBeenCalledTimes(0);
    });

    it('opens link with a valid link', () => {
      alertDialogService.alert = jest.fn();
      window.open = jest.fn();
      const url = "http://www.alink.com";
      service.openLink(url);
      expect(alertDialogService.alert).toHaveBeenCalledTimes(0);
      expect(window.open).toHaveBeenCalledWith(url, "_blank");
    });
  });
});