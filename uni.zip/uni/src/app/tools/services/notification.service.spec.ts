import { TestBed, inject } from '@angular/core/testing';

import { NotificationService } from './notification.service';
import { ToasterService } from 'angular2-toaster';

class ToasterServiceMock { }

describe('NotificationService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                NotificationService,
                { provide: ToasterService, useClass: ToasterServiceMock }
            ]
        });
    });

    it('should be created', inject([NotificationService], (service: NotificationService) => {
        expect(service).toBeTruthy();
    }));
});