import { Injectable } from '@angular/core';
import { ToasterService } from 'angular2-toaster';
import { SaveResult } from '../common.types';

@Injectable()
export class NotificationService {
    constructor(
        private toasterService: ToasterService) {
    }

    public process<T extends SaveResult>(result: T, title?: string) {
        if (result) {
            this.toasterService.pop(
                result.success ? 'success' : 'error',
                title,
                result.message);
        }
    }

    public success(title: string, message: string) {
        this.toasterService.pop('success', title, message);
    }

    public error(title: string, message: string) {
        this.toasterService.pop('error', title, message);
    }
}