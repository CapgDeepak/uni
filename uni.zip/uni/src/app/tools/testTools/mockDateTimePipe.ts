import { Pipe, PipeTransform } from "@angular/core";

@Pipe({name: 'araDateTime'})
export class MockDateTimePipe implements PipeTransform {
    transform(value: number): number {
        return value;
    }
}