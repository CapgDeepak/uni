// Deprecated: use string constants for improved readability and consistency
export enum PhraseStatusId {
    ToBeApproved = 0,
    Approved = 1,
    Rejected = 2
}

export enum PhraseChangeType {
    None = "",
    Minor = "Minor",
    Significant = "Significant"
}

export enum MarketWorkListType {
    Assess = "assess",
    Review = "review",
    Create = "create"
}

export enum PhraseStatus {
    ToBeApproved = "ToBeApproved",
    Approved = "Approved",
    Rejected = "Rejected"
}

const ToBeApprovedString: string = 'To be approved';
export function PhraseStatusToString(phraseStatus: PhraseStatus | string): string {
    if (!phraseStatus || phraseStatus == PhraseStatus.ToBeApproved) {
        return ToBeApprovedString;
    }
    return phraseStatus;
}

export enum AssignmentStatus {
    ToBeAssessed = "ToBeAssessed",
    Accepted = "Accepted",
    NotRelevant = "NotRelevant",
    DeclinedTopic = "DeclinedTopic"
}

const ToBeAssessedString: string = 'To be assessed';
const NotRelevantString: string = 'Not relevant';
const ApprovedAndAcceptedString: string = 'Approved and accepted';
export function AssignmentStatusToString(assignmentStatus: AssignmentStatus | string): string {
    if (!assignmentStatus || assignmentStatus === AssignmentStatus.ToBeAssessed) {
        return ToBeAssessedString;
    } else if (assignmentStatus === AssignmentStatus.Accepted) {
        return ApprovedAndAcceptedString;
    } else if (assignmentStatus == AssignmentStatus.NotRelevant) {
        return NotRelevantString;
    }
    return assignmentStatus;
}

export class TabType {
    public static readonly StatementsTabId: string = "statements";
    public static readonly TabularInputsTabId: string = "tabularInputs";
}

export enum DetailLevels {
    Standard = "Standard",
    Detailed = "Detailed",
    InternalRA = "Internal RA",
}

export class PhraseType {
    public static readonly Statement: string = "Statement";
    public static readonly StatementId: number = 0;
    public static readonly TabularInput: string = "TabularInput";
    public static readonly TabularInputId: number = 1;
}

export enum TopicLinkStatus {
    Accepted = "Accepted",
    Declined = "Declined"
}

export enum ColumnSortOrder {
    Descending = "col-sort-desc",
    Ascending = "col-sort-asc"
}

export enum ExcelExportLimits {
    WarningLimit = 1000,
    BatchLimit = 50000
}

export enum sortType {
    na = '',
    default = 'fa fa-ellipsis-v',
    asc = 'fa fa-sort-asc',
    desc = 'fa fa-sort-desc'
  }

export const ToBeAssessedStatus: string = 'ToBeAssessed';

export const EmptyTabularInputValueWarning = 'Enter valid tabular input value before accepting assignment';


export const MISSING_CHANGE_TYPE_ERROR = 'Please specify a change type for the modification made.';
export const MISSING_CHANGE_ERROR = 'No changes currently requiring a save.';
export const MISSING_PERMISSIONS_ERROR = 'You do not have the required permission(s) to perform this action.';
export const MISSING_DETAIL_LEVEL_ERROR = 'Please specify a detail level for the phrase.';

export enum UrlEndpoint {
    DetailLevelLookup_Items = "api/DetailLevelLookup/Items",
    EditPhrase_LoadPhrase = "PhraseLibrary/EditPhrase/LoadPhrase",
    EditPhrase_LoadPhraseAssigments = "PhraseLibrary/EditPhrase/LoadphraseAssignmentForEdit",
    EditPhrase_SavePhrase = "PhraseLibrary/EditPhrase/SavePhrase",
    EditPhrase_RestorePhrase = "PhraseLibrary/EditPhrase/RestorePhrase",
    Permissions_GetUserProfile = "api/Permissions/GetUserProfile",
    Permissions_GetUserPermissions = "api/users/current/permissions",
    PhraseLibrary_AllowRemovePhrase = "PhraseLibrary/Phrases/AllowRemovePhrase",
    PhraseLibrary_ApprovePhrase = "PhraseLibrary/ApprovePhrase/ApprovePhrase",
    PhraseLibrary_FilterPhraseAssignments = "PhraseLibrary/Phrases/FilterPhraseAssignments",
    PhraseLibrary_FilterPhrases = "PhraseLibrary/Phrases/FilterPhrases",
    PhraseLibrary_FilterOrderedPhrases = "PhraseLibrary/Phrases/FilterOrderedPhrases",
    PhraseLibrary_ReorderPhrase = "PhraseLibrary/Phrases/ReorderPhrase",
    PhraseLibrary_DragReorderPhrase = "PhraseLibrary/Phrases/ReorderPhrases",
    PhraseLibrary_LoadApprovalData = "PhraseLibrary/ApprovePhrase/LoadApprovalData",
    PhraseLibrary_LoadMarketRPCs = "PhraseLibrary/PhraseAssignments/LoadMarketRegulatoryProductClasses",
    PhraseLibrary_LoadPhraseText = "PhraseLibrary/Phrases/PhraseText",
    PhraseLibrary_RemovePhrase = "PhraseLibrary/Phrases/RemovePhrase",
    PhraseLibrary_RejectPhrase = "PhraseLibrary/ApprovePhrase/RejectPhrase",
    PhraseLibrary_SavePhrase = "PhraseLibrary/AddPhrase/SavePhrase",
    PhraseLibrary_WhereUsed = "PhraseLibrary/WhereUsed",
    PhraseLibrary_DeletePhrase = "PhraseLibrary/Phrases/DeletePhrase",
    PhraseLibrary_LoadAuditData = "PhraseLibrary/PhraseAudit/LoadAuditData",
    PhraseMatrix_AddSavePhrase = "PhraseMatrix/AddPhrase/SavePhrase",
    PhraseMatrix_EditSavePhrase = "PhraseMatrix/EditPhrase/SavePhrase",
    PhraseMatrix_FilterPhraseAssignments = "PhraseMatrix/Phrases/FilterPhraseAssignments",
    PhraseMatrix_FilterPhrases = "PhraseMatrix/Phrases/FilterPhrases",
    PhraseMatrix_GetCellDetailData = "PhraseMatrix/MatrixCell/GetCellDetailData",
    PhraseMatrix_GetCellEditData = "PhraseMatrix/MatrixCell/GetCellEditData",
    PhraseMatrix_GetCells = "PhraseMatrix/Phrases/GetCells",
    PhraseMatrix_GetPhraseAssessDetails = "PhraseMatrix/PhraseAssess/GetPhraseAssessDetails",
    PhraseMatrix_GetPhraseAssessImpact = "PhraseMatrix/PhraseAssess/GetPhraseAssessImpact",
    PhraseMatrix_GetTopicAssessDetails = "PhraseMatrix/TopicAssess/GetTopicAssessDetails",
    PhraseMatrix_GetTopicAssessImpact = "PhraseMatrix/TopicAssess/GetTopicAssessImpact",
    PhraseMatrix_GetTopicList = "PhraseMatrix/Topic/GetList",
    PhraseMatrix_LoadPhrase = "PhraseMatrix/EditPhrase/LoadPhrase",
    PhraseMatrix_PerformPhraseAssess = "PhraseMatrix/PhraseAssess/PerformPhraseAssess",
    PhraseMatrix_PerformTopicAssess = "PhraseMatrix/TopicAssess/PerformTopicAssess",
    PhraseMatrix_CreateAssignment = "PhraseMatrix/MatrixCell/CreateAssignment",
    PhraseMatrix_RemoveAssignment = "PhraseMatrix/MatrixCell/RemoveAssignment",
    Phrases_GetPhrasesToLinkAgainst = "api/Phrases/Linked",
    RPCNavigator_AllItems = "api/RegulatoryProductClassNavigator/AllItems",
    RPCNavigator_AllItems_Old = "api/RegulatoryProductClassNavigator/RPClist",
    RegulatoryMarketNavigator_AllItems = "api/RegulatoryMarketNavigator/AllItems",
    Server_Version = "api/server/version",
    TopicNavigator_AllTopicToUpdMappings = "api/TopicNavigator/AllTopicToUpdMappings",
    WorkList_LoadGramWorkList = "WorkList/WorkList/LoadGramWorkList",
    WorkList_LoadMarketWorkList = "WorkList/WorkList/LoadMarketWorkList",
    WorkList_LoadMarketCreateWorkList = "WorkList/WorkList/LoadCreateMarketWorkList",
    WorkList_KeepPhrasesByGramorMarket = "WorkList/WorkList/KeepPhrasesByGramorMarket",
    UnitOfMeasure_AllItems = "UnitOfMeasureLookup/Items",
    HelpSupport_LoadDetails = "HelpSection/HelpandSupport/GetHelpandSupportDetails",
    HelpSupport_CreateFile = "HelpSection/HelpandSupport/SaveDocument",
    HelpSupport_EditFile = "HelpSection/HelpandSupport/EditDocument",
    HelpSupport_DeleteFile = "HelpSection/HelpandSupport/DeleteDocument",
    HelpSupport_UploadFile = "HelpSection/HelpandSupport/UploadFileToBlobContainerAsync",
    HelpSupport_DownloadFile = "HelpSection/HelpandSupport/DownloadFilefromBlobContainerAsync",
    HelpSupport_ValidateDocument = "HelpSection/HelpandSupport/ValidateDocument",
    HelpSupport_ValidateFileName = "HelpSection/HelpandSupport/ValidateFileName",
}
