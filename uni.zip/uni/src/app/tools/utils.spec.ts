import each from 'jest-each';
import { applyFiltersToArray, joinArrayValues, getLinkedPhraseNrsForPhrase, getLinkedPhraseNrs, isNullOrWhitespace } from './utils';
import { DetailLevels } from './constants';
import { getTestMatrixCellPhrases } from '../testData';

describe('applyFiltersToArray', () => {
  it('returns original array for empty filters input', () => {
    const dataToFilter = getTestMatrixCellPhrases();
    expect(applyFiltersToArray(dataToFilter, {})).toEqual(dataToFilter);
    expect(applyFiltersToArray(dataToFilter, "")).toEqual(dataToFilter);
    expect(applyFiltersToArray(dataToFilter, undefined)).toEqual(dataToFilter);
  });

  it('returns original array for null filters input', () => {
    const dataToFilter = getTestMatrixCellPhrases();
    expect(applyFiltersToArray(dataToFilter, null)).toEqual(dataToFilter);
  });

  it('returns correct element for exact filter match', () => {
    const dataToFilter = getTestMatrixCellPhrases();
    const filter = dataToFilter[3];
    expect(applyFiltersToArray(dataToFilter, filter)[0]).toEqual(dataToFilter[3]);
  });

  it('returns correct elements for general filter match', () => {
    const dataToFilter = getTestMatrixCellPhrases();
    const filter = {
      phraseStatus: "Approved"
    };
    expect(applyFiltersToArray(dataToFilter, filter).length).toEqual(5);
  });

  it('returns correct elements for single filter match', () => {
    const dataToFilter = getTestMatrixCellPhrases();
    const filter = {
      phraseStatus: "ToBeApproved"
    };
    expect(applyFiltersToArray(dataToFilter, filter).length).toEqual(2);
  });

  it('returns correct elements for invalid filter match', () => {
    const dataToFilter = getTestMatrixCellPhrases();
    const filter = {
      phrasexStatus: "To be Approved"
    };
    expect(applyFiltersToArray(dataToFilter, filter).length).toEqual(0);
  });

  it('returns correct elements for numerical filter match', () => {
    const dataToFilter = getTestMatrixCellPhrases();
    const filter = {
      assignmentId: 13
    };
    const filteredData = applyFiltersToArray(dataToFilter, filter);
    expect(filteredData.length).toEqual(1);
    expect(filteredData[0].assignmentId).toEqual(13);
  });

  it('returns correct elements for numerical filter match with undefined data key', () => {
    const dataToFilter = getTestMatrixCellPhrases();
    dataToFilter[0].phraseStatus = undefined;
    const filter = {
      assignmentId: 13
    };
    const filteredData = applyFiltersToArray(dataToFilter, filter);
    expect(filteredData.length).toEqual(1);
    expect(filteredData[0].assignmentId).toEqual(13);
  });

  it('returns correct elements for numerical filter match with null data key', () => {
    const dataToFilter = getTestMatrixCellPhrases();
    dataToFilter[0].phraseStatus = null;
    const filter = {
      assignmentId: 13
    };
    const filteredData = applyFiltersToArray(dataToFilter, filter);
    expect(filteredData.length).toEqual(1);
    expect(filteredData[0].assignmentId).toEqual(13);
  });

  it('returns correct elements for numerical filter match with undefined data key on filtered data', () => {
    const dataToFilter = getTestMatrixCellPhrases();
    dataToFilter[0].assignmentId = undefined;
    const filter = {
      assignmentId: 12
    };
    expect(applyFiltersToArray(dataToFilter, filter).length).toEqual(0);
  });

  it('returns correct elements for numerical filter match with null data key on filtered data', () => {
    const dataToFilter = getTestMatrixCellPhrases();
    dataToFilter[0].assignmentId = null;
    const filter = {
      assignmentId: 12
    };
    expect(applyFiltersToArray(dataToFilter, filter).length).toEqual(0);
  });

  it('returns correct elements for bool filter match', () => {
    const dataToFilter = getTestMatrixCellPhrases();
    const filter = {
      isHidden: false
    };
    expect(applyFiltersToArray(dataToFilter, filter).length).toEqual(4);
    filter.isHidden = true;
    expect(applyFiltersToArray(dataToFilter, filter).length).toEqual(2);
  });
});

describe('joinArrayValues', () => {
  it('returns an empty string if input is null', () => {
    expect(joinArrayValues(null)).toEqual('');
  });

  it('returns an empty string if input is empty array', () => {
    expect(joinArrayValues([])).toEqual('');
  });

  it('returns correctly formatted string if input is multi-element array', () => {
    expect(joinArrayValues(['1', 'fish', ';#'])).toEqual('1, fish, ;#');
  });

  it('returns correctly formatted string if input is single-element array', () => {
    expect(joinArrayValues(['single'])).toEqual('single');
  });
});

describe('getLinkedPhraseNrsForPhrase', () => {
    it('returns the linkedGenericPhraseNr for detailed phrases', () => {
        const phrase = { detailLevelDescription: 'Detailed', linkedGenericPhraseNr: 1, linkedSpecificPhraseNrs: [2, 3, 4]};
        expect(getLinkedPhraseNrsForPhrase(phrase)).toEqual('');
    });

    it('returns empty string for detailed phrase without link', () => {
        const phrase = { detailLevelDescription: 'Detailed' };
        expect(getLinkedPhraseNrsForPhrase(phrase)).toEqual('');
    });

    it('returns empty string for standard phrase without link', () => {
        const phrase = { detailLevelDescription: 'Standard' };
        expect(getLinkedPhraseNrsForPhrase(phrase)).toEqual('');
    });

    it('returns empty string for internal phrase without link', () => {
        const phrase = { detailLevelDescription: 'Internal RA' };
        expect(getLinkedPhraseNrsForPhrase(phrase)).toEqual('');
    });

    it('returns the correctly formatted linkedSpecificPhraseNrs for standard phrases', () => {
      const phrase = { detailLevelDescription: 'Standard', linkedGenericPhraseNr: 1, linkedSpecificPhraseNrs: [2, 3, 4]};
      expect(getLinkedPhraseNrsForPhrase(phrase)).toEqual('');
    });
});

describe('getLinkedPhraseNrs', () => {
    it('returns the linkedGenericPhraseNr for detailed phrases', () => {
        expect(getLinkedPhraseNrs(DetailLevels.Detailed, 1, [2, 3, 4])).toEqual('2, 3, 4');
    });

    it('returns empty string for detailed phrase without link', () => {
        expect(getLinkedPhraseNrs(DetailLevels.Detailed, null, null)).toEqual('');
    });

    it('returns empty string for standard phrase without link', () => {
        expect(getLinkedPhraseNrs(DetailLevels.Standard, null, null)).toEqual('');
    });

    it('returns empty string for internal phrase without link', () => {
        expect(getLinkedPhraseNrs(DetailLevels.InternalRA, null, null)).toEqual('');
    });

    it('returns the correctly formatted linkedSpecificPhraseNrs for standard phrases', () => {
      const phrase = { detailLevelDescription: 'Standard', linkedGenericPhraseNr: 1, linkedSpecificPhraseNrs: [2, 3, 4]};
      expect(getLinkedPhraseNrs(DetailLevels.Standard, 1, [2, 3, 4])).toEqual('2, 3, 4');
    });
});

describe('isNullOrWhitespace', () => {
  each([null, '', ' ', '          ', undefined]).it ('returns true for a null, undefined or whitespace value', (value) => {
    expect(isNullOrWhitespace(value)).toBe(true);
  });
  each(['a', 'word', ' a ', 'this is a sentence', '9', '*&^%$']).it ('returns false for a valid value', (value) => {
    expect(isNullOrWhitespace(value)).toBe(false);
  });
});
