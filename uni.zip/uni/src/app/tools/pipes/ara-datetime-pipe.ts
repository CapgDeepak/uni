import { DatePipe } from '@angular/common';
import { Pipe, PipeTransform } from "@angular/core";
import * as moment from 'moment';
@Pipe({
    name: 'araDateTime'
})
export class AraDateTime implements PipeTransform {

    // transform(value: any, ...args: any[]) {
    //     if (value) {
    //         const pipe = new DatePipe('en-US');
    //         return pipe.transform(value, 'dd-MMM-yyyy, HH:mm');
    //     }

    // }
    transform(date: any): any {
        if (date) {
        return moment(new Date(date)).format('DD-MM-YYYY, HH:mm');

        }
    }

}