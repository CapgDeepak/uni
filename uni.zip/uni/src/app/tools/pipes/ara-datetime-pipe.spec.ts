import { AraDateTime } from './ara-datetime-pipe';
import * as timeZoneMock from 'timezone-mock';

describe('AraDateTime', () => {
  beforeEach(() => {
    timeZoneMock.register('US/Eastern');
  });

  afterEach(() => {
    timeZoneMock.unregister();
  });

  it('Given valid UTC DateTime string should convert to local date time', () => {
    const araDateTime = new AraDateTime();
    const dateTransform = araDateTime.transform('2018-12-04T02:36:14.273Z');
    expect(dateTransform).toBe('03-12-2018, 21:36');
  });

  it('Given valid UTC DateTime string should convert to local date time', () => {
    const araDateTime = new AraDateTime();
    const dateTransform = araDateTime.transform('2018-12-04T12:36:14.273Z');
    expect(dateTransform).toBe('04-12-2018, 07:36');
  });

  it('Given null should return undefined', () => {
    const araDateTime = new AraDateTime();
    const dateTransform = araDateTime.transform(null);
    expect(dateTransform).toBeUndefined();
  });

});
