import { AraDate } from './ara-date-pipe';
import * as timeZoneMock from 'timezone-mock';

describe('AraDateTime', () => {
  beforeEach(() => {
    timeZoneMock.register('US/Eastern');
  });

  afterEach(() => {
    timeZoneMock.unregister();
  });

  it('Given valid UTC DateTime string should convert to local date', () => {
    const araDate = new AraDate();
    const dateTransform = araDate.transform('2018-12-04T12:36:14.273Z');
    expect(dateTransform).toBe('04-12-2018');
  });

  it('Given valid UTC DateTime string should convert to local date', () => {
    const araDate = new AraDate();
    const dateTransform = araDate.transform('2018-12-04T02:36:14.273Z');
    expect(dateTransform).toBe('03-12-2018');
  });

  it('Given null should return undefined', () => {
    const araDate = new AraDate();
    const dateTransform = araDate.transform(null);
    expect(dateTransform).toBeUndefined();
  });
});
