export interface SaveResult {
    success: boolean;
    message: string;
    needsConfirmation: boolean | null;
}

export interface Confirmation {
    confirmed: boolean | null;
}

export interface Item {
    id: number | null;
    description: string;
    parentId: number | null;
    requiresSubselection: boolean;
    regulatoryMarketId: number;
    isUserAuthorizedMarket: boolean;


}

export interface RegulatoryMarketHierarchyItem extends Item {
    regulatoryMarketId: number | null;
    isNavigationMarket: boolean | null;
}

export interface DetailLevel {
    id: number;
    description: string;
}

/**
 * A set of notification builders, i.e. functions that create a notification
 * given an error, indexed by HTTP status code.
 * @see HttpService.getDefaultNotificationBuilderSet
 */
export class NotificationBuilderSet {
    [key: number]: (err: string) => Notification;
}

/**
 * Class representing a toast notification.
 */
export class Notification {
    title: string;
    message: string;
    logLevel: LogLevel;

    constructor (title: string, message: string, logLevel: LogLevel) {
        this.title = title;
        this.message = message;
        this.logLevel = logLevel;
    }
}

export class FilterObject {
    filterId1?: number | null;
    filterId2?: number | null;
    filterId3?: number | null;
}

/**
 * Enumeration of detail levels for message logging.
 */
export enum LogLevel {
    Success,
    Error
}
export class Rpc {
    id: number;
    description: string;
    parentId: number;
    isDeclined: boolean;
    order: number;
    isValidForRpcAndMarket: boolean;
}
export class RpcTree {
    id: number = 0;
    description: string = '';
    isDeclined: boolean = false;

    expanded: boolean = false;
    visible: boolean = true;
    isValidForRpcAndMarket = false;

    parent: RpcTree | null = null;
    childs: RpcTree[] = new Array<RpcTree>();

    get hasChilds(): boolean {
        return this.childs.length > 0;
    }
}
