import { Injectable, EventEmitter } from "@angular/core";

import { Permission } from '../tools/shared-types/permissions/permission';
import { PermissionsLoaderService } from './permissions-loader/permissions-loader.service';
import { TopicToUpdMapping, Permissions } from './authorization.types';
import { RegulatoryMarketAndRegulatoryProductClassIds } from '../tools/shared-types/regulatory-market-and-regulatory-product-class-ids';
import { RegulatoryMarketAndUnileverProductDivisionIds } from '../tools/shared-types/regulatory-market-and-unilever-product-division-ids';
import { PhraseAssignment } from "../shared-components/phrase-assignments/phrase-assignments.types";

@Injectable()
export class AuthorizationService {
    public phrasePermissions: Permission[] = [
        Permission.AraPReFDCT_Phrases_Approve,
        Permission.AraPReFDCT_Phrases_ChangeActiveState,
        Permission.AraPReFDCT_Phrases_Read,
        Permission.AraPReFDCT_Phrases_Remove,
        Permission.AraPReFDCT_Phrases_WriteWithAssignments,
        Permission.AraPReFDCT_Phrases_WriteWithoutAssignments,
    ];
    public phraseAssignmentPermissions: Permission[] = [
        Permission.AraPReFDCT_PhraseAssignments_Assess,
        Permission.AraPReFDCT_PhraseAssignments_DeclineTopic,
        Permission.AraPReFDCT_PhraseAssignments_Read,
        Permission.AraPReFDCT_PhraseAssignments_Write,
    ];
    public phraseAssignmentHasEditPhrasePermissions: Permission[] = [
        Permission.AraPReFDCT_PhraseAssignments_Read,
        Permission.AraPReFDCT_PhraseAssignments_Write,
      ];
    public gramWorkListPermissions: Permission[] = [
        Permission.AraPReFDCT_Phrases_Approve,
    ];
    public marketWorkListPermissions: Permission[] = [
        Permission.AraPReFDCT_PhraseAssignments_Assess,
    ];

    constructor(private permissionsLoaderService: PermissionsLoaderService) {
    }

    get permissions(): Permissions {
        return this.permissionsLoaderService.permissions;
    }

    get topicToUpdMapping(): TopicToUpdMapping {
        return this.permissionsLoaderService.topicToUpdMapping;
    }

    /**
     * Check whether the user has the permission to modify the input assignment
     * @param assignment The assignment to check modify status for.
     */
    public checkUserCanModifyAssignment(assignment: PhraseAssignment): boolean {
        return (!!assignment &&
            this.checkUserHasPermissionForMarketRpcAndTopic(
                Permission.AraPReFDCT_PhraseAssignments_Write,
                assignment.regulatoryMarketId,
                assignment.regulatoryProductClassId,
                assignment.topicId)
        );
    }

    public arePermissionsAvailable(): boolean {
      return this.permissionsLoaderService.arePermissionsLoaded();
    }

    public permissionLoadEvent(): EventEmitter<boolean> {
      return this.permissionsLoaderService.permissionsLoaded;
    }
    /**
     * Check whether the user has at least one of the specified permissions.
     * @param permissionsToCheck The permissions to check for.
     */
    public checkUserHasAnyPermission(permissionsToCheck: Permission[]): boolean {
        // Validate the existence of the provided and the supplied permissions.
        if (!this.permissionsLoaderService.arePermissionsLoaded()) {
          return false;
        }
        if (!this.permissionsProvided(permissionsToCheck)) {
            return false;
        }
        // Return true if the user holds any of the input permissions, false otherwise.
        return Object.keys(this.permissions).some(key => permissionsToCheck.indexOf(Permission[key]) !== -1);
    }

    /**
     * Check whether the user holds all of the specified permissions
     * @param permissionsToCheck The permissions to check for.
     */
    public checkUserHasAllPermissions(permissionsToCheck: Permission[]): boolean {
        // Validate the existence of the provided and the supplied permissions.
        if (!this.permissionsLoaderService.arePermissionsLoaded()) {
            return false;
        }
        if (!this.permissionsProvided(permissionsToCheck)) {
            return false;
        }

        // Return true if the user holds all of the input permissions, false otherwise.
        const permissionKeys = Object.keys(this.permissions);
        return this.userHoldsAllPermissions(permissionKeys, permissionsToCheck);
    }

    /**
     * Gets a value representing whether or not the user holds all specified permissions.
     * @param userPermissions the collection of all permissions held by the user
     * @param permissionsToCheck the collection of all permissions to check against the user
     */
    userHoldsAllPermissions (userPermissions: string[], permissionsToCheck: string[]) {
        // If the user has no permissions...
        if (!userPermissions) {
            // Then return true if no permissions to check were provided,
            // and false if there were permissions to check.
            return !!permissionsToCheck;
        }

        // If the user has permissions, but no permissions to check were provided,
        // it is not possible for the user to hold the permissions, so return false.
        if (!permissionsToCheck) {
            return false;
        }

        // Otherwise, the user has permissions, and permissions to check were provided,
        // so perform the checking. Return true if every permission in the permissions to
        // check is contained in the user's permissions.
        return permissionsToCheck.every(function (value) {
            return (userPermissions.indexOf(value) >= 0);
        });
    }

    /**
     * Determine whether the Topic to UPD mappings have been loaded: return true if so; false otherwise.
     */
    isTopicToUpdMappingLoaded(): boolean {
        return !!this.topicToUpdMapping;
    }

    /**
     * Ensure that the permissions to check have been provided.
     * Return true if the permissions to check have been provided. False otherwise.
     */
    permissionsProvided(permissionsToCheck: Permission[]): boolean {
        if (!permissionsToCheck) {
            console.error('No permissions provided.');
            return false;
        }
        return true;
    }

    /**
     * Check whether the user has one of the specified permissions for the indicated
     * regulatory market and technical formulation category.
     * @param permissionsToCheck The permissions to check for.
     * @param regulatoryMarketId The id of the regulatory market to check the indicated permissions for. Use <c>null</c> to indicate any / not applicable.
     * @param technicalFormulationCategoryId The id of the TFC to check the indicated permissions for. Use <c>null</c> to indicate any / not applicable.
     */
    public checkUserHasAnyPermissionForMarketAndProductDivision(
        permissionsToCheck: Permission[],
        regulatoryMarketId?: number,
        technicalFormulationCategoryId?: number): boolean
    {
        // Validate the existence of the provided and the supplied permissions.
        if (!this.permissionsLoaderService.arePermissionsLoaded()) {
            return false;
        }
        if (!this.permissionsProvided(permissionsToCheck)) {
            return false;
        }
        // Return true if the user holds any of the input permissions, where the regulatory market ID for that
        // permission matches the input regulatory market AND the TFC ID for that permission
        // matches the input TFC ID. False otherwise.
        return Object.keys(this.permissions)
                     .some(key => permissionsToCheck.indexOf(Permission[key]) > -1 &&
                                  this.permissions[key].some(x => (regulatoryMarketId             == null || x.rm  == regulatoryMarketId) &&
                                                                  (technicalFormulationCategoryId == null || x.tfc == technicalFormulationCategoryId)));
    }

    /**
     * Check whether the user has the specified permission for the indicated
     * regulatory market, rpc and topic.
     * @param permissionToCheck The permission to check for.
     * @param marketId The id of the regulatory market to check the indicated permission for.
     * @param rpcId The id of the RPC to check the indicated permission for.
     * @param topicId The id of the Topic to check the indicated permission for.
     */
    public checkUserHasPermissionForMarketRpcAndTopic(
        permissionToCheck: Permission,
        marketId: number,
        rpcId: number,
        topicId: number): boolean
    {
        // Validate the existence of the provided and the supplied permissions and the Topic to TFC map.
        if (!this.permissionsLoaderService.arePermissionsLoaded() || !this.isTopicToUpdMappingLoaded()) {
            return false;
        }

        // Check that the requested permission exists in the collection of permissions retrieved for the
        // current user on app startup.
        const permissionScopes = this.permissions[Permission[permissionToCheck]];
        if (!permissionScopes) {
            return false;
        }

        // Get all the valid UPDs for the topic
        const updsMappedToTopic = this.topicToUpdMapping[topicId];
        if (!updsMappedToTopic) {
            return false;
        }

        return permissionScopes.some(x => x.rm == marketId &&
                                          x.rpcs.indexOf(rpcId) > -1 &&
                                          updsMappedToTopic.indexOf(x.upd) > -1);
    }

    /**
     * Check whether the user has any of the specified permissions for the indicated
     * regulatory market, RPC and topic.
     * @param permissionsToCheck The permissions to check for.
     * @param marketId The id of the regulatory market to check the indicated permission for.
     * @param rpcId The id of the RPC to check the indicated permission for.
     * @param topicId The id of the Topic to check the indicated permission for.
     */
    public checkUserHasAnyPermissionForMarketRpcAndTopic(
        permissionsToCheck: Permission[],
        marketId?: number,
        rpcId?: number,
        topicId?: number): boolean
    {
        // Validate the existence of the provided and the supplied permissions and the Topic to TFC map.
        if (!this.permissionsLoaderService.arePermissionsLoaded() || !this.isTopicToUpdMappingLoaded()) {
            return false;
        }

        if (!this.permissionsProvided(permissionsToCheck)) {
            return false;
        }

        // Get all the valid UPDs for the topic
        const updsMappedToTopic = (topicId == null) ? [] : this.topicToUpdMapping[topicId];
        if (!updsMappedToTopic) {
            return false;
        }

        return Object.keys(this.permissions)
                     .some(key => permissionsToCheck.indexOf(Permission[key]) > -1 &&
                                  this.permissions[key].some(x => (marketId == null || x.rm == marketId) &&
                                                                  (rpcId == null || x.rpcs.indexOf(rpcId) > -1) &&
                                                                  (topicId == null || updsMappedToTopic.indexOf(x.upd) > -1)));
    }

    /**
     * Get all regulatory markets and regulatory product classes that the calling
     * user has the specified permission for.
     * @param permission The permission to retrieve regulatory markets and regulatory product classes for.
     */
    public getMarketsAndRpcsUserHasPermissionFor(permission: Permission): RegulatoryMarketAndRegulatoryProductClassIds[] {
        if (!this.permissionsLoaderService.arePermissionsLoaded()) {
            return [];
        }

        // Check that the input permission exists in the collection of permissions retrieved for the
        // current user on app startup.
        const permissionScopes = this.permissions[Permission[permission]];
        if (!permissionScopes) {
            return [];
        }

        // Return an array of regulatory market ID/regulatory product class ID pairs.
        return Array.prototype.concat(...permissionScopes.map(x => x.rpcs.map(y => new RegulatoryMarketAndRegulatoryProductClassIds(x.rm, y))));
    }

    /**
     * Get all regulatory markets and Unilever product divisions that the calling
     * user has the specified permission for.
     * @param permission The permission to retrieve regulatory markets and Unilever product divisions for.
     */
    public getMarketsAndUpdsUserHasPermissionFor(permission: Permission): RegulatoryMarketAndUnileverProductDivisionIds[] {
        if (!this.permissionsLoaderService.arePermissionsLoaded()) {
            return [];
        }

        // Check that the input permission exists in the collection of permissions retrieved for the
        // current user on app startup.
        const permissionScopes = this.permissions[Permission[permission]];
        if (!permissionScopes) {
            return [];
        }

        // Return an array of regulatory market ID/unilever product division ID pairs.
        return permissionScopes.map(x => new RegulatoryMarketAndUnileverProductDivisionIds(x.rm, x.tfc));
    }

    public userHasPermissionToViewPhraseLibrary() {
        return this.checkUserHasAnyPermission(this.phrasePermissions);
    }

    public userHasPermissionToOrderPhrases() {
      return this.checkUserHasAnyPermission([ Permission.AraPReFDCT_Phrases_Order ]);
    }

    public userHasPermissionToViewPhraseMatrix() {
        return this.checkUserHasAnyPermission(this.phraseAssignmentPermissions);
    }

    public userHasPermissionToEditPhraseMatrix(){
        return this.checkUserHasAllPermissions(this.phraseAssignmentHasEditPhrasePermissions);
    }

    public userHasPermissionToViewGramWorkList() {
        return this.checkUserHasAnyPermission(this.gramWorkListPermissions);
    }

    public userHasPermissionToViewMarketWorkList() {
        return this.checkUserHasAnyPermission(this.marketWorkListPermissions);
    }
}
