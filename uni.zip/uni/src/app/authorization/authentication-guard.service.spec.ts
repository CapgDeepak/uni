import { TestBed, inject, async, getTestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { Observable, of } from 'rxjs';

import { AuthenticationGuardService } from './authentication-guard.service';
import { AuthenticationService } from './authentication.service';
import { AuthorizationService } from './authorization.service';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';

class MockAdalService {
  handleWindowCallback() { }
}
class MockAuthService {
  getToken() {
    return new Observable(observer => {
      observer.next('token');
      observer.complete();
    });
  }
}
class MockAuthorizationService {
  arePermissionsAvailable() {
    return true;
  }
  userHasPermissionToViewPhraseLibrary() {
    return true;
  }
  userHasPermissionToOrderPhrases() {
    return true;
  }
  userHasPermissionToViewPhraseMatrix() {
    return true;
  }
  userHasPermissionToViewGramWorkList() {
    return true;
  }
  userHasPermissionToViewMarketWorkList() {
    return true;
  }
}

class MockRouterStateSnapshot {
}

describe('AuthenticationGuardService', () => {
  let injector: TestBed;
  let authMock: AuthenticationService;
  let authorizationMock: AuthorizationService;
  let routerMock: Router;
  let stateMock: RouterStateSnapshot;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([
          { path: 'unauthorized/false', component: UnauthorizedComponent },
        ])
      ],
      declarations: [UnauthorizedComponent],
      providers: [
        AuthenticationGuardService,
        { provide: AuthenticationService, useClass: MockAuthService },
        { provide: AuthorizationService, useClass: MockAuthorizationService },
        { provide: RouterStateSnapshot, useClass: MockRouterStateSnapshot },
      ]
    });

    injector = getTestBed();
    authMock = injector.get(AuthenticationService);
    authorizationMock = injector.get(AuthorizationService);
    routerMock = injector.get(Router);
    stateMock = injector.get(RouterStateSnapshot);
    stateMock.url = '/phrase-library';
  });

  it('should be created', inject([AuthenticationGuardService], (service: AuthenticationGuardService) => {
    expect(service).toBeTruthy();
  }));

  xdescribe('canActivate', () => {
    it('returns true if permissions available',
      async(inject([AuthenticationGuardService], (service: AuthenticationGuardService) => {
        // Assemble
        const route = new ActivatedRouteSnapshot;
        const spy2 = jest.spyOn(authorizationMock, 'arePermissionsAvailable');
        spy2.mockReturnValue(true);

      })
      ));

    it('returns false if permissions not available',
      async(inject([AuthenticationGuardService], (service: AuthenticationGuardService) => {
        // Assemble
        const route = new ActivatedRouteSnapshot;
        const spy2 = jest.spyOn(authorizationMock, 'arePermissionsAvailable');
        spy2.mockReturnValue(false);

      })
      ));

  });
  describe('canActivateChild', () => {
    it('returns true if token retrieved and permissions available',
      async(inject([AuthenticationGuardService], (service: AuthenticationGuardService) => {
        // Assemble
        const route = new ActivatedRouteSnapshot;

        const spy2 = jest.spyOn(authorizationMock, 'arePermissionsAvailable');
        spy2.mockReturnValue(true);
      })
      ));

    it('returns false if token retrieved but permissions not available',
      async(inject([AuthenticationGuardService], (service: AuthenticationGuardService) => {
        // Assemble
        const route = new ActivatedRouteSnapshot;

        const spy2 = jest.spyOn(authorizationMock, 'arePermissionsAvailable');
        spy2.mockReturnValue(false);


      })
      ));

    it('returns false if token not retrieved',
      async(inject([AuthenticationGuardService], (service: AuthenticationGuardService) => {
        // Assemble
        const route = new ActivatedRouteSnapshot;

        const spy2 = jest.spyOn(authorizationMock, 'arePermissionsAvailable');
      })
      ));
  });
  describe('isAuthorised calls expected check for', () => {
    it('phrase library',
      inject([AuthenticationGuardService], (service: AuthenticationGuardService) => {
        // Assemble
        const spy = jest.spyOn(authorizationMock, 'userHasPermissionToViewPhraseLibrary');
        // Act
        service.isAuthorised('/phrase-library');
        // Assert
        expect(spy).toHaveBeenCalledTimes(1);
      })
    );
    it('phrase library ordering',
      inject([AuthenticationGuardService], (service: AuthenticationGuardService) => {
        // Assemble
        const spy = jest.spyOn(authorizationMock, 'userHasPermissionToOrderPhrases');
        // Act
        service.isAuthorised('/phrase-library/ordering');
          // Assert
        expect(spy).toHaveBeenCalledTimes(0);
      })
    );
    it('phrase matrix',
      inject([AuthenticationGuardService], (service: AuthenticationGuardService) => {
        // Assemble
        const spy = jest.spyOn(authorizationMock, 'userHasPermissionToViewPhraseMatrix');
        // Act
        service.isAuthorised('/phrase-matrix');
        // Assert
        expect(spy).toHaveBeenCalledTimes(1);
      })
    );
    it('work list - grams',
      inject([AuthenticationGuardService], (service: AuthenticationGuardService) => {
        // Assemble
        const spy = jest.spyOn(authorizationMock, 'userHasPermissionToViewGramWorkList');
        // Act
        service.isAuthorised('/work-list/grams');
        // Assert
        expect(spy).toHaveBeenCalledTimes(1);
      })
    );
    it('work list - markets assess',
      inject([AuthenticationGuardService], (service: AuthenticationGuardService) => {
        // Assemble
        const spy = jest.spyOn(authorizationMock, 'userHasPermissionToViewMarketWorkList');
        // Act
        service.isAuthorised('/work-list/markets/assess');
        // Assert
        expect(spy).toHaveBeenCalledTimes(1);
      })
    );
    it('work list - markets review',
      inject([AuthenticationGuardService], (service: AuthenticationGuardService) => {
        // Assemble
        const spy = jest.spyOn(authorizationMock, 'userHasPermissionToViewMarketWorkList');
        // Act
        service.isAuthorised('/work-list/markets/review');
        // Assert
        expect(spy).toHaveBeenCalledTimes(1);
      })
    );
  });
});
