import { Injectable, OnInit } from '@angular/core';

import { PageLink } from '../navmenu/navmenu.types';
import { HttpService } from '../tools/services/http.service';
import { UrlEndpoint } from '../tools/constants';

@Injectable()
export class AuthenticationService implements OnInit {

  constructor(
    private httpService: HttpService,
  ) {
  }

  ngOnInit(): void {
  }

  /**
   * Get details of all applications the user has access to.
   */
  loadAccessibleApplications(): Promise<PageLink[]> {
    return new Promise<PageLink[]>((resolve, reject) => {
      this.httpService.get('api/users/current/applications')
        .subscribe(result => {
          resolve(result);
        },
          error => {
            reject(error);
          });
    });
  }

  getUserProfile() {
    return this.httpService.getPromise(UrlEndpoint.Permissions_GetUserProfile);
  }
}