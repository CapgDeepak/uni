import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logged-out',
  templateUrl: './logged-out.component.html',
})
export class LoggedOutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    this.logout();
  }

  logout(){

    window.open("about:blank", "_self");
    window.close();
  }
}
