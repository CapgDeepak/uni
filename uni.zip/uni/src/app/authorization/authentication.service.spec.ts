import { TestBed, inject, async, getTestBed } from '@angular/core/testing';
import { Observable, of, throwError } from 'rxjs';

import { AuthenticationService } from './authentication.service';
import { PageLink } from '../navmenu/navmenu.types';
import { HttpService } from '../tools/services/http.service';
import { MsalService } from '@azure/msal-angular';

class HttpServiceMock {
  get() { }
}
const hasToken = true;
class MockMsalService {
  userInfo = { authenticated: true, token: '1234' };
  getCachedToken() { return 'token'; }
  acquireToken(clientId: string) {
    return hasToken ? new Observable(observer => {
      observer.next('token');
      observer.complete();
    })
      : new Observable(observer => {
        throwError('error!');
      });
  }
  login() { return; }
}

describe('AuthenticationService', () => {
  let httpService: HttpService;
  let msalMock: MsalService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AuthenticationService,
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: MsalService, useClass: MockMsalService },
      ],
    });

    httpService = getTestBed().get(HttpService);
    msalMock = getTestBed().get(MsalService);
  });

  it('should be created', inject([AuthenticationService], (service: AuthenticationService) => {
    expect(service).toBeTruthy();
  }));

  describe('loadAccessibleApplications', () => {
    it('should return all applications accessible to the user', async(inject([AuthenticationService], (service: AuthenticationService) => {
      // Assemble
      const pageLinks: PageLink[] = [{ name: 'Pref', hostedUri: 'PrefUri' }];
      spyOn(httpService, 'get').and.returnValue(of(pageLinks));

      // Act
      service.loadAccessibleApplications().then(result => {
        // Assert
        expect(result).toBeTruthy();
        expect(result).toEqual(pageLinks);
      });
    })));
  });

});
