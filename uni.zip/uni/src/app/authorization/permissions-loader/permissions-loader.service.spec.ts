import { TestBed, getTestBed } from '@angular/core/testing';

import { PermissionsLoaderService } from './permissions-loader.service';
import { HttpService } from '../../tools/services/http.service';
import { UserPermissions, Permissions } from '../../authorization/authorization.types';
import { UrlEndpoint } from "../../tools/constants";

let retrievedUserPermissions;
let retrievedTopicTfcMap;
const testScopes: Permissions = {
    "10|20": [
      {
        rm: 10,
        tfc: 20,
        upd: 42,
        rpcs: [ 51, 52 ]
      }
    ],
    "10|21": [
      {
        rm: 10,
        tfc: 21,
        upd: 42,
        rpcs: [ 54, 55 ]
      }
    ],
};

const validUserPermissions: UserPermissions = {
    permissions: {
      'AraPReFDCT_Phrases_Approve':              ['10|20', '10|21'],
      'AraPReFDCT_Phrases_WriteWithAssignments': ['10|20'],
    },
    scopes: testScopes,
  };

const validUserPermissionsWithNoScope: UserPermissions = {
    permissions: {
        'AraPReFDCT_Phrases_Approve':              ['10|20', '10|21'],
        'AraPReFDCT_Phrases_WriteWithAssignments': ['10|20'],
    },
    scopes: {},
};

const userPermissionsWithNonMatchingKey: UserPermissions = {
  permissions: {
    'AraPReFDCT_Phrases_Approve':              ['10|20', '10|21'],
    'AraPReFDCT_NON_MATCHING_PERMISSION': ['10|20'],
  },
  scopes: testScopes,
};

const emptyUserPermissions: UserPermissions = {
  permissions: {},
  scopes: {},
};

export class HttpServiceMock {
  getPromise(url: string) {
      if (url == UrlEndpoint.TopicNavigator_AllTopicToUpdMappings) {
        return new Promise((resolve, reject) => {
            resolve(retrievedTopicTfcMap);
          });
      }
      return new Promise((resolve, reject) => {
          resolve(retrievedUserPermissions);
      });
  }
}

describe('PermissionsLoaderService', () => {
  let service: PermissionsLoaderService;
  let httpService: HttpServiceMock;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PermissionsLoaderService,
        { provide: HttpService, useClass: HttpServiceMock }
      ]
    });
    const injector = getTestBed();
    service = injector.get(PermissionsLoaderService);
    httpService = injector.get(HttpService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('arePermissionsLoaded', () => {
    it('should return false initially', () => {
      expect(service.arePermissionsLoaded()).toBeFalsy();
    });
    it('should return false when no data available', () => {
      service.permissions = null;
      expect(service.arePermissionsLoaded()).toBeFalsy();
      service.permissions = undefined;
      expect(service.arePermissionsLoaded()).toBeFalsy();
      service.permissions = {};
      expect(service.arePermissionsLoaded()).toBeFalsy();
    });
    it('should return true when data available', () => {
      service.permissions = { blah: [] };
      expect(service.arePermissionsLoaded()).toBeTruthy();
    });
  });

  describe('loadTopicToUpdMapping', () => {
    it('should resolve and set data', done => {
      // Assemble
      const expectedMap: { [key: number]: number[] } = {
        1: [ 1, 2, 3 ],
        5: [1, 4, 6 ]
      };
      retrievedTopicTfcMap = expectedMap;

      // Act
      return service.loadTopicToUpdMapping().then(data => {
        // Assert
        expect(data).toEqual(true);
        expect(service.topicToUpdMapping).toEqual(expectedMap);
        done();
      });
    });
  });

  describe('loadPermissions', () => {
    it('should resolve and map valid set of user permissions retrieved from backend to expected dictionary of permissions', done => {
      // Assemble
      retrievedUserPermissions = validUserPermissions;
      const expectedPermissions: Permissions = {
        'AraPReFDCT_Phrases_Approve': [
          {
            rm: 10,
            tfc: 20,
            upd: 42,
            rpcs: [ 51, 52 ]
          },
          {
            rm: 10,
            tfc: 21,
            upd: 42,
            rpcs: [ 54, 55 ]
          },
        ],
        'AraPReFDCT_Phrases_WriteWithAssignments': [
          {
            rm: 10,
            tfc: 20,
            upd: 42,
            rpcs: [ 51, 52 ]
          },
        ],
      };
      service.permissions = {};

      // Act
      return service.loadPermissions().then(data => {
        // Assert
        expect(data).toEqual(expectedPermissions);
        expect(service.permissions).toEqual(expectedPermissions);
        done();
      });
    });

    it('should resolve and not map any permissions with non-matching permission keys from backend', done => {
      // Assemble
      retrievedUserPermissions = userPermissionsWithNonMatchingKey;
      const expectedPermissions: Permissions = {
        'AraPReFDCT_Phrases_Approve': [
          {
            rm: 10,
            tfc: 20,
            upd: 42,
            rpcs: [ 51, 52 ]
          },
          {
            rm: 10,
            tfc: 21,
            upd: 42,
            rpcs: [ 54, 55 ]
          },
        ],
      };
      service.permissions = {};

      // Act
      return service.loadPermissions().then(data => {
        // Assert
        expect(data).toEqual(expectedPermissions);
        expect(service.permissions).toEqual(expectedPermissions);
        done();
      });
    });

    it('should resolve and not map any permissions with no scope from backend', done => {
        // Assemble
        retrievedUserPermissions = validUserPermissionsWithNoScope;
        const expectedPermissions: Permissions = {
          'AraPReFDCT_Phrases_Approve': [],
          'AraPReFDCT_Phrases_WriteWithAssignments': []
        };
        // Act
        return service.loadPermissions().then(data => {
          // Assert
          expect(data).toEqual(expectedPermissions);
          expect(service.permissions).toEqual(expectedPermissions);
          done();
        });
    });

    it('should resolve and not perform any mapping when no permissions returned from backend', done => {
      // Assemble
      retrievedUserPermissions = emptyUserPermissions;

      // Act
      return service.loadPermissions().then(data => {
        // Assert
        expect(data).toEqual({});
        expect(Object.keys(service.permissions).length).toEqual(0);
        done();
      });
    });

    it('should not reload permissions when these are already available', done => {
      // Assemble
      jest.spyOn(httpService, 'getPromise');
      service.permissions = testScopes;
      // Act
      return service.loadPermissions().then(data => {
        // Assert
        expect(data).toEqual(testScopes);
        expect(httpService.getPromise).not.toHaveBeenCalled();
        done();
      });
    });

    it('should load permissions when these are not available', done => {
      // Assemble
      jest.spyOn(httpService, 'getPromise');
      service.permissions = {};

      // Act
      return service.loadPermissions().then(data => {
        // Assert
        expect(httpService.getPromise).toHaveBeenCalled();
        done();
      });
    });

    it('should reject with error when backend call fails', done => {
      // Assemble
      jest.spyOn(httpService, 'getPromise').mockRejectedValue('error');

      // Act
      return service.loadPermissions().catch(e => {
        // Assert
        expect(e).toEqual('error');
        done();
      });
    });
  });
});
