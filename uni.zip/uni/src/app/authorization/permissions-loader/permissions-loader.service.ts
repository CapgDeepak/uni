import { Injectable, Output, EventEmitter } from "@angular/core";

import { Permission } from './../../tools/shared-types/permissions/permission';
import { UserPermissions, TopicToUpdMapping, Permissions } from '../authorization.types';
import { HttpService } from "../../tools/services/http.service";
import { UrlEndpoint } from "../../tools/constants";

@Injectable({
  providedIn: 'root'
})
export class PermissionsLoaderService {
  public permissions: Permissions = {};
  public topicToUpdMapping: TopicToUpdMapping = {};

  @Output()
  permissionsLoaded: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(private httpService: HttpService) {
  }

  /**
   * Determine whether the permissions of the user have been loaded: return true if so; false otherwise.
   */
  public arePermissionsLoaded(): boolean {
    return !!this.permissions && !(Object.entries(this.permissions).length === 0 && this.permissions.constructor === Object);
  }

  /**
   * Gets the permissions of the current user.
   */
  public loadPermissions(): Promise<Permissions> {
    if (this.arePermissionsLoaded()) {
      return new Promise<Permissions>(resolve => resolve(this.permissions));
    }
    return new Promise<Permissions>((resolve, reject) => {
      this.loadUserPermissions(resolve, reject);
    });
  }

  /**
   * Gets the Topic to TFC map - which is used to complete permission checks against phrase assignments (these are associated
   * with a Topic ID, which indirectly references a TFC).
   */
  public loadTopicToUpdMapping(): Promise<boolean> {
    return new Promise<boolean>((resolve, reject) => {
      this.loadTopicUpdMapping(resolve, reject);
    });
  }

  private loadTopicUpdMapping(resolve: (value?: boolean | PromiseLike<boolean>) => void, reject: (reason?: any) => void) {
    this.httpService.getPromise(UrlEndpoint.TopicNavigator_AllTopicToUpdMappings)
      .then((result: TopicToUpdMapping) => {
        this.topicToUpdMapping = result;
        resolve(true);
      }).catch(error => {
        console.error('Error when loading topic to TFC map', error);
        reject(error);
      });
  }

  private loadUserPermissions(resolve: (value?: Permissions | PromiseLike<Permissions>) => void, reject: (reason?: any) => void) {
    this.httpService.getPromise(UrlEndpoint.Permissions_GetUserPermissions)
      .then((result: UserPermissions) => {
        // Wipe the permissions
        this.permissions = {};
        // Map the response
        if (result && result.permissions) {
          Object.keys(result.permissions)
            .forEach(y => {
              // Check that is is a known permission
              const permissionEnum: Permission = Permission[y];
              if (permissionEnum) {
                this.permissions[y] = Array.prototype.concat(...result.permissions[y].map(z => result.scopes[z]));
                this.permissions[y] = this.permissions[y].filter(function (el) { return el; }); // strip out undefined values
              }
              else {
                // If the permission was not recognised, log an error to the console
                console.error('Unknown permission ', y);
              }
            });
        }
        this.permissionsLoaded.emit(true);
        resolve(this.permissions);
      }).catch(error => {
        console.error('Error when loading permissions for user', error);
        reject(error);
      });
  }
}
