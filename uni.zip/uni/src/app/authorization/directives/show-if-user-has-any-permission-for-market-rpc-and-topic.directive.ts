import { Directive, Input, TemplateRef, ViewContainerRef, OnInit } from '@angular/core';

import { AuthorizationService } from './../authorization.service';
import { MarketRpcAndTopicScopedPermissions } from '../../tools/shared-types/permissions/market-rpc-and-topic-scoped-permissions';

@Directive({
    selector: '[ShowIfUserHasAnyPermissionForMarketProductClassAndTopic]'
})
export class ShowIfUserHasAnyPermissionForMarketProductClassAndTopicDirective implements OnInit {

    constructor(
        private templateRef: TemplateRef<any>,
        private viewContainer: ViewContainerRef,
        private authorizationService: AuthorizationService
    ) {}

    ngOnInit() {
    }

    /**
     * Directive to determine whether or not an element should be displayed based on whether or not
     * the user holds any of the permissions specified in the input MarketRpcAndTopicScopedPermissions,
     * for the specified regulatory market, regulatory product class and topic.
     * @param scopedPermissions The permissions (with Market, RPC and topic scope) to check that the user holds.
     */
    @Input() public set ShowIfUserHasAnyPermissionForMarketProductClassAndTopic(scopedPermissions: MarketRpcAndTopicScopedPermissions) {
        // Regardless of whether permissions have been provided, and whether or not the user has the
        // permissions (in the case that they have been provided), remove the view to which the directive refers.
        this.viewContainer.clear();

        // If the scoped permissions exist, call the authorization service to check the permission and permission scope.
        if (scopedPermissions) {
            const userHasPermission = this.authorizationService.checkUserHasAnyPermissionForMarketRpcAndTopic(
                scopedPermissions.permissions,
                scopedPermissions.regulatoryMarketId,
                scopedPermissions.regulatoryProductClassId,
                scopedPermissions.topicId,
            );

            // If the user holds the permission with the correct scope, create the element to which this directive applies.
            if (userHasPermission) {
                this.viewContainer.createEmbeddedView(this.templateRef);
            }
        }
    }
}