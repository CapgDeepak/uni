import { Directive, Input, TemplateRef, ViewContainerRef, OnInit } from '@angular/core';

import { AuthorizationService } from './../authorization.service';
import { Permission } from '../../tools/shared-types/permissions/permission';

@Directive({
    selector: '[ShowIfUserHasAllPermissions]'
})
export class ShowIfUserHasAllPermissionsDirective implements OnInit {

    constructor(
        private templateRef: TemplateRef<any>,
        private viewContainer: ViewContainerRef,
        private authorizationService: AuthorizationService
    ) {}

    ngOnInit() {
    }

    /**
     * Directive to determine whether or not to show an element based on whether or not
     * the user holds all of the permissions specified. This directive does not check the
     * permissions against any scope (i.e. Regulatory market, UPD, RPC).
     * @param permissionsToCheck the permissions to check that the user holds
     */
    @Input() public set ShowIfUserHasAllPermissions(permissionsToCheck: Permission[]) {
        // Regardless of whether permissions have been provided, and whether or not the user has the
        // permissions (in the case that they have been provided), remove the view to which the directive refers.
        this.viewContainer.clear();

        // If permissions have been provided, check that the user has all of the provided permissions.
        if (permissionsToCheck && permissionsToCheck.length) {
            const userHasPermission = this.authorizationService.checkUserHasAllPermissions(permissionsToCheck);
            // If the user does have all of the permissions, create the view to which this directive applies.
            if (userHasPermission) {
                this.viewContainer.createEmbeddedView(this.templateRef);
            }
        }
    }
}