import { Directive, Input, TemplateRef, ViewContainerRef, OnInit } from '@angular/core';

import { AuthorizationService } from './../authorization.service';
import { MarketAndUpdScopedPermissions } from '../../tools/shared-types/permissions/market-and-upd-scoped-permissions';

@Directive({
    selector: '[ShowIfUserHasAnyPermissionForMarketAndProductDivision]'
})
export class ShowIfUserHasAnyPermissionForMarketAndProductDivisionDirective implements OnInit {

    constructor(
        private templateRef: TemplateRef<any>,
        private viewContainer: ViewContainerRef,
        private authorizationService: AuthorizationService,
    ) {}

    ngOnInit() {
    }

    /**
     * Directive to determine whether or not an element should be displayed based on whether or not
     * the user holds any of the permissions specified in the input MarketAndRpcScopedPermissions,
     * for the specified regulatory market and Unilever product division.
     * @param scopedPermissions The permissions (with Market and Upd scope) to check that the user holds.
     */
    @Input() public set ShowIfUserHasAnyPermissionForMarketAndProductDivision(scopedPermissions: MarketAndUpdScopedPermissions) {
        // Regardless of whether permissions have been provided, and whether or not the user has the
        // permissions (in the case that they have been provided), remove the view to which the directive refers.
        this.viewContainer.clear();

        // If the scoped permissions exist, call the authorization service to check the permission and permission scope.
        if (scopedPermissions) {
            const userHasPermission = this.authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision(
                scopedPermissions.permissions,
                scopedPermissions.regulatoryMarketId,
                scopedPermissions.unileverProductDivisionId,
            );

            // If the user holds the permission with the correct scope, create the element to which this directive applies.
            if (userHasPermission) {
                this.viewContainer.createEmbeddedView(this.templateRef);
            }
        }
    }
}