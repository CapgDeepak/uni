import { Directive, Input, TemplateRef, ViewContainerRef, OnInit } from '@angular/core';

import { AuthorizationService } from './../authorization.service';
import { Permission } from '../../tools/shared-types/permissions/permission';

@Directive({
    selector: '[ShowIfUserHasAnyPermission]'
})
export class ShowIfUserHasAnyPermissionDirective implements OnInit {

    constructor(
        private templateRef: TemplateRef<any>,
        private viewContainer: ViewContainerRef,
        private authorizationService: AuthorizationService
    ) {}

    ngOnInit() {
    }

    /**
     * Directive to determine whether or not to show an element based on whether or not
     * the user holds any of the permissions specified. This directive does not check the
     * permissions against any scope (i.e. Regulatory market, UPD, RPC).
     * @param permissionsToCheck the permissions to check that the user holds
     */
    @Input() public set ShowIfUserHasAnyPermission(permissionsToCheck: Permission[]) {
        // Regardless of whether permissions have been provided, and whether or not the user has the
        // permissions (in the case that they have been provided), remove the view to which the directive refers.
        this.viewContainer.clear();

        // If permissions have been provided, check that the user has at least one of the provided permissions.
        if (permissionsToCheck && permissionsToCheck.length) {
            const userHasPermission = this.authorizationService.checkUserHasAnyPermission(permissionsToCheck);
            // If the user does have one of the permissions, create the view to which this directive applies.
            if (userHasPermission) {
                this.viewContainer.createEmbeddedView(this.templateRef);
            }
        }
    }
}