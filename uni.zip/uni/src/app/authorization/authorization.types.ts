export class Permissions { [key: string]: PermissionScope[] }

export class PermissionScope {
    // The id of the regulatory market
    rm: number | null;
    // The id of the technical formulation category
    tfc: number | null;
    // The id of the lowest Unilever product division the technical formulation category is a descendant of
    upd: number | null;
    // The ids of the regulatory product classes.
    rpcs: number[];
}

export class UserPermissions {
    permissions: { [permission: string]: string[] };
    scopes: Permissions;
}

export class TopicToUpdMapping {
    [topicId: number]: number[];
}