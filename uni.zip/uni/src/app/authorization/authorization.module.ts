import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { AuthenticationGuardService } from "./authentication-guard.service";
import { AuthenticationService } from "./authentication.service";
import { AuthorizationService } from "./authorization.service";
import { LoggedOutComponent } from "./logged-out/logged-out.component";
import { UnauthorizedComponent } from "./unauthorized/unauthorized.component";
import { ShowIfUserHasAnyPermissionDirective } from "./directives/show-if-user-has-any-permission.directive";
import { ShowIfUserHasAllPermissionsDirective } from './directives/show-if-user-has-all-permissions.directive';
import { ShowIfUserHasAnyPermissionForMarketAndProductDivisionDirective } from "./directives/show-if-user-has-any-permission-for-market-and-upd.directive";
import { ShowIfUserHasAnyPermissionForMarketProductClassAndTopicDirective } from "./directives/show-if-user-has-any-permission-for-market-rpc-and-topic.directive";
import { RouterModule } from "@angular/router";

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
    ],
    declarations: [
        LoggedOutComponent,
        UnauthorizedComponent,
        ShowIfUserHasAnyPermissionDirective,
        ShowIfUserHasAllPermissionsDirective,
        ShowIfUserHasAnyPermissionForMarketProductClassAndTopicDirective,
        ShowIfUserHasAnyPermissionForMarketAndProductDivisionDirective,
    ],
    entryComponents: [
    ],
    providers: [
        AuthenticationService,
        AuthenticationGuardService,
        AuthorizationService,
    ],
    exports: [
        UnauthorizedComponent,
        ShowIfUserHasAnyPermissionDirective,
        ShowIfUserHasAllPermissionsDirective,
        ShowIfUserHasAnyPermissionForMarketProductClassAndTopicDirective,
        ShowIfUserHasAnyPermissionForMarketAndProductDivisionDirective,
    ]
})

export class AuthorizationModule {
}