import { TestBed, getTestBed } from '@angular/core/testing';

import { AuthorizationService } from './authorization.service';
import { TopicToUpdMapping, Permissions } from './authorization.types';
import { Permission } from '../tools/shared-types/permissions/permission';
import { PermissionsLoaderService } from './permissions-loader/permissions-loader.service';
import { createPhraseAssignment } from '../testData';

class PermissionsLoaderServiceMock {
  permissions: Permissions = {
    'AraPReFDCT_Phrases_WriteWithAssignments': [
      {
        rm: 1,
        tfc: 21,
        upd: 420,
        rpcs: [51],
      },
      {
        rm: 2,
        tfc: 22,
        upd: 421,
        rpcs: [52, 53],
      },
    ],
    'AraPReFDCT_Phrases_Read': [
      {
        rm: 3,
        tfc: 23,
        upd: 422,
        rpcs: [54, 55],
      },
    ]
  };
  topicToUpdMapping: TopicToUpdMapping = {
    1: [420, 421],
    5: [422],
  };
  arePermissionsLoaded(): boolean {
    return true;
  }
}

class PermissionsLoaderServiceNoMapMock {
  permissions: Permissions = {
    'AraPReFDCT_Phrases_Read': [
      {
        rm: 2,
        tfc: 22,
        upd: 42,
        rpcs: [52, 53],
      },
    ]
  };
  topicToUpdMapping: null;
  arePermissionsLoaded(): boolean {
    return true;
  }
}

class PermissionsLoaderServiceNoPermissionsMock {
  permissions: null;
  topicToUpdMapping: TopicToUpdMapping = {
    1: [420, 421],
    5: [422]
  };
  arePermissionsLoaded(): boolean {
    return false;
  }
}

const validTopicId = 1;
const topicIdWithNoMatchingUpd = 5;
const validMarketId = 2;
const validRpcId = 53;
const validPermission = Permission.AraPReFDCT_Phrases_WriteWithAssignments;

describe('AuthorizationService', () => {
  let service: AuthorizationService;
  let permissionsLoaderServiceMock: PermissionsLoaderServiceMock;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AuthorizationService,
        { provide: PermissionsLoaderService, useClass: PermissionsLoaderServiceMock },
      ]
    });
    const injector = getTestBed();
    service = injector.get(AuthorizationService);
    permissionsLoaderServiceMock = injector.get(PermissionsLoaderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('checkUserHasAnyPermission', () => {
    it('should return false if user has no matching permission', () => {
      // Act
      const result = service.checkUserHasAnyPermission([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic]);

      // Assert
      expect(result).not.toBeNull();
      expect(result).toEqual(false);
    });
  });

  describe('checkUserCanModifyAssignment', () => {
    it('should return false for non existing assignment', () => {
      const result = service.checkUserCanModifyAssignment(createPhraseAssignment(0, 0, 0));

      expect(result).not.toBeNull();
      expect(result).toEqual(false);
    });

    it('should return false for invalid assignment object', () => {
      expect(service.checkUserCanModifyAssignment(null)).toEqual(false);
      expect(service.checkUserCanModifyAssignment(undefined)).toEqual(false);
    });

    it('should return true for valid existing assignment', () => {
      const result = service.checkUserCanModifyAssignment(createPhraseAssignment(0, 0, 0));

      expect(result).not.toBeNull();
      expect(result).toEqual(false);
    });
  });

  describe('checkUserHasPermissionForMarketRpcAndTopic', () => {
    it('should return true for valid selections', () => {
      expect(service.checkUserHasPermissionForMarketRpcAndTopic(validPermission, validMarketId, validRpcId, validTopicId)).toEqual(true);
    });

    it('should return false if permissions not available', () => {
      getTestBed().resetTestingModule();
      TestBed.configureTestingModule({
        providers: [
          AuthorizationService,
          { provide: PermissionsLoaderService, useClass: PermissionsLoaderServiceNoPermissionsMock },
        ]
      });
      service = getTestBed().get(AuthorizationService);
      expect(service.checkUserHasPermissionForMarketRpcAndTopic(validPermission, validMarketId, validRpcId, validTopicId)).toEqual(false);
    });

    it('should return false if topic to tfc map not available', () => {
      getTestBed().resetTestingModule();
      TestBed.configureTestingModule({
        providers: [
          AuthorizationService,
          { provide: PermissionsLoaderService, useClass: PermissionsLoaderServiceNoMapMock },
        ]
      });
      service = getTestBed().get(AuthorizationService);
      expect(service.checkUserHasPermissionForMarketRpcAndTopic(validPermission, validMarketId, validRpcId, validTopicId)).toEqual(false);
    });

    it('should return false if user has no matching permission', () => {
      expect(service.checkUserHasPermissionForMarketRpcAndTopic(Permission.AraPReFDCT_PhraseAssignments_DeclineTopic, validMarketId, validRpcId, validTopicId)).toEqual(false);
    });

    it('should return false if user has no matching market', () => {
      expect(service.checkUserHasPermissionForMarketRpcAndTopic(validPermission, 0, validRpcId, validTopicId)).toEqual(false);
    });

    it('should return false if user has no matching rpc', () => {
      expect(service.checkUserHasPermissionForMarketRpcAndTopic(validPermission, validMarketId, 0, validTopicId)).toEqual(false);
    });

    it('should return false if user has no matching topic', () => {
      expect(service.checkUserHasPermissionForMarketRpcAndTopic(validPermission, validMarketId, validRpcId, 0)).toEqual(false);
    });

    it('should return false if user has no matching topic', () => {
      expect(service.checkUserHasPermissionForMarketRpcAndTopic(validPermission, validMarketId, validRpcId, topicIdWithNoMatchingUpd)).toEqual(false);
    });
  });

  describe('checkUserHasAnyPermissionForMarketRpcAndTopic', () => {
    describe('given permission the user does not have', () => {
      describe('given null market, null RPC and null topic', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic]);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given invalid market, null RPC and null topic', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], 90000, null, null);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given null market, invalid RPC and null topic', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], null, 90001, null);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given null market, null RPC and invalid topic', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], null, null, 99999);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given valid market, null RPC and null topic', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], 1, null, null);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given null market, valid RPC and null topic', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], null, 51, null);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given null market, null RPC and valid topic', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], null, null, 1);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given valid market, valid RPC and valid topic', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], 1, 51, 1);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given invalid market, invalid RPC and invalid topic', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], 90000, 90001, 99999);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });
    });

    describe('given permission the user has', () => {
      describe('given null market, null RPC and null topic', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic]);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });

        it('should return true', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([validPermission]);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(true);
        });
      });

      describe('given valid market, null RPC and null topic', () => {
        it('should return true', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([validPermission], 1, null, null);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(true);
        });
      });

      describe('given null market, valid RPC and null topic', () => {
        it('should return true', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([validPermission], null, 51, null);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(true);
        });
      });

      describe('given null market, null RPC and valid topic', () => {
        it('should return true', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([validPermission], null, null, 1);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(true);
        });
      });

      describe('given invalid market, null RPC and null topic', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([validPermission], 90000, null, null);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given null market, invalid RPC and null topic', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([validPermission], null, 90001, null);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given null market, null RPC and invalid topic', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([validPermission], null, null, 99999);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given valid market, valid RPC and valid topic', () => {
        it('should return true', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([validPermission], 1, 51, 1);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(true);
        });
      });

      describe('given invalid market, invalid RPC and invalid topic', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([validPermission], 90000, 90001, 99999);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given invalid combination of valid market, valid RPC and valid topic', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketRpcAndTopic([validPermission], 1, 52, 5);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });
    });
  });

  describe('checkUserHasAnyPermissionForMarketAndProductDivision', () => {
    describe('given permission the user does not have', () => {
      describe('given null market and null UPD', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic]);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given null market and invalid UPD', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], null, 90001);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given null market and valid UPD', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], null, 21);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given invalid market and null UPD', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], 90000, null);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given invalid market and invalid UPD', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], 90000, 90001);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given invalid market and valid UPD', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], 90000, 21);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given valid market and null UPD', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], 1, null);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given valid market and invalid UPD', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], 1, 90001);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given valid market and valid UPD', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([Permission.AraPReFDCT_PhraseAssignments_DeclineTopic], 1, 21);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });
    });

    describe('given permission the user has', () => {
      describe('given null market and null UPD', () => {
        it('should return true', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([validPermission]);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(true);
        });
      });

      describe('given null market and invalid UPD', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([validPermission], null, 90001);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given null market and valid UPD', () => {
        it('should return true', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([validPermission], null, 21);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(true);
        });
      });

      describe('given invalid market and null UPD', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([validPermission], 90000, null);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given invalid market and invalid UPD', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([validPermission], 90000, 90001);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given invalid market and valid UPD', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([validPermission], 90000, 21);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given valid market and null UPD', () => {
        it('should return true', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([validPermission], 1, null);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(true);
        });
      });

      describe('given valid market and invalid UPD', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([validPermission], 1, 90001);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });

      describe('given valid market and valid UPD', () => {
        it('should return true', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([validPermission], 1, 21);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(true);
        });
      });

      describe('given invalid combination of valid market and valid UPD', () => {
        it('should return false', () => {
          // Act
          const result = service.checkUserHasAnyPermissionForMarketAndProductDivision([validPermission], 1, 22);

          // Assert
          expect(result).not.toBeNull();
          expect(result).toEqual(false);
        });
      });
    });
  });

  describe('getMarketsAndRPCsUserHasPermissionFor', () => {
    describe('given permission the user does not have', () => {
      it('should return an empty array', () => {
        // Act
        const result = service.getMarketsAndRpcsUserHasPermissionFor(Permission.AraPReFDCT_PhraseAssignments_DeclineTopic);

        // Assert
        expect(result).not.toBeNull();
        expect(result).toEqual([]);
      });
    });

    describe('given permission the user has', () => {
      it('should return an array with the correct market and UPD combinations', () => {
        // Act
        const result = service.getMarketsAndRpcsUserHasPermissionFor(validPermission);

        // Assert
        expect(result).not.toBeNull();

        const comparableResult = result.map(x => [x.regulatoryMarketId, x.regulatoryProductClassId])
          .sort();
        const expected = [
          [1, 51],
          [2, 52],
          [2, 53],
        ];
        expect(comparableResult).toEqual(expected);
      });
    });
  });

  describe('getMarketsAndUPDsUserHasPermissionFor', () => {
    describe('given permission the user does not have', () => {
      it('should return an empty array', () => {
        // Act
        const result = service.getMarketsAndUpdsUserHasPermissionFor(Permission.AraPReFDCT_PhraseAssignments_DeclineTopic);

        // Assert
        expect(result).not.toBeNull();
        expect(result).toEqual([]);
      });
    });

    describe('given permission the user has', () => {
      it('should return an array with the correct market and UPD combinations', () => {
        // Act
        const result = service.getMarketsAndUpdsUserHasPermissionFor(validPermission);

        // Assert
        expect(result).not.toBeNull();

        const comparableResult = result.map(x => [x.regulatoryMarketId, x.unileverProductDivisionId])
          .sort();
        const expected = [
          [1, 21],
          [2, 22]
        ];
        expect(comparableResult).toEqual(expected);
      });
    });
  });

  describe('userHoldsAllPermissions', () => {
    it('returns true if user holds all the specified permissions', () => {
      // Assemble
      const userPermissions: Permission[] = [
        Permission.AraPReFDCT_PhraseAssignments_Assess,
        Permission.AraPReFDCT_PhraseAssignments_DeclineTopic,
        Permission.AraPReFDCT_PhraseAssignments_Read
      ];
      const permissionsToCheck: Permission[] = [
        Permission.AraPReFDCT_PhraseAssignments_Assess,
        Permission.AraPReFDCT_PhraseAssignments_DeclineTopic,
        Permission.AraPReFDCT_PhraseAssignments_Read
      ];

      // Act
      const result = service.userHoldsAllPermissions(userPermissions, permissionsToCheck);

      // Assert
      expect(result).toBeTruthy();
    });

    it('returns false if user holds one of the specified permissions', () => {
      // Assemble
      const userPermissions: Permission[] = [
        Permission.AraPReFDCT_PhraseAssignments_Assess,
      ];
      const permissionsToCheck: Permission[] = [
        Permission.AraPReFDCT_PhraseAssignments_Assess,
        Permission.AraPReFDCT_PhraseAssignments_DeclineTopic,
        Permission.AraPReFDCT_PhraseAssignments_Read,
      ];

      // Act
      const result = service.userHoldsAllPermissions(userPermissions, permissionsToCheck);

      // Assert
      expect(result).toBeFalsy();
    });

    it('returns false if user holds none of the specified permissions', () => {
      // Assemble
      const userPermissions: Permission[] = [];
      const permissionsToCheck: Permission[] = [
        Permission.AraPReFDCT_PhraseAssignments_Assess,
        Permission.AraPReFDCT_PhraseAssignments_DeclineTopic,
        Permission.AraPReFDCT_PhraseAssignments_Read
      ];

      // Act
      const result = service.userHoldsAllPermissions(userPermissions, permissionsToCheck);

      // Assert
      expect(result).toBeFalsy();
    });
  });
});
