import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-unauthorized',
  templateUrl: './unauthorized.component.html',
})
export class UnauthorizedComponent implements OnInit {

  isAuthenticated = false;

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.isAuthenticated = this.route.snapshot.paramMap.get('isAuthenticated') === 'true';
  }

  getErrorMessage(): string {
    if (this.isAuthenticated) {
      return "You do not have the correct access permissions to use this functionality.";
    }
    return "You are not authorized to view the ARA application.";
  }

  getShowUNALink(): boolean {
    if (localStorage.getItem('showUNALink') == 'true') {
      return true;
    } else {
      return false;
    }
  }

  getUnauthorisedErrorMsgNum(): any {
    return localStorage.getItem('unauthorisedErrorMsgNum');
  }
}
