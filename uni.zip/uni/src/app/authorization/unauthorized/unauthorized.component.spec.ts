import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { UnauthorizedComponent } from './unauthorized.component';

describe('UnauthorizedComponent', () => {
  let component: UnauthorizedComponent;
  let fixture: ComponentFixture<UnauthorizedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [
        UnauthorizedComponent
      ],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnauthorizedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot when unauthenticated', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when unauthenticated', () => {
    component.isAuthenticated = true;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  describe('getErrorMessage', () => {
    it('should return correct message when authenticated', () => {
      // Arrange
      component.isAuthenticated = true;
      // Act & Assert
      expect(component.getErrorMessage()).toContain('permissions');
    });
    it('should return correct message when not authenticated', () => {
      // Arrange
      component.isAuthenticated = false;
      // Act & Assert
      expect(component.getErrorMessage()).toContain('authorized');
    });
  });
});