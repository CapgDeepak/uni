import { Injectable } from '@angular/core';
import { AuthorizationService } from './authorization.service';
import { ActivatedRouteSnapshot, CanActivate, CanActivateChild, Router, RouterStateSnapshot } from '@angular/router';
import { Observable, of } from 'rxjs';

@Injectable()
export class AuthenticationGuardService implements CanActivate, CanActivateChild {
  constructor(
    private authorizationService: AuthorizationService,
    private router: Router,
  ) { }

  /**
   * The canActivate method for the guard. Determines whether or not the calling
   * user can load the route or not, based on the user's authentication status.
   * @param route object containing info about the current ActivatedRoute
   */
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
        if (!this.authorizationService.arePermissionsAvailable()) {
      return this.authorizationService.permissionLoadEvent();
    }
    return of(this.isAuthorised(state.url));
  }

  canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    return this.canActivate(childRoute, state);
  }

  isAuthorised(urlPath: string): boolean {
    let hasAuthorisaton = true;
    if (urlPath === '/phrase-library') {
      hasAuthorisaton = this.authorizationService.userHasPermissionToViewPhraseLibrary();
    }
    // else if (urlPath === '/phrase-library/ordering') {
    //   hasAuthorisaton = this.authorizationService.userHasPermissionToOrderPhrases();
    // }
    else if (urlPath === '/phrase-matrix') {
      hasAuthorisaton = this.authorizationService.userHasPermissionToViewPhraseMatrix();
    } else if (urlPath === '/work-list/grams') {
      hasAuthorisaton = this.authorizationService.userHasPermissionToViewGramWorkList();
    } else if (urlPath.startsWith('/work-list/markets')) {
      hasAuthorisaton = this.authorizationService.userHasPermissionToViewMarketWorkList();
    } else if (urlPath.startsWith('/work-list/create')) {
      hasAuthorisaton = this.authorizationService.userHasPermissionToViewMarketWorkList();
    }
    if (!hasAuthorisaton) {
      console.log('isAuthorised failed - ' + hasAuthorisaton);
      this.router.navigate(['unauthorized/true']);
    }
    return hasAuthorisaton;
  }
}
