import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { QuillModule } from 'ngx-quill';
import { ToasterModule, ToasterService } from 'angular2-toaster';
import { CalendarModule } from 'primeng/calendar';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { NavMenuComponent } from './navmenu/navmenu.component';

import { ModulePreloadingStrategy } from './tools/module-preloading-strategy';
import { AuthorizationModule } from './authorization/authorization.module';
import { MenubarModule } from 'primeng/menubar';
import { ToolsModule } from './tools/tools.module';
import { SharedComponentsModule } from './shared-components/shared-components.module';
import { SubnavmenuComponent } from './navmenu/subnavmenu/subnavmenu.component';
import { TableModule } from 'primeng/table';
import { HelpSupportComponent } from './navmenu/help-support/help-support.component';
import { DialogModule } from 'primeng/dialog';

@NgModule({
    declarations: [
        AppComponent,
        NavMenuComponent,
        SubnavmenuComponent,
        HomeComponent,
        HelpSupportComponent
    ],
    imports: [
        AuthorizationModule,
        CommonModule,
        TableModule,
        DialogModule,
        HttpClientModule,
        FormsModule,
        QuillModule.forRoot(),
        RouterModule,
        SharedComponentsModule,
        ToasterModule.forRoot(),
        ToolsModule,
        MenubarModule,
        NgbModule,
        CalendarModule
    ],
    providers: [
        ToasterService,
        ModulePreloadingStrategy
    ]
})

export class AppModuleShared {
}
