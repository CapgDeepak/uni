import { Component, Input, OnInit, forwardRef, Output, EventEmitter } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR, ControlContainer, NgForm } from '@angular/forms';

import { Phrase, EmptyPhrase } from '../../phrase-library/phrase-library.types';
import { EmptyPhraseAssignment, PhraseAssignment, MarketRegulatoryProductClass, MarketRegulatoryProductClassFilter } from './phrase-assignments.types';
import { AlertDialogService } from '../alert-dialog/alert-dialog.service';
import { HttpService } from '../../tools/services/http.service';
import { FilterService } from '../../tools/services/filter.service';
import { UrlEndpoint, sortType } from '../../tools/constants';
import { FilterObject } from '../../tools/common.types';

const noop = () => {
};

@Component({
  selector: 'ara-phrase-assignments',
  templateUrl: './phrase-assignments.component.html',
  styleUrls: ['./phrase-assignments.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => PhraseAssignmentsComponent),
      multi: true
    }
  ],
  viewProviders: [
    {
      provide: ControlContainer,
      useExisting: NgForm,
    }
  ],
})
export class PhraseAssignmentsComponent implements OnInit, ControlValueAccessor {
  public newAssignment: EmptyPhraseAssignment = new EmptyPhraseAssignment();
  public phrase: Phrase = new EmptyPhrase();
  private assignmentCounter: number = -1;

  public allMarketRegulatoryProductClasses: MarketRegulatoryProductClass[] = new Array<MarketRegulatoryProductClass>();
  public marketRegulatoryProductClasses: MarketRegulatoryProductClass[] = new Array<MarketRegulatoryProductClass>();
  sortIcon: string = 'fa fa-ellipsis-v';
  constructor(
    private alertDialogService: AlertDialogService,
    private httpService: HttpService,
    private filterService: FilterService) { }

  ngOnInit(): void {
  }

  get value(): any {
    return this.phrase;
  }
  set value(newValue: any) {
    this.phrase = newValue || new EmptyPhrase();
    this.phrase.assignments = this.phrase.assignments || new Array<PhraseAssignment>();
  }

  private _topicId: number | null = null;
  @Input()
  get topicId(): number | null {
    return this._topicId;
  }
  set topicId(value: number | null) {
    if (this._topicId != value) {
      this._topicId = value;
      this.filter.topicId = value;
      this.filterChanged();
    }
  }

  private _topicText: string | null = null;
  @Input()
  get topicText(): string | null {
    return this._topicText;
  }
  set topicText(value: string | null) {
    if (this._topicText != value) {
      this._topicText = value;
      this.filter.topic = value;
    }
  }

  private isLoadingUpds: boolean = false; // UPDs are loaded in the child tree navigator
  private isLoadingRmRpcs: boolean = false;
  @Output() public isLoadingEvent: EventEmitter<boolean> = new EventEmitter<boolean>();

  private _isEol: boolean = true;
  public get isEol() {
    // Does search result embodies full result or is it capped
    return this._isEol;
  }

  private _unileverProductDivisionId: number | null = null;
  @Input()
  get unileverProductDivisionId(): number | null {
    return this._unileverProductDivisionId;
  }
  set unileverProductDivisionId(value: number | null) {
    if (this._unileverProductDivisionId != value) {
      this._unileverProductDivisionId = value;
      if (value) {
        this.productDivisionChanged(value);
      }
    }
  }

  productDivisionChanged(unileverProductDivisionId: number) {
    if (this.filter.productDivisionId != unileverProductDivisionId) {
      this._unileverProductDivisionId = unileverProductDivisionId;
      this.filter.productDivisionId = unileverProductDivisionId;
      this.filterChanged();
    }
  }

  handleUpdsLoaded(isLoading: boolean) {
    this.isLoadingUpds = isLoading;
    this.emitLoadingState();
  }

  private loadMarketRegulatoryProductClasses() {
    if (this.filter.topicId && this.filter.productDivisionId) {
      this.isLoadingRmRpcs = true;
      this.emitLoadingState();
      const selection = this.getMRPCSelection().concat();
      this.httpService.postContentPromise(this.filter, UrlEndpoint.PhraseLibrary_LoadMarketRPCs).then(result => {
        this.allMarketRegulatoryProductClasses = this.marketRegulatoryProductClasses = result.items;
        this._isEol = result.isEol;

        // Persist selection
        this.marketRegulatoryProductClasses
          .filter(c => selection.some(s =>
            s.regulatoryMarketId == c.regulatoryMarketId &&
            s.regulatoryProductClassId == c.regulatoryProductClassId))
          .forEach(c => c.isSelected = true);

        this.isLoadingRmRpcs = false;
        this.emitLoadingState();
      }, error => {
        this.isLoadingRmRpcs = false;
        this.emitLoadingState();
      });
    }
  }

  private _editable: boolean = false;
  @Input()
  get editable(): boolean {
    return this._editable;
  }
  set editable(value: boolean) {
    this._editable = value;
  }

  filter: MarketRegulatoryProductClassFilter = new MarketRegulatoryProductClassFilter();
  filterChanged() {
    this.loadMarketRegulatoryProductClasses();
  }

  private keyTimer: any = null;
  filterKeyUp(event: any) {
    if (this.filterService.isKeyCodeFilterable(event.keyCode)) {
      if (this.keyTimer) {
        clearTimeout(this.keyTimer);
        this.keyTimer = null;
      }
      if (event.keyCode == 13) {
        this.filterChanged();
      }
      else {
        this.keyTimer = setTimeout(() => {
          this.keyTimer = null;
          this.filterChanged();
        }, 1000);
      }
    }
  }

  selectMRPC(item: MarketRegulatoryProductClass, event: Event) {
    item.isSelected = !item.isSelected;
    event.stopPropagation();
  }

  private getMRPCSelection(): MarketRegulatoryProductClass[] {
    return this.allMarketRegulatoryProductClasses.filter(item => item.isSelected);
  }

  private setMRPCSelection(selected: boolean) {
    this.allMarketRegulatoryProductClasses.forEach(item => item.isSelected = selected);
  }

  private areAllMRPCSelected(): boolean {
    return this.allMarketRegulatoryProductClasses.length > 0 &&
      !this.allMarketRegulatoryProductClasses.some(item => !item.isSelected);
  }

  get selectAllMRPC(): boolean {
    return this.areAllMRPCSelected();
  }
  set selectAllMRPC(value: boolean) {
    const selectAll = this.areAllMRPCSelected();
    this.setMRPCSelection(!selectAll);
  }

  get addLabel(): string {
    const selCount = this.getMRPCSelection().length;
    const selPart = selCount > 1 ? selCount.toString() + " " : '';
    let label = `Add ${selPart}assignment`;
    if (selCount > 1) {
      label += 's';
    }
    return label;
  }

  get areNoMRPCsSelected(): boolean {
    return this.getMRPCSelection().length == 0;
  }

  get isSourceTooLong(): boolean {
    return this.newAssignment.source.length > 250;
  }

  get isAssignEnabled(): boolean {
    return !this.areNoMRPCsSelected && !this.isSourceTooLong;
  }

  public get assignButtonTooltipText(): string {
    if (this.areNoMRPCsSelected) {
      return 'Select one or more rows to assign the phrase to.';
    } else if (this.isSourceTooLong) {
      return 'The Source field is too long';
    } else {
      return '';
    }
  }

  addAssignment() {
    // Selected mrpc
    const sel = this.getMRPCSelection();
    console.log(sel);
    if (!sel.length) {
      return;
    }

    // Validate input
    const selValidated = sel.filter(item =>
      !this.phrase.assignments.some(a =>
        a.regulatoryProductClassId == item.regulatoryProductClassId &&
        a.regulatoryMarketId == item.regulatoryMarketId &&
        a.unileverProductDivisionId == item.unileverProductDivisionId));
    if (selValidated.length == 0) {
      this.alertDialogService.alert('Done', 'All selected topic, regulatory classes and market combinations have already been added.');
      return;
    }

    // Add
    selValidated.forEach(item => {
      const assignment = new EmptyPhraseAssignment();
      const source = this.addHref();
      assignment.regulatoryProductClassId = item.regulatoryProductClassId;
      assignment.regulatoryProductClassText = item.regulatoryProductClassSearchValue;
      assignment.regulatoryMarketId = item.regulatoryMarketId;
      assignment.regulatoryMarketText = item.regulatoryMarketDescription;
      assignment.source = source;
      assignment.unileverProductDivisionPath = item.unileverProductDivisionPath;
      assignment.unileverProductDivisionId = item.unileverProductDivisionId;
      assignment.id = this.assignmentCounter--;
      assignment.marketStatu = item.marketStatus;
      assignment.topicId = this.filter.topicId;
      assignment.topic = localStorage.getItem("topicDescExistAssigment");
      assignment.isUserUpd = true;
      assignment.assignmentStatusText = "To be assessed";
      this.phrase.assignments.push(assignment);
    });

    this.setMRPCSelection(false);
    this.onChangeCallback(this.phrase);
  }

  openSourceLink() {
    if (this.newAssignment.source) {
      if (this.newAssignment.source.indexOf("://") > 0) {
        this.newAssignment.source = this.newAssignment.source.trim();
        window.open(this.newAssignment.source, "_blank");
      }
      else {
        this.alertDialogService.alert("Error", "This link cannot be opened. URLs should be of the form 'https://www.example.com'");
      }
    }
  }

  addHref() {
    if (this.newAssignment.source) {
      if (this.newAssignment.source.indexOf('http://') >= 0 || this.newAssignment.source.indexOf('https://') >= 0 || this.newAssignment.source.indexOf('www.') >= 0) {
      this.newAssignment.source = this.newAssignment.source.trim();
      const array = this.newAssignment.source.split(" ");
      let str = "";
      const regexpUrl = new RegExp('http\:\/\/|https\:\/\/|www.');
      for ( const val in array ) {
           if (regexpUrl.test(array[val])){
          str += "<a href = " + array[val] + ">" + array[val] + "</a> ";
             } else {
             str += array[val] + " ";
            }
        }
      return str;
      } else {
        return this.newAssignment.source;
      }
    }
  }

  private onTouchedCallback: () => void = noop;
  private onChangeCallback: (_: any) => void = noop;

  public blur(): void {
    this.onTouchedCallback();
  }

  writeValue(obj: any): void {
    this.value = obj;
  }
  registerOnChange(fn: any): void {
    this.onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }

  public getTopicNavigatorFilterObject(): FilterObject {
    return {
      filterId1: this.topicId,
    };
  }

  emitLoadingState() {
    this.isLoadingEvent.emit(this.isLoadingRmRpcs || this.isLoadingUpds);
  }

  setSortOrder(columnName: string) {
    if (this.filter.sortDescending) {
      this.filter.sortDescending = !this.filter.sortDescending;
      this.marketRegulatoryProductClasses.sort(function(a, b){
        if (columnName == "Geography")
        { if (a.regulatoryMarketDescription > b.regulatoryMarketDescription){ return -1; }
            if ( a.regulatoryMarketDescription < b.regulatoryMarketDescription){ return 1; }
            return 0; }
        if (columnName == "RPC")
        { if ( a.regulatoryProductClassSearchValue > b.regulatoryProductClassSearchValue){ return -1; }
            if ( a.regulatoryProductClassSearchValue < b.regulatoryProductClassSearchValue){ return 1; }
            return 0; }
      });
    } else {
      this.filter.sortColumn = columnName;
      this.filter.sortDescending = true;
      this.marketRegulatoryProductClasses.sort(function(a, b){
        if (columnName == "Geography")
        {   if ( a.regulatoryMarketDescription < b.regulatoryMarketDescription){ return -1; }
            if ( a.regulatoryMarketDescription > b.regulatoryMarketDescription){ return 1; }
            return 0; }
        if (columnName == "RPC")
        { if ( a.regulatoryProductClassSearchValue < b.regulatoryProductClassSearchValue){ return -1; }
            if ( a.regulatoryProductClassSearchValue > b.regulatoryProductClassSearchValue){ return 1; }
            return 0; }
      });
    }
    return this.marketRegulatoryProductClasses;
  }

  getSortDirection(columnName: string): string {
    if (this.filter.sortColumn == columnName) {
      return (this.filter.sortDescending ? this.sortIcon = sortType.asc : this.sortIcon = sortType.desc);
    }
    return this.sortIcon = sortType.default;
  }

}