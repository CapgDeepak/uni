import { Component, OnInit, forwardRef, DoCheck, Input, Output, EventEmitter } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import * as isEqual from 'lodash.isequal';

import { Phrase, EmptyPhrase } from '../../phrase-library/phrase-library.types';
import { PhraseAssignment, PhraseAssignmentFilter } from './phrase-assignments.types';
import { AlertDialogService } from '../alert-dialog/alert-dialog.service';
import { ConfirmationDialogService } from '../confirmation-dialog/confirmation-dialog.service';
import { FilterService } from '../../tools/services/filter.service';
import { applyFiltersToArray } from '../../tools/utils';
import { sortType } from '../../tools/constants';

const noop = () => {
};

@Component({
    selector: 'existing-phrase-assignments',
    templateUrl: './existing-assignments.component.html',
    styleUrls: ['./phrase-assignments.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => ExistingPhraseAssignmentsComponent),
            multi: true
        }
    ]
})

export class ExistingPhraseAssignmentsComponent implements OnInit, ControlValueAccessor, DoCheck {
    public phrase: Phrase = new EmptyPhrase();
    public filteredAssignments: PhraseAssignment[] = [];
    sortingFlage: boolean = false;
    outSideUpd: boolean = false;

    marketForExistingAssignment: string = "";
    rpcForExistingAssignment: string = "";
    topicForExistingAssignment: string = "";
    updForExistingAssignment: string = "";

    constructor(
        private alertDialogService: AlertDialogService,
        private confirmationDialogService: ConfirmationDialogService,
        private filterService: FilterService) { }

    @Input() showRemoveAssignments: boolean;
    @Input() phraseForAssignments: Phrase = new EmptyPhrase();
    @Input() toPageForExistingAssignment: any = 20;
    @Output() pageChanged: EventEmitter<any> = new EventEmitter();
    @Output() filterChangedDetails: EventEmitter<any> = new EventEmitter();
    ngOnInit(): void {
    }

    public get pageNr(): number {
        return (this.toPageForExistingAssignment % 20);
    }

    public set pageNr(value: number) {
        this.toPageForExistingAssignment = value - 1;
    }

    ngDoCheck() { // used to pick up changes from the sibling control - to pick up when new assignments are added
        //  if (!isEqual(this.filteredAssignments.sort(compareAssignments()), this.phrase.assignments.sort(compareAssignments()))) {
        this.setPhraseAssignments();
        // }
    }

    get value(): any {
        return this.phrase;
    }

    set value(newValue: any) {
        this.phrase = newValue || new EmptyPhrase();
        this.phrase.assignmentIdsToDelete = new Array<number>(); // reset this when the tab loads, to clear out old values
        this.setPhraseAssignments();
    }

    private setPhraseAssignments() {
        this.phrase.assignments = this.phrase.assignments || new Array<PhraseAssignment>();
        this.filteredAssignments = this.phrase.assignments;
        this.filterChanged();
    }

    getAssignmentTopic(index: any) {
        this.filteredAssignments = this.phrase.assignments;
        if (this.filteredAssignments.length > 0) {
            this.filteredAssignments[index].topic = localStorage.getItem("topicDescExistAssigment");
            // localStorage.removeItem("topicDescExistAssigment");
            return this.filteredAssignments[index].topic;
        } else {
            return this.filteredAssignments[0].topic;
        }
    }

    filter: PhraseAssignmentFilter = new PhraseAssignmentFilter();
    filterChanged() {
        const data = {
            market: this.filter.regulatoryMarketText,
            rpc: this.filter.regulatoryProductClassText,
            topic: this.filter.topic,
            upd: this.filter.unileverProductDivisionPath
        };
        if (this.marketForExistingAssignment != data.market ||
            this.rpcForExistingAssignment != data.rpc ||
            (data.upd != null &&
                data.upd != undefined &&
                this.updForExistingAssignment != data.upd) ||
            (data.topic != null &&
                data.topic != undefined &&
                this.topicForExistingAssignment != data.topic)) {
            this.marketForExistingAssignment = data.market != undefined ? data.market : "";
            this.rpcForExistingAssignment = data.rpc != undefined ? data.rpc : "";
            this.updForExistingAssignment = data.upd != undefined ? data.upd : "";
            this.topicForExistingAssignment = data.topic != undefined ? data.topic : "";
            this.filterChangedDetails.emit(data);
        }
        if (!this.sortingFlage) {
            const nonRemovedAssignments = this.phrase.assignments.filter(a => !this.phrase.assignmentIdsToDelete.includes(a.id));
            this.filteredAssignments = applyFiltersToArray(nonRemovedAssignments, this.filter);
        }
    }

    private keyTimer: any = null;
    filterKeyUp(event: any) {
        this.sortingFlage = false;
        if (this.filter.sortColumn) {
            delete this.filter.sortColumn;
            delete this.filter.sortDescending;
        }
        if (this.filterService.isKeyCodeFilterable(event.keyCode)) {
            if (this.keyTimer) {
                clearTimeout(this.keyTimer);
                this.keyTimer = null;
            }
            if (event.keyCode == 13) {
                this.filterChanged();
            }
            else {
                this.keyTimer = setTimeout(() => {
                    this.keyTimer = null;
                    this.filterChanged();
                }, 100);
            }
        }
    }

    selectAssignment(assignment: PhraseAssignment, event: Event) {
        assignment.isSelected = !assignment.isSelected;
        event.stopPropagation();
    }

    private getAssignmentsSelection(): PhraseAssignment[] {
        return this.filteredAssignments.filter(item => item.isSelected);
    }

    private setAssignmentsSelection(selected: boolean) {
        this.filteredAssignments.forEach(item => item.isSelected = selected);
    }

    private areAllAssignmentsSelected(): boolean {
        return this.filteredAssignments.length > 0 &&
            !this.filteredAssignments.some(item => !item.isSelected);
    }

    get selectAllAssignments(): boolean {
        return this.areAllAssignmentsSelected();
    }
    set selectAllAssignments(value: boolean) {
        const selectAll = this.areAllAssignmentsSelected();
        this.setAssignmentsSelection(!selectAll);
    }

    get removeLabel(): string {
        return `Remove ${this.getLabelPart()}`;
    }

    private getLabelPart() {
        const selCount = this.getAssignmentsSelection().length;
        const selPart = selCount > 1 ? selCount.toString() + " " : '';
        let label = `${selPart}assignment`;
        if (selCount > 1) {
            label += 's';
        }
        return label;
    }

    get isRemoveEnabled(): boolean {
        const assignmentsToRemoveSelected = this.filteredAssignments.filter(a => a.isSelected);
        if (assignmentsToRemoveSelected) {
            if (assignmentsToRemoveSelected.every(a => a.isUserUpd)) {
                return this.getAssignmentsSelection().length > 0;
            }
        }
    }

    public get removeButtonTooltipText(): string {
        if (this.getAssignmentsSelection().length > 0) {
            return this.isRemoveEnabled ? '' : "Assignment outside user's UPD scope'";
        }
        return this.isRemoveEnabled ? '' : 'Select one or more rows to remove.';
    }

    removeAssignment() {
        const assignmentsToRemove = this.filteredAssignments.filter(a => a.isSelected);
        if (assignmentsToRemove) {
            if (assignmentsToRemove.every(a => a.allowModify)) {
                this.confirmationDialogService.confirm('Remove assignment', `Do you want to remove the selected ${this.getLabelPart()}?`).
                    then((confirmed) => {
                        if (confirmed) {
                            this.phrase.assignments = this.phrase.assignments.filter(x => !assignmentsToRemove.includes(x));
                            const oldAssignmentsToRemove = this.filteredAssignments.filter(a => a.isSelected && a.id > 0); // we only need to track old assignments (with positive IDs) to delete
                            this.phrase.assignmentIdsToDelete = this.phrase.assignmentIdsToDelete.concat(oldAssignmentsToRemove.map(a => a.id));
                            this.setAssignmentsSelection(false);
                            this.setPhraseAssignments();
                            this.onChangeCallback(this.phrase);
                        }
                    });
            }
            else {
                this.alertDialogService.alert("Forbidden", "You are not allowed to remove (one or more of) the assignment(s)!");
            }
        }
    }

    private onTouchedCallback: () => void = noop;
    private onChangeCallback: (_: any) => void = noop;

    public blur(): void {
        this.onTouchedCallback();
    }

    writeValue(obj: any): void {
        this.value = obj;
    }
    registerOnChange(fn: any): void {
        this.onChangeCallback = fn;
    }
    registerOnTouched(fn: any): void {
        this.onTouchedCallback = fn;
    }

    setSortOrder(columnName: string) {
        this.sortingFlage = true;
        if (this.filter.sortDescending) {
            this.filter.sortColumn = columnName;
            this.filter.sortDescending = !this.filter.sortDescending;
            this.filteredAssignments.sort(function (a, b) {
                if (columnName == "Geography") {
                    if (a.regulatoryMarketText > b.regulatoryMarketText) { return -1; }
                    if (a.regulatoryMarketText < b.regulatoryMarketText) { return 1; }
                    return 0;
                }
                if (columnName == "RPC") {
                    if (a.regulatoryProductClassText > b.regulatoryProductClassText) { return -1; }
                    if (a.regulatoryProductClassText < b.regulatoryProductClassText) { return 1; }
                    return 0;
                }
                if (columnName == "Topic") {
                    if (a.topic > b.topic) { return -1; }
                    if (a.topic < b.topic) { return 1; }
                    return 0;
                }
                if (columnName == "UPD") {
                    if (a.unileverProductDivisionPath > b.unileverProductDivisionPath) { return -1; }
                    if (a.unileverProductDivisionPath < b.unileverProductDivisionPath) { return 1; }
                    return 0;
                }
                if (columnName == "Status") {
                    if (a.assignmentStatusText > b.assignmentStatusText) { return -1; }
                    if (a.assignmentStatusText < b.assignmentStatusText) { return 1; }
                    return 0;
                }
            });
        } else {
            this.filter.sortDescending = true;
            this.filter.sortColumn = columnName;
            this.filteredAssignments.sort(function (a, b) {
                if (columnName == "Geography") {
                    if (a.regulatoryMarketText < b.regulatoryMarketText) { return -1; }
                    if (a.regulatoryMarketText > b.regulatoryMarketText) { return 1; }
                    return 0;
                }
                if (columnName == "RPC") {
                    if (a.regulatoryProductClassText < b.regulatoryProductClassText) { return -1; }
                    if (a.regulatoryProductClassText > b.regulatoryProductClassText) { return 1; }
                    return 0;
                }
                if (columnName == "Topic") {
                    if (a.topic < b.topic) { return -1; }
                    if (a.topic > b.topic) { return 1; }
                    return 0;
                }
                if (columnName == "UPD") {
                    if (a.unileverProductDivisionPath < b.unileverProductDivisionPath) { return -1; }
                    if (a.unileverProductDivisionPath > b.unileverProductDivisionPath) { return 1; }
                    return 0;
                }
                if (columnName == "Status") {
                    if (a.assignmentStatusText < b.assignmentStatusText) { return -1; }
                    if (a.assignmentStatusText > b.assignmentStatusText) { return 1; }
                    return 0;
                }
            });
        }
        this.phrase.assignments = this.filteredAssignments;
        return this.filteredAssignments;
    }

    getSortDirection(columnName: string): string {
        if (this.filter.sortColumn == columnName) {
            return (this.filter.sortDescending ? sortType.asc : sortType.desc);
        }
        return sortType.default;
    }

    loadPhraseAssignmentData(pageNr) {
        const pageNrNo = pageNr + 1;
        const toPageForExistingAssignment = (JSON.parse(localStorage.getItem('toPageForExistingAssignment'))) % 20;
        if (toPageForExistingAssignment + 1 != pageNrNo) {
            this.pageChanged.emit(pageNr + 1);
        }
    }
}

function compareAssignments(): (a: PhraseAssignment, b: PhraseAssignment) => number {
    return function (a, b) {
        return (a.isUserUpd === b.isUserUpd) ? 0 : a.isUserUpd ? -1 : 1;
    };
}