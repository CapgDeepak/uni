import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { EmptyPhraseAssignment, PhraseAssignment } from './phrase-assignments.types';
import { ExistingPhraseAssignmentsComponent } from './existing-assignments.component';
import { AlertDialogService } from '../alert-dialog/alert-dialog.service';
import { ConfirmationDialogService } from '../confirmation-dialog/confirmation-dialog.service';
import { FilterService } from '../../tools/services/filter.service';
import { getTestPhraseData } from '../../testData';

class AlertDialogServiceMock { }
class ConfirmationDialogServiceMock {
  confirm(): Promise<boolean> {
    return new Promise((resolve, reject) => resolve(true));
  }
}

class FilterServiceMock {
  isKeyCodeFilterable() { return true; }
}

describe('ExistingPhraseAssignmentsComponent', () => {
  let component: ExistingPhraseAssignmentsComponent;
  let fixture: ComponentFixture<ExistingPhraseAssignmentsComponent>;
  let injector: TestBed;
  let alertDialogService: AlertDialogService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ExistingPhraseAssignmentsComponent
      ],
      providers: [
        { provide: AlertDialogService, useClass: AlertDialogServiceMock },
        { provide: FilterService, useClass: FilterServiceMock },
        { provide: ConfirmationDialogService, useClass: ConfirmationDialogServiceMock },
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
      .compileComponents();

      injector = getTestBed();
      alertDialogService = injector.get(AlertDialogService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingPhraseAssignmentsComponent);
    component = fixture.componentInstance;
    component.phrase = getTestPhraseData();
    component.phrase.assignments = getAssignmentsData();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot when no assignments specified', () => {
    component.phrase.assignments = [];
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when assignments specified', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('removeLabel should display appropriately when no assignments specified', () => {
    component.phrase.assignments = [];
    fixture.detectChanges();
    expect(component.removeLabel).toEqual("Remove assignment");
  });

  describe('removeAssignment', () => {
    it('should not add assignment to delete when dealing with new assignments', () => {
      component.filteredAssignments[0].isSelected = true;
      component.filteredAssignments[0].allowModify = true;
      component.filteredAssignments[0].id = -1;
      component.removeAssignment();
      expect(component.phrase.assignmentIdsToDelete.length).toEqual(0);
    });

    it('should add assignment to delete when dealing with new assignments', async() => {
      component.filteredAssignments[0].isSelected = true;
      component.filteredAssignments[0].allowModify = true;
      component.filteredAssignments[0].id = 2;

      await component.removeAssignment();
      expect(component.phrase.assignmentIdsToDelete.length).toEqual(1);
      expect(component.phrase.assignmentIdsToDelete[0]).toEqual(2);
    });
  });

  it('removeLabel should display appropriately when assignments specified, but none selected', () => {
    fixture.detectChanges();
    expect(component.removeLabel).toEqual("Remove assignment");
  });

  it('ngDoCheck should not update selected assignments if these have not changed', () => {
    component.filteredAssignments = getAssignmentsData();
    fixture.detectChanges();
    component.ngDoCheck();
    expect(component.filteredAssignments).toEqual(component.phrase.assignments);
  });

  it('ngDoCheck should update selected assignments if source has assignment removed', () => {
    component.phrase.assignments.pop();
    fixture.detectChanges();
    component.ngDoCheck();
    expect(component.filteredAssignments == component.phrase.assignments);
    expect(component.filteredAssignments.length == 1);
  });

  it('ngDoCheck should update selected assignments if source has assignment added', () => {
    component.filteredAssignments = getAssignmentsData();
    component.phrase.assignments.push(new EmptyPhraseAssignment());
    fixture.detectChanges();
    component.ngDoCheck();
    expect(component.filteredAssignments == component.phrase.assignments);
    expect(component.filteredAssignments.length == 3);
  });

  it('ngDoCheck should order selected assignments if source has assignment changed', () => {
    component.filteredAssignments = getAssignmentsData();
    component.phrase.assignments.push(new EmptyPhraseAssignment());
    component.phrase.assignments[0].id = 0;
    component.phrase.assignments[0].regulatoryMarketText = "zambia";
    component.phrase.assignments[1].id = 1;
    component.phrase.assignments[1].regulatoryMarketText = "Austria";
    component.phrase.assignments[2].id = 2;
    component.phrase.assignments[2].regulatoryMarketText = "scotland";
    fixture.detectChanges();
    component.ngDoCheck();
    expect(component.filteredAssignments == component.phrase.assignments);
    expect(component.filteredAssignments.length == 3);
    expect(component.filteredAssignments[0].id = 1);
  });

  it('ngDoCheck should order selected assignments if source has assignment changed + duplicate market names', () => {
    component.filteredAssignments = getAssignmentsData();
    component.phrase.assignments.push(new EmptyPhraseAssignment());
    component.phrase.assignments[0].id = 0;
    component.phrase.assignments[0].regulatoryMarketText = "scotland";
    component.phrase.assignments[0].regulatoryProductClassText = "whisky";
    component.phrase.assignments[1].id = 1;
    component.phrase.assignments[1].regulatoryMarketText = "Austria";
    component.phrase.assignments[2].id = 2;
    component.phrase.assignments[2].regulatoryMarketText = "scotland";
    component.phrase.assignments[2].regulatoryProductClassText = "golf";
    fixture.detectChanges();
    component.ngDoCheck();
    // expect(component.filteredAssignments == component.phrase.assignments);
    // expect(component.filteredAssignments.length == 3);
    // expect(component.filteredAssignments[0].id == 1);
    // expect(component.filteredAssignments[2].id == 0);
  });

  it('ngDoCheck should update selected assignments if source has assignment changed', () => {
    component.filteredAssignments = getAssignmentsData();
    component.phrase.assignments[1].id = 222;
    fixture.detectChanges();
    component.ngDoCheck();
    expect(component.filteredAssignments == component.phrase.assignments);
    expect(component.filteredAssignments.length).toEqual(2);
  });

  it('removeLabel should display appropriately when assignments specified and one selected', () => {
    component.filteredAssignments[1].isSelected = true;
    fixture.detectChanges();
    expect(component.removeLabel).toEqual("Remove assignment");
  });

  it('removeLabel should display appropriately when assignments specified and more than one selected', () => {
    component.filteredAssignments[0].isSelected = true;
    component.filteredAssignments[1].isSelected = true;
    fixture.detectChanges();
    expect(component.removeLabel).toEqual("Remove 2 assignments");
  });

  it('isRemoveEnabled should return false when no assignments specified', () => {
    component.phrase.assignments = [];
    fixture.detectChanges();
    expect(component.isRemoveEnabled).toBeFalsy();
  });

  it('isRemoveEnabled should return false when assignments specified, but none selected', () => {
    fixture.detectChanges();
    expect(component.isRemoveEnabled).toBeFalsy();
  });

  it('isRemoveEnabled should return true when assignments specified and one selected', () => {
    component.filteredAssignments[1].isSelected = true;
    fixture.detectChanges();
    expect(component.isRemoveEnabled).toBeFalsy();
  });

  describe('when the showRemoveAssignments input', () => {
    describe('is true', () => {
      beforeEach(() => {
        component.showRemoveAssignments = true;
      });

      it('removeButtonTooltipText should return text when no assignments specified', () => {
          component.phrase.assignments = [];
          fixture.detectChanges();
          expect(component.removeButtonTooltipText).toBeTruthy();
      });

      it('removeButtonTooltipText should return text when assignments specified, but none selected', () => {
        fixture.detectChanges();
        expect(component.removeButtonTooltipText).toBeTruthy();
      });

      it('removeButtonTooltipText should return nothing when assignments specified and one selected', () => {
        component.filteredAssignments[1].isSelected = true;
        fixture.detectChanges();
        expect(component.removeButtonTooltipText).toBeTruthy();
      });

      it('Remove button should not be displayed when no data available', () => {
        component.phrase.assignments = [];
        fixture.detectChanges();
        const button = fixture.debugElement.query(By.css('#remove-button'));
        expect(button).toBeFalsy();
      });

      it('Remove button should be displayed when data available', () => {
        fixture.detectChanges();
        const button = fixture.debugElement.query(By.css('#remove-button'));
        expect(button).toBeTruthy();
      });

      it('Remove button should be disabled when no assignments specified', () => {
        fixture.detectChanges();
        const button = fixture.debugElement.query(By.css('#remove-button'));
        expect(button.properties.disabled).toBeTruthy();
      });

      it('Remove button should be disabled when assignments specified, but none selected', () => {
        fixture.detectChanges();
        const button = fixture.debugElement.query(By.css('#remove-button'));
        expect(button.properties.disabled).toBeTruthy();
      });
    });
    describe('is false', () => {
      beforeEach(() => {
        component.showRemoveAssignments = false;
      });
      describe('and no data is available', () => {
        it('Remove button should be hidden', () => {
          fixture.detectChanges();
          const button = fixture.debugElement.query(By.css('#remove-button'));
          expect(button).toBeFalsy();
        });
      });
      describe('and data is available', () => {
        beforeEach(() => {
          fixture.detectChanges();
        });
        it('Remove button should be hidden', () => {
          fixture.detectChanges();
          const button = fixture.debugElement.query(By.css('#remove-button'));
          expect(button).toBeFalsy();
        });
      });
    });
  });
});

function getAssignmentsData() {
  const assignments = new Array<PhraseAssignment>();
  assignments.push(new EmptyPhraseAssignment());
  assignments.push(new EmptyPhraseAssignment());
  return assignments;
}

