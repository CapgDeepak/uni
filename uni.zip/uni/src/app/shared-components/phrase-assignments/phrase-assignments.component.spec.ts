import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { EmptyPhraseAssignment, PhraseAssignment, MarketRegulatoryProductClass } from './phrase-assignments.types';
import { PhraseAssignmentsComponent } from './phrase-assignments.component';
import { AlertDialogService } from '../alert-dialog/alert-dialog.service';
import { CacheService } from '../../tools/services/cache.service';
import { DetailLevel } from '../../tools/common.types';
import { HttpService } from '../../tools/services/http.service';
import { FilterService } from '../../tools/services/filter.service';
import { UrlEndpoint } from '../../tools/constants';
import { FormsModule, NgForm } from '@angular/forms';
import { TreeNavigatorComponent } from '../tree-navigator/tree-navigator.component';

// Mocking global to test window.open (see https://stackoverflow.com/questions/41885841/how-to-mock-the-javascript-window-object-using-jest)
const globalAny: any = global;

class AlertDialogServiceMock { }
class CacheServiceMock {
  getDetailLevels(): Promise<DetailLevel[]> {
    return new Promise<DetailLevel[]>((resolve, reject) => {
      resolve(new Array<DetailLevel>());
    });
  }
}
class HttpServiceMock {
  getFiltered() {}
  postContentPromise(content: any, url: string) {
    switch (url) {
      case UrlEndpoint.PhraseLibrary_LoadMarketRPCs:
        return Promise.resolve({items: [], isEOL: true});
    }
  }
}

class FilterServiceMock {
  isKeyCodeFilterable() { return true; }
}

describe('PhraseAssignmentsComponent', () => {
  let component: PhraseAssignmentsComponent;
  let fixture: ComponentFixture<PhraseAssignmentsComponent>;
  let injector: TestBed;
  let alertDialogService: AlertDialogService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
      ],
      declarations: [
        PhraseAssignmentsComponent,
        TreeNavigatorComponent,
      ],
      providers: [
        { provide: AlertDialogService, useClass: AlertDialogServiceMock },
        { provide: CacheService, useClass: CacheServiceMock },
        { provide: FilterService, useClass: FilterServiceMock },
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: NgForm, useValue: new NgForm([], []) },
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
      .compileComponents();

      injector = getTestBed();
      alertDialogService = injector.get(AlertDialogService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhraseAssignmentsComponent);
    component = fixture.componentInstance;
    component.editable = true;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot when no assignments specified', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when assignments specified', () => {
    const assignments = new Array<PhraseAssignment>();
    assignments.push(new EmptyPhraseAssignment());
    assignments.push(new EmptyPhraseAssignment());
    component.phrase.assignments = assignments;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when new assignment specified', () => {
    const assignments = new Array<PhraseAssignment>();
    assignments.push(new EmptyPhraseAssignment());
    assignments.push(new EmptyPhraseAssignment());
    component.phrase.assignments = assignments;

    const newAssignment = new EmptyPhraseAssignment();
    newAssignment.source = 'source';
    component.newAssignment = newAssignment;

    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when unileverProductDivisionId is specified', () => {
    component.unileverProductDivisionId = 1;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  describe('openSourceLink', () => {
    it('should open the link in a new window when it is valid', () => {
      globalAny.open = jest.fn();
      const validUrl = 'https://www.example.com';
      component.newAssignment.source = validUrl;

      component.openSourceLink();

      expect(globalAny.open).toHaveBeenCalledWith('https://www.example.com', '_blank');
    });

    it('should not open the link in a new window when it is invalid', () => {
      globalAny.open = jest.fn();
      alertDialogService.alert = jest.fn();
      const validUrl = 'notValidUrl';
      component.newAssignment.source = validUrl;

      component.openSourceLink();

      expect(globalAny.open).toHaveBeenCalledTimes(0);
      expect(alertDialogService.alert).toHaveBeenCalled();
    });
  });

  it('addLabel should display appropriately when no assignments specified', () => {
    expect(component.addLabel).toEqual("Add assignment");
  });

  it('addLabel should display appropriately when assignments specified, but none selected', () => {
    component.allMarketRegulatoryProductClasses = getMarketAndRpcData();
    fixture.detectChanges();
    expect(component.addLabel).toEqual("Add assignment");
  });

  it('addLabel should display appropriately when assignments specified and one selected', () => {
    component.allMarketRegulatoryProductClasses = getMarketAndRpcData();
    component.allMarketRegulatoryProductClasses[1].isSelected = true;
    fixture.detectChanges();
    expect(component.addLabel).toEqual("Add assignment");
  });

  it('addLabel should display appropriately when assignments specified and more than one selected', () => {
    component.allMarketRegulatoryProductClasses = getMarketAndRpcData();
    component.allMarketRegulatoryProductClasses[0].isSelected = true;
    component.allMarketRegulatoryProductClasses[1].isSelected = true;
    fixture.detectChanges();
    expect(component.addLabel).toEqual("Add 2 assignments");
  });

  it('isAssignEnabled should return false when no assignments specified', () => {
    expect(component.isAssignEnabled).toBeFalsy();
  });

  it('isAssignEnabled should return false when assignments specified, but none selected', () => {
    component.allMarketRegulatoryProductClasses = getMarketAndRpcData();
    fixture.detectChanges();
    expect(component.isAssignEnabled).toBeFalsy();
  });

  it('isAssignEnabled should return true when assignments specified and one selected', () => {
    component.allMarketRegulatoryProductClasses = getMarketAndRpcData();
    component.allMarketRegulatoryProductClasses[1].isSelected = true;
    fixture.detectChanges();
    expect(component.isAssignEnabled).toBeTruthy();
  });

  it('assignButtonTooltipText should return text when no assignments specified', () => {
    expect(component.assignButtonTooltipText).toBeTruthy();
  });

  it('assignButtonTooltipText should return text when assignments specified, but none selected', () => {
    component.allMarketRegulatoryProductClasses = getMarketAndRpcData();
    fixture.detectChanges();
    expect(component.assignButtonTooltipText).toBeTruthy();
  });

  it('assignButtonTooltipText should return nothing when assignments specified and one selected', () => {
    component.allMarketRegulatoryProductClasses = getMarketAndRpcData();
    component.allMarketRegulatoryProductClasses[1].isSelected = true;
    fixture.detectChanges();
    expect(component.assignButtonTooltipText).toBeFalsy();
  });

  it('Assign button should be displayed', () => {
    component.allMarketRegulatoryProductClasses = getMarketAndRpcData();
    fixture.detectChanges();
    const button = fixture.debugElement.query(By.css('#assign-button'));
    expect(button).toBeTruthy();
  });

  it('Assign button should be disabled when no assignments specified', () => {
    component.allMarketRegulatoryProductClasses = getMarketAndRpcData();
    fixture.detectChanges();
    const button = fixture.debugElement.query(By.css('#assign-button'));
    expect(button.properties.disabled).toBeTruthy();
  });

  it('Assign button should be disabled when assignments specified, but none selected', () => {
    component.allMarketRegulatoryProductClasses = getMarketAndRpcData();
    fixture.detectChanges();
    const button = fixture.debugElement.query(By.css('#assign-button'));
    expect(button.properties.disabled).toBeTruthy();
  });

  it('Assign button should be enabled when assignments specified and one selected', () => {
    component.allMarketRegulatoryProductClasses = getMarketAndRpcData();
    component.allMarketRegulatoryProductClasses[1].isSelected = true;
    fixture.detectChanges();
    const button = fixture.debugElement.query(By.css('#assign-button'));
    expect(button.properties.disabled).toBeFalsy();
  });

  describe('isLoadingEvent', () => {
    it('should emit false on filterChanged with undefined filter', () => {
      spyOn(component.isLoadingEvent, 'emit');
      component.filterChanged();
      fixture.detectChanges();

      expect(component.isLoadingEvent.emit).toHaveBeenCalledTimes(0);
    });

    it('should emit true on filterChanged with defined filter', () => {
      spyOn(component.isLoadingEvent, 'emit');
      component.filter.topicId = 1;
      component.filter.productDivisionId = 1;
      component.filterChanged();
      fixture.detectChanges();

      expect(component.isLoadingEvent.emit).toHaveBeenCalledTimes(1);
      expect(component.isLoadingEvent.emit).toHaveBeenCalledWith(true);
    });
  });
});

function getMarketAndRpcData() {
  const assignments = new Array<MarketRegulatoryProductClass>();
  assignments.push({
    isSelected: false,
    regulatoryMarketId: 1,
    regulatoryMarketDescription: "europe",
    regulatoryProductClassId: 3,
    regulatoryProductClassSearchValue: "socks",
    isRegulatoryProductClassRoot: false,
    unileverProductDivisionId: 1,
    unileverProductDivisionPath: null,
    marketStatus: "",
    topicId: 3,
    topic: "Claims [I/A]"
  });
  assignments.push({
    isSelected: false,
    regulatoryMarketId: 2,
    regulatoryMarketDescription: "uk",
    regulatoryProductClassId: 3,
    regulatoryProductClassSearchValue: "socks",
    isRegulatoryProductClassRoot: false,
    unileverProductDivisionId: 2,
    unileverProductDivisionPath: null,
    marketStatus: "",
    topicId: 3,
    topic: "Claims [I/A]"
  });
  return assignments;
}
