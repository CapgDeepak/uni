export interface PhraseAssignment {
    assignmentStatus?: string;
    id: number | null;
    regulatoryMarketId: number | null;
    regulatoryMarketText: string;
    regulatoryProductClassId: number | null;
    regulatoryProductClassText: string;
    topicId: number | null;
    source: string;
    allowModify: boolean | null;
    isSelected: boolean;
    unileverProductDivisionId: number | null;
    unileverProductDivisionPath: number | null;
    isUserUpd: boolean | null;
    assignmentStatusText: string;
    topic: string;
}

export class EmptyPhraseAssignment implements PhraseAssignment {
    id: number | null = null;
    regulatoryMarketId: number | null = null;
    regulatoryMarketText: string = '';
    regulatoryProductClassId: number | null = null;
    regulatoryProductClassText: string = '';
    topicId: number | null = null;
    source: string = '';
    status: string = '';
    allowModify: boolean = true;
    isSelected: boolean = false;
    unileverProductDivisionId: number | null;
    unileverProductDivisionPath: number | null;
    marketStatu: string = '';
    isUserUpd: boolean | null;
    assignmentStatusText: string;
    topic: string;
}

export class PhraseAssignmentFilter {
    regulatoryMarketText: string = '';
    regulatoryProductClassText: string = '';
    source: string = '';
    assignmentStatusText: string = '';
    detailLevelText: string = '';
    unileverProductDivisionId: number | null;
    unileverProductDivisionPath: string | null;
    sortColumn: string;
    sortDescending: boolean;
    topic: string;
    topicId: number;
}

export interface MarketRegulatoryProductClass {
    isSelected: boolean;
    regulatoryMarketId: number;
    regulatoryMarketDescription: string;
    regulatoryProductClassId: number;
    regulatoryProductClassSearchValue: string;
    isRegulatoryProductClassRoot: boolean;
    unileverProductDivisionId: number | null;
    unileverProductDivisionPath: number | null;
    marketStatus: string;
    topicId: number;
    topic: string;
}

export class MarketRegulatoryProductClassResult {
    items: MarketRegulatoryProductClass[];
    isEol: boolean = true;
}

export class MarketRegulatoryProductClassFilter {
    rootRpcsOnly: boolean = true;
    productDivisionId: number | null;
    topicId: number;
    regulatoryMarketDescription: string;
    regulatoryProductClassSearchValue: string;
    sortColumn: string;
    sortDescending: boolean;
    topic: string;
}

export class ExistingAssignmentsFilter extends MarketRegulatoryProductClassFilter {
    detailLevel: string;
    source: string;
    status: string;
}

export class AuditPhraseAssignment {
    actionType: string;
    id: any;
    phraseId: number;
    phraseAssignmentId: number;
    phraseModifiedDate: any;
    regulatoryMarket: string;
    regulatoryProductClass: string;
    statusType: any;
    systemUserDisplayName: any;
}

export class AuditPhrase {
    actionType: string;
    id: any;
    phraseId: number;
    phraseModifiedDate: any;
    statusType: any;
    systemUserDisplayName: any;
}