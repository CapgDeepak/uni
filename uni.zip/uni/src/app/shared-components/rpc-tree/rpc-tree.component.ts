import { Component, OnInit, Output, EventEmitter, Input } from "@angular/core";
import { Params, ActivatedRoute } from '@angular/router';

import {  RpcTree, Rpc, Item } from '../../tools/common.types';
import { HttpService } from '../../tools/services/http.service';
import { UrlEndpoint } from '../../tools/constants';

@Component({
  selector: 'ara-rpc-tree',
  templateUrl: './rpc-tree.component.html',
  styleUrls: ['./rpc-tree.component.scss']
})
export class RpcTreeComponent implements OnInit {

    private initialRpcIdSelection: number;

    private _regulatoryMarketId: number | null = null;
    isSystemSelected: boolean = true;
    isRpcLoaded: boolean = true;
    get regulatoryMarketId(): number | null {
        return this._regulatoryMarketId;
    }
    @Input() set regulatoryMarketId(newValue: number | null) {
        if (newValue != this._regulatoryMarketId) {
            this._regulatoryMarketId = newValue;
            if (this._regulatoryMarketId > 0) {
                this.loadRpcsIfDataAvailable();
            }
        }
    }

    @Input() public items: Item[] = new Array<Item>();
    @Input() public required: boolean = false;


    private _regulatoryProductClassId: number | null = null;
    get regulatoryProductClassId(): number | null {
        return this._regulatoryProductClassId;
    }
    @Input() set regulatoryProductClassId(newValue: number | null) {
        if (newValue != this._regulatoryProductClassId) {
            this._regulatoryProductClassId = newValue;
            this.loadRpcsIfDataAvailable();
        }
    }
    // private rpcFilter: string | number | null = null;
    // get filter(): string | number | null {
    //     return this.rpcFilter;
    // }
    // @Input() set filter(value: string | number | null) {
    //     this.rpcFilter = value;
    // }

    public allNodes: RpcTree[] = new Array<RpcTree>();
    public tree: RpcTree[] = new Array<RpcTree>();
    public selectedNode: RpcTree | null = null;
    public tempNode: RpcTree | null = null;
    public newSelectedNode: RpcTree | null = null;

    @Output()
    selectionChange: EventEmitter<RpcTree | null> = new EventEmitter<RpcTree | null>();

    constructor(
        private httpService: HttpService,
        private route: ActivatedRoute) {
    }

    ngOnInit(): void {
        this.route.queryParams.forEach((params: Params) => {
            this.storeInitialSelection(params);
        });
    }

    private storeInitialSelection(params: Params) {
        // Note: the '+' on params here converts the string id to a number
        // - also: the RPC and Market IDs will be passed in via the matrix component - so no need to extract these here
        const rpcId = +params['rpcId'];
        if (rpcId > 0) {
            this.initialRpcIdSelection = rpcId;
        }
    }

    private loadRpcsIfDataAvailable() {
        if (this._regulatoryMarketId && this._regulatoryProductClassId > 0 && +sessionStorage.getItem("rpcId") > 0) {
            this.loadRpcs(this._regulatoryMarketId, this._regulatoryProductClassId);
        }
        else {
            const selectedNodeId = this.getCurrentlySelectedRpc();
            const expandedNodes = this.getExistingExpandedNodesAndCollapseTree();
            this.setupLoadedRpcsData([], expandedNodes, selectedNodeId);
        }
    }
    public getClass(node: RpcTree) {
        let classList = '';
        if (this.isSystemSelected && this.selectedNode != null && this.selectedNode.id == node.id && this.selectedNode.description.toLowerCase() == node.description.toLowerCase()) {
            classList = 'node-system-selected';
            if (!node.visible) {
                classList += 'node-invisible';
            }
        }
        else if (this.newSelectedNode != null && this.newSelectedNode.id == node.id && this.newSelectedNode.description.toLowerCase() == node.description.toLowerCase()) {
            if (classList != '') {
                classList = 'node-selected';
            }
            else {
                classList += 'node-selected';
            }
            if (!node.visible) {
                classList += 'node-invisible';
            }
        }
        // if ((this.rpcFilter != null || this.rpcFilter != '') && !node.visible) {
        //     if (classList != '') {
        //         classList = 'node-invisible';
        //     }
        //     else {
        //         classList += 'node-invisible';
        //     }
        // }
        return classList;
    }

    private loadRpcs(regulatoryMarketId: number, regulatoryProductClassId: number) {
        this.isRpcLoaded = true;
        const selectedNodeId = this.getCurrentlySelectedRpc();
        const expandedNodes = this.getExistingExpandedNodesAndCollapseTree();
        const filter = { marketId: regulatoryMarketId ? regulatoryMarketId.toString() : '' };
        if (regulatoryMarketId && regulatoryMarketId > -1) {
            this.httpService.getFilteredPromise(
                // { regulatoryMarketId: regulatoryMarketId.toString(), regulatoryProductClassId: regulatoryProductClassId.toString() },
                filter,  UrlEndpoint.RPCNavigator_AllItems)
                .then(rpcs => {
                    this.isRpcLoaded = false;
                    this.setupLoadedRpcsData(rpcs, expandedNodes, selectedNodeId);
                    if (!rpcs || rpcs.length == 0) {
                        this.selectionChange.emit(null);
                    }
                });
        } else {
            this.isRpcLoaded = false;
            this.setupLoadedRpcsData([], expandedNodes, selectedNodeId);
        }
    }

    private getCurrentlySelectedRpc() {
        if (+localStorage.getItem("selectedRpcId") > 0) {
            this.initialRpcIdSelection = +localStorage.getItem("selectedRpcId");
        }
        else {
            this.initialRpcIdSelection = +localStorage.getItem("rpcId");
        }
        let selectedNodeId: number | null = null;
        if (this.initialRpcIdSelection && (this.initialRpcIdSelection > 0)) {
            selectedNodeId = this.initialRpcIdSelection;
        }
        else if (this.selectedNode) {
            selectedNodeId = this.selectedNode.id;
        }
        return selectedNodeId;
    }

    private getExistingExpandedNodesAndCollapseTree() {
        const expandedNodes = new Array<number>();
        this.allNodes.filter(node => node.expanded).forEach(expanded => {
            expandedNodes.push(expanded.id);
        });
        this.allNodes = new Array<RpcTree>();
        return expandedNodes;
    }

    private setupLoadedRpcsData(rpcs: Rpc[], expandedNodes: number[], selectedNodeId: number) {
        this.isRpcLoaded = true;
        this.buildTreeRoot(rpcs, expandedNodes);
        const currentNode = this.getNodeOrDefault(selectedNodeId);
        this.expandAndSelectNode(currentNode);
        this.isRpcLoaded = false;
    }

    private getNodeOrDefault(selectedNodeId: number) {
        let currentNode: RpcTree | null;
        if (selectedNodeId) {
            currentNode = this.allNodes.find(n => n.id == selectedNodeId);
        }
        if (currentNode == null && this.tree.length > 0) { // select the first available node, if the current selection is not found
            currentNode = this.tree[0];
        }
        return currentNode;
    }

    private buildTreeRoot(rpcs: Rpc[], expandedNodes: number[]) {
        this.tree = new Array<RpcTree>();
        const rootRpcs = this.sortRpcsByOrder(rpcs.filter(i => i.parentId == null));
        rootRpcs.forEach(rpc => {
            const node = this.createRpcTreeNode(rpc, expandedNodes);
            this.tree.push(node);
            this.addChildNodes(node, rpcs, expandedNodes);
        });
    }

    private addChildNodes(node: RpcTree, rpcs: Rpc[], expandedNodes: number[]) {
        this.allNodes.push(node);
        this.fillChildNodes(node, rpcs, expandedNodes);
    }

    private createRpcTreeNode(rpc: Rpc, expandedNodes: number[]) {
        const node = new RpcTree();
        node.id = rpc.id;
        node.description = rpc.description;
        node.isDeclined = rpc.isDeclined;
        node.isValidForRpcAndMarket = rpc.isValidForRpcAndMarket;
        node.expanded = (expandedNodes.findIndex(value => value == rpc.id) >= 0);
        return node;
    }

    private fillChildNodes(parentNode: RpcTree, rpcs: Rpc[], expandedNodes: number[]) {
        const childRpcs = this.sortRpcsByOrder(rpcs.filter(i => i.parentId == parentNode.id));
        childRpcs.forEach(rpc => {
            const node = this.createRpcTreeNode(rpc, expandedNodes);
            node.parent = parentNode;
            parentNode.childs.push(node);
            this.addChildNodes(node, rpcs, expandedNodes);
        });
    }

    toggleNode(node: RpcTree) {
        node.expanded = !node.expanded;
    }

    expandNode(node: RpcTree) {
        node.expanded = true;
        if (node.expanded) {
            this.expandParentNodes(node.parent); // ensure the parent nodes are also expanded - needed if navigating to the page from a work list selection
        }
    }

    expandAndSelectNode(node: RpcTree) {
        if (node) {
            this.selectNode(node, false);
            this.expandNode(node);
        }
    }

    // isSystemSelected will be passed as false when user selects any node in the tree view
    // isSystemSelected is used in user selection and system selection
    selectNode(node: RpcTree, isSel: boolean) {
        if (node != null) {
            if (isSel) {
                this.newSelectedNode = node;
                localStorage.setItem("selectedRpcId", node.id.toString());
                this.selectedNode = null;
                if (this._regulatoryProductClassId > 0) {
                    this.selectionChange.emit(this.newSelectedNode);
                }
            }
            else if (this.selectedNode != node && !isSel) {
                this.selectedNode = node;
                this.newSelectedNode = null;
                localStorage.removeItem("selectedRpcId");
                if (this._regulatoryProductClassId > 0) {
                    this.selectionChange.emit(this.selectedNode);
                }
            }
            localStorage.setItem("rpcId", node.id.toString());
        }
    }

    public filterNodes(filter: string) {
        this.allNodes.forEach(element => {
            element.visible = filter == '' ||
                element.description.toLowerCase().includes(filter.toLowerCase());
        });

        if (filter != '') {
            this.allNodes.forEach(element => {
                if (element.visible) {
                    this.expandParentNodes(element.parent);
                }
            });
        } else {
            // reset the tree to the current selection
            this.allNodes.forEach(element => {
                element.expanded = false;
            });
            if (this.selectedNode != null || this.newSelectedNode) {
                this.expandAndSelectNode(this.selectedNode);
            }
            this.selectedNode != null ? this.expandAndSelectNode(this.selectedNode) : this.expandAndSelectNode(this.newSelectedNode);
        }
    }

    /**
     * Sort an array of rpcs by order
     * @param rpcs The array of rpcs to be sorted
     */
    public sortRpcsByOrder(rpcs: Rpc[]): Rpc[] {
        return rpcs.sort((x, y) => (x.order > y.order) ? 1 : (x.order < y.order) ? -1 : 0);
    }

    private expandParentNodes(parentNode: RpcTree) {
        while (parentNode != null) {
            parentNode.visible = true;
            parentNode.expanded = true;
            parentNode = parentNode.parent;
        }
        return parentNode;
    }
}