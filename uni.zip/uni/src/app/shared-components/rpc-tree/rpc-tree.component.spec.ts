import { async, ComponentFixture, TestBed, getTestBed  } from '@angular/core/testing';
import { HttpService } from '../../tools/services/http.service';
import { RpcTreeComponent } from './rpc-tree.component';
import { ActivatedRoute, Params } from '@angular/router';
import { Observable } from 'rxjs';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Rpc } from '../../tools/common.types';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

class ActivatedRouteMock {
  queryParams: Observable<Params> = new Observable<Params>(subscriber => {
    subscriber.complete();
  });
}
class HttpServiceMock {
  getFilteredPromise() {
    return new Promise<Rpc[]>((resolve) => {
      resolve([
        { id: 1, description: "Topic1", parentId: null, isDeclined: true, order: 1, isValidForRpcAndMarket: false },
        { id: 2, description: "Topic2", parentId: 1, isDeclined: false, order: 2, isValidForRpcAndMarket: false }
      ]);
    });
  }
}
describe('RpcTreeComponent', () => {
  let component: RpcTreeComponent;
  let fixture: ComponentFixture<RpcTreeComponent>;
  let httpService: HttpService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RpcTreeComponent ],
      providers: [
        { provide: ActivatedRoute, useClass: ActivatedRouteMock },
        { provide: HttpService, useClass: HttpServiceMock }
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA
      ]
    })
    .compileComponents();
    const injector = getTestBed();
    httpService = injector.get(HttpService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RpcTreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should not call GetList whilst data no marketId is specified', () => {
    // fixture.detectChanges();
    jest.spyOn(httpService, 'getFilteredPromise');
    component.regulatoryProductClassId = 3;
    expect(httpService.getFilteredPromise).toHaveBeenCalledTimes(0);
  });

});
