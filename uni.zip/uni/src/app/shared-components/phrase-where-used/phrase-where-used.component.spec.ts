import {  NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { PhraseWhereUsedComponent } from './phrase-where-used.component';
import { HttpService } from '../../tools/services/http.service';

class NgbActiveModalMock { }
class HttpServiceMock { }

describe('PhraseWhereUsedComponent', () => {
  let component: PhraseWhereUsedComponent;
  let fixture: ComponentFixture<PhraseWhereUsedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        PhraseWhereUsedComponent
      ],
      providers: [
        { provide: NgbActiveModal, useClass: NgbActiveModalMock },
        { provide: HttpService, useClass: HttpServiceMock }
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhraseWhereUsedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });
});
