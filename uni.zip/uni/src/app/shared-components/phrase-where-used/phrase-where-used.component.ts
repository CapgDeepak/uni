import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Phrase } from '../../phrase-library/phrase-library.types';

@Component({
    selector: 'ara-phrase-where-used',
    templateUrl: './phrase-where-used.component.html',
    styleUrls: ['./phrase-where-used.component.scss']
})
export class PhraseWhereUsedComponent {
    constructor(
        public activeModal: NgbActiveModal) {
    }

    public phrase: Phrase;
}