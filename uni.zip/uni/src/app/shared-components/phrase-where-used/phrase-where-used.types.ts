import { PhraseAssignment } from "../phrase-assignments/phrase-assignments.types";

export interface PhraseWhereUsed {
    phraseId: number;
    phraseText: string;
    assignments: PhraseAssignment[];
}

export class EmptyPhraseWhereUsed implements PhraseWhereUsed {
    phraseId: number;
    phraseText: string = "";
    assignments: PhraseAssignment[] = new Array<PhraseAssignment>();
}