import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { QuillModule } from 'ngx-quill';

import { AuthorizationModule } from '../authorization/authorization.module';

import { AlertDialogComponent } from './alert-dialog/alert-dialog.component';
import { AlertDialogService } from './alert-dialog/alert-dialog.service';
import { BootstrapTemplatesModule } from '../bootstrap-templates/bootstrap-templates.module';
import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';
import { ConfirmationDialogService } from './confirmation-dialog/confirmation-dialog.service';


import { ListBoxComponent } from './list-box/list-box.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PhraseTextComponent } from './phrase-text/phrase-text.component';
import { ProgressSpinnerComponent } from './progress-spinner/progress-spinner.component';
import { SelectEditableComponent } from './select-editable/select-editable.component';
import { TreeNavigatorComponent } from './tree-navigator/tree-navigator.component';
import { TreePathComponent } from './tree-path/tree-path.component';


import { PhraseStatusComponent } from './phrase-status/phrase-status.component';
import { BatchExportDialogComponent } from './batch-export-dialog/batch-export-dialog.component';
import { FindPhraseComponent } from './find-phrase/find-phrase.component';
import { ToolsModule } from '../tools/tools.module';
import { PhraseWhereUsedComponent } from './phrase-where-used/phrase-where-used.component';
import { ExistingPhraseAssignmentsComponent } from './phrase-assignments/existing-assignments.component';
import { EditPhraseService } from '../phrase-library/edit-phrase/edit-phrase.service';
import { LinkedPhraseComponent } from './linked-phrase/linked-phrase.component';
import { AssignmentSourceComponent } from './assignment-source/assignment-source.component';
import { PhraseTextChangesComponent } from './phrase-text-changes/phrase-text-changes.component';
import { TableModule } from 'primeng/table';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { RpcTreeComponent } from './rpc-tree/rpc-tree.component';

@NgModule({
    imports: [
        AuthorizationModule,
        BootstrapTemplatesModule,
        CommonModule,
        FormsModule,
        NgbModule,
        ToolsModule,
        TableModule,
        QuillModule,
        NgMultiSelectDropDownModule.forRoot(),
    ],
    declarations: [
        AlertDialogComponent,
        BatchExportDialogComponent,
        ConfirmationDialogComponent,
        ExistingPhraseAssignmentsComponent,
        FindPhraseComponent,
        ListBoxComponent,
        PageNotFoundComponent,
        LinkedPhraseComponent,
        PhraseStatusComponent,
        PhraseTextComponent,
        PhraseWhereUsedComponent,
        ProgressSpinnerComponent,
        SelectEditableComponent,
        TreeNavigatorComponent,
        TreePathComponent,
        AssignmentSourceComponent,
        PhraseTextChangesComponent,
        RpcTreeComponent,
    ],
    entryComponents: [
        AlertDialogComponent,
        BatchExportDialogComponent,
        ConfirmationDialogComponent,
        ExistingPhraseAssignmentsComponent,
        FindPhraseComponent,
        PhraseWhereUsedComponent,
    ],
    providers: [
        AlertDialogService,
        ConfirmationDialogService,
        EditPhraseService,
    ],
    exports: [
        AlertDialogComponent,
        ConfirmationDialogComponent,
        ExistingPhraseAssignmentsComponent,
        ListBoxComponent,
        PhraseStatusComponent,
        PhraseTextComponent,
        PhraseWhereUsedComponent,
        ProgressSpinnerComponent,
        SelectEditableComponent,
        TreePathComponent,
        TreeNavigatorComponent,
        LinkedPhraseComponent,
        AssignmentSourceComponent,
        PhraseTextChangesComponent,
        RpcTreeComponent
    ]
})
export class SharedComponentsModule {
}