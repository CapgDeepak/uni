import { TestBed, inject } from '@angular/core/testing';

import { ConfirmationDialogService } from './confirmation-dialog.service';
import { DialogService } from '../../tools/services/dialog.service';

class DialogServiceMock { }

describe('AlertDialogService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: DialogService, useClass: DialogServiceMock },
                ConfirmationDialogService
            ]
        });
    });

    it('should be created', inject([ConfirmationDialogService], (service: ConfirmationDialogService) => {
        expect(service).toBeTruthy();
    }));
});