import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmationDialogComponent } from './confirmation-dialog.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

class NgbActiveModalMock { }

describe('ConfirmationDialogComponent', () => {
    let component: ConfirmationDialogComponent;
    let fixture: ComponentFixture<ConfirmationDialogComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ConfirmationDialogComponent],
            providers: [
                { provide: NgbActiveModal, useClass: NgbActiveModalMock }
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ConfirmationDialogComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should match snapshot', () => {
        fixture.detectChanges();
        (expect(fixture) as any).toMatchSnapshot();
    });

    it('should match snapshot with data set', () => {
        component.message = "some dialog message";
        component.btnOkText = "some text for the ok button";
        component.btnCancelText = "some text for the cancel button";
        component.title = "some text for the dialog title bar";
        fixture.detectChanges();
        (expect(fixture) as any).toMatchSnapshot();
    });
});