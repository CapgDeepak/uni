import { Injectable } from '@angular/core';
import { ConfirmationDialogComponent } from './confirmation-dialog.component';
import { DialogService } from '../../tools/services/dialog.service';

@Injectable()
export class ConfirmationDialogService {
    constructor(private dialogService: DialogService) { }

    public confirm(title: string, message: string, btnOkText: string = 'OK', btnCancelText: string = 'Cancel', dialogSize: 'sm' | 'lg' = 'sm'): Promise<boolean> {
        const modalRef = this.dialogService.open(ConfirmationDialogComponent, {
            size: dialogSize,
            backdrop: 'static',
            centered: true
        });

        modalRef.componentInstance.title = title;
        modalRef.componentInstance.message = message;
        modalRef.componentInstance.btnOkText = btnOkText;
        modalRef.componentInstance.btnCancelText = btnCancelText;
        return modalRef.result;
    }

    public question(title: string, message: string, dialogSize: 'sm' | 'lg' = 'lg'): Promise<boolean> {
        return this.confirm(title, message, "Yes", "No", dialogSize);
    }
}