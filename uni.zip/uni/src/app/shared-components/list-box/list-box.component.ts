import { Component, forwardRef, Output, EventEmitter, Input } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { Item } from '../../tools/common.types';

const noop = () => {
};

@Component({
  selector: 'ara-list-box',
  templateUrl: './list-box.component.html',
  styleUrls: ['./list-box.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => ListBoxComponent),
      multi: true
    }
  ]
})
export class ListBoxComponent implements ControlValueAccessor {

  @Input() public items: Item[] = new Array<Item>();
  @Input() public required: boolean = false;

  private onTouchedCallback: () => void = noop;
  private onChangeCallback: (_: any) => void = noop;
  isSytemSelected: boolean = true;

  constructor() { }

  @Output()
  change: EventEmitter<number> = new EventEmitter<number>();

  selectedId: number = -1;
  newSelected: boolean = false;
  get value(): any {
    // if (+sessionStorage.getItem("rpcId") > 0) {
    if (+localStorage.getItem("rpcId") > 0) {
      this.selectedId = +localStorage.getItem("rpcId");
    }
    return this.selectedId;
  }
  set value(newValue: any) {
    if (this.selectedId != newValue) {
      this.selectedId = newValue;
      localStorage.setItem("rpcId", newValue.toString());
      // sessionStorage.setItem("rpcId", newValue.toString());
      this.newSelected = true;
      this.change.emit(newValue);
      this.onChangeCallback(newValue);
    }
  }

  selectItem(id: number) {
    this.isSytemSelected = false;
    this.value = id;
  }

  public blur(): void {
    this.onTouchedCallback();
  }

  writeValue(obj: any): void {
    this.selectedId = obj;
  }
  registerOnChange(fn: any): void {
    this.onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }

}
