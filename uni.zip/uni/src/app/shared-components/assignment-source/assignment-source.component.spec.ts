import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignmentSourceComponent } from './assignment-source.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { LinkService } from '../../tools/services/link.service';
import { createStatementAssignment } from '../../phrase-matrix/matrix-cell-edit/matrix-cell-edit.component.spec';
import { By } from '@angular/platform-browser';
import { AssignmentStatus, PhraseStatus } from '../../tools/constants';
import { FormsModule, NgForm } from '@angular/forms';
import { MaxLengthDirective } from '../../tools/directives/maxlength.directive';

class LinkServiceMock {
  openLink() {}
}

describe('AssignmentSourceComponent', () => {
  let component: AssignmentSourceComponent;
  let fixture: ComponentFixture<AssignmentSourceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
      ],
      declarations: [ AssignmentSourceComponent, MaxLengthDirective ],
      providers: [
        { provide: LinkService, useClass: LinkServiceMock },
        { provide: NgForm, useValue: new NgForm([], []) },
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignmentSourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when sourceIsEditable is false', () => {
    component.selected = createStatementAssignment();
    component.isSourceEditable = false;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when sourceIsEditable is true', () => {
    component.selected = createStatementAssignment();
    component.isSourceEditable = true;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('openSourceLink button displayed when selected has a source location', () => {
    component.selected = createStatementAssignment();
    component.selected.inheritedSourceLocation = null;
    fixture.detectChanges();
    const button = fixture.debugElement.query(By.css('.btn'));
    expect(button).toBeTruthy();
  });

  it('openSourceLink button hidden when selected does not have a source location', () => {
    component.selected = createStatementAssignment();
    component.selected.inheritedSourceLocation = null;
    component.selected.sourceLocation = null;
    fixture.detectChanges();
    const button = fixture.debugElement.query(By.css('.btn'));
    expect(button).toBeFalsy();
  });

  describe('sourceLocation not editable when', () => {
    beforeEach(() => {
      component.selected = createStatementAssignment();
    });

    it('selected is not active', () => {
      component.selected.isActive = false;
      fixture.detectChanges();
      const button = fixture.debugElement.query(By.css('#sourceLocation'));
      expect(button).toBeFalsy();
    });

    it('selected is to be approved', () => {
      component.selected.phraseAssignmentStatus = AssignmentStatus.NotRelevant;
      fixture.detectChanges();
      const button = fixture.debugElement.query(By.css('#sourceLocation'));
      expect(button).toBeFalsy();
    });

    it('selected is rejected', () => {
      component.selected.phraseStatus = PhraseStatus.Rejected;
      fixture.detectChanges();
      const button = fixture.debugElement.query(By.css('#sourceLocation'));
      expect(button).toBeFalsy();
    });
  });
});
