import { Component, Input } from '@angular/core';
import { StatementData } from '../../phrase-matrix/matrix-cell-edit/matrix-cell-edit.types';
import { LinkService } from '../../tools/services/link.service';
import { ControlContainer, NgForm } from '@angular/forms';

@Component({
  selector: 'app-assignment-source',
  templateUrl: './assignment-source.component.html',
  styleUrls: ['./assignment-source.component.scss'],
  viewProviders: [
    {
      provide: ControlContainer,
      useExisting: NgForm,
    }
  ],
})
export class AssignmentSourceComponent {

  constructor(private linkService: LinkService) { }

  @Input() selected: StatementData = null;
  @Input() isSourceEditable: boolean = false;

  openSourceLink(link: string) {
    if (this.selected) {
        this.linkService.openLink(link);
    }
  }
  public get isToBeAssessed(){
  if (this.isSourceEditable && this.selected.sourceLocation != null) {
    const re = /<a[\s]+href[^>]+>|<\/\a>/gi;
    const str = this.selected.sourceLocation;
    const replaceHref = str.replace(re, "");
  this.selected.sourceLocation = replaceHref;
  }
    return this.selected.phraseAssignmentStatus == "ToBeAssessedStatus";
  }
}
