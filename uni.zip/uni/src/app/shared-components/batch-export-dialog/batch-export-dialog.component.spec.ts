import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';

import { BatchExportDialogComponent } from './batch-export-dialog.component';
import { FormsModule } from '@angular/forms';
import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpService } from '../../tools/services/http.service';
import { of } from 'rxjs';

class HttpServiceMock {
  downloadFile() {
    return of(true);
  }
}

class NgbActiveModalMock {}

describe('BatchExportDialogComponent', () => {
  let component: BatchExportDialogComponent;
  let httpService: HttpService;
  let fixture: ComponentFixture<BatchExportDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BatchExportDialogComponent ],
      imports: [
        FormsModule,
        NgbModule
      ],
      providers: [
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: NgbActiveModal, useClass: NgbActiveModalMock },
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BatchExportDialogComponent);
    const injector = getTestBed();
    httpService = injector.get(HttpService);


    component = fixture.componentInstance;
    component.totalCount = 123456;
    component.filter = { filter: true };
    component.url = '/url';
    fixture.detectChanges();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when loading', () => {
    component.isLoading = true;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should calculate batch statistics on init', () => {
    expect(component.batchRange).toEqual([1, 2, 3]);
    expect(component.batchStart).toBe(1),
    expect(component.batchEnd).toBe(50000);
  });

  it('should call downloadFile on export', () => {
    jest.spyOn(httpService, 'downloadFile');
    component.export();
    expect(httpService.downloadFile).toHaveBeenCalledWith('/url', {filter: true, endIndex: 50000, startIndex: 0, isBatched: true});
    expect(component.isLoading).toBeFalsy();
  });
});
