import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpService } from './../../tools/services/http.service';
import { ExcelExportLimits } from '../../tools/constants';

@Component({
  selector: 'app-batch-export-dialog',
  templateUrl: './batch-export-dialog.component.html',
  styleUrls: ['./batch-export-dialog.component.scss']
})
export class BatchExportDialogComponent implements OnInit {

  @Input() totalCount: number = 0;
  @Input() filter: any;
  @Input() url: string;
  numberOfBatches: number = 0;
  batchRange = [];
  selectedBatch: number = 1;
  batchStart: number = 1;
  batchEnd: number = 1;
  isLoading: boolean = false;

  constructor(private activeModal: NgbActiveModal, private httpService: HttpService) { }

  ngOnInit() {
    this.numberOfBatches = Math.ceil(this.totalCount / ExcelExportLimits.BatchLimit);
    this.batchRange = Array.from(Array(this.numberOfBatches).keys()).map(x => ++x);
    this.calculateRowNumbers();
  }

  calculateRowNumbers() {
    this.batchStart = (ExcelExportLimits.BatchLimit * (this.selectedBatch - 1)) + 1;
    this.batchEnd = this.batchStart - 1 + ExcelExportLimits.BatchLimit < this.totalCount
      ? this.batchStart - 1 + ExcelExportLimits.BatchLimit
      : this.totalCount;
  }

  public cancel() {
      this.activeModal.close({exportData: false});
  }

  public export() {
    this.isLoading = true;
    this.filter.startIndex = (this.batchStart - 1);
    this.filter.endIndex = this.batchEnd;
    this.filter.isBatched = true;
    this.downloadContent(this.url, this.filter);
  }

  private downloadContent(url: string, filter: any) {
    return this.httpService.downloadFile(url, filter).subscribe(() => {
        this.isLoading = false;
      },
      () => {
        this.isLoading = false;
    });
  }

  identify(index, item) {
    return item.label;
 }
}
