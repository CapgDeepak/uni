import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PhraseTextChangesComponent } from './phrase-text-changes.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('PhraseTextChangesComponent', () => {
  let component: PhraseTextChangesComponent;
  let fixture: ComponentFixture<PhraseTextChangesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PhraseTextChangesComponent ],
      schemas: [ NO_ERRORS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhraseTextChangesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot for a new, uneditable phrase', () => {
    component.newText = 'New text';
    component.existingText = '';
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot for an edited, uneditable phrase', () => {
    component.newText = 'New text';
    component.existingText = 'Existing text';
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot for a new, editable phrase', () => {
    component.newText = 'New text';
    component.existingText = '';
    component.isEditable = true;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot for an edited, editable phrase', () => {
    component.newText = 'New text';
    component.existingText = 'Existing text';
    component.isEditable = true;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });
});
