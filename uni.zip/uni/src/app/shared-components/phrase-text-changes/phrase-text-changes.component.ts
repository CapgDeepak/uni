import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-phrase-text-changes',
  templateUrl: './phrase-text-changes.component.html',
  styleUrls: ['./phrase-text-changes.component.scss']
})
export class PhraseTextChangesComponent {

  constructor() { }

  @Input() existingText: string;
  @Input() newText: string;
  @Input() isEditable: boolean;
  @Input() quillModules;
  @Input() quillFormats;

  @Output() dataChangeEmitter: EventEmitter<string> = new EventEmitter<string>();

  onTextContentChange(text: string) {
    this.dataChangeEmitter.emit(text);
  }
}
