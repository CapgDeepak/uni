import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { Observable, throwError } from 'rxjs';

import { TreeNavigatorComponent } from './tree-navigator.component';
import { Item } from '../../tools/common.types';
import { HttpService } from '../../tools/services/http.service';
import { ItemSelector } from './tree-navigator.types';
import { By } from '@angular/platform-browser';

const mockItems: Item[] = [
  { id: 1, parentId: null, description: "Item1", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  { id: 2, parentId: null, description: "Item2", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  { id: 3, parentId: 1, description: "Item1a", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  { id: 4, parentId: 1, description: "Item1b", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  { id: 5, parentId: 2, description: "Item2a", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  { id: 6, parentId: 2, description: "Item2b", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  { id: 7, parentId: null, description: "Item3", requiresSubselection: true, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  { id: 8, parentId: 7, description: "Item3a", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
];

function createItemSelector(items: Item[], parentId: number | null, required: boolean): ItemSelector {
  const result = new ItemSelector();
  result.items = items;
  result.parentId = parentId;
  result.currentItem = required ? items[0] : { id: null, description: "", parentId: null, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false };
  result.required = required;
  return result;
}

const mockItemTree: ItemSelector[] = [
  createItemSelector([
    { id: 1, parentId: null, description: "Item1", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
    { id: 2, parentId: null, description: "Item2", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
    { id: 7, parentId: null, description: "Item3", requiresSubselection: true, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  ], null, true),
  createItemSelector([
    { id: 3, parentId: 1, description: "Item1a", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
    { id: 4, parentId: 1, description: "Item1b", requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
  ], 1, false),
];

let httpServiceReturnsError = false;
class HttpServiceMock {
  getFiltered() {
    if (httpServiceReturnsError) {
      return throwError('Expected error from HttpServiceMock');
    } else {
      return new Observable(observer => {
        observer.next(mockItems);
        observer.complete();
      });
    }
  }
}

describe('TreeNavigatorComponent', () => {
  const testControllerName = "TestController";

  let component: TreeNavigatorComponent;
  let fixture: ComponentFixture<TreeNavigatorComponent>;
  let httpService: HttpService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TreeNavigatorComponent],
      imports: [
        FormsModule
      ],
      providers: [
        { provide: HttpService, useClass: HttpServiceMock }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    httpService = getTestBed().get(HttpService);
    jest.spyOn(httpService, 'getFiltered');

    fixture = TestBed.createComponent(TreeNavigatorComponent);
    component = fixture.componentInstance;
    component.controllerName = testControllerName;
    component.required = true;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    (expect(fixture) as any).toMatchSnapshot();
  });

  describe('initialisation', () => {
    it('should call HttpService.getFiltered()', () => {
      const url = `api/${testControllerName}/AllItems`;

      expect(httpService.getFiltered).toHaveBeenCalledWith(null, url);
    });

    it('should set itemTree', () => {
      expect(component.itemTree).toEqual(mockItemTree);
    });

    it('should emit initial true load event', () => {
      jest.spyOn(component.isLoadingEvent, 'emit');
      fixture.detectChanges();
      component.ngOnInit();
      expect(component.isLoadingEvent.emit).toHaveBeenCalledTimes(2);
      expect(component.isLoadingEvent.emit).toHaveBeenNthCalledWith(1, true);
      expect(component.isLoadingEvent.emit).toHaveBeenNthCalledWith(2, false);
    });

    it('should load items', () => {
      expect(component.items).toEqual(mockItems);
    });
  });

  describe('set filter', () => {
    describe('HttpService.getFiltered() returns data', () => {
      beforeEach(() => {
        jest.clearAllMocks(); // this resets the calls to httpService - which will already have been invoked due to a call in ngOnInit
        httpServiceReturnsError = false;
      });

      describe('filtered is false', () => {
        beforeEach(() => {
          component.filtered = false;
          component.filter = { filterId1: 42 };
          fixture.detectChanges();
        });

        it('should call HttpService.getFiltered()', () => {
          const url = `api/${testControllerName}/AllItems`;

          expect(httpService.getFiltered).toHaveBeenCalledTimes(1);
          expect(httpService.getFiltered).toHaveBeenCalledWith(null, url);
        });

        it('should load items', () => {
          expect(component.items).toEqual(mockItems);
        });

        it('should set itemTree', () => {
          expect(component.itemTree).toEqual(mockItemTree);
        });

        it('should emit load events', () => {
          jest.spyOn(component.isLoadingEvent, 'emit');
          fixture.detectChanges();
          component.filter = { filterId1: 422 };
          expect(component.isLoadingEvent.emit).toHaveBeenCalledTimes(2);
          expect(component.isLoadingEvent.emit).toHaveBeenNthCalledWith(1, true);
          expect(component.isLoadingEvent.emit).toHaveBeenNthCalledWith(2, false);
        });
      });

      describe('filtered is true', () => {
        beforeEach(() => {
          jest.clearAllMocks();
          component.filtered = true;
          component.filter = { filterId1: 42 };
          fixture.detectChanges();
        });

        it('should call HttpService.getFiltered()', () => {
          const filter = {
            'filterId': '42',
            'filterId2': null,
            'filterId3': null,
          };
          const url = `api/${testControllerName}/AllItems`;

          expect(httpService.getFiltered).toHaveBeenCalledTimes(1);
          expect(httpService.getFiltered).toHaveBeenCalledWith(filter, url);
        });

        it('should load items', () => {
          expect(component.items).toEqual(mockItems);
        });

        it('should set itemTree', () => {
          expect(component.itemTree).toEqual(mockItemTree);
        });
      });

      describe('filtered is true but null filter set', () => {
        beforeEach(() => {
          jest.clearAllMocks();
          component.filtered = true;
          component.filter = null;
          fixture.detectChanges();
        });

        it('should not call HttpService.getFiltered()', () => {
          expect(httpService.getFiltered).not.toHaveBeenCalled();
        });
      });

      describe('filtered is true but empty filter set', () => {
        beforeEach(() => {
          component.filtered = true;
          component.filter = {
            filterId1: null,
            filterId2: null,
            filterId3: null
          };
          fixture.detectChanges();
        });

        it('should not call HttpService.getFiltered()', () => {
          expect(httpService.getFiltered).not.toHaveBeenCalled();
        });
      });

      describe('filtered is true but no filter set', () => {
        beforeEach(() => {
          component.filtered = true;
          component.filter = {};
          fixture.detectChanges();
        });

        it('should not call HttpService.getFiltered()', () => {
          expect(httpService.getFiltered).not.toHaveBeenCalled();
        });
      });
    });

    describe('HttpService.getFiltered() throws error', () => {
      beforeEach(() => {
        httpServiceReturnsError = true;
        component.filter = { filterId1: 42 };
      });

      it('should set items to an empty array', () => {
        expect(component.items).toEqual([]);
      });

      it('should set itemTree to an empty array', () => {
        expect(component.itemTree).toEqual([]);
      });
    });
  });

  describe('set filterId2', () => {
    describe('HttpService.getFiltered() returns data', () => {
      beforeEach(() => {
        jest.clearAllMocks(); // this resets the calls to httpService - which will already have been invoked due to a call in ngOnInit
        httpServiceReturnsError = false;
      });

      describe('filtered is false', () => {
        beforeEach(() => {
          component.filtered = false;
          component.filter = { filterId2: 42 };
          fixture.detectChanges();
        });

        it('should call HttpService.getFiltered()', () => {
          const url = `api/${testControllerName}/AllItems`;

          expect(httpService.getFiltered).toHaveBeenCalledTimes(1);
          expect(httpService.getFiltered).toHaveBeenCalledWith(null, url);
        });

        it('should load items', () => {
          expect(component.items).toEqual(mockItems);
        });

        it('should set itemTree', () => {
          expect(component.itemTree).toEqual(mockItemTree);
        });
      });

      describe('filtered is true', () => {
        beforeEach(() => {
          component.filtered = true;
          component.filter = { filterId2: 42 };
          fixture.detectChanges();
        });

        it('should call HttpService.getFiltered()', () => {
          const filter = {
            'filterId': null,
            'filterId2': '42',
            'filterId3': null,
          };
          const url = `api/${testControllerName}/AllItems`;

          expect(httpService.getFiltered).toHaveBeenCalledTimes(1);
          expect(httpService.getFiltered).toHaveBeenCalledWith(filter, url);
        });

        it('should load items', () => {
          expect(component.items).toEqual(mockItems);
        });

        it('should set itemTree', () => {
          expect(component.itemTree).toEqual(mockItemTree);
        });
      });
    });

    describe('HttpService.getFiltered() throws error', () => {
      beforeEach(() => {
        httpServiceReturnsError = true;
        component.filter = { filterId2: 42 };
      });

      it('should set items to an empty array', () => {
        expect(component.items).toEqual([]);
      });

      it('should set itemTree to an empty array', () => {
        expect(component.itemTree).toEqual([]);
      });
    });
  });

  describe('set filterId and filterId2', () => {
    describe('HttpService.getFiltered() returns data', () => {
      beforeEach(() => {
        jest.clearAllMocks(); // this resets the calls to httpService - which will already have been invoked due to a call in ngOnInit
        httpServiceReturnsError = false;
      });

      describe('filtered is false', () => {
        beforeEach(() => {
          component.filtered = false;
          component.filter = { filterId1: 42, filterId2: 43 };
          fixture.detectChanges();
        });

        it('should call HttpService.getFiltered()', () => {
          const url = `api/${testControllerName}/AllItems`;

          expect(httpService.getFiltered).toHaveBeenCalledTimes(1);
          expect(httpService.getFiltered).toHaveBeenCalledWith(null, url);
        });

        it('should load items', () => {
          expect(component.items).toEqual(mockItems);
        });

        it('should set itemTree', () => {
          expect(component.itemTree).toEqual(mockItemTree);
        });
      });

      describe('filtered is true', () => {
        beforeEach(() => {
          component.filtered = true;
          component.filter = { filterId1: 42, filterId2: 43 };
          fixture.detectChanges();
        });

        it('should call HttpService.getFiltered()', () => {
          const filter = {
            'filterId': '42',
            'filterId2': '43',
            'filterId3': null,
          };
          const url = `api/${testControllerName}/AllItems`;

          expect(httpService.getFiltered).toHaveBeenCalledTimes(1);
          expect(httpService.getFiltered).toHaveBeenCalledWith(filter, url);
        });

        it('should load items', () => {
          expect(component.items).toEqual(mockItems);
        });

        it('should set itemTree', () => {
          expect(component.itemTree).toEqual(mockItemTree);
        });
      });
    });

    describe('HttpService.getFiltered() throws error', () => {
      beforeEach(() => {
        httpServiceReturnsError = true;
        component.filter = { filterId1: 42, filterId2: 43 };
      });

      it('should set items to an empty array', () => {
        expect(component.items).toEqual([]);
      });

      it('should set itemTree to an empty array', () => {
        expect(component.itemTree).toEqual([]);
      });
    });
  });

  describe('reset', () => {
    describe('HttpService.getFiltered() throws error', () => {
      beforeEach(() => {
        httpServiceReturnsError = true;

        component.reset();
      });

      it('should set items to an empty array', () => {
        expect(component.items).toEqual([]);
      });

      it('should set itemTree to an empty array', () => {
        expect(component.itemTree).toEqual([]);
      });

      it('should match snapshot', () => {
        (expect(fixture) as any).toMatchSnapshot();
      });

      it('should emit load events', () => {
        jest.spyOn(component.isLoadingEvent, 'emit');
        fixture.detectChanges();
        component.reset();
        expect(component.isLoadingEvent.emit).toHaveBeenCalledTimes(2);
        expect(component.isLoadingEvent.emit).toHaveBeenNthCalledWith(1, true);
        expect(component.isLoadingEvent.emit).toHaveBeenNthCalledWith(2, false);
      });
    });
  });

  describe('setting preset value', () => {
    describe('setting value to one not found in items', () => {
      beforeEach(() => {
        httpServiceReturnsError = false;
        component.value = 999;
        component.filtered = false;
        fixture.detectChanges();
      });

      it('should call HttpService.getFiltered()', () => {
        const url = `api/${testControllerName}/AllItems`;
        expect(httpService.getFiltered).toHaveBeenCalledWith(null, url);
      });

      it('should load items', () => {
        expect(component.items).toEqual(mockItems);
      });

      it('should preset value to the first parent item id', () => {
        const select = fixture.debugElement.query(By.css('#tree-navigator-select-0'));
        expect(select.properties.value).toEqual("1");
      });
    });

    describe('setting value to a parent found in items', () => {
      beforeEach(() => {
        httpServiceReturnsError = false;
        component.value = 2;
        component.filtered = false;
        fixture.detectChanges();
      });

      it('should call HttpService.getFiltered()', () => {
        const url = `api/${testControllerName}/AllItems`;
        expect(httpService.getFiltered).toHaveBeenCalledWith(null, url);
      });

      it('should load items', () => {
        expect(component.items).toEqual(mockItems);
      });

      it('should preset value to the set value', () => {
        const select = fixture.debugElement.query(By.css('#tree-navigator-select-0'));
        expect(select.properties.value).toEqual("2");
      });
    });

    describe('setting value to a child found in items', () => {
      beforeEach(() => {
        httpServiceReturnsError = false;
        component.value = 4;
        component.filtered = false;
        fixture.detectChanges();
      });

      it('should call HttpService.getFiltered()', () => {
        const url = `api/${testControllerName}/AllItems`;
        expect(httpService.getFiltered).toHaveBeenCalledWith(null, url);
      });

      it('should load items', () => {
        expect(component.items).toEqual(mockItems);
      });

      it('should preset value to the parent of set value', () => {
        const select = fixture.debugElement.query(By.css('#tree-navigator-select-0'));
        expect(select.properties.value).toEqual("1");
      });
    });

    describe('setting value to a parent with requires-subselect found in items', () => {
      beforeEach(() => {
        httpServiceReturnsError = false;
        component.value = 7;
        component.filtered = false;
        fixture.detectChanges();
      });

      it('should call HttpService.getFiltered()', () => {
        const url = `api/${testControllerName}/AllItems`;
        expect(httpService.getFiltered).toHaveBeenCalledWith(null, url);
      });

      it('should load items', () => {
        expect(component.items).toEqual(mockItems);
      });

      it('should preset value to the first child value and set value to the child value', () => {
        const selects = fixture.debugElement.queryAll(By.css('#tree-navigator-select-0'));
        expect(selects.length).toEqual(1);
        const selectsChild = fixture.debugElement.queryAll(By.css('#tree-navigator-select-1'));
        expect(selectsChild.length).toEqual(1);
        expect(selectsChild[0].properties.value).toEqual("8");
        expect(component.value).toEqual(8);
      });
    });

    describe('setting value to null', () => {
      beforeEach(() => {
        httpServiceReturnsError = false;
        component.required = false;
        component.value = 7;
        component.filtered = false;
        fixture.detectChanges();
      });

      it('should preset value to the any value', () => {
        component.value = null;
        fixture.detectChanges();

        const selects = fixture.debugElement.queryAll(By.css('#tree-navigator-select-0'));
        expect(selects.length).toEqual(1);
        expect(selects[0].properties.value).toEqual("null");
        const selectsChild = fixture.debugElement.queryAll(By.css('#tree-navigator-select-1'));
        expect(selectsChild.length).toEqual(0);
      });

      it('should emit changes', () => {
        let onChangeCalled = false;
        component.registerOnChange(() => onChangeCalled = true);
        component.value = null;
        expect(onChangeCalled).toBe(true);
      });
    });
  });

  describe("emits changes", () => {
    it("should emit changes if value property set", () => {
      let onChangeCalled = false;
      component.registerOnChange(() => onChangeCalled = true);
      component.value = 3;
      expect(onChangeCalled).toBe(true);
    });

    it("should not emit changes if writeValue method called", () => {
      let onChangeCalled = false;
      component.registerOnChange(() => onChangeCalled = true);
      component.writeValue(3);
      expect(onChangeCalled).toBe(false);
    });
  });
});
