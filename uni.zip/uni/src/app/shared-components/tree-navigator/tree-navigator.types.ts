import { Item } from "../../tools/common.types";

export class ItemSelector {
    public items: Item[] = new Array<Item>();
    public parentId: number | null = null;
    public currentItem: Item = { id: null, description: "", parentId: null, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false };
    public required: boolean = false;
}