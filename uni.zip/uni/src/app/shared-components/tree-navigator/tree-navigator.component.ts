import { Component, Input, Output, EventEmitter, OnInit, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import * as isEqual from 'lodash.isequal';

import { Item, FilterObject } from '../../tools/common.types';
import { ItemSelector } from './tree-navigator.types';
import { HttpService } from '../../tools/services/http.service';

const noop = () => {
};

interface ControllerFilterSet {
  filterId: string | null;
  filterId2: string | null;
  filterId3: string | null;
}

@Component({
  selector: 'tree-navigator',
  templateUrl: './tree-navigator.component.html',
  styleUrls: ['./tree-navigator.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => TreeNavigatorComponent),
      multi: true
    }
  ]
})

export class TreeNavigatorComponent implements OnInit, ControlValueAccessor {
  public itemTree: ItemSelector[] = new Array<ItemSelector>();

  private onTouchedCallback: () => void = noop;
  private onChangeCallback: (_: any) => void = noop;

  @Output() selectionChange: EventEmitter<number | null> = new EventEmitter<number | null>();
  @Output() public isLoadingEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() public valueChanged: EventEmitter<any> = new EventEmitter<any>();

  @Input() controllerName: string = "";
  @Input() filtered: boolean = false;
  @Input() name: string = "";
  @Input() required: boolean = false;
  @Input() items: Item[] = new Array<Item>();
  @Input() isCreateMarket: boolean = false;
  @Input() EditableAllowed: boolean = false;
  private suspendChangeNotifications: boolean = false;
  selectedItemId: number | null;
  isSystemSelected: boolean = true;


  constructor(
    private httpService: HttpService) {
  }

  private _presetItem: number | null;
  get value(): any {
    return this.getCurrentItemId();
  }
  set value(value: any) {
    const currentValue = this.getCurrentItemId() || this._presetItem;
    if (value != currentValue) {
      this._presetItem = value;
      this.selectPresetItem(this._presetItem); // we assume we have data loaded at this point, so just directly update the selected item
    }
  }

  private _filter: FilterObject | null = null;
  get filter(): FilterObject | null {
    return this._filter;
  }
  @Input() set filter(newValue: FilterObject | null) {
    // If the filter has changed, then we reload the items that the tree navigator component is to display.
    if (!isEqual(newValue, this._filter)) {
      this._filter = newValue;
      this.loadItems();
    }
  }

  private setCurrentItemId(selector: ItemSelector, value: number | null) {
    selector.currentItem = {
      id: null, description: "", parentId: null, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false
    };
    if ((value != null) && (value > 0) && (value.toString() != "null")) {
      const itemIndex = selector.items.findIndex(myObj => myObj.id == value);
      if (itemIndex >= 0) {
        selector.currentItem.id = selector.items[itemIndex].id;
        selector.currentItem.description = selector.items[itemIndex].description;
        selector.currentItem.requiresSubselection = selector.items[itemIndex].requiresSubselection;
        selector.currentItem.isUserAuthorizedMarket = selector.items[itemIndex].isUserAuthorizedMarket;
      }
    }

    if (!this.suspendChangeNotifications) {
      this.selectionChange.emit(selector.currentItem.id);
      this.selectedItemId = selector.currentItem.id;
      this.onChangeCallback(selector.currentItem.id);
    }
  }

  private getCurrentItemId(): number | null {
    if (this.itemTree.length > 0) {
      if (this.itemTree[this.itemTree.length - 1].currentItem.id != null) {
        return this.itemTree[this.itemTree.length - 1].currentItem.id;
      }
      else {
        return -1;
      }
    }
    return null;
  }

  ngOnInit(): void {
    // If the tree navigator uses filters, then we do not need to load items in
    // ngOnInit as a loadItems call is triggered from the filter change (see filter input setter).
    if (!this.filtered) {
      this.loadItems();
    }
  }

  private selectPresetItem(itemId: number | null) {
    if (itemId == null && !this.required) {
      // Explicitly set the selector to the 'any' value.
      this.fillRootLevel();
      this.itemTree[0].currentItem.id = null;
      this.itemTree[0].currentItem.description = null;
      if (!this.suspendChangeNotifications) {
        this.selectionChange.emit(null);
        this.selectedItemId = null;
        this.onChangeCallback(null);
      }

      return;
    }

    // Set item given the itemId input if found in items
    let item = this.items.find(i => i.id == itemId);
    if (!item) {
      // If not found in items, items are first set to parents, then children, otherwise null
      item = this.items.find(i => i.parentId == null);
      if (!item) {
        item = this.items.length == 0 ? null : this.items[0];
      }
    }
    if (item) {
      this._presetItem = item.id;
      // Collect all parents for the specified item id
      let parentIds = new Array<number>();
      while ((item != null) && (item.parentId > 0)) {
        parentIds.push(item.parentId);
        item = this.items.find(i => i.id == item.parentId);
      }
      parentIds = parentIds.reverse();

      // Populate the dropdowns in reverse order (top to bottom)
      this.fillRootLevel();
      let levelIndex = 0;
      parentIds.forEach(id => {
        const selector = this.itemTree[levelIndex];
        const itemIndex = selector.items.findIndex(myObj => myObj.id == id);
        if (itemIndex >= 0) {
          selector.currentItem.id = selector.items[itemIndex].id;
          selector.currentItem.description = selector.items[itemIndex].description;
        }
        this.fillNextLevel(id);
        levelIndex++;
      });
      // Select the item in the last dropdown
      this.setCurrentItemId(this.itemTree[this.itemTree.length - 1], this._presetItem);
      this.fillNextLevel(this._presetItem);
    }
  }

  public reset() {
    this.loadItems();
  }

  private createFilterSet() {
    if (!this._filter || !this.filtered) {
      return null;
    }

    return {
      'filterId': (this._filter.filterId1 || this._filter.filterId1 == 0) && this._filter.filterId1.toString() || null,
      'filterId2': (this._filter.filterId2 || this._filter.filterId2 == 0) && this._filter.filterId2.toString() || null,
      'filterId3': (this._filter.filterId3 || this._filter.filterId3 == 0) && this._filter.filterId3.toString() || null,
    };
  }

  /**
   * Returns a boolean value indicating whether the given filter values are 'current', i.e. they
   * equal the current filter selection.  If they are not current, then the filters have changed
   * since the request was submitted and hence the returned data are likely to be out of date.
   * @param filterToUse The filters that were applied as part of the given HTTP request.
   * @return True if the filters given are current, false otherwise.
   */
  private isFilterSetCurrent(filterToUse: ControllerFilterSet | null): boolean {
    const currentFilterSet: ControllerFilterSet = this.createFilterSet();
    if (currentFilterSet === null && filterToUse === null) {
      return true;
    }

    if (currentFilterSet === null || filterToUse === null) {
      return false;
    }

    return currentFilterSet.filterId == filterToUse.filterId
      && currentFilterSet.filterId2 == filterToUse.filterId2
      && currentFilterSet.filterId3 == filterToUse.filterId3;
  }

  private loadItems() {
    if (this.controllerName != "") {
      this.items = new Array<Item>();
      let filterToUse = null;
      if (this.filtered) {
        // if we are expecting to use a filter and none has been specified yet, then escape early to avoid unnecessary loading
        if (!this._filter || !(this._filter.filterId1 || this._filter.filterId2 || this._filter.filterId3)) {
          return;
        }
        filterToUse = this.createFilterSet();
      }
      const url = 'api/' + this.controllerName + '/AllItems';
      this.isLoadingEvent.emit(true);
      this.httpService.getFiltered(filterToUse, url)
        .subscribe(result => {
          this.isLoadingEvent.emit(false);
          if (!this.isFilterSetCurrent(filterToUse)) {
            return;
          }

          this.items = result as Item[];
          this.fillRootLevel();
          if (this._presetItem != null) {
            this.selectPresetItem(this._presetItem);
          }
        }, error => {
          this.isLoadingEvent.emit(false);
          console.error(error);
        });
    }
    else {
      this.fillRootLevel();
    }
  }

  private fillRootLevel() {
    this.itemTree = new Array<ItemSelector>();
    const selector = new ItemSelector();
    const defaultSelector = new ItemSelector();
    selector.items = this.items.filter(i => i.parentId == null);
    defaultSelector.items = this.items.filter(i => i.parentId == null && i.description.includes('Claims'));
    if (this.isCreateMarket) {
      if (defaultSelector.items.length > 0) {
        selector.required = !this.required;
        selector.currentItem.id = defaultSelector.items[0].id;
        sessionStorage.setItem("marketTopicId", selector.currentItem.id.toString());
      }
      else {
        selector.required = !this.required;
        selector.currentItem.id = selector.items[0].id;
        sessionStorage.setItem("marketTopicId", selector.currentItem.id.toString());
      }
    }
    selector.required = this.required;
    if (selector.required && (selector.items.length > 0) && !this._presetItem) {
      selector.currentItem = {
        id: selector.items[0].id,
        description: selector.items[0].description,
        parentId: null,
        requiresSubselection: selector.items[0].requiresSubselection,
        regulatoryMarketId: 0,
        isUserAuthorizedMarket: false
      };
    }
    this.itemTree.push(selector);
    if (selector.currentItem.id != null) {
      this.setCurrentItemId(selector, selector.currentItem.id);
      this.fillNextLevel(selector.currentItem.id);
      localStorage.setItem("topicDescExistAssigment", selector.currentItem.description);
      this.valueChanged.emit();
    }
  }

  private fillNextLevel(parentId: number) {
    const newItems = this.items.filter(i => i.parentId == parentId);
    const parentItem = this.items.filter(i => i.id == parentId)[0];
    if (newItems.length > 0) {
      let selector = this.itemTree.find(s => s.parentId == parentId);
      if (selector == null) {
        selector = new ItemSelector();
        selector.parentId = parentId;
        selector.required = (!!parentItem && parentItem.requiresSubselection);
        this.itemTree.push(selector);
      }
      selector.items = newItems;

      if (this.itemTree.length == 0) {
        selector.required = this.required;
      }

      if (selector.required && (selector.items.length > 0)) {
        this.setCurrentItemId(selector, selector.items[0].id);
        localStorage.setItem("topicDescExistAssigment", selector.currentItem.description);
      }
    }
  }

  getCurrentItemPath(): Item[] {
    const result = new Array<Item>();
    if (this.itemTree.length > 0) {
      for (let i = 0; i < this.itemTree.length; i++) {
        const item = this.itemTree[i].currentItem;
        if (item.id) {
          result.push(item);
        }
        else {
          break;
        }
      }
    }
    return result;
  }

  public itemChanged(event: Event, itemSelector: ItemSelector, selectorIndex: number) {
    this.isSystemSelected = false;
    if (itemSelector.currentItem == null || (itemSelector.currentItem.id == null) || (itemSelector.currentItem.id.toString() == "null")) {
      this.itemTree = this.itemTree.slice(0, selectorIndex + 1);
      if (this.itemTree.length > 1) {
        itemSelector = this.itemTree[this.itemTree.length - 2];
        this.setCurrentItemId(itemSelector, itemSelector.currentItem.id);
        localStorage.setItem("topicDescExistAssigment", itemSelector.currentItem.description);
        this.valueChanged.emit();
      }
      else {
        this.setCurrentItemId(itemSelector, null);
      }
    }
    else {
      this.itemTree = this.itemTree.slice(0, selectorIndex + 1);
      itemSelector = this.itemTree[this.itemTree.length - 1];
      this.setCurrentItemId(itemSelector, itemSelector.currentItem.id);
      this.fillNextLevel(itemSelector.currentItem.id);
      localStorage.setItem("topicDescExistAssigment", itemSelector.currentItem.description);
      this.valueChanged.emit();
    }
    localStorage.setItem("topicDescExistAssigment", itemSelector.currentItem.description);
    this.valueChanged.emit();
  }

  public blur(): void {
    this.onTouchedCallback();
  }

  writeValue(obj: any): void {
    this.suspendChangeNotifications = true;
    try {
      this.value = obj;
    }
    finally {
      this.suspendChangeNotifications = false;
    }
  }

  registerOnChange(fn: any): void {
    this.onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }

  identify(index, item) {
    return item.label;
  }
}