import { Component, OnInit, forwardRef, Input } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

const noop = () => {
};

@Component({
  selector: 'tree-path',
  templateUrl: './tree-path.component.html',
  styleUrls: ['./tree-path.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => TreePathComponent),
      multi: true
    }
  ]
})
export class TreePathComponent implements ControlValueAccessor {

  constructor() { }

  path: string[] = new Array<string>();
  @Input() marketsStatus = [];
  get value(): any {
    return this.path;
  }
  set value(newValue: any) {
    this.path = newValue;
  }

  writeValue(obj: any): void {
    this.path = obj;
  }
  public checkMarketStatus(market: string) {
   if (this.marketsStatus != undefined){
     const marketStatus = this.marketsStatus.find(x => x.description.toLowerCase() === market.toLowerCase());
    return marketStatus != undefined && marketStatus['status'].toLowerCase() == 'RetiredMarket'.toLowerCase() ? true : false;
   }
}

  private onTouchedCallback: () => void = noop;
  private onChangeCallback: (_: any) => void = noop;

  registerOnChange(fn: any): void {
    this.onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
  }
}
