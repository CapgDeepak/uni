import { Component, Input, OnInit, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { HttpService } from '../../tools/services/http.service';

const noop = () => {
};

@Component({
    selector: 'select-editable',
    templateUrl: './select-editable.component.html',
    styleUrls: ['./select-editable.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => SelectEditableComponent),
            multi: true
        }
    ]
})

export class SelectEditableComponent implements OnInit, ControlValueAccessor {

    private onTouchedCallback: () => void = noop;
    private onChangeCallback: (_: any) => void = noop;

    constructor(
        private httpService: HttpService) {
    }

    innerValue: any = "";
    get value(): any {
        return this.innerValue;
    }
    set value(newValue: any) {
        if (this.innerValue != newValue) {
            this.innerValue = newValue;
            this.onChangeCallback(newValue);
        }
    }

    public get isValid(): boolean {
        return !this.required || !!this.innerValue;
    }

    @Input() items: Item[] = new Array<Item>(); // either can set the items directly, or indirectly via the controllerName
    @Input() controllerName: string = "";
    @Input() required: boolean = false;
    @Input() disabled: boolean = false;

    ngOnInit(): void {
        if (this.controllerName) {
            this.httpService.get('api/' + this.controllerName + '/Items').subscribe(result => {
                this.items = result as Item[];
            }, error => console.error(error));
        }
    }

    identify(index, item) {
        return item.label;
     }
    public blur(): void {
        this.onTouchedCallback();
    }

    writeValue(obj: any): void {
        this.innerValue = obj;
    }
    registerOnChange(fn: any): void {
        this.onChangeCallback = fn;
    }
    registerOnTouched(fn: any): void {
        this.onTouchedCallback = fn;
    }
}

export interface Item {
    description: string;
}
