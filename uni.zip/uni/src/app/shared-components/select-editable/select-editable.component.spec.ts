import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { SelectEditableComponent } from './select-editable.component';
import { HttpService } from '../../tools/services/http.service';

class HttpServiceMock {}

describe('SelectEditableComponent', () => {
  let component: SelectEditableComponent;
  let fixture: ComponentFixture<SelectEditableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SelectEditableComponent],
      imports: [
        FormsModule,
        HttpClientTestingModule
      ],
      providers: [
        { provide: HttpService, useClass: HttpServiceMock }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectEditableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when disabled', () => {
    component.disabled = true;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });
});