import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { HttpService } from '../../tools/services/http.service';
import { UrlEndpoint } from '../../tools/constants';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { AuditPhraseAssignment, AuditPhrase, PhraseAssignment } from '../phrase-assignments/phrase-assignments.types';
import { TableModule, Table } from 'primeng/table';
import { Phrase, EmptyPhrase } from '../../phrase-library/phrase-library.types';
@Component({
  selector: 'app-phrase-audit-trail',
  templateUrl: './phrase-audit-trail.component.html',
  styleUrls: ['./phrase-audit-trail.component.scss']
})
export class PhraseAuditTrailComponent implements OnInit {
  @ViewChild('phraseTable', { static: false }) phraseTable: Table;
  @ViewChild('phraseassignmentTable', { static: false }) phraseassignmentTable: Table;

  public phrase: Phrase = new EmptyPhrase();
  fromDate: any = '';
  toDate: any = '';
  auditPhraseAssignmentDetails: AuditPhraseAssignment[] = [];
  auditPhrasesDetails: AuditPhrase[] = [];
  formPhrase: FormGroup;
  formPhraseAssignment: FormGroup;
  phraseActionTypeList: any[] = ['Add', 'Edit(M)', 'Edit(S)', 'Accept', 'Reject', 'Active', 'Inactive', 'Delete'];
  phraseAssignmentActionTypeList: any[] = ['Add', 'Accept', 'Reject', 'Removed'];
  actionTypeData: any;
  phraseStatusList: any[] = ['Approved', 'To Be Approved', 'Rejected', 'Inactive', 'Active', 'Delete Request', 'Keep'];
  phraseAssignmentStatusList: any[] = ['To Be Assessed', 'Accepted', 'Not Relevant', 'Removed'];
  oriAuditPhraseAssignmentDetails: any;
  oriAuditPhraseDetails: any;
  formatedFromDate: any;
  filteredPhraseAssignmnentData: any;
  filteredPhraseData: any;
  isPhraseSorted: boolean = false;
  isPhraseAssignmentSorted: boolean = false;
  private _phraseId: number | null = null;
  loadingAuditTrail: boolean = true;
  tooltip: string = '';
  constructor(
    private httpService: HttpService,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.formPhrase = this.formBuilder.group({
      actionType: new FormControl(''),
      phraseModifiedDate: new FormControl(''),
      systemUserDisplayName: new FormControl(''),
      statusType: new FormControl('')
    });
    this.formPhraseAssignment = this.formBuilder.group({
      actionType: new FormControl(''),
      phraseModifiedDate: new FormControl(''),
      systemUserDisplayName: new FormControl(''),
      statusType: new FormControl(''),
      regulatoryMarket: new FormControl(''),
      regulatoryProductClass: new FormControl('')
    });
  }

  @Input()
  get phraseId(): number | null {
    return this._phraseId;
  }
  set phraseId(value: number | null) {
    if (this._phraseId != value) {
      this._phraseId = value;
      this.loadingAuditTrail = true;
      this.loadAuditTrail(this._phraseId);
    }
  }

  loadAuditTrail(phraseId: any) {
    this.httpService.getFiltered({ phraseId }, UrlEndpoint.PhraseLibrary_LoadAuditData).subscribe(result => {
      this.auditPhrasesDetails = result.auditPhrases;
      this.auditPhraseAssignmentDetails = result.auditPhraseAssignment;
      this.filteredPhraseData = JSON.parse(JSON.stringify(result.auditPhrases));
      this.filteredPhraseAssignmnentData = JSON.parse(JSON.stringify(result.auditPhraseAssignment));
      this.oriAuditPhraseDetails = JSON.parse(JSON.stringify(result.auditPhrases));
      localStorage.setItem('oriAuditPhraseDetails', JSON.stringify(result.auditPhrases));
      this.oriAuditPhraseAssignmentDetails = JSON.parse(JSON.stringify(result.auditPhraseAssignment));
      localStorage.setItem('oriAuditPhraseAssignmentDetails', JSON.stringify(result.auditPhraseAssignment));
      this.loadingAuditTrail = false;
    });
  }

  filterDateRange() {
    localStorage.setItem('filteredPhraseAssignmnentData', JSON.stringify(this.filteredPhraseAssignmnentData));
    localStorage.setItem('filteredPhraseData', JSON.stringify(this.filteredPhraseData));
    if (this.fromDate && this.toDate) {
      const fromdate = new Date(this.fromDate);
      const fromdateNow = fromdate.setDate(fromdate.getDate());
      const formatedFromDate = new Date(fromdateNow).toISOString();

      const todate = new Date(this.toDate);
      const todateNow = todate.setDate(todate.getDate() + 1);
      const formatedToDate = new Date(todateNow).toISOString();
      const phraseFiltered = JSON.parse(localStorage.getItem('oriAuditPhraseDetails')).reverse().filter(phrase => {
        return phrase.phraseModifiedDate >= formatedFromDate && phrase.phraseModifiedDate <= formatedToDate;
      });
      const phraseAssignmentFiltered = JSON.parse(localStorage.getItem('oriAuditPhraseAssignmentDetails')).reverse().filter(phraseAss => {
        return phraseAss.phraseModifiedDate >= formatedFromDate && phraseAss.phraseModifiedDate <= formatedToDate;
      });
      this.auditPhrasesDetails = phraseFiltered;
      this.auditPhraseAssignmentDetails = phraseAssignmentFiltered;
      // this.auditPhrasesDetails = this.auditPhrasesDetails.phraseModifiedDate >= this.fromDate && this.auditPhrasesDetails.phraseModifiedDate <= this.toDate;
    }
  }

  disabledFilterDateRange() {
    if (this.fromDate == '' || this.toDate == '') {
      return true;
    } else {
      return false;
    }
  }

  disabledResetFilterDateRange() {
    if (this.fromDate != '' || this.toDate != '') {
      return false;
    } else {
      return true;
    }
  }

  onFilterPhrase(data: any) {
    this.filteredPhraseData = data.filteredValue;
  }
  onFilterPhraseAssignment(data: any) {
    this.filteredPhraseAssignmnentData = data.filteredValue;
  }
  clearPhraseFilter() {
    this.formPhrase.value.actionType = '';
    this.formPhrase.value.systemUserDisplayName = '';
    this.formPhrase.value.statusType = '';
    this.phraseTable.reset();
    this.isPhraseSorted = false;
    this.filteredPhraseData = JSON.parse(localStorage.getItem('oriAuditPhraseDetails'));
    this.auditPhrasesDetails = JSON.parse(localStorage.getItem('oriAuditPhraseDetails'));
  }

  sortPhraseAudit() {
    this.isPhraseSorted = true;
  }

  sortPhraseAssignmentAudit() {
    this.isPhraseAssignmentSorted = true;
  }

  clearPhraseAssignmentFilter() {
    this.formPhraseAssignment.value.actionType = '';
    this.formPhraseAssignment.value.systemUserDisplayName = '';
    this.formPhraseAssignment.value.statusType = '';
    this.formPhraseAssignment.value.regulatoryMarket = '';
    this.formPhraseAssignment.value.regulatoryProductClass = '';
    this.phraseassignmentTable.reset();
    this.isPhraseAssignmentSorted = false;
    this.filteredPhraseAssignmnentData = JSON.parse(localStorage.getItem('oriAuditPhraseAssignmentDetails'));
    this.auditPhraseAssignmentDetails = JSON.parse(localStorage.getItem('oriAuditPhraseAssignmentDetails'));
  }

  disabledPhraseClearButton() {
    if (this.formPhrase &&
      this.formPhrase.value.actionType != '' ||
      this.formPhrase.value.systemUserDisplayName != '' ||
      this.formPhrase.value.statusType != '' ||
      this.isPhraseSorted == true) {
      return false;
    }
    else { return true; }
  }

  disabledPhraseAssignmentClearButton() {
    if (this.formPhraseAssignment &&
      this.formPhraseAssignment.value.actionType != '' ||
      this.formPhraseAssignment.value.systemUserDisplayName != '' ||
      this.formPhraseAssignment.value.statusType != '' ||
      this.formPhraseAssignment.value.regulatoryMarket != '' ||
      this.formPhraseAssignment.value.regulatoryProductClass != '' ||
      this.isPhraseAssignmentSorted == true) {
      return false;
    }
    else { return true; }
  }

  resetDateRange() {
    this.fromDate = '';
    this.toDate = '';
    this.auditPhrasesDetails = JSON.parse(localStorage.getItem('filteredPhraseData'));
    this.auditPhraseAssignmentDetails = JSON.parse(localStorage.getItem('filteredPhraseAssignmnentData'));
  }

  filterActionType() {
    this.actionTypeData = this.formPhrase.value.actionType;
  }

  public get goButtonTooltipText(): string {
    this.tooltip = '';
    if (this.fromDate == '' && this.toDate == '') {
      this.tooltip = "Please select From and To date";
    } else if (this.fromDate == '') {
      this.tooltip = "Please select a From date";
    } else if (this.toDate == '') {
      this.tooltip = "Please select a To date";
    }
    return this.tooltip;
  }

  identify(index, item) {
    return item.label;
 }
}
