import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';

import { PhraseAuditTrailComponent } from './phrase-audit-trail.component';
import { Observable } from 'rxjs';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { HttpService } from '../../tools/services/http.service';
import { NgModule } from '@angular/core';
import { TableModule } from 'primeng/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
class MockHttpService {
  get(url: string) {
    return new Observable(observer => {
      observer.next([]);
      observer.complete();
    });
  }
}

class MockAlertDialogService {
}



describe('PhraseAuditTrailComponent', () => {
  let component: PhraseAuditTrailComponent;
  let fixture: ComponentFixture<PhraseAuditTrailComponent>;
  let injector: TestBed;

  const buildComponent = () => {
    fixture = TestBed.createComponent(PhraseAuditTrailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PhraseAuditTrailComponent
      ],
      imports: [NgbModule, TableModule, FormsModule, ReactiveFormsModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        ConfirmationService,
        { provide: HttpService, useClass: MockHttpService },
      ]
    })
      .compileComponents();
    injector = getTestBed();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhraseAuditTrailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    expect(fixture).toMatchSnapshot();
  });
});
