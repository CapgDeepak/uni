import { Component, Input, Output, EventEmitter } from '@angular/core';
// tslint:disable-next-line:max-line-length
import { PhraseSimpleModel } from '../../tools/shared-types/phrase.types';

@Component({
    selector: 'app-linked-phrase',
    templateUrl: './linked-phrase.component.html',
    styleUrls: ['./linked-phrase.component.scss']
})
/**
 * Component to handle the linked generic phrase control.
 * Would have liked to use two way data binding with the control value accessor here,
 * but some problems occured, potentially due to having two nested control value accessors
 * and the binding not lining up quite right. Decided to go with traditional input
 * and emitter style data binding and change detection instead.
 */
export class LinkedPhraseComponent {
    private _phrasesToLinkAgainst: PhraseSimpleModel[] = [];
    selectedlinkedphraseIds: PhraseSimpleModel[];
    templinkedIds: PhraseSimpleModel[];
    linkedphrasedropdownSettings: any = {
        enableCheckAll: false,
        allowSearchFilter: true,
        closeDropDownOnSelection: true,
        clearable: false,
        idField: 'phraseId',
        textField: 'nr',
        itemsShowLimit: 3
    };
    @Input() EditableAllowed: boolean = false;
    @Input()
    get phrasesToLinkAgainst(): PhraseSimpleModel[] {
        return this._phrasesToLinkAgainst;
    }

    set phrasesToLinkAgainst(value: PhraseSimpleModel[]) {
        this._phrasesToLinkAgainst = value;
        this.templinkedIds = this._phrasesToLinkAgainst != null ? [...this._phrasesToLinkAgainst.filter(x => (this._linkedPhraseId != null && this._linkedPhraseId != undefined) ? this._linkedPhraseId.includes(x.phraseId) : 0)] : this.templinkedIds;
        this.selectedlinkedphraseIds = (this.templinkedIds != null && this.templinkedIds.length > 0) ? this.templinkedIds : this.selectedlinkedphraseIds;
    }

    /**
     * The ID of the phrase selected to link against. f
     */
    private _linkedPhraseId: any | null;
    @Input()
    get linkedPhraseId(): any | null {
        return this._linkedPhraseId;
    }
    set linkedPhraseId(value: any | null) {
        this.templinkedIds = this._phrasesToLinkAgainst != null ? [...this._phrasesToLinkAgainst.filter(x => (value != null && value != undefined) ? value.find(a => a == x.phraseId) : 0)] : this.templinkedIds;
        this.selectedlinkedphraseIds = [];
        if (this.phrasesToLinkAgainst != null && this.phrasesToLinkAgainst != undefined) {
            if (value != null) {
                value.forEach(phraseSelected => {
                    this.selectedlinkedphraseIds.push(this.phrasesToLinkAgainst.filter(x => x.nr == phraseSelected)[0]);
                });
            }
        }
        // this.selectedlinkedphraseIds = (this.templinkedIds != null && this.templinkedIds.length > 0) ? this.templinkedIds : this.selectedlinkedphraseIds;
        this._linkedPhraseId = value;
        console.log(this._linkedPhraseId);
    }

    /**
     * whether to disable the selector
     */
    private _disabled: boolean | null;
    @Input()
    get disabled(): boolean | null {
        return this._disabled;
    }
    set disabled(value: boolean | null) {
        this._disabled = value;
    }

    @Input() phrasesToLinkAgainstLoading: boolean = false;

    @Output() dataChangeEmitter: EventEmitter<PhraseSimpleModel[]> = new EventEmitter<PhraseSimpleModel[]>();

    /**
     * Method to handle a selection of the linked phrase dropdown.
     * Emits an event to the parent containing the linked phrase ID.
     */
    onDataChange(selectedLinkedPhraseId: any) {
        this.dataChangeEmitter.emit(selectedLinkedPhraseId);
    }

    /**
     * Get the phrase number for the specified id from the phrasesToLinkAgainst list
     */
    get phraseNumber(): number | null {

        if (!this._phrasesToLinkAgainst || this._phrasesToLinkAgainst.length === 0 || !this._linkedPhraseId) {
            return null;
        }

        const matchingPhrase = this._phrasesToLinkAgainst.find(x => x.phraseId.toString() === this._linkedPhraseId.toString());

        if (!matchingPhrase) {
            return null;
        }

        return matchingPhrase.nr;
    }

    public selectedLinkedPhraseId(itemSelector: any) {
        this.dataChangeEmitter.emit(this.selectedlinkedphraseIds);
    }
}