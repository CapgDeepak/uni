import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { when } from 'jest-when';
import { By } from '@angular/platform-browser';

import { LinkedPhraseComponent } from './linked-phrase.component';
import { PhraseSimpleModel } from '../../tools/shared-types/phrase.types';

const phrasesToLinkAgainst: PhraseSimpleModel[] = [
  {
    phraseId: 50,
    nr: 100,
  },
  {
    phraseId: 51,
    nr: 101,
  },
  {
    phraseId: 52,
    nr: 102,
  }
];

describe('LinkedPhraseComponent', () => {
  let component: LinkedPhraseComponent;
  let fixture: ComponentFixture<LinkedPhraseComponent>;

  const buildComponent = () => {
    fixture = TestBed.createComponent(LinkedPhraseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        LinkedPhraseComponent,
      ],
      providers: [],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    buildComponent();
    component.phrasesToLinkAgainst = phrasesToLinkAgainst;
    component.linkedPhraseId = phrasesToLinkAgainst.map(x => x.nr);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  describe('phraseNumber tests', () => {
    it('WHEN _phrasesToLinkAgainst is null returns null', () => {
      component.phrasesToLinkAgainst = null;
      expect(component.phraseNumber).toBeNull();
    });

    it('WHEN _linkedPhraseId is null returns null', () => {
      component.linkedPhraseId = null;
      expect(component.phraseNumber).toBeNull();
    });

    it('WHEN _phrasesToLinkAgainst is populated, but no matching phraseId returns null', () => {
      component.linkedPhraseId = new Array(1);
      expect(component.phraseNumber).toBeNull();
    });

    it('WHEN _phrasesToLinkAgainst is populated,and matching phraseId returns expected Nr', () => {
      expect(component.phraseNumber).toEqual(null);
    });
  });
});

