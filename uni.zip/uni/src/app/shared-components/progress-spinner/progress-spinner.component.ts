import { Component, Input } from '@angular/core';

@Component({
    selector: 'spinner',
    templateUrl: './progress-spinner.component.html',
    styleUrls: ['./progress-spinner.component.scss']
})
export class ProgressSpinnerComponent {
    constructor() { }

    private _active: boolean = false;
    get active(): boolean {
        return this._active;
    }
    @Input()
    set active(value: boolean) {
        this._active = value;
    }

    private _block: boolean = false;
    get block(): boolean {
        return this._block;
    }
    @Input()
    set block(value: boolean) {
        this._block = value;
    }
}