import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PhraseTextComponent } from './phrase-text.component';

describe('PhraseTextComponent', () => {
  let component: PhraseTextComponent;
  let fixture: ComponentFixture<PhraseTextComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PhraseTextComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhraseTextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });
});
