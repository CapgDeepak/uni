import { Component, forwardRef, ViewEncapsulation } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

const noop = () => {
};

@Component({
    selector: 'phrase-text',
    templateUrl: './phrase-text.component.html',
    styleUrls: ['./phrase-text.component.scss'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => PhraseTextComponent),
            multi: true
        }
    ]
})
export class PhraseTextComponent implements ControlValueAccessor {

    public phraseText: string;

    get value(): any {
        return this.phraseText;
    }
    set value(newValue: any) {
        this.phraseText = newValue;
    }

    writeValue(obj: any): void {
        this.phraseText = obj;
    }

    private onTouchedCallback: () => void = noop;
    private onChangeCallback: (_: any) => void = noop;

    registerOnChange(fn: any): void {
        this.onChangeCallback = fn;
    }
    registerOnTouched(fn: any): void {
        this.onTouchedCallback = fn;
    }
    setDisabledState?(isDisabled: boolean): void {
        // throw new Error("Method not implemented.");
    }
}