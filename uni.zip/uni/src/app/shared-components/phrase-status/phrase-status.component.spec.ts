import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PhraseStatusComponent } from './phrase-status.component';

describe('PhraseStatusComponent', () => {
  let component: PhraseStatusComponent;
  let fixture: ComponentFixture<PhraseStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PhraseStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhraseStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });
});
