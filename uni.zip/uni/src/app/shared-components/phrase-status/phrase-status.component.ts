import { Component, Input } from '@angular/core';

@Component({
    selector: 'phrase-status',
    templateUrl: './phrase-status.component.html',
    styleUrls: ['./phrase-status.component.scss']
})
export class PhraseStatusComponent {
    constructor() { }

    private _status: Number;
    private _text: string;

    @Input()
    public get status(): Number {
        return this._status;
    }
    public set status(value: Number) {
        this._status = value;
    }

    @Input()
    public get text(): string {
        return this._text;
    }
    public set text(value: string) {
        this._text = value;
    }
}