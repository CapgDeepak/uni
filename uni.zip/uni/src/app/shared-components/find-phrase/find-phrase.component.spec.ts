import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { when } from 'jest-when';
import { By } from '@angular/platform-browser';

import { FindPhraseComponent } from './find-phrase.component';
import { CacheService } from '../../tools/services/cache.service';
import { SideDialogService } from '../../tools/side-dialog/side-dialog.service';
import { DetailLevel } from '../../tools/common.types';
import { of } from 'rxjs';
import { FilterService } from '../../tools/services/filter.service';
import { HttpService } from '../../tools/services/http.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { MockDateTimePipe } from '../../tools/testTools/mockDateTimePipe';
import { EmptyPhraseList } from '../../phrase-matrix/phrase-matrix.types';
import { AuthorizationService } from '../../authorization/authorization.service';
import { ShowIfUserHasAnyPermissionDirective } from '../../authorization/directives/show-if-user-has-any-permission.directive';
import { Permission } from '../../tools/shared-types/permissions/permission';

class NgbActiveModalMock { }
class CacheServiceMock {
  getDetailLevels(): Promise<DetailLevel[]> {
    return new Promise<DetailLevel[]>((resolve, reject) => {
      return new Array<DetailLevel>();
    });
  }
}

class AuthorizationServiceMock {
  checkUserHasAnyPermission = jest.fn();
}
class HttpServiceMock {
  postContent() {
    return of(new EmptyPhraseList());
  }
 }
class SideDialogServiceMock { }
class FilterServiceMock {
  isKeyCodeFilterable() { return true; }
}

const addCopyPhrasePermissions: Permission[] = [Permission.AraPReFDCT_Phrases_WriteWithoutAssignments, Permission.AraPReFDCT_Phrases_WriteWithAssignments];

describe('FindPhraseComponent', () => {
  let component: FindPhraseComponent;
  let fixture: ComponentFixture<FindPhraseComponent>;
  let httpService: HttpService;
  let injector: TestBed;
  let authService: AuthorizationService;

  const buildComponent = () => {
    fixture = TestBed.createComponent(FindPhraseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        FindPhraseComponent,
        ShowIfUserHasAnyPermissionDirective,
        MockDateTimePipe,
      ],
      providers: [
        { provide: NgbActiveModal, useClass: NgbActiveModalMock },
        { provide: CacheService, useClass: CacheServiceMock },
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: SideDialogService, useClass: SideDialogServiceMock },
        { provide: FilterService, useClass: FilterServiceMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
    .compileComponents();
    injector = getTestBed();
    httpService = injector.get(HttpService);
    authService = injector.get(AuthorizationService);
  }));

  beforeEach(() => {
    buildComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should load data on initialisation', () => {
    jest.spyOn(httpService, 'postContent');

    component.ngOnInit();

    expect(httpService.postContent).not.toHaveBeenCalled();
  });

  describe('when user has permission to add and copy phrases', () => {
    beforeEach(() => {
      when(authService.checkUserHasAnyPermission).calledWith(addCopyPhrasePermissions)
      .mockReturnValue(true);
      buildComponent();
    });

    it('shows the copy and add buttons', () => {
      const addButton = fixture.debugElement.query(By.css('#add-button'));
      const copyButton = fixture.debugElement.query(By.css('#copy-button'));
      expect(addButton).toBeTruthy();
      expect(copyButton).toBeTruthy();
    });
  });

  describe('when user does not have permission to add and copy phrases', () => {
    beforeEach(() => {
      when(authService.checkUserHasAnyPermission).calledWith(addCopyPhrasePermissions)
      .mockReturnValue(false);
      buildComponent();
    });

    it('does not show the copy and add buttons', () => {
      const addButton = fixture.debugElement.query(By.css('#add-button'));
      const copyButton = fixture.debugElement.query(By.css('#copy-button'));
      expect(addButton).toBeFalsy();
      expect(copyButton).toBeFalsy();
    });
  });

  describe('when user has permission to assign phrases', () => {
    beforeEach(() => {
      when(authService.checkUserHasAnyPermission).calledWith([Permission.AraPReFDCT_PhraseAssignments_Write])
      .mockReturnValue(true);
      buildComponent();
    });

    it('shows the assign button', () => {
      const assignButton = fixture.debugElement.query(By.css('#assign-button'));
      expect(assignButton).toBeTruthy();
    });
  });

  describe('when user has not permission to assign phrases', () => {
    beforeEach(() => {
      when(authService.checkUserHasAnyPermission).calledWith([Permission.AraPReFDCT_PhraseAssignments_Write])
      .mockReturnValue(false);
      buildComponent();
    });

    it('does not show the assign button', () => {
      const assignButton = fixture.debugElement.query(By.css('#assign-button'));
      expect(assignButton).toBeFalsy();
    });
  });

  describe('when user opens find phrase with read only true', () => {
    beforeEach(() => {
      fixture.componentInstance.readOnly = true;
      fixture.detectChanges();
    });

    it('should match snapshot', () => {
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('does not show the add button', () => {
      const addButton = fixture.debugElement.query(By.css('#add-button'));
      expect(addButton).toBeFalsy();
    });

    it('does not show the copy button', () => {
      const copyButton = fixture.debugElement.query(By.css('#copy-button'));
      expect(copyButton).toBeFalsy();
    });

    it('does not show the assign button', () => {
      const assignButton = fixture.debugElement.query(By.css('#assign-button'));
      expect(assignButton).toBeFalsy();
    });
  });

  describe('linkedPhraseNrs', () => {
    it('returns the linkedGenericPhraseNr for detailed phrases', () => {
      // Assemble
      const phrase = { detailLevelDescription: 'Detailed', linkedGenericPhraseNr: 1, linkedSpecificPhraseNrs: [2, 3, 4]};

      // Assert
      expect(component.linkedPhraseNrs(phrase)).toEqual("");
    });

    it('returns the correctly formatted linkedSpecificPhraseNrs for standard phrases', () => {
      // Assemble
      const phrase = { detailLevelDescription: 'Standard', linkedGenericPhraseNr: 1, linkedSpecificPhraseNrs: [2, 3, 4]};

      // Assert
      expect(component.linkedPhraseNrs(phrase)).toEqual('');
    });
  });
});