import { Component, OnInit, Input } from '@angular/core';
import { SelectedMatrixCell, PhraseFilter, PhraseList, EmptyPhraseList, ListPhrase } from '../../phrase-matrix/phrase-matrix.types';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SideDialogService } from '../../tools/side-dialog/side-dialog.service';
import { MatrixPhraseEditComponent } from '../../phrase-matrix/matrix-phrase-edit/matrix-phrase-edit.component';
import { UrlEndpoint, ColumnSortOrder } from '../../tools/constants';
import { CacheService } from '../../tools/services/cache.service';
import { DetailLevel } from '../../tools/common.types';
import { FilterService } from '../../tools/services/filter.service';
import { HttpService } from '../../tools/services/http.service';
import { Permission } from '../../tools/shared-types/permissions/permission';
import { getLinkedPhraseNrsForPhrase } from '../../tools/utils';

@Component({
    selector: 'app-find-phrase',
    templateUrl: './find-phrase.component.html',
    styleUrls: ['./find-phrase.component.scss']
})
export class FindPhraseComponent implements OnInit {
    assignPhrasePermissions: Permission[] = [Permission.AraPReFDCT_PhraseAssignments_Write];

    addCopyPhrasePermissions: Permission[] = [Permission.AraPReFDCT_Phrases_WriteWithoutAssignments, Permission.AraPReFDCT_Phrases_WriteWithAssignments];
    PhraseCreatedby = "Phrase Created by";
    PhraseModifiedby = "Phrase Modified by";
    constructor(
        public activeModal: NgbActiveModal,
        private cacheService: CacheService,
        private httpService: HttpService,
        private sideDialogService: SideDialogService,
        private filterService: FilterService) { }

    ngOnInit() {
        // commented here to avaoid phrase load before loading topics
        // load Phrase data after Topics are loaded (fix for performance issue)
        // this.filterChanged();
        this.loadingPhrases = true;
        this.cacheService.getDetailLevels().then(results => {
            this.detailLevels = results;
        });
    }

    private _selectedCell: SelectedMatrixCell | null = null;
    public get selectedCell(): SelectedMatrixCell {
        return this._selectedCell;
    }
    public set selectedCell(value: SelectedMatrixCell) {
        if (this._selectedCell != value) {
            this._selectedCell = value;
            if (value) {
                this.filter.topicId = value.topicId;
            }
        }
    }
    public filter: PhraseFilter = new PhraseFilter();
    public detailLevels: DetailLevel[] = new Array<DetailLevel>();
    public phraseList: PhraseList = new EmptyPhraseList();
    public selectedPhrase: ListPhrase | null = null;
    public loadingPhrases: boolean = false;
    public readOnly: boolean = false;

    public get showAssignments(): boolean {
        return this.filter.showAssignments;
    }
    public set showAssignments(value: boolean) {
        if (this.filter.showAssignments != value) {
            this.filter.showAssignments = value;
            this.filterChanged();
        }
        if (value) {
            this.PhraseCreatedby = "Assignment Created by";
            this.PhraseModifiedby = "Assignment Modified by";
        } else {
            this.PhraseCreatedby = "Phrase Created by";
            this.PhraseModifiedby = "Phrase Modified by";
        }
    }

    assignPhrase(newPhraseId = null) {
        const assignedPhraseId = newPhraseId ||
            (this.selectedPhrase == null ? null : this.selectedPhrase.id);
        if (assignedPhraseId && !this.readOnly) {
            this.activeModal.close({
                phraseId: assignedPhraseId
            });
        }
    }

    addPhrase() {
        const modalRef = this.sideDialogService.openWithCallback(MatrixPhraseEditComponent, (newPhraseId: number) => {
            this.filterChanged();
            this.assignPhrase(newPhraseId);
        });
        modalRef.componentInstance.initAddPhrase(this._selectedCell, this.filter.detailLevelId);
    }

    copyPhrase() {
        if (this.selectedPhrase) {
            const modalRef = this.sideDialogService.openWithCallback(MatrixPhraseEditComponent, (newPhraseId: number) => {
                this.filterChanged();
                this.assignPhrase(newPhraseId);
            });
            modalRef.componentInstance.initCopyPhrase(this._selectedCell, this.selectedPhrase.phraseId);
        }
    }

    // load Phrase data after Topics are loaded (fix for performance issue)
    callfilterChangedAfterTopicsLoaded(isTopicsLoaded: boolean) {
        if (!isTopicsLoaded) {
            this.filterChanged();
        }
    }

    topicChanged(value: number | null) {
        if (this.filter.topicId != value) {
            this.filter.topicId = value;
            this.filterChanged();
        }
    }

    clearFilter() {
        this.filter = new PhraseFilter();
        this.filterChanged();
    }

    gridPageChange() {
        this.loadPhraseData();
    }

    loadPhraseData() {
        this.loadingPhrases = true;

        // Preserve selection
        const selectedPhraseId = this.selectedPhrase ? this.selectedPhrase.phraseId : null;
        const selectedId = this.selectedPhrase ? this.selectedPhrase.id : null;
        this.selectedPhrase = null;
        const url = this.filter.showAssignments ? UrlEndpoint.PhraseMatrix_FilterPhraseAssignments : UrlEndpoint.PhraseMatrix_FilterPhrases;
        this.httpService.postContent(this.filter, url).subscribe(result => {
            this.phraseList = result;

            // Preserve selection
            this.selectedPhrase = this.phraseList.phrases.find(p => p.phraseId == selectedPhraseId || p.id == selectedId);

            this.loadingPhrases = false;
        }, error => {
            console.error(error);
            this.loadingPhrases = false;
        });
    }
    RaOwnerfilte = null;
    filterChanged() {
        this.filter.pageNr = 0;
        if (this.RaOwnerfilte == '' || this.RaOwnerfilte == null) {
            this.filter.raOwner = null;
        } else {
            this.filter.raOwner = this.RaOwnerfilte;
        }
        this.loadPhraseData();
    }

    setSortOrder(columnName: string) {
        if (this.filter.sortColumn == columnName) {
            this.filter.sortDescending = !this.filter.sortDescending;
        }
        else {
            this.filter.sortColumn = columnName;
            this.filter.sortDescending = false;
        }
        this.filterChanged();
    }

    getSortDirection(columnName: string): string {
        if (this.filter.sortColumn == columnName) {
            return (this.filter.sortDescending ? ColumnSortOrder.Descending : ColumnSortOrder.Ascending);
        }
        return "";
    }
    public getTitleForPhraseOrAssignment(phrase: string): string {
        if ('created' == phrase) {
            if (!this.filter.showAssignments) {
                return 'Phrase Created by';
            }
            else {
                return 'Assignment Created by';
            }
        }
        else if ('modified' == phrase) {
            if (!this.filter.showAssignments) {
                return 'Phrase Modified by';
            }
            else {
                return 'Assignment Modified by';
            }
        }
    }

    selectPhrase(event: Event, phrase: ListPhrase) {
        this.selectedPhrase = phrase;
    }

    private keyTimer: any = null;
    filterKeyPress(event: any) {
        if (this.filterService.isKeyCodeFilterable(event.keyCode)) {
            if (this.keyTimer) {
                clearTimeout(this.keyTimer);
                this.keyTimer = null;
            }
            if (event.keyCode == 13) {
                this.filterChanged();
            }
            else {
                this.keyTimer = setTimeout(() => {
                    this.keyTimer = null;
                    this.filterChanged();
                }, 1000);
            }
        }
    }

    linkedPhraseNrs(phrase: any): string {
        return getLinkedPhraseNrsForPhrase(phrase);
    }

    @Input()
    public get pageNr(): number {
        return this.filter.pageNr + 1;
    }
    public set pageNr(value: number) {
        this.filter.pageNr = value - 1;
    }

    identify(index, item) {
        return item.label;
     }
}