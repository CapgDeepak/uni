import { Injectable } from '@angular/core';
import { AlertDialogComponent } from './alert-dialog.component';
import { DialogService } from '../../tools/services/dialog.service';

@Injectable()
export class AlertDialogService {
    constructor(private dialogService: DialogService) { }

    public alert(title: string, message: string, btnOkText: string = 'OK', dialogSize: 'sm' | 'lg' = 'sm'): Promise<boolean> {
        const modalRef = this.dialogService.open(AlertDialogComponent, {
            size: dialogSize,
            centered: true
        });

        modalRef.componentInstance.title = title;
        modalRef.componentInstance.message = message;
        modalRef.componentInstance.btnOkText = btnOkText;
        return modalRef.result;
    }
}