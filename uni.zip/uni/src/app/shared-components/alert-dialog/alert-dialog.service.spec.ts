import { TestBed, inject } from '@angular/core/testing';

import { AlertDialogService } from './alert-dialog.service';
import { DialogService } from '../../tools/services/dialog.service';

class DialogServiceMock { }

describe('AlertDialogService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: DialogService, useClass: DialogServiceMock },
                AlertDialogService
            ]
        });
    });

    it('should be created', inject([AlertDialogService], (service: AlertDialogService) => {
        expect(service).toBeTruthy();
    }));
});