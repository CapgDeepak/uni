import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlertDialogComponent } from './alert-dialog.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

class NgbActiveModalMock { }

describe('AlertDialogComponent', () => {
  let component: AlertDialogComponent;
  let fixture: ComponentFixture<AlertDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AlertDialogComponent],
      providers: [
        { provide: NgbActiveModal, useClass: NgbActiveModalMock }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlertDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot with data set', () => {
    component.message = "some dialog message";
    component.btnOkText = "some text for the ok button";
    component.title = "some text for the dialog title bar";
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });
});