import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'app-alert-dialog',
    templateUrl: './alert-dialog.component.html',
    styleUrls: ['./alert-dialog.component.scss']
})
export class AlertDialogComponent implements OnInit {

    @Input() title: string = "Alert";
    @Input() message: string = "Hello world!";
    @Input() btnOkText: string = "Ok";

    constructor(private activeModal: NgbActiveModal) { }

    ngOnInit() {
    }

    public close() {
        this.activeModal.close(true);
    }
}