import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BootstrapCardComponent } from './bootstrap-card/bootstrap-card.component';
import { BootstrapModalComponent } from './bootstrap-modal/bootstrap-modal.component';
import { BootstrapPaginationComponent } from './bootstrap-pagination/bootstrap-pagination.component';

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [
        BootstrapCardComponent,
        BootstrapModalComponent,
        BootstrapPaginationComponent
    ],
    entryComponents: [
    ],
    providers: [
    ],
    exports: [
        BootstrapCardComponent,
        BootstrapModalComponent,
        BootstrapPaginationComponent
    ]
})
export class BootstrapTemplatesModule {
}
