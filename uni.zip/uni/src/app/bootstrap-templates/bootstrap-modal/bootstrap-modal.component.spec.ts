import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';

import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { BootstrapModalComponent } from './bootstrap-modal.component';

describe('BootstrapModalComponent', () => {
  let component: BootstrapModalComponent;
  let fixture: ComponentFixture<BootstrapModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        BrowserModule,
        NgbModule
      ],
      declarations: [BootstrapModalComponent],
      providers: [
        NgbActiveModal
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BootstrapModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    component.title = "test";
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot 2', () => {
    component.title = "test 2";
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });
});
