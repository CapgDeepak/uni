import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'bootstrap-modal',
    templateUrl: './bootstrap-modal.component.html',
    styleUrls: ['./bootstrap-modal.component.scss']
})
export class BootstrapModalComponent implements OnInit {
    constructor(
        public activeModal: NgbActiveModal,
    ) { }

    ngOnInit() {
    }

    @Input() public title: string;

    @Output()
    close: EventEmitter<any> = new EventEmitter<any>();
}
