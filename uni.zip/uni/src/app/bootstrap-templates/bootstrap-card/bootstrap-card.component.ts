import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'bootstrap-card',
  templateUrl: './bootstrap-card.component.html',
  styleUrls: ['./bootstrap-card.component.scss']
})
export class BootstrapCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  @Input() public title: string = '';

}
