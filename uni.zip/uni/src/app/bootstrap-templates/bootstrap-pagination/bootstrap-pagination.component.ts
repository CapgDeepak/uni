import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'bootstrap-pagination',
  templateUrl: './bootstrap-pagination.component.html',
  styleUrls: ['./bootstrap-pagination.component.scss']
})
export class BootstrapPaginationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  pages: number[] = new Array<number>(0);

  @Input() public currentPage: number;

  private _pageCount: number = 1;
  public get pageCount() {
    return this._pageCount;
  }
  @Input() public set pageCount(newValue) {
    if (newValue > 0) {
      this._pageCount = newValue;
      this.pages = new Array<number>(newValue).fill(0).map((x, i) => i);
    }
  }

  @Output()
  pageChanged: EventEmitter<number> = new EventEmitter<number>();

  selectPage(pageNumber: number) {
    if (pageNumber != this.currentPage) {
      if ((pageNumber >= 0) && (pageNumber <= (this.pageCount - 1))) {
        this.currentPage = pageNumber;
        this.pageChanged.emit(pageNumber);
      }
    }
    return false;
  }

  previousPage() {
    if (this.currentPage > 0) {
      this.selectPage(this.currentPage - 1);
    }
    return false;
  }

  nextPage() {
    if (this.currentPage < (this.pageCount - 1)) {
      this.selectPage(this.currentPage + 1);
    }
    return false;
  }

}
