import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BootstrapPaginationComponent } from './bootstrap-pagination.component';

describe('BootstrapPaginationComponent', () => {
  let component: BootstrapPaginationComponent;
  let fixture: ComponentFixture<BootstrapPaginationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BootstrapPaginationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BootstrapPaginationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

});
