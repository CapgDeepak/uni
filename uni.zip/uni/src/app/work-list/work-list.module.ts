import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AuthorizationModule } from './../authorization/authorization.module';
import { BootstrapTemplatesModule } from '../bootstrap-templates/bootstrap-templates.module';
import { PhraseLibraryModule } from '../phrase-library/phrase-library.module';
import { ToolsModule } from './../tools/tools.module';
import { SharedComponentsModule } from './../shared-components/shared-components.module';
import { PhraseMatrixModule } from '../phrase-matrix/phrase-matrix.module';

import { GramWorkListComponent } from './gram-work-list/gram-work-list.component';
import { MarketWorkListComponent } from './market-work-list/market-work-list.component';
import { PageNotFoundComponent } from '../shared-components/page-not-found/page-not-found.component';
import { WorkListExcelExportComponent } from './work-list-excel-export/work-list-excel-export.component';
import { MarketCreateComponent } from './market-create/market-create.component';
import {DropdownModule} from 'primeng/dropdown';

const routes: Routes = [
  {
      path: 'grams',
      component: GramWorkListComponent,
  },
  {
      path: 'markets/:type',
      component: MarketWorkListComponent,
  },
  {
    path: 'create',
    component: MarketCreateComponent,
},
  {
      path: '**',
      component: PageNotFoundComponent
  }
];

@NgModule({
    imports: [
        AuthorizationModule,
        BootstrapTemplatesModule,
        CommonModule,
        FormsModule,
        NgbModule,
        PhraseLibraryModule,
        PhraseMatrixModule,
        ToolsModule,
        SharedComponentsModule,
        DropdownModule,
        RouterModule.forChild(routes)
    ],
    declarations: [
        GramWorkListComponent,
        MarketWorkListComponent,
        WorkListExcelExportComponent,
        MarketCreateComponent
    ],
    entryComponents: [
        WorkListExcelExportComponent
    ]
})
export class WorkListModule {
}
