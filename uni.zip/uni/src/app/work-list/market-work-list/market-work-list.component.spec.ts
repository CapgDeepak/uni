import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'angular2-toaster';
import { of } from 'rxjs';

import { MarketWorkListComponent } from './market-work-list.component';
import { MarketWorkListData, MarketWorkListItem } from '../work-list.types';
import { AuthorizationService } from '../../authorization/authorization.service';
import { ShowIfUserHasAnyPermissionDirective } from '../../authorization/directives/show-if-user-has-any-permission.directive';
import { UrlEndpoint, MarketWorkListType } from '../../tools/constants';
import { CacheService } from '../../tools/services/cache.service';
import { FilterService } from '../../tools/services/filter.service';
import { HttpService } from '../../tools/services/http.service';
import { SideDialogService } from '../../tools/side-dialog/side-dialog.service';
import { MockDateTimePipe } from '../../tools/testTools/mockDateTimePipe';
import { MarketAndUpdScopedPermissions } from '../../tools/shared-types/permissions/market-and-upd-scoped-permissions';
import { Permission } from '../../tools/shared-types/permissions/permission';
import { DetailLevel } from '../../tools/common.types';

class SideDialogServiceMock { }
class ToasterServiceMock { }
class HttpServiceMock {
  postContentPromise(content: any, url: string) {
    switch (url) {
      case UrlEndpoint.WorkList_LoadMarketWorkList:
        return Promise.resolve(new MarketWorkListData());
    }
  }
}
class FilterServiceMock {
  isKeyCodeFilterable() { return true; }
}
class RouterMock { }
let userHasPermissionForMarketAndProductDivision: boolean;
class AuthorizationServiceMock {
  checkUserHasAnyPermission() {
    return true;
  }
  checkUserHasAnyPermissionForMarketAndProductDivision() {
    return userHasPermissionForMarketAndProductDivision;
  }
}
class CacheServiceMock {
  getDetailLevels(): Promise<DetailLevel[]> {
    return new Promise<DetailLevel[]>(() => {
      return [{id: 1, description: 'detailLevel1'}];
    });
  }
}

function createTestSelectedItem(): MarketWorkListItem  {
    return {
        phraseId: 1,
        phraseNr: 1,
        phraseText: 'phrase text',
        phraseType: 1,
        phraseTypeText: 'phrase type text',
        changeType: 1,
        changeTypeText: 'change type text',
        createdAt: null,
        createdBy: 'created by',
        lastModifiedAt: null,
        lastModifiedBy: 'last modified by',
        topic: 'topic',
        regulatoryMarket: 'Algeria',
        regulatoryProductClass: 'rpc',
        unileverProductDivision: 'HC',
        unileverProductDivisionId: 100,
        phraseAssignmentStatus: 'phrase assignment status',
        phraseAssignmentStatusText: 'phrase assignment status text',
        topicId: 50,
        regulatoryMarketId: 100,
        regulatoryProductClassId: 200,
        lastReviewedBy: null,
        lastReviewedAt: null
    };
}

describe('MarketWorkListComponent', () => {
  let component: MarketWorkListComponent;
  let fixture: ComponentFixture<MarketWorkListComponent>;
  let httpService: HttpService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        MarketWorkListComponent,
        MockDateTimePipe,
        ShowIfUserHasAnyPermissionDirective,
      ],
      providers: [
        { provide: SideDialogService, useClass: SideDialogServiceMock },
        { provide: ToasterService, useClass: ToasterServiceMock },
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: FilterService, useClass: FilterServiceMock },
        { provide: Router, useClass: RouterMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
        { provide: CacheService, useClass: CacheServiceMock },
        { provide: ActivatedRoute, useValue: {
            params: of([{type: MarketWorkListType.Assess}])
          }
        }
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA,
        NO_ERRORS_SCHEMA
      ]
    })
    .compileComponents();

    httpService = getTestBed().get(HttpService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarketWorkListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when change type visible', () => {
    component.showChangeType = true;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should not load data on initialisation', () => {
    jest.spyOn(httpService, 'postContentPromise');
    component.ngOnInit();
    expect(httpService.postContentPromise).toHaveBeenCalledTimes(0);
  });

  it('should load data on filter change', () => {
    jest.spyOn(httpService, 'postContentPromise');
    component.filterChanged();
    expect(httpService.postContentPromise).toHaveBeenCalled();
  });

  describe('when workListType is set to Assess', () => {
    beforeEach(() => {
      component.workListType = MarketWorkListType.Assess;
      fixture.detectChanges();
    });

    it('should match snapshot', () => {
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('should have the market work list assess header', () => {
      const header = fixture.debugElement.query(By.css('#work-list-header'));
      expect(header.nativeElement.textContent).toContain('Market Work List - Assess');
    });
  });

  describe('when workListType is set to Review', () => {
    beforeEach(() => {
      component.workListType = MarketWorkListType.Review;
      fixture.detectChanges();
    });

    it('should match snapshot', () => {
      (expect(fixture) as any).toMatchSnapshot();
    });

    it('should have the market work list review header', () => {
      const header = fixture.debugElement.query(By.css('#work-list-header'));
      expect(header.nativeElement.textContent).toContain('Market Work List - Review');
    });
  });

  describe('assessPhraseAssignmentPermissions', () => {
    it('should hold appropriate permissions', () => {
      // Assemble
      const expectedPermissions: MarketAndUpdScopedPermissions = {
        permissions: [Permission.AraPReFDCT_PhraseAssignments_Assess],
        regulatoryMarketId: null,
        unileverProductDivisionId: null
      };

      // Assert
      expect(component.assessPhraseAssignmentPermissions).toEqual(expectedPermissions);
    });
  });

  describe('phraseAssignmentAssessmentDisabled', () => {
    beforeEach(() => {
        userHasPermissionForMarketAndProductDivision = true;
    });
      it('should return true for no item selection', () => {
        component.selectedItem = null;
        expect(component.phraseAssignmentAssessmentDisabled).toBeTruthy();
    });
    it('should return false when valid selected item', () => {
        component.selectedItem = createTestSelectedItem();
        expect(component.phraseAssignmentAssessmentDisabled).toBeFalsy();
    });
    it('should return true when no valid permission', () => {
        component.selectedItem = createTestSelectedItem();
        userHasPermissionForMarketAndProductDivision = false;
        expect(component.phraseAssignmentAssessmentDisabled).toBeTruthy();
    });
    it('should return true for item selection with incomplete data', () => {
        component.selectedItem = createTestSelectedItem();
        expect(component.phraseAssignmentAssessmentDisabled).toBeFalsy();
        component.selectedItem.phraseId = -1;
        expect(component.phraseAssignmentAssessmentDisabled).toBeTruthy();
        component.selectedItem.phraseId = 1;
        expect(component.phraseAssignmentAssessmentDisabled).toBeFalsy();
        component.selectedItem.topicId = -1;
        expect(component.phraseAssignmentAssessmentDisabled).toBeTruthy();
        component.selectedItem.topicId = 1;
        expect(component.phraseAssignmentAssessmentDisabled).toBeFalsy();
        component.selectedItem.regulatoryProductClassId = -1;
        expect(component.phraseAssignmentAssessmentDisabled).toBeTruthy();
        component.selectedItem.regulatoryProductClassId = 1;
        expect(component.phraseAssignmentAssessmentDisabled).toBeFalsy();
        component.selectedItem.regulatoryMarketId = -1;
        expect(component.phraseAssignmentAssessmentDisabled).toBeTruthy();
    });
  });
});
