import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { CacheService } from '../../tools/services/cache.service';
import { MarketWorkListData, MarketWorkListFilter, MarketWorkListItem } from '../work-list.types';
import { WorkListExcelExportComponent } from '../work-list-excel-export/work-list-excel-export.component';
import { AuthorizationService } from '../../authorization/authorization.service';
import { DetailLevel } from '../../tools/common.types';
import { UrlEndpoint, ColumnSortOrder, MarketWorkListType } from '../../tools/constants';
import { DialogService } from '../../tools/services/dialog.service';
import { FilterService } from '../../tools/services/filter.service';
import { HttpService } from '../../tools/services/http.service';
import { MarketAndUpdScopedPermissions } from '../../tools/shared-types/permissions/market-and-upd-scoped-permissions';
import { Permission } from '../../tools/shared-types/permissions/permission';

@Component({
  selector: 'app-market-work-list',
  templateUrl: './market-work-list.component.html',
  styleUrls: ['./market-work-list.component.scss']
})
export class MarketWorkListComponent implements OnInit {
  public assessPhraseAssignmentPermissions: MarketAndUpdScopedPermissions = {
    permissions: [Permission.AraPReFDCT_PhraseAssignments_Assess],
    regulatoryMarketId: null,
    unileverProductDivisionId: null
  };

  public data: MarketWorkListData = new MarketWorkListData();
  public filter: MarketWorkListFilter = new MarketWorkListFilter();
  public selectedItem: MarketWorkListItem | null = null;
  public loadingWorkList: boolean = false;
  public detailLevels: DetailLevel[] = new Array<DetailLevel>();

  workListType: MarketWorkListType;
  showChangeType: boolean = false;
  isInitialFlag: boolean = false;
  isTopicsLoaded: boolean = false;
  isMarketChange: boolean = false;
  yellowColorFlag: boolean = false;
  marketChange: boolean = false;
  clearFlage: boolean = false;

  constructor(
    private cacheService: CacheService,
    private dialogService: DialogService,
    private httpService: HttpService,
    private filterService: FilterService,
    private router: Router,
    private authorizationService: AuthorizationService,
    private route: ActivatedRoute,
  ) {
    this.route.params.subscribe(params => { // this is called if the worklist route is changed - e.g. between assess and review
      this.workListType = params.type;
      this.showChangeType = this.workListType == MarketWorkListType.Review;
      this.filter.workListType = this.workListType;
      this.isMarketChange = true;
      this.yellowColorFlag = true;
      // this.callfilterChangedAfterTopicsLoaded(!this.isTopicsLoaded);
      this.filterChanged();
    });
  }

  ngOnInit() {
    this.loadingWorkList = true;
    this.cacheService.getDetailLevels().then(results => {
      this.detailLevels = results;
    });
    this.isInitialFlag = true;
  }

  callfilterChangedAfterTopicsLoaded(isTopicsLoaded: boolean) {
    if (!isTopicsLoaded) {
      // this.filterChanged();
    }
  }
  public selectItem(item: MarketWorkListItem) {
    this.selectedItem = item;
  }

  public get rootRpcsOnly(): boolean {
    return this.filter.rootRpcsOnly;
  }
  public set rootRpcsOnly(value: boolean) {
    if (this.filter.rootRpcsOnly != value) {
      this.filter.rootRpcsOnly = value;
      this.filterChanged();
    }
  }
  RaOwnerfilte = null;
  filterChanged() {
    this.filter.pageNr = 1;
    if (!this.isInitialFlag && !this.showChangeType) {
      this.yellowColorFlag = false;
    }
    if (this.RaOwnerfilte == '' || this.RaOwnerfilte == 'null') {
      this.filter.raOwner = null;
    } else {
      this.filter.raOwner = this.RaOwnerfilte;
    }
    this.loadWorkListData();
  }

  gridPageChange(newPage: number) {
    this.filter.pageNr = newPage;
    this.loadWorkListData();
  }

  loadWorkListData() {
    this.loadingWorkList = true;
    this.selectedItem = null;
    // if (this.clearFlage || !this.isInitialFlag) {
    //   this.filter.geographyText = '';
    // }
    if (!this.isInitialFlag && this.filter.pageNr <= 0 && !this.showChangeType) {
      this.filter.pageNr = 1;
      this.yellowColorFlag = false;
    }
    this.httpService.postContentPromise(this.filter, UrlEndpoint.WorkList_LoadMarketWorkList).then(result => {
      this.loadingWorkList = false;
      this.data = result;
      if (this.isInitialFlag && !this.showChangeType && this.data.isHighesMarket) {
        this.filter.geographyText = this.data.items[0].regulatoryMarket;
        this.isMarketChange = false;
      }
      this.isInitialFlag = false;
    }).catch(() => {
      this.loadingWorkList = false;
    });
  }


  private keyTimer: any = null;
  filterKeyPress(event: any) {
    if (this.filterService.isKeyCodeFilterable(event.keyCode)) {
      if (this.keyTimer) {
        clearTimeout(this.keyTimer);
        this.keyTimer = null;
      }
      if (event.keyCode == 13) {
        this.filterChanged();
      } else {
        this.keyTimer = setTimeout(() => {
          this.keyTimer = null;
          this.filterChanged();
        }, 1000);
      }
    }
  }

  setSortOrder(columnName: string) {
    if (this.filter.sortColumn == columnName) {
      this.filter.sortDescending = !this.filter.sortDescending;
    } else {
      this.filter.sortColumn = columnName;
      this.filter.sortDescending = false;
    }
    this.filterChanged();
  }

  getSortDirection(columnName: string): string {
    if (this.filter.sortColumn == columnName) {
      return (this.filter.sortDescending ? ColumnSortOrder.Descending : ColumnSortOrder.Ascending);
    } else {
      return "";
    }
  }

  openMatrix() {
    if (this.selectedItem != null) {
      sessionStorage.setItem("wl-msel-topicId", this.selectedItem.topicId.toString());
      sessionStorage.setItem("wl-msel-rpcId", this.selectedItem.regulatoryProductClassId.toString());
      sessionStorage.setItem("wl-msel-marketId", this.selectedItem.regulatoryMarketId.toString());
      this.router.navigate(['/phrase-matrix']);
    }
  }

  openExcelExportModal() {
    const modalRef = this.dialogService.open(WorkListExcelExportComponent);
    modalRef.componentInstance.filter = this.filter;
    modalRef.componentInstance.workListType = 'Market';
    modalRef.componentInstance.workListExportPermissions = this.assessPhraseAssignmentPermissions;
  }

  public get phraseAssignmentAssessmentDisabled(): boolean {
    return this.selectedItem == null ||
      this.selectedItem.phraseId < 1 ||
      this.selectedItem.topicId < 1 ||
      this.selectedItem.regulatoryProductClassId < 1 ||
      this.selectedItem.regulatoryMarketId < 1 ||
      !this.authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision(this.assessPhraseAssignmentPermissions.permissions,
        this.assessPhraseAssignmentPermissions.regulatoryMarketId,
        this.assessPhraseAssignmentPermissions.unileverProductDivisionId);
  }

  public get workListTitle(): string {
    if (this.workListType == MarketWorkListType.Assess) {
      return "Market Work List - Assess";
    } else if (this.workListType == MarketWorkListType.Review) {
      return "Market Work List - Review";
    } else {
      return "Market Work List";
    }
  }

  topicChanged(value: number | null) {
    if (this.filter.topicId != value) {
      this.filter.topicId = value;
      this.filterChanged();
      this.selectedItem = null;
    }
  }

  clearTopicFilter() {
    const type = this.filter.workListType;
    this.RaOwnerfilte = null;
    // this.loadingWorkList = true;
    this.filter = new MarketWorkListFilter();
    this.data = new MarketWorkListData();
    this.filter.pageNr = 1;
    this.filter.geographyText = '';
    this.filter.raOwner = null;
    this.filter.workListType = type;
    this.clearFlage = true;
    this.loadWorkListData();
  }
  identify(index, item) {
    return item.label;
  }
}