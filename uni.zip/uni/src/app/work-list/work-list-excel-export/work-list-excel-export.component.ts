import { Component, OnInit } from '@angular/core';
import { WorkListFilter } from './../work-list.types';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ExcelExportService } from '../../tools/services/excel-export.service';
import { AuthorizationService } from './../../authorization/authorization.service';
import { MarketAndUpdScopedPermissions } from '../../tools/shared-types/permissions/market-and-upd-scoped-permissions';

@Component({
  selector: 'app-work-list-excel-export',
  templateUrl: './work-list-excel-export.component.html',
  styleUrls: ['./work-list-excel-export.component.scss']
})
export class WorkListExcelExportComponent implements OnInit {
  isExporting = false;
  // The below permissions are set from the modalRef that initialises this component.
  // As a result, these permissions may pertain to the exporting of a market work list,
  // as well as a gram work list (and, in the future, any other work lists that utilize
  // this component).
  public workListExportPermissions: MarketAndUpdScopedPermissions;

  public workListType: string;
  public filter: WorkListFilter = new WorkListFilter();

  urlEndpoint: string = 'WorkList';

  constructor(
    public activeModal: NgbActiveModal,
    private excelExportService: ExcelExportService,
    private authorizationService: AuthorizationService,
  ) { }

  ngOnInit() {
  }

  exportFilteredWorkList() {
    this.isExporting = true;
    this.excelExportService.exportContent(`Filtered${this.workListType}${this.urlEndpoint}`, this.urlEndpoint, this.filter, false)
      .subscribe(() => this.isExporting = false,
      () => this.isExporting = false);
  }
  exportAllWorkList() {
    this.isExporting = true;
    this.excelExportService.exportContent(`All${this.workListType}${this.urlEndpoint}`, this.urlEndpoint, this.filter, false)
      .subscribe(() => this.isExporting = false,
      () => this.isExporting = false);
  }


  public get excelExportAllowed(): boolean {
    return !this.isExporting &&
            this.authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision(
                                        this.workListExportPermissions.permissions,
                                        this.workListExportPermissions.regulatoryMarketId,
                                        this.workListExportPermissions.unileverProductDivisionId);
  }
}
