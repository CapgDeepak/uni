import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { BootstrapTemplatesModule } from './../../bootstrap-templates/bootstrap-templates.module';
import { WorkListExcelExportComponent } from './work-list-excel-export.component';
import { ExcelExportService } from '../../tools/services/excel-export.service';
import { MockDirective } from '../../tools/testTools/mockDirective';
import { ShowIfUserHasAnyPermissionDirective } from '../../authorization/directives/show-if-user-has-any-permission.directive';
import { AuthorizationService } from '../../authorization/authorization.service';
import { Permission } from '../../tools/shared-types/permissions/permission';

let userHasPermission: boolean;
let userHasPermissionForMarketAndProductDivision: boolean;
class AuthorizationServiceMock {
  checkUserHasAnyPermission() {
    return userHasPermission;
  }
  checkUserHasAnyPermissionForMarketAndProductDivision() {
    return userHasPermissionForMarketAndProductDivision;
  }
}

describe('WorkListExcelExportComponent', () => {
  let component: WorkListExcelExportComponent;
  let fixture: ComponentFixture<WorkListExcelExportComponent>;

  class NgbActiveModalMock { }
  class ExcelExportServiceMock {
    exportContent() {}
   }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        BootstrapTemplatesModule
      ],
      declarations: [
        WorkListExcelExportComponent,
        ShowIfUserHasAnyPermissionDirective,
      ],
      providers: [
        { provide: NgbActiveModal, useClass: NgbActiveModalMock },
        { provide: ExcelExportService, useClass: ExcelExportServiceMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
      ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkListExcelExportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  describe('when user has correct permissions', () => {
    beforeEach(() => {
      // Assemble
      const userPermissions = [Permission.AraPReFDCT_Phrases_Read];
      userHasPermission = true;
      component.workListExportPermissions = {
        permissions: userPermissions,
        regulatoryMarketId: null,
        unileverProductDivisionId: 1
      };
      fixture.detectChanges();
    });

    describe('with correct scope', () => {
      beforeEach(() => {
        // Assemble
        userHasPermissionForMarketAndProductDivision = true;
        fixture.detectChanges();
      });

      it('export buttons should be enabled', () => {
        // Assert
        const filteredExportButton = fixture.debugElement.query(By.css('#export-filtered-set-button'));
        expect(filteredExportButton).toBeTruthy();
        expect(filteredExportButton.properties.disabled).toBeFalsy();
        const fullExportButton = fixture.debugElement.query(By.css('#export-filtered-set-button'));
        expect(fullExportButton).toBeTruthy();
        expect(fullExportButton.properties.disabled).toBeFalsy();
      });
    });

    describe('with incorrect scope', () => {
      beforeEach(() => {
        // Assemble
        userHasPermissionForMarketAndProductDivision = false;
        fixture.detectChanges();
      });

      it('export buttons should be disabled', () => {
        // Assert
        const filteredExportButton = fixture.debugElement.query(By.css('#export-filtered-set-button'));
        expect(filteredExportButton).toBeTruthy();
        expect(filteredExportButton.properties.disabled).toBeTruthy();
        const fullExportButton = fixture.debugElement.query(By.css('#export-full-set-button'));
        expect(fullExportButton).toBeTruthy();
        expect(fullExportButton.properties.disabled).toBeTruthy();
      });
    });
  });

  describe('when user does not have permission to approve phrases', () => {
    beforeEach(() => {
      // Assemble
      userHasPermission = false;
      component.workListExportPermissions = {
        permissions: [],
        regulatoryMarketId: null,
        unileverProductDivisionId: 1
      };
      fixture.detectChanges();
    });

    it('export buttons should be hidden', () => {
      // Assert
      const filteredExportButton = fixture.debugElement.query(By.css('#export-filtered-set-button'));
      expect(filteredExportButton).toBeFalsy();
      const fullExportButton = fixture.debugElement.query(By.css('#export-full-set-button'));
      expect(fullExportButton).toBeFalsy();
    });
  });
});
