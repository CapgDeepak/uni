import { Component, OnInit } from '@angular/core';
import { ToasterService } from 'angular2-toaster';

import { ApprovePhraseComponent } from '../../phrase-library/approve-phrase/approve-phrase.component';
import { CacheService } from '../../tools/services/cache.service';
import { GramWorkListData, GramWorkListFilter, GramWorkListItem } from '../work-list.types';
import { SideDialogService } from '../../tools/side-dialog/side-dialog.service';

import { DetailLevel, SaveResult } from '../../tools/common.types';
import { UrlEndpoint, ColumnSortOrder } from '../../tools/constants';
import { DialogService } from '../../tools/services/dialog.service';
import { WorkListExcelExportComponent } from '../work-list-excel-export/work-list-excel-export.component';
import { FilterService } from '../../tools/services/filter.service';
import { HttpService } from '../../tools/services/http.service';
import { AuthorizationService } from './../../authorization/authorization.service';
import { Permission } from '../../tools/shared-types/permissions/permission';
import { MarketAndUpdScopedPermissions } from '../../tools/shared-types/permissions/market-and-upd-scoped-permissions';

@Component({
  selector: 'app-gram-work-list',
  templateUrl: './gram-work-list.component.html',
  styleUrls: ['./gram-work-list.component.scss']
})
export class GramWorkListComponent implements OnInit {
  public approvePhrasePermissions: MarketAndUpdScopedPermissions = {
    permissions: [Permission.AraPReFDCT_Phrases_Approve],
    regulatoryMarketId: null,
    unileverProductDivisionId: null,
  };

  public data: GramWorkListData = new GramWorkListData();
  public filter: GramWorkListFilter = new GramWorkListFilter();
  public selectedItem: GramWorkListItem;
  public selectedId: number | null = null;
  public loadingWorkList: boolean = false;
  public detailLevels: DetailLevel[] = new Array<DetailLevel>();

  constructor(
    private cacheService: CacheService,
    private dialogService: DialogService,
    private sideDialogService: SideDialogService,
    private toasterService: ToasterService,
    private httpService: HttpService,
    private filterService: FilterService,
    private authorizationService: AuthorizationService,
  ) { }

  ngOnInit() {
    this.loadingWorkList = true;
    this.cacheService.getDetailLevels().then(results => {
      this.detailLevels = results;
    });
  }

  public selectItem(item: GramWorkListItem) {
    this.selectedId = item.phraseId;
    this.selectedItem = item;
  }
  RaOwnerfilte = null;
  filterChanged() {
    this.filter.pageNr = 0;
    if (this.RaOwnerfilte == 'null' || this.RaOwnerfilte == '' || this.RaOwnerfilte == null) {
      this.filter.raOwner = null;
    }
    else {
      this.filter.raOwner = this.RaOwnerfilte;
    }
    this.loadWorkListData();
  }

  gridPageChange(newPage: number) {
    this.filter.pageNr = newPage;
    this.loadWorkListData();
  }

  loadWorkListData() {
    this.loadingWorkList = true;
    this.httpService.postContentPromise(this.filter, UrlEndpoint.WorkList_LoadGramWorkList).then(result => {
      this.loadingWorkList = false;
      this.data = result;
    }).catch(error => {
      this.loadingWorkList = false;
    });
  }

  private keyTimer: any = null;
  filterKeyPress(event: any) {
    if (this.filterService.isKeyCodeFilterable(event.keyCode)) {
      if (this.keyTimer) {
        clearTimeout(this.keyTimer);
        this.keyTimer = null;
      }
      if (event.keyCode == 13) {
        this.filterChanged();
      } else {
        this.keyTimer = setTimeout(() => {
          this.keyTimer = null;
          this.filterChanged();
        }, 1000);
      }
    }
  }

  setSortOrder(columnName: string) {
    if (this.filter.sortColumn == columnName) {
      this.filter.sortDescending = !this.filter.sortDescending;
    }
    else {
      this.filter.sortColumn = columnName;
      this.filter.sortDescending = false;
    }
    this.filterChanged();
  }

  getSortDirection(columnName: string): string {
    if (this.filter.sortColumn == columnName) {
      return (this.filter.sortDescending ? ColumnSortOrder.Descending : ColumnSortOrder.Ascending);
    } else {
      return "";
    }
  }

  openApprovePhraseModal(item: GramWorkListItem) {
    const modalRef = this.sideDialogService.openWithCallback(ApprovePhraseComponent, (saveResult) => {
      const resultData = saveResult as SaveResult;
      if (resultData && resultData.success) {
        if (item.phraseStatusText != 'Deletion Request') {
          this.toasterService.pop('success', 'Approve phrase', resultData.message);
          this.filterChanged();
        }
      } else {
        const ok = saveResult as boolean;
        if (ok) {
          this.filterChanged();
        }
      }
    });
    modalRef.componentInstance.phraseId = this.selectedId;
    modalRef.componentInstance.phrase = this.selectedItem;
  }

  openExcelExportModal() {
    const modalRef = this.dialogService.open(WorkListExcelExportComponent);
    modalRef.componentInstance.filter = this.filter;
    modalRef.componentInstance.workListType = 'GRAM';
    modalRef.componentInstance.workListExportPermissions = this.approvePhrasePermissions;
  }

  public get phraseApprovalAllowed(): boolean {
    return this.selectedId > 0 &&
      this.authorizationService.checkUserHasAnyPermissionForMarketAndProductDivision(this.approvePhrasePermissions.permissions,
        this.approvePhrasePermissions.regulatoryMarketId,
        this.approvePhrasePermissions.unileverProductDivisionId);
  }

  clearTopicFilter() {
    this.RaOwnerfilte = null;
    this.loadingWorkList = true;
    this.data = new GramWorkListData();
    this.filter = new GramWorkListFilter();
    this.filter.pageNr = 0;
  }

  // load Phrase data after Topics are loaded (fix for performance issue)
  callfilterChangedAfterTopicsLoaded(isTopicsLoaded: boolean) {
    if (!isTopicsLoaded) {
      this.filterChanged();
    }
  }


  topicChanged(value: number | null) {
    if (this.filter.topicId != value) {
      this.filter.topicId = value;
      this.filterChanged();
      this.selectedId = 0;


    }
  }

  identify(index, item) {
    return item.label;
  }
}
