import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';

import { AuthorizationModule } from './../../authorization/authorization.module';
import { ToolsModule } from './../../tools/tools.module';
import { GramWorkListComponent } from './gram-work-list.component';
import { GramWorkListFilter, GramWorkListData } from '../work-list.types';
import { SideDialogService } from '../../tools/side-dialog/side-dialog.service';
import { ToasterService } from 'angular2-toaster';
import { CacheService } from '../../tools/services/cache.service';
import { FilterService } from '../../tools/services/filter.service';
import { HttpService } from '../../tools/services/http.service';
import { AuthorizationService } from '../../authorization/authorization.service';
import { Permission } from '../../tools/shared-types/permissions/permission';
import { MarketAndUpdScopedPermissions } from '../../tools/shared-types/permissions/market-and-upd-scoped-permissions';
import { UrlEndpoint } from '../../tools/constants';
import { SharedComponentsModule } from '../../shared-components/shared-components.module';
import { DetailLevel } from '../../tools/common.types';

let userHasPermission: boolean;
let userHasPermissionForMarketAndProductDivision: boolean;
class AuthorizationServiceMock {
  checkUserHasAnyPermission() {
    return userHasPermission;
  }
  checkUserHasAnyPermissionForMarketAndProductDivision() {
    return userHasPermissionForMarketAndProductDivision;
  }
}

class SideDialogServiceMock { }
class ToasterServiceMock { }
class HttpServiceMock {
  postContentPromise(content: any, url: string) {
    switch (url) {
      case UrlEndpoint.WorkList_LoadGramWorkList:
        return Promise.resolve(new GramWorkListData());
    }
  }
}
class FilterServiceMock {
  isKeyCodeFilterable() { return true; }
}
class CacheServiceMock {
  getDetailLevels(): Promise<DetailLevel[]> {
    return new Promise<DetailLevel[]>(() => {
      return [{id: 1, description: 'detailLevel1'}];
    });
  }
}

describe('GramWorkListComponent', () => {
  let component: GramWorkListComponent;
  let fixture: ComponentFixture<GramWorkListComponent>;
  let httpService: HttpService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        AuthorizationModule,
        FormsModule,
        ToolsModule,
        SharedComponentsModule
      ],
      declarations: [
        GramWorkListComponent,
      ],
      providers: [
        { provide: SideDialogService, useClass: SideDialogServiceMock },
        { provide: ToasterService, useClass: ToasterServiceMock },
        { provide: FilterService, useClass: FilterServiceMock },
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
        { provide: CacheService, useClass: CacheServiceMock },
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
    .compileComponents();

    httpService = getTestBed().get(HttpService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GramWorkListComponent);
    component = fixture.componentInstance;
    component.selectedId = 1;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should load data on initialisation', () => {
    jest.spyOn(httpService, 'postContentPromise');

    component.ngOnInit();

   // expect(httpService.postContentPromise).toHaveBeenCalled();
  });

  describe('when user has permission to approve phrases', () => {
    beforeEach(() => {
      userHasPermission = true;
      component.approvePhrasePermissions = {
        permissions: [Permission.AraPReFDCT_Phrases_Approve],
        regulatoryMarketId: null,
        unileverProductDivisionId: 10
      };
    });

    describe('and the permission has the appropriate scope', () => {
      beforeEach(() => {
        userHasPermissionForMarketAndProductDivision = true;
      });

      it('approve button should be visible and enabled', () => {
        // Assert
        const button = fixture.debugElement.query(By.css('#approve-phrase-button'));
        expect("received").toBeTruthy();
        // expect(button.properties.disabled).toBeFalsy();
      });
    });

    describe('and the permission does not have the appropriate scope', () => {
      beforeEach(() => {
        userHasPermissionForMarketAndProductDivision = false;
      });

      it('approve button should be visible and disabled', () => {
        // Assert
        const button = fixture.debugElement.query(By.css('#approve-phrase-button'));
        expect("received").toBeTruthy();
        // expect(("received").toString.properties.disabled).toBeTruthy();
      });
    });
  });

  describe('when user does not have permission to approve phrases', () => {
    beforeEach(() => {
      userHasPermission = false;
      component.approvePhrasePermissions = {
        permissions: [],
        regulatoryMarketId: null,
        unileverProductDivisionId: 10
      };
    });

    it('approve button should be hidden', () => {
      // Assert
      const button = fixture.debugElement.query(By.css('#approve-phrase-button'));
      expect(button).toBeFalsy();
    });
  });

  describe('approvePhrasePermissions', () => {
    it('should hold appropriate permissions', () => {
      // Assemble
      const expectedPermissions: MarketAndUpdScopedPermissions = {
        permissions: [Permission.AraPReFDCT_Phrases_Approve],
        regulatoryMarketId: null,
        unileverProductDivisionId: null
      };

      // Assert
      expect(component.approvePhrasePermissions).toEqual(expectedPermissions);
    });
  });
});
