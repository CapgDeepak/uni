import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'angular2-toaster';
import { of } from 'rxjs';

import { MarketCreateComponent } from './market-create.component';
import { MarketWorkListData, MarketCreateWorkList } from '../work-list.types';
import { AuthorizationService } from '../../authorization/authorization.service';
import { ShowIfUserHasAnyPermissionDirective } from '../../authorization/directives/show-if-user-has-any-permission.directive';
import { UrlEndpoint, MarketWorkListType } from '../../tools/constants';
import { CacheService } from '../../tools/services/cache.service';
import { FilterService } from '../../tools/services/filter.service';
import { HttpService } from '../../tools/services/http.service';
import { SideDialogService } from '../../tools/side-dialog/side-dialog.service';
import { MockDateTimePipe } from '../../tools/testTools/mockDateTimePipe';
import { MarketAndUpdScopedPermissions } from '../../tools/shared-types/permissions/market-and-upd-scoped-permissions';
import { Permission } from '../../tools/shared-types/permissions/permission';
import { DetailLevel, RegulatoryMarketHierarchyItem } from '../../tools/common.types';

class SideDialogServiceMock { }
class ToasterServiceMock { }
class HttpServiceMock {
  postContentPromise(content: any, url: string) {
    switch (url) {
      case UrlEndpoint.WorkList_LoadMarketCreateWorkList:
        return Promise.resolve(new MarketWorkListData());
    }
  }
}
class FilterServiceMock {
  isKeyCodeFilterable() { return true; }
}
class RouterMock { }
class AuthorizationServiceMock {
  checkUserHasAnyPermission() {
    return true;
  }
}
class CacheServiceMock {
  getDetailLevels(): Promise<DetailLevel[]> {
    return new Promise<DetailLevel[]>(() => {
      return [{id: 1, description: 'detailLevel1'}];
    });
  }
  getRegulatoryMarkets(): Promise<RegulatoryMarketHierarchyItem[]> {
    return new Promise<RegulatoryMarketHierarchyItem[]>((resolve) => {
      resolve([
        { id: 99, description: 'Global', parentId: null, regulatoryMarketId: 1, isNavigationMarket: null, requiresSubselection: true, isUserAuthorizedMarket: false },
        { id: 98, description: 'EU',     parentId: 99,   regulatoryMarketId: 2, isNavigationMarket: null, requiresSubselection: false, isUserAuthorizedMarket: false }
      ]);
    });
  }
}


function createTestSelectedItem(): MarketCreateWorkList  {
  return {
      topicId: 50,
      topicPath: 'topic',
      regulatoryMarketId: 100,
      regulatoryMarket: 'Algeria',
      regulatoryProductClassId: 200,
      regulatoryProductClassText: 'rpc'
  };
}

describe('MarketCreateComponent', () => {
  let component: MarketCreateComponent;
  let fixture: ComponentFixture<MarketCreateComponent>;
  let httpService: HttpService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        MarketCreateComponent,
        MockDateTimePipe,
        ShowIfUserHasAnyPermissionDirective,
      ],
      providers: [
        { provide: SideDialogService, useClass: SideDialogServiceMock },
        { provide: ToasterService, useClass: ToasterServiceMock },
        { provide: HttpService, useClass: HttpServiceMock },
        { provide: FilterService, useClass: FilterServiceMock },
        { provide: Router, useClass: RouterMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
        { provide: CacheService, useClass: CacheServiceMock },
        { provide: ActivatedRoute, useValue: {
            params: of([{type: MarketWorkListType.Assess}])
          }
        }
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA,
        NO_ERRORS_SCHEMA
      ]
    })
    .compileComponents();

    httpService = getTestBed().get(HttpService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarketCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should match snapshot when change type visible', () => {
    component.showChangeType = true;
    fixture.detectChanges();
    (expect(fixture) as any).toMatchSnapshot();
  });

  it('should not load data on initialisation', () => {
    jest.spyOn(httpService, 'postContentPromise');
    component.ngOnInit();
    expect(httpService.postContentPromise).toHaveBeenCalledTimes(0);
  });

  it('should load data on filter change', () => {
    jest.spyOn(httpService, 'postContentPromise');
    component.filterChanged();
    expect(httpService.postContentPromise).toHaveBeenCalled();
  });

  describe('assessPhraseAssignmentPermissions', () => {
    it('should hold appropriate permissions', () => {
      // Assemble
      const expectedPermissions: MarketAndUpdScopedPermissions = {
        permissions: [Permission.AraPReFDCT_PhraseAssignments_Assess],
        regulatoryMarketId: null,
        unileverProductDivisionId: null
      };

      // Assert
      expect(component.assessPhraseAssignmentPermissions).toEqual(expectedPermissions);
    });
  });
});
