import { MarketWorkListType } from '../tools/constants';

export interface WorkListItem {
    phraseId: number;
    phraseNr: number;
    phraseText: string;
    phraseType: number;
    phraseTypeText: string;
    changeType: number;
    changeTypeText: string;
    createdAt: Date | null;
    createdBy: string;
    lastModifiedAt: Date | null;
    lastModifiedBy: string;
    lastReviewedAt: Date | null;
    lastReviewedBy: string;
    topic: string;
    regulatoryMarket: string;
    regulatoryProductClass: string;
    unileverProductDivision: string;
    unileverProductDivisionId: number | null;

}

export class WorkListData {
    count: number;
    pageCount: number;
    isHighesMarket: boolean;
}

export class WorkListFilter {
    phraseNr: number | null;
    phraseText: string;
    phraseType: number | null;
    changeType: number | null;
    public topicId: number | null = null;
    topicText: string;
    detailLevelId: number | null;
    linkedPhraseNr: number | null;
    unileverProductDivisionText: string;
    assignedUPDPathText: string;
    geographyText: string;
    regulatoryProductClassText: string;
    auditText: string;
    pageNr: number;
    sortColumn: string;
    sortDescending: boolean;
    public rootRpcsOnly: boolean = true;
    isHighesMarket: boolean;
    topic: string;
    regulatoryMarket: string;
    regulatoryProductClass: string;
    public raOwner: string = '';
    lastReviewedBy: string;
}

export interface GramWorkListItem extends WorkListItem {
    phraseStatus: string;
    phraseStatusText: string;
}

export interface MarketCreateWorkList {
    topicId: number;
    topicPath: string;
    regulatoryMarketId: number;
    regulatoryMarket: string;
    regulatoryProductClassId: number;
    regulatoryProductClassText: string;
}

export class GramWorkListData extends WorkListData {
    items: WorkListItem[] = new Array<WorkListItem>();
}
export class MarketCreateWorkListData extends WorkListData {
    items: MarketCreateWorkList[] = new Array<MarketCreateWorkList>();
}

export class GramWorkListFilter extends WorkListFilter {
}

export interface MarketWorkListItem extends WorkListItem {
    phraseAssignmentStatus: string;
    phraseAssignmentStatusText: string;
    topicId: number;
    regulatoryMarketId: number;
    regulatoryProductClassId: number;
}

export class MarketWorkListData extends WorkListData {
    items: MarketWorkListItem[] = new Array<MarketWorkListItem>();
}

export class MarketWorkListFilter extends WorkListFilter {
    workListType: MarketWorkListType;
}