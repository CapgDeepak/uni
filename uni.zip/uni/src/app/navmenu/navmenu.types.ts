export interface UserProfile {
    displayName: string;
}
export interface ServerVersion {
    version: string;
}
export interface PageLink {
    hostedUri: string;
    name: string;
}

export interface HelpSupportDetailsList {
    items: HelpDetailsList[];
    count: number;
    pageCount: number;

}

export interface HelpDetailsList {
    fileId: number;
    documentName: string;
    fileName: string;
    createdByUserId?: number;
    createdUserName: string;
    createdDate: Date;
    modifiedByUserId?: number;
    modifiedByUserName: string;
    modifiedDate: Date;
    documentVersion: number;
    isFileDeleted: boolean;
}

export class HelpSupportFilter {
    public startIndex: number = 0;
    public count: number = 20;
    public sortColumn: string = '';
    public sortDescending: boolean = false;
    public filterColumn: string = '';
    public filterValue: string = '';
}

export class FieldFilterModel {
    public Column: string;
    public Value: string;
}