import { HelpSupportComponent } from './help-support.component';
import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { Observable } from 'rxjs';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Pipe, PipeTransform } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { HttpService } from '../../tools/services/http.service';
import { NgModule } from '@angular/core';
import { TableModule } from 'primeng/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';
import { FilterService } from '../../tools/services/filter.service';
import { AddEditHelpFileComponent } from '../add-edit-help-file/add-edit-help-file.component';
import { ConfirmationDialogService } from '../../shared-components/confirmation-dialog/confirmation-dialog.service';
import { DatePipe } from '@angular/common';
import { Item } from '../../tools/common.types';

class MockHttpService {
  get(url: string) {
    return new Observable(observer => {
      observer.next([]);
      observer.complete();
    });
  }
}

@Pipe({ name: 'araDateTime' })
class MockDateTimePipe implements PipeTransform {
  transform(value: number): any {
    const pipe = new DatePipe('en-US');
    return pipe.transform(value, 'dd-MMM-yyyy, HH:mm', '+0000');
  }
}
class MockAlertDialogService {
}

class AlertDialogServiceMock {
  alert() { }
}

class ConfirmationDialogServiceMock { }

class ToasterServiceMock { }

class FilterServiceMock {
  isKeyCodeFilterable() { return true; }
}

class HttpServiceMock {
  getFilteredPromise() {
    return new Promise<Item[]>((resolve) => {
      resolve([
        { id: 1, description: "Food", parentId: null, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false },
        { id: 2, description: "Crisps", parentId: 1, requiresSubselection: false, regulatoryMarketId: 0, isUserAuthorizedMarket: false }]);
    });
  }

  postContentPromise(): Promise<object> {
    return new Promise<object>((resolve, reject) => {
      resolve({});
    });
  }
}

describe('HelpSupportComponent', () => {
  let component: HelpSupportComponent;
  let fixture: ComponentFixture<HelpSupportComponent>;
  let injector: TestBed;

  const buildComponent = () => {
    fixture = TestBed.createComponent(HelpSupportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [HelpSupportComponent,
        AddEditHelpFileComponent,
        MockDateTimePipe],
      imports: [NgbModule, TableModule, FormsModule, ReactiveFormsModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        ConfirmationService,
        { provide: HttpService, useClass: MockHttpService },
        { provide: ToasterService, useClass: ToasterServiceMock },
        { provide: AlertDialogService, useClass: AlertDialogServiceMock },
        { provide: FilterService, useClass: FilterServiceMock },
        { provide: ConfirmationDialogService, useClass: ConfirmationDialogServiceMock },
        { provide: HttpService, useClass: HttpServiceMock },

      ]
    })
      .compileComponents();
    injector = getTestBed();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HelpSupportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should match snapshot', () => {
    expect(fixture).toMatchSnapshot();
  });
});
