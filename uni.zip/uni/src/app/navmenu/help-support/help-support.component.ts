import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmationDialogService } from '../../shared-components/confirmation-dialog/confirmation-dialog.service';
import { UrlEndpoint, ColumnSortOrder } from '../../tools/constants';
import { HttpService } from '../../tools/services/http.service';
import { ToasterService } from 'angular2-toaster';
import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';
import { HelpSupportFilter, HelpDetailsList } from '../navmenu.types';
import { FilterService } from '../../tools/services/filter.service';
import { TableModule, Table } from 'primeng/table';
import { AddEditHelpFileComponent } from '../add-edit-help-file/add-edit-help-file.component';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-help-support',
  templateUrl: './help-support.component.html',
  styleUrls: ['./help-support.component.scss']
})
export class HelpSupportComponent implements OnInit, AfterViewInit {
  @ViewChild('dt', { static: false }) phraseTable: Table;

  constructor(
    private modalService: NgbModal,
    private confirmationDialogService: ConfirmationDialogService,
    private httpService: HttpService,
    private toasterService: ToasterService,
    private alertDialogService: AlertDialogService,
    private filterService: FilterService,

  ) { }

  public _isLoading: boolean = true;
  public filter: HelpSupportFilter = new HelpSupportFilter();
  fieldFilterString: any;
  contentRows: any;
  selectedSelection: any;
  content: any;
  isuserAdmin: boolean = false;


  ngOnInit() {
    this.LoadDetails();
  }

  ngAfterViewInit() {
    setTimeout(() => {
     const element = document.getElementById("MenuOpen");
     element.classList.remove("open");
     const element1 = document.getElementById("hamburger-icon");
     element1.classList.remove("open");
     const element2 = document.getElementById("MenuClose");
     element2.classList.remove("open");
    }, 550);
   }

  LoadDetails() {
    const filterParams = {
      startIndex: this.filter.startIndex,
      count: this.filter.count,
      sortColumn: this.filter.sortColumn,
      sortDescending: this.filter.sortDescending,
      filterColumn: this.filter.filterValue ? 'DocumentName' : '',
      filterValue: this.filter.filterValue
    };
    console.log(filterParams);
    this.httpService.postContentPromise(filterParams as any, UrlEndpoint.HelpSupport_LoadDetails)
      .then(filteredContent => {
        this.content = filteredContent;
        this.contentRows = filteredContent.items;
        this._isLoading = false;
        this.isuserAdmin = filteredContent.isUserAdmin;
      }, error => {
        this.alertDialogService.alert('Error', 'Error loading documents list.');
        this._isLoading = false;
      });

  }

  private keyTimer: any = null;
  filterKeyPress(event: any, filterValue: any) {
    if (this.filterService.isKeyCodeFilterable(event.keyCode)) {
      if (this.keyTimer) {
        clearTimeout(this.keyTimer);
        this.keyTimer = null;
      }
      if (event.keyCode == 13 || filterValue === null || filterValue === '') {
        this._isLoading = true;
        this.LoadDetails();
      }
      else if (filterValue.length >= 2) {
        this._isLoading = true;
        this.LoadDetails();
      }
    }
  }

  paginatorChange(event) {
    // this.filter.count = event.rows;
    this.filter.startIndex = (event.first / event.rows) + 1;
    this.LoadDetails();
  }


  onDelete(rowSelected) {
    this.confirmationDialogService.confirm('Confirmation', 'If you delete the file, this file cannot be retrieved again. Are you sure to delete it?', 'Ok')
      .then((confirmed) => {
        if (confirmed) {
          this.httpService.postContentPromise(rowSelected, UrlEndpoint.HelpSupport_DeleteFile).then(result => {
            if (result.success) {
              this.toasterService.pop('success', 'Delete File', 'File deleted successfully');
              this.LoadDetails();
            }
            else {
              this.alertDialogService.alert('Error', result.message);
            }
          });
        }
      });
    this.selectedSelection = "";
  }

  onDownload(item) {
    this.confirmationDialogService.confirm('Confirmation', `Do you want to download the ${item.fileName} ?`, 'Ok')
      .then((confirmed) => {
        if (confirmed) {
          return this.httpService.getdownload(UrlEndpoint.HelpSupport_DownloadFile + '/' + item.fileName)
            .subscribe((result: any) => {
              if (result) {
                const blob = new Blob([result]);
                const FileSaver = require('file-saver');
                const file = item.fileName;
                FileSaver.saveAs(blob, file);
                this.toasterService.pop('success', 'Download File', 'The File has been downloaded successfully.');
                this.LoadDetails();
              }
              else {
                this.alertDialogService.alert('Error', 'File download failed. Please try again');
              }
            }
            );
        }
      });
  }

  onEdit(rowSelected) {
    const modalRef = this.modalService.open(AddEditHelpFileComponent, {
      backdrop: 'static',
      centered: true,
    });
    modalRef.componentInstance.title = "Edit Training Files";
    modalRef.componentInstance.editData = rowSelected;
    modalRef.result.then((result) => {
      if (result) {
        console.log(result);
        this.LoadDetails();
        this.selectedSelection = "";
      }
    });
  }

  onAdd() {
    const modalRef = this.modalService.open(AddEditHelpFileComponent, {
      backdrop: 'static',
      centered: true,
    });
    modalRef.componentInstance.title = "Upload Training Files";
    modalRef.result.then((result) => {
      if (result) {
        console.log(result);
        this.LoadDetails();
        this.selectedSelection = "";
      }
    });
  }

  // to get the sorting direction
  getSortDirection(columnName: string) {
    if (this.filter.sortColumn == columnName) {
      return (this.filter.sortDescending ? 'fa fa-sort-desc' : 'fa fa-sort-asc');
    }
    return 'fa fa-ellipsis-v';
  }

  public setSortOrder(columnName: string) {
    if (this.filter.sortColumn == columnName) {
      this.filter.sortDescending = !this.filter.sortDescending;
    }
    else {
      this.filter.sortColumn = columnName;
      this.filter.sortDescending = true;
    }
    this.LoadDetails();
  }
  intializeFlags() {
    this.isuserAdmin = false;
  }
}
