import { Component, OnInit, ElementRef, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { AlertDialogService } from '../../shared-components/alert-dialog/alert-dialog.service';
import { HttpService } from '../../tools/services/http.service';
import { UrlEndpoint } from '../../tools/constants';
import { Title } from '@angular/platform-browser';
import { HelpDetailsList } from '../navmenu.types';
import { ToasterService } from 'angular2-toaster';
import { HttpClient } from '@angular/common/http';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';

@Component({
  selector: 'app-add-edit-help-file',
  templateUrl: './add-edit-help-file.component.html',
  styleUrls: ['./add-edit-help-file.component.css']
})
export class AddEditHelpFileComponent implements OnInit {
  file: any;

  constructor(public activeModal: NgbActiveModal,
    private httpService: HttpService,
    private toasterService: ToasterService,
    private alertDialogService: AlertDialogService
  ) { }

  @ViewChild('labelImport', { static: true })

  @Output() afterEdit: EventEmitter<any> = new EventEmitter();
  @Output() afterAdd: EventEmitter<any> = new EventEmitter();
  labelImport: ElementRef;
  // changeValue: ElementRef;
  @Input() title: string;
  @Input() editData: any;
  modalTitle: string;
  fileName: string;
  isFileNameChanged: boolean = false;
  isFileUploaded: boolean = false;
  documentUploaded: string;
  fileSize;

  ngOnInit() {
    this.modalTitle = this.title;
    if (this.editData != null) {
      this.fileName = this.editData.documentName;
    }
    this.intializeFlags();
  }

  fileSizeFlag: boolean = false;
  fileTypeFlag: boolean = false;
  formData: FormData = new FormData();

  onFileChange(files) {
    this.isFileUploaded = true;
    document.getElementById("test").innerText = files[0].name;
    this.documentUploaded = files[0].name;
    this.fileSize = files[0].size;
    this.file = files[0];
    this.formData.append('file', files[0]);
    const type = files[0].name.substr(files[0].name.lastIndexOf('.') + 1).toLowerCase();
    if (this.fileSize <= 5242880) { this.fileSizeFlag = true; } else { this.fileSizeFlag = false; }
    if (type == 'xlsx' || type == 'xls' || type == 'pdf' || type == 'docx' || type == 'doc' || type == 'pptx' || type == 'ppt') { this.fileTypeFlag = true; } else { this.fileTypeFlag = false; }
  }

  fileNameChanged() {
    if (this.editData.documentName == this.fileName) {
      return true;
    } else {
      return false;
    }
  }

  onChangeofFileName(event) {
    if (event.target.value.length > 0) {
      this.isFileNameChanged = true;
    }
    else {
      this.isFileNameChanged = false;
    }
  }

  validate(operation: string) {
    if (this.fileSizeFlag && this.fileTypeFlag) {
      if (operation == 'edit') {
        this.uploadFile('Edit');
      }
      else {
        this.onAdd();
      }
    }
    else {
      this.formData = new FormData();
      if (!this.fileSizeFlag) { this.alertDialogService.alert('Error', 'File size cannot be more than 5 MB.'); }
      if (!this.fileTypeFlag) {
        this.alertDialogService.alert('Error', 'This filetype is not allowed. Only file with following extensions are allowed .xlsx .xls .pdf .docx .doc .pptx .ppt', 'Ok', 'sm');
      }
    }
  }

  onSubmit() {
    if (this.modalTitle == 'Edit Training Files') {
      if (this.isFileUploaded) {
        this.validate('edit');
      }
      else {
        this.onEdit();
      }
    }
    else {
      this.validate('add');
    }

  }

  onEdit() {
    const supportsection: HelpDetailsList = this.model('edit', this.editData);
    return this.httpService.postContentPromise(supportsection as any, UrlEndpoint.HelpSupport_EditFile)
      .then((result) => {
        if (result.success) {
          console.log(result);
          this.activeModal.close(true);
          this.toasterService.pop('success', 'File has Updated');
          this.intializeFlags();
        }
        else {
          this.alertDialogService.alert('Error', result.message);
        }
      }).catch(error => {
        console.error("File Update failed:", error);
        this.alertDialogService.alert('Error', "Edit failed");
      });
  }

  onAdd() {
    this.uploadFile('Add');
  }

  postUploadAdd() {
    const supportsection: HelpDetailsList = this.model('add');
    return this.httpService.postContentPromise(supportsection as any, UrlEndpoint.HelpSupport_CreateFile)
      .then((result) => {
        if (result.success) {
          console.log(result);
          this.toasterService.pop('success', result.message);
          this.activeModal.close(true);
          this.intializeFlags();
        }
        else {
          this.alertDialogService.alert('Error', result.message);
        }
      }).catch(error => {
        // this.alertDialogService.alert('Error', error);
        this.alertDialogService.alert('Error', 'File Creation failed');
        console.error("File Creation failed:", error);
      });
  }

  uploadFile(edits: any) {

    const supportsection: HelpDetailsList = edits == 'Add' ? this.model('add') : this.model('edit', this.editData);
    return this.httpService.postContentPromise(supportsection as any, UrlEndpoint.HelpSupport_ValidateDocument).then((results) => {
      if (edits !== 'Add' && !this.isFileUploaded) {
        this.onEdit();
      }
      else {
        const file = this.formData;
        this.httpService.postContentPromise(file, UrlEndpoint.HelpSupport_UploadFile).then((resultset) => {
          if (edits == 'Add') {
            this.postUploadAdd();
          } else {
            this.onEdit();
          }
        }).catch(error => {
          // this.alertDialogService.alert('Error', error);
          console.log(error);
          if (edits == 'Add') {
            if (error.status == 409) {
              this.alertDialogService.alert('Error', 'The file name is in use already.  Please select a unique name and try saving again.');
            }
            else {
              this.alertDialogService.alert('Error', 'File Upload failed. Please try again');
            }
          }
          else {
            if (error.status == 409) {
              this.alertDialogService.alert('Error', 'The file name is in use already.  Please select a unique name and try saving again.');
            }
            else {
              this.alertDialogService.alert('Error', 'File Upload failed. Please try again');
            }
          }
        });
      }
    }).catch(errors => {
      if (errors.status == 409) {
        this.alertDialogService.alert('Error', 'The file name is in use already.  Please select a unique name and try saving again.');
      }
      else {
        this.alertDialogService.alert('Error', 'File name has not been provided.');
      }
    });
  }

  model(operation: string, data?: any) {
    console.log(this.editData);

    const helpandSupportsection: HelpDetailsList = {
      fileId: operation == 'edit' ? data.fileId : 0,
      documentName: this.fileName,
      fileName: document.getElementById("test").innerText,
      createdByUserId: operation == 'edit' ? data.createdByUserId : 0,
      createdUserName: operation == 'edit' ? data.createdUserName : null,
      createdDate: operation == 'edit' ? data.createdDate : new Date(),
      modifiedByUserId: operation == 'edit' ? 0 : 0,
      modifiedByUserName: operation == 'edit' ? null : null,
      modifiedDate: operation == 'edit' ? data.modifiedDate : new Date(),
      documentVersion: operation == 'edit' ? data.documentVersion : 0,
      isFileDeleted: operation == 'edit' ? data.isFileDeleted : false
    };
    return helpandSupportsection;
  }

  intializeFlags() {
    this.fileSizeFlag = false;
    this.fileTypeFlag = false;
    this.isFileUploaded = false;
    this.isFileNameChanged = false;
  }
}
