import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MenubarModule } from 'primeng/menubar';
import { AuthorizationService } from '../../authorization/authorization.service';
import { Permission } from '../../tools/shared-types/permissions/permission';

import { SubnavmenuComponent } from './subnavmenu.component';


const userHasPermissionToViewPhraseLibrary: boolean = false;
const userHasPermissionToViewPhraseMatrix: boolean = false;
const userHasPermissionToViewGramWorkList: boolean = false;
const userHasPermissionToViewMarketWorkList: boolean = false;
const userHasPermission: boolean = false;
class AuthorizationServiceMock {
  userHasPermissionToViewPhraseLibrary() {
    return userHasPermissionToViewPhraseLibrary;
  }
  userHasPermissionToViewPhraseMatrix() {
    return userHasPermissionToViewPhraseMatrix;
  }
  userHasPermissionToViewGramWorkList() {
    return userHasPermissionToViewGramWorkList;
  }
  userHasPermissionToViewMarketWorkList() {
    return userHasPermissionToViewMarketWorkList;
  }
  checkUserHasAnyPermission(permissionsToCheck: Permission[]) {
    if (permissionsToCheck.some(p => p == Permission.AraPReFDCT_Phrases_Order)) {
      return userHasPermission;
    }
  }
}

describe('SubNavMenuComponent', () => {
  let component: SubnavmenuComponent;
  let fixture: ComponentFixture<SubnavmenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        MenubarModule,
        RouterTestingModule
      ],
      declarations: [SubnavmenuComponent],
      providers: [
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubnavmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should match snapshot when empty', () => {
    addMenuItems(component);
    fixture.detectChanges();
    expect(fixture).toMatchSnapshot();
  });

  it('should match snapshot for basic menu', () => {
    addMenuItems(component);
    component.menuItems = [
      getPageLink('pageOne', '/pageOne.html'),
      getPageLink('pageTwo', '/pageTwo.html'),
    ];
    fixture.detectChanges();
    expect(fixture).toMatchSnapshot();
  });

  it('displays menu with submenus', () => {
    component.menuItems = [
      getPageLink('pageOne', '/pageOne.html'),
      getPageLink('pageOne', '/pageOne.html'),
      {
        label: 'pageThree', routerLink: '/pageThree.html',
        items: [
          getPageLink('pageFour', '/pageFour.html'),
          getPageLink('pageFive', '/pageFive.html')
        ],
      },
      getPageLink('pageTwo', '/pageTwo.html')
    ];
    fixture.detectChanges();
    expect(fixture).toMatchSnapshot();
  });

});

function addMenuItems(component: SubnavmenuComponent) {
  component.menuItems = [
    {
      label: 'ARA',
      icon: 'pi pi-fw',
      routerLink: ['/home']
    },
    getPageLink('PReF', '/requirement-type')
  ];
}

function getPageLink(name: string, linkUrl: string) {
  return { label: name, routerLink: linkUrl };
}
