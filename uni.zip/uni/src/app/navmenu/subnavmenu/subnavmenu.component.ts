import { Component, OnInit, Input } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { AuthorizationService } from '../../authorization/authorization.service';
import { Permission } from '../../tools/shared-types/permissions/permission';

@Component({
  selector: 'app-subnavmenu',
  templateUrl: './subnavmenu.component.html',
  styleUrls: ['./subnavmenu.component.scss']
})
export class SubnavmenuComponent implements OnInit {

  public userHasPermissions: boolean = false;
  constructor(private authorizationService: AuthorizationService) { }
  @Input() menuItems: MenuItem[];

  ngOnInit() {
    if (!this.authorizationService.userHasPermissionToViewGramWorkList() && !this.authorizationService.userHasPermissionToViewMarketWorkList()
      && !this.authorizationService.userHasPermissionToViewPhraseLibrary() && !this.authorizationService.checkUserHasAnyPermission([Permission.AraPReFDCT_Phrases_Order])) {
      this.userHasPermissions = true;
    }
  }

}
