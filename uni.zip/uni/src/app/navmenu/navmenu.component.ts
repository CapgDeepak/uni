import { Component, OnInit, Output, EventEmitter, Inject } from "@angular/core";
import { Router } from "@angular/router";
import { MenuItem } from "primeng/api";
import { Observable, of } from "rxjs";

import { PageLink } from "./navmenu.types";
import { UrlEndpoint } from "../tools/constants";
import { HttpService } from "../tools/services/http.service";
import { AuthenticationService } from "../authorization/authentication.service";
import { environment } from "../../environments/environment";
import { AuthorizationService } from "../authorization/authorization.service";
import { Permission } from "../tools/shared-types/permissions/permission";
import { ConfigService } from "../tools/services/config.service";
import { MSAL_GUARD_CONFIG, MsalGuardConfiguration, MsalService } from "@azure/msal-angular";
import { AuthenticationResult, RedirectRequest } from "@azure/msal-browser";

@Component({
  selector: "nav-menu",
  templateUrl: "./navmenu.component.html",
  styleUrls: ["./navmenu.component.scss"],
})
export class NavMenuComponent implements OnInit {
  PageLinksForNavMenu: PageLink[];
  userDetails: string = "";
  constructor(@Inject(MSAL_GUARD_CONFIG) private msalGuardConfig: MsalGuardConfiguration,
    private envConfig: ConfigService,
    private msalService: MsalService,
    private authenticationService: AuthenticationService,
    private httpService: HttpService,
    private router: Router,
    private authorizationService: AuthorizationService
  ) { }

  public pageLinks$: Observable<PageLink[]>;
  public menuItems: MenuItem[] = [];

  public isLoggedIn$: Observable<boolean>;
  public userName: string = "";
  public serverVersion: string = "";
  public uiVersion: string = "";
  isUserHasPermission: any = true;
  public loggedinUserRoleList: any[] = [];
  showTrainingInfoMsg: boolean = false;
  roleLoggedInUserUrl = "api/Role/GetRolesByUserId";
  baseUrl: any;
  // = 'https://bnlwe-es01-q-57312-unilevercom-webapp-09.azurewebsites.net/services';
  @Output() setLogin: EventEmitter<any> = new EventEmitter();
  @Output() setRoles: EventEmitter<any> = new EventEmitter();
  // SEP2020
  public isMenuOpen: boolean = false;
  @Output() isMenu: EventEmitter<any> = new EventEmitter();
  public menuLinks: any;
  // --SEP2020

  ngOnInit(): void {
    // If the user is authenticated (i.e. if they have logged in successfully),
    // then set the logged in observable to true, once their display name has been
    // retrieved from the backend.
    localStorage.setItem("showUNALink", 'false');
    this.msalService.handleRedirectObservable().subscribe({
      next: (resultAuth: AuthenticationResult) => {
        if (resultAuth) {
          console.log("this.authenticationService.isLoggedIn() - true");
          this.msalService.instance.setActiveAccount(resultAuth.account);
          this.authenticationService
            .getUserProfile()
            .then(() => {
              this.setLoggedIn(true);
            })
            .catch((error) => {
              localStorage.setItem("unauthorisedErrorMsgNum", error.status);
              if (error.status == 403 || error.status == 404 || error.status == 405 || error.status == 409) {
                const environ = this.envConfig.getAraDctUrl().split('-').pop().split('.')[0];
                if (environ == "dev" || environ == "test" || environ == "regression") {
                  localStorage.setItem("showUNALink", 'false');
                } else {
                  localStorage.setItem("showUNALink", 'true');
                }
                console.log("user profile failed -  " + error);
                this.router.navigate(["/unauthorized/false"]);
              }
            });

          const env = this.envConfig.getAraDctUrl().split('-').pop().split('.')[0];
          if (env == "dev" || env == "test" || env == "qa" || env == "training" || env == "regression") {
            this.baseUrl = 'https://ara-admin-' + env + '.unilever.com/services';
          }
          else if (env == "dc") {
            this.baseUrl = 'https://ara-admin.unilever.com/services';
          }
          else {
            this.baseUrl = this.baseUrl = 'https://ara-admin-' + env + '.unilever.com/services';
          }

          this.httpService
            .getWithBaseUrl(this.baseUrl, this.roleLoggedInUserUrl)
            .subscribe((data) => {
              this.loggedinUserRoleList = data;
              this.setRoles.emit(data);
              this.authenticationService.loadAccessibleApplications().then((result) => {
                // SEP2020
                this.menuLinks = result;
                // --SEP2020
                this.PageLinksForNavMenu = result;
                const environ = this.envConfig.getAraDctUrl().split('-').pop().split('.')[0];
                console.log(environ, 'env');
                if (environ == "training") {
                  this.showTrainingInfoMsg = true;
                  console.log(this.showTrainingInfoMsg, 'trainingMsg');
                }
                const getUserDetailsUrl = "api/Role/GetUserType";
                this.httpService
                  .getWithBaseUrl(this.baseUrl, getUserDetailsUrl)
                  .subscribe((res) => {
                    this.userDetails = res;
                    if (this.userDetails == "R&D") {
                      console.log("RD user -  " + this.userDetails);
                      // RA Viewer has access to Pref DCT application can viewabl
                      const obj = this.loggedinUserRoleList.find((o, i) => {
                        if (o.description === "RA Viewer") {
                          return true; // stop searching
                        }
                      });

                      if (!obj) {
                        this.PageLinksForNavMenu = this.PageLinksForNavMenu.filter(
                          (page) => page.name != "PReF DCT"
                        );
                      }
                      this.PageLinksForNavMenu = this.PageLinksForNavMenu.filter(
                        (page) => page.name != "FAsT"
                      );

                      const prefDCTPermission = this.loggedinUserRoleList.find(
                        (o, i) => {
                          if (
                            o.description === "RA Viewer" ||
                            o.description === "PReF Admin" ||
                            o.description === "PReF Global RA" ||
                            o.description === "PReF Market/Cluster RA"
                          ) {
                            return true; // stop searching
                          }
                        }
                      );

                      if (!prefDCTPermission) {
                        this.isUserHasPermission = false;
                        console.log("RD user -  " + this.isUserHasPermission);
                      }
                    } else {
                      console.log("RA user or Admin");

                      const obj = this.loggedinUserRoleList.find((o, i) => {
                        if (
                          o.description === "RA Viewer" ||
                          o.description === "PReF Admin" ||
                          o.description === "PReF Global RA" ||
                          o.description === "PReF Market/Cluster RA" ||
                          o.description === "Super Admin"
                        ) {
                          console.log("obj -  " + o.description);
                          return true; // stop searching
                        }
                      });

                      if (obj) {
                        this.isUserHasPermission = true;
                        console.log("obj -  " + this.isUserHasPermission);
                      } else {
                        this.PageLinksForNavMenu = this.PageLinksForNavMenu.filter(
                          (page) => page.name != "PReF"
                        );
                        this.PageLinksForNavMenu = this.PageLinksForNavMenu.filter(
                          (page) => page.name != "FAsT"
                        );
                        this.isUserHasPermission = false;
                        console.log("RA user -  " + this.isUserHasPermission);
                      }

                      const prefDCTPermission = this.loggedinUserRoleList.find(
                        (o, i) => {
                          if (
                            o.description === "RA Viewer" ||
                            o.description === "PReF Admin" ||
                            o.description === "PReF Global RA" ||
                            o.description === "PReF Market/Cluster RA"
                          ) {
                            console.log("prefDCTPermission -  " + o.description);
                            return true; // stop searching
                          }
                        }
                      );

                      if (!prefDCTPermission) {
                        this.isUserHasPermission = false;
                        console.log("RA user - PrefDCT -  " + this.isUserHasPermission);
                      }
                    }
                    this.menuLinks = this.PageLinksForNavMenu;
                    this.pageLinks$ = of(this.PageLinksForNavMenu);
                    if (!this.isUserHasPermission) {
                      console.log(
                        "Top Menu - user doesnt have access -  " +
                        this.PageLinksForNavMenu
                      );
                      const prefDCTExists = this.PageLinksForNavMenu.find((o, i) => {
                        if (o.name === "PReF DCT") {
                          return true; // stop searching
                        }
                      });
                      console.log(prefDCTExists);
                      if (!prefDCTExists) {
                        this.router.navigate(["/unauthorized/false"]);
                      }
                    }
                  });
              });
            });
        } else {
          console.log("this.setLoggedIn(false); - false");
          // Otherwise, ensure that they are not displayed as being logged in.
          // Set/reset the username as well.
          this.setLoggedIn(false);
          this.login();
        }

        if (!environment.production) {
          this.serverVersion = environment.version;
        } else {
          this.httpService.getPromise(UrlEndpoint.Server_Version).then((result) => {
            this.serverVersion = result;
          });
        }

        this.uiVersion = require("../../../package.json").version;
      },
      error: (error) => console.log(error)
    });
  }

  setLoggedIn(loggedIn: boolean) {
    this.isLoggedIn$ = of(loggedIn);
    this.setLogin.emit({ isLoggedIn: loggedIn });
    this.userName = loggedIn ? this.msalService.instance.getActiveAccount().username : '';
  }

  /**
   * Logs the user in to the system.
   * Called when the user clicks the login button.
   */
  public login() {
    if (this.msalGuardConfig.authRequest) {
      this.msalService.loginRedirect({ ...this.msalGuardConfig.authRequest } as RedirectRequest);
    } else {
      this.msalService.loginRedirect();
    }
  }
  // SEP2020
  toggleMenu() {
    this.isMenuOpen = !this.isMenuOpen;
    this.isMenu.emit({
      isMenu: this.isMenuOpen,
      userName: this.userName,
      menuLinks: this.menuLinks,
    });
  }
}
