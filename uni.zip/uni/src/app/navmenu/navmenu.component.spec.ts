import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs';

import { NavMenuComponent } from './navmenu.component';
import { PageLink } from './navmenu.types';
import { AuthenticationService } from '../authorization/authentication.service';
import { HttpService } from '../tools/services/http.service';
import { environment } from '../../environments/environment';
import { Permission } from '../tools/shared-types/permissions/permission';
import { AuthorizationService } from '../authorization/authorization.service';
import { ConfigService } from '../tools/services/config.service';
import { HttpClientModule } from '@angular/common/http';
import { FilterService } from '../tools/services/filter.service';
import { NotificationService } from '../tools/services/notification.service';
import { ToasterService } from 'angular2-toaster';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { MsalService, MSAL_INSTANCE, MSAL_GUARD_CONFIG } from '@azure/msal-angular';
import { IPublicClientApplication, PublicClientApplication } from '@azure/msal-browser';


function MSALInstanceFactory(): IPublicClientApplication {
  return new PublicClientApplication({
    auth: {
      clientId: '6226576d-37e9-49eb-b201-ec1eeb0029b6',
      redirectUri: 'http://localhost:4200'
    },
    system: {
     allowNativeBroker: false // Disables WAM Bridge
    }
  });
}
const applications = [
  { name: 'Test app 1', hostedUri: 'https://test.app.uri/1/' },
  { name: 'Test app 2', hostedUri: 'https://test.app.uri/2/' },
  { name: 'Test app 3', hostedUri: 'https://test.app.uri/3/' },
];

const pageLinks: PageLink[] = [{ name: 'Test App', hostedUri: 'https://test.app.uri/' }];
const userHasPermissionToViewPhraseLibrary: boolean = false;
const userHasPermissionToViewPhraseMatrix: boolean = false;
const userHasPermissionToViewGramWorkList: boolean = false;
const userHasPermissionToViewMarketWorkList: boolean = false;
const userHasPermission: boolean = false;
class AuthorizationServiceMock {
  userHasPermissionToViewPhraseLibrary() {
    return userHasPermissionToViewPhraseLibrary;
  }
  userHasPermissionToViewPhraseMatrix() {
    return userHasPermissionToViewPhraseMatrix;
  }
  userHasPermissionToViewGramWorkList() {
    return userHasPermissionToViewGramWorkList;
  }
  userHasPermissionToViewMarketWorkList() {
    return userHasPermissionToViewMarketWorkList;
  }
  checkUserHasAnyPermission(permissionsToCheck: Permission[]) {
    if (permissionsToCheck.some(p => p == Permission.AraPReFDCT_Phrases_Order)) {
      return userHasPermission;
    }
  }
}

class AuthenticationServiceMock {
  getLoggedInStatus() {
    return new Observable(observer => {
      observer.next(true);
      observer.complete();
    });
  }
  getUserProfile() {
    return Promise.resolve(true);
  }
  loadAccessibleApplications() {
    return Promise.resolve(pageLinks);
  }
  isLoggedIn() {
    return true;
  }
}

class MockMsalService {
  getCachedToken() { return 'token'; }
  acquireToken(clientId: string) {
    return new Observable(observer => {
      observer.next(`token: ${clientId}`);
      observer.complete();
    });
  }
  login() { return; }
  userInfo: { userName: 'Test User' };
}

class HttpServiceMock {
  getPromise(url: string) {
    return Promise.resolve();
  }
}

describe('NavMenuComponent', () => {
  let injector: TestBed;
  let httpService: HttpServiceMock;
  let component: NavMenuComponent;
  let fixture: ComponentFixture<NavMenuComponent>;
  let msalMock: MockMsalService;
  let authServiceMock: AuthenticationServiceMock;

  const providers: any[] = [];

  function setupTestBed(response) {
    providers.push(
      { provide: HttpService, useValue: { getWithBaseUrl: jest.fn(() => response), getHttpService: jest.fn(() => response) } });
    TestBed.configureTestingModule({
      providers: providers
    });
  }
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule,
        HttpClientModule],
      declarations: [NavMenuComponent],
      schemas: [
        NO_ERRORS_SCHEMA
      ],
      providers: [
        {
          provide: MSAL_GUARD_CONFIG,
      },
        ConfigService,
        {
          provide: MSAL_INSTANCE,
          useFactory: MSALInstanceFactory
        },
        { provide: ConfigService, useValue: { getAraDctUrl: jest.fn(() => 'TEST_URL') } },
        { provide: AuthenticationService, useClass: AuthenticationServiceMock },
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
        HttpService,
        {provide: MsalService, useClass: MockMsalService},
        FilterService,
        NotificationService,
        ToasterService
      ]
    })
      .compileComponents();
    injector = getTestBed();
    msalMock = injector.get(MsalService);
    httpService = injector.get(HttpService);
    msalMock.userInfo = { userName: 'Test User' };
    authServiceMock = injector.get(AuthenticationService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.uiVersion = 'testVersion';
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });

});
