import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-genaichatbot',
  templateUrl: './genaichatbot.component.html',
  styleUrls: ['./genaichatbot.component.css']
})
export class GenaichatbotComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
