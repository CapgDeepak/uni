import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GenaichatbotComponent } from './genaichatbot.component';

describe('GenaichatbotComponent', () => {
  let component: GenaichatbotComponent;
  let fixture: ComponentFixture<GenaichatbotComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GenaichatbotComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GenaichatbotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
