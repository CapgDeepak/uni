import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ModulePreloadingStrategy } from './tools/module-preloading-strategy';
import { AuthenticationGuardService } from './authorization/authentication-guard.service';
import { HomeComponent } from './home/home.component';
import { LoggedOutComponent } from './authorization/logged-out/logged-out.component';
import { PageNotFoundComponent } from './shared-components/page-not-found/page-not-found.component';
import { UnauthorizedComponent } from './authorization/unauthorized/unauthorized.component';
import { HelpSupportComponent } from './navmenu/help-support/help-support.component';
import { GenaichatbotComponent } from './GENAI/genaichatbot/genaichatbot.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    component: HomeComponent,
    canActivate: [AuthenticationGuardService]
  },
  {
    path: 'phrase-library',
    canActivate: [AuthenticationGuardService],
    loadChildren: './phrase-library/phrase-library.module#PhraseLibraryModule',
    data: {
      preload: false,
    }
  },
  {
    path: 'phrase-matrix',
    canActivate: [AuthenticationGuardService],
    loadChildren: './phrase-matrix/phrase-matrix.module#PhraseMatrixModule',
    data: {
      preload: false,
    }
  },
  {
    path: 'work-list',
    canActivate: [AuthenticationGuardService],
    loadChildren: './work-list/work-list.module#WorkListModule',
    data: {
      preload: false,
    }
  },
  {
    path: 'help-support',
    canActivate: [AuthenticationGuardService],
    // loadChildren: './work-list/work-list.module#WorkListModule',
    // data: {
    //   preload: false,
    // }
    component: HelpSupportComponent

  },
  {
    path: 'genaichatbot',        
    component: GenaichatbotComponent
  },
  
  {
    path: 'unauthorized/:isAuthenticated',
    component: UnauthorizedComponent
  },
  {
    path: 'logged-out',
    component: LoggedOutComponent
  },
  {
    path: '**',
    component: PageNotFoundComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      routes,
      { preloadingStrategy: ModulePreloadingStrategy }
    )
  ],
  exports: [
    RouterModule
  ],
  providers: [
    ModulePreloadingStrategy
  ]
})
export class AppRoutingModule { }
